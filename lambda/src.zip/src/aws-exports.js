const awsConfig = {
  aws_project_region: 'us-east-1',
  aws_cognito_region: 'us-east-1',
  aws_user_pools_id: process.env.REACT_APP_USER_POOL_ID,
  aws_user_pools_web_client_id: process.env.REACT_APP_APP_ID,
  authenticationFlowType: 'CUSTOM_AUTH',
  oauth: {},
};

export default awsConfig;
