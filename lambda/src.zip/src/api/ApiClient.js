/* eslint-disable class-methods-use-this */
import axios from 'axios';

class ApiClient {
  async get(url, config = {}) {
    const response = await axios.get(url, config);
    const { data: resData = {} } = response || {};
    return resData;
  }

  async post(url, data = {}, config = {}) {
    const response = await axios.post(url, data, config);
    const { data: resData = {} } = response || {};
    return resData;
  }

  async put(url, data = {}, config = {}) {
    const response = await axios.put(url, data, config);
    const { data: resData = {} } = response || {};
    return resData;
  }

  async delete(url, config = {}) {
    const response = await axios.delete(url, config);
    const { data: resData = {} } = response || {};
    return resData;
  }
}

export default new ApiClient();
