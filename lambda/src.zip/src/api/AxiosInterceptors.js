import axios from 'axios';
import { Auth } from 'aws-amplify';
import { v4 as uuidv4 } from 'uuid';

import { routePath } from 'routes';
import { loadSavanaTimerComponent } from 'store/actions';
import { checkAuthState, errorCodes } from 'utils';
import strings from 'localization/translation';

const { LOGIN } = routePath;

const createInterceptor = (store) => {
  /**
   * Axios Error Response Handler
   *
   * @param {object} response - axios error response object
   * TODO: error loger to be implemented in future
   */
  const axiosResponseErrorHandler = (error) => {
    const { response } = error;
    const { data } = response || {};
    const { status = {} } = data || {};
    if (Object.keys(status).length > 0) {
      // Savana Token Expiry
      if (status?.description?.includes('Invalid Customer Token')) {
        store.dispatch(loadSavanaTimerComponent());
      } else {
        // Any status codes that falls outside the range of 2xx cause this function to trigger
        // Do something with response error
        const customError = {
          code: status.code,
          message:
            status.description ||
            errorCodes[status.code] ||
            strings.systemError,
        };
        return Promise.reject(customError);
      }
    }
    return Promise.reject(new Error(strings.systemError));
  };

  /**
   * Axios Request Handler
   *
   * @param {object} request - axios request object
   */
  const axiosRequestHandler = async (request) => {
    const { isAuthenticated, user } = await checkAuthState();
    const newReqParams = { ...request };
    const isApiUrl = request.url.startsWith(process.env.REACT_APP_API_ENDPOINT);
    if (isAuthenticated && isApiUrl) {
      try {
        const session = await Auth.currentSession();
        const idToken = session.getIdToken().getJwtToken();
        newReqParams.headers = { ...request.headers };
        newReqParams.headers.authorization = idToken;
        newReqParams.headers.userid = user.username;
        newReqParams.headers.corelationid = uuidv4();
        newReqParams.headers = { ...newReqParams.headers, ...request.headers };
      } catch (err) {
        // Handling invalid session
        localStorage.clear();
        window.history.pushState({}, 'Sign In', LOGIN);
        window.location.reload();
      }
    }
    return newReqParams;
  };

  // Adding a response interceptors to track api error from default axios instance

  axios.interceptors.response.use((res) => res, axiosResponseErrorHandler);

  // Adding a request interceptors to track api requests from default axios instance
  axios.interceptors.request.use(axiosRequestHandler);

  const { create } = axios;

  // Adding a request and response interceptors to track api's from all newly created instances
  axios.create = (...args) => {
    const instance = create.apply(this, args);
    instance.interceptors.request.use(axiosRequestHandler);
    instance.interceptors.response.use((res) => res, axiosResponseErrorHandler);
    return instance;
  };
};

export default createInterceptor;
