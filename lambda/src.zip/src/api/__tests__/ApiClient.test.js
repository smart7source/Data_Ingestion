import axios from 'axios';
import ApiClient from '../ApiClient';

describe('test ApiClient method', () => {
  test('should call get method', () => {
    axios.get = jest.fn().mockResolvedValue({ data: 'success' });
    ApiClient.get('url');
    expect(axios.get).toHaveBeenCalledTimes(1);
  });

  test('should call post method', () => {
    axios.post = jest.fn().mockResolvedValue({ data: 'success' });
    ApiClient.post('url', { firstName: 'test' });
    expect(axios.post).toHaveBeenCalledTimes(1);
  });

  test('should test delete method', () => {
    axios.delete = jest.fn().mockResolvedValue({ data: 'success' });
    ApiClient.delete('url');
    expect(axios.delete).toHaveBeenCalledTimes(1);
  });

  test('should test put method', () => {
    axios.put = jest.fn().mockResolvedValue({ data: 'success' });
    ApiClient.put('url', { firstName: 'test' });
    expect(axios.put).toHaveBeenCalledTimes(1);
  });
});
