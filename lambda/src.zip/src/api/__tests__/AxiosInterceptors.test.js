import axios from 'axios';
import { rest } from 'msw';
import { Auth } from 'aws-amplify';

import awsConfigure from 'aws-exports';
import 'api/AxiosInterceptors';
import { cognitoUserMock, cognitoCurrentSessionMock } from 'testHelpers';
import server from 'apiMocks/server';

Auth.configure(awsConfigure);

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('test axios interceptors', () => {
  afterAll(() => {
    jest.clearAllMocks();
  });

  it('newly created instance also should get intercepted', async () => {
    server.use(
      rest.post(`${process.env.REACT_APP_API_ENDPOINT}url`, (req, res, ctx) => {
        return res.once(
          ctx.json({
            message: 'success',
          }),
        );
      }),
    );

    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    const instance = axios.create({
      baseURL: process.env.REACT_APP_API_ENDPOINT,
      headers: { 'X-Custom-Header': 'foobar' },
    });

    await instance.post(`${process.env.REACT_APP_API_ENDPOINT}url`, {
      foo: 'bar',
    });

    expect(instance.interceptors).toBeDefined();
  });

  it('axios network errors should be logged', async () => {
    server.use(
      rest.post(`${process.env.REACT_APP_API_ENDPOINT}url`, (req, res, ctx) => {
        return res.networkError('Network error');
      }),
    );

    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    const instance = axios.create({
      baseURL: process.env.REACT_APP_API_ENDPOINT,
      headers: { 'X-Custom-Header': 'foobar' },
    });

    let error;
    try {
      await instance.post(`${process.env.REACT_APP_API_ENDPOINT}url`, {
        foo: 'bar',
      });
    } catch (err) {
      error = err;
    }

    expect(error).toBeDefined();
  });
});
