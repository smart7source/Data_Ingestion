import { useRef, useState, useCallback, useEffect } from 'react';
import IdleTimer from 'react-idle-timer';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';

import { useFetchUser } from 'hooks';
import { handleLogout, millisToMinutesAndSeconds } from 'utils';
import { updateAuthenticatedStatus } from 'store/actions';

import strings from '../localization/translation';

import DialogBox from './UIElements/DialogBox/DialogBox';

const {
  sessionExpireTitle,
  sessionExpireMessage,
  logOff,
  continueSession,
  logOutIn,
} = strings;

const IdleTimerComponent = () => {
  const history = useHistory();
  const dispatch = useDispatch();

  const [Open, setOpen] = useState(false);
  const isHardLogout = useRef(false);
  const idleTimerRef = useRef(null);
  const sessionTimeoutRef = useRef(null);
  const timerRef = useRef(null);
  const [timeObj, setTimeObj] = useState({
    time: 120000,
    displayTime: '2:00',
  });

  const modalTimer = 120000; // 2mins
  const sessionTimer = 1080000; // 18mins //1200000

  const { isAuthenticated } = useFetchUser();

  const onLogout = useCallback(() => {
    clearTimeout(sessionTimeoutRef.current);
    setOpen(false);
    handleLogout({
      history,
      historyState: {
        isIdle: isHardLogout.current,
        message: [
          {
            message: strings?.autoSessionOutMsg,
            severity: 'info',
          },
        ],
      },
      onLogout: () => {
        dispatch(updateAuthenticatedStatus(false));
        dispatch({
          type: 'USER_LOGGED_OUT',
        });
      },
    });
  }, [dispatch, history]);

  const clearSession = useCallback(() => {
    isHardLogout.current = true;
    clearTimeout(sessionTimeoutRef.current);
    clearTimeout(timerRef.current);
    onLogout();
    setOpen(false);
  }, [onLogout]);

  const interValFun = useCallback(() => {
    if (timeObj?.time >= 0) {
      setTimeObj((c) => ({
        time: c.time - 1000,
        displayTime: millisToMinutesAndSeconds(c.time - 1000),
      }));
    } else {
      clearSession();
    }
  }, [clearSession, timeObj]);

  useEffect(() => {
    if (Open) {
      timerRef.current = setTimeout(interValFun, 1000);
    }
  }, [Open, interValFun]);

  const handleIdle = useCallback(() => {
    if (isAuthenticated) {
      setOpen(true);
      sessionTimeoutRef.current = setTimeout(() => {
        setTimeObj({ time: 0, displayTime: '0:00' });
        isHardLogout.current = true;
        onLogout();
      }, modalTimer);
    } else {
      clearSession();
    }
  }, [isAuthenticated, onLogout, clearSession]);

  const extendSession = useCallback(() => {
    clearTimeout(sessionTimeoutRef.current);
    clearTimeout(timerRef.current);
    setOpen(false);
  }, []);

  return (
    <>
      <DialogBox
        Open={Open}
        buttonTwoFn={extendSession}
        buttonOneFn={onLogout}
        buttonOne={logOff}
        buttonTwo={continueSession}
        title={sessionExpireTitle}
        message={sessionExpireMessage}
        timerMessage={logOutIn}
        timer={timeObj?.displayTime}
      />
      <IdleTimer
        ref={idleTimerRef}
        timeout={sessionTimer}
        onIdle={handleIdle}
      />
    </>
  );
};

export default IdleTimerComponent;
