import { act, fireEvent, render } from '@testing-library/react';
import { useForm } from 'react-hook-form';

import CustomInput from '../CustomInput';
import { primaryColor } from 'utils';

describe('render <CustomInput /> component', () => {
  const sampleComponentTestID = 'sample-component';

  const defaultProps = {
    type: 'text',
    id: 'Username',
    fullWidth: true,
    label: 'Username',
    error: false,
    errorText: '',
    margin: 'none',
    name: 'Username',
    defaultValue: 'Username',
    dataTestid: sampleComponentTestID,
  };

  beforeEach(() => render);

  const SampleComponent = (extraProps) => {
    const { control } = useForm();
    const currentProps = {
      ...defaultProps,
      ...extraProps,
      control,
    };

    return <CustomInput {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };
  it('should render custom input component', async () => {
    const screen = RenderAsync();

    expect(screen.getByTestId(sampleComponentTestID)).toBeInTheDocument();
  });

  it('should render component without  values for type text', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      defaultValue: '',
      helperText: 'field is mandatory',
    });

    expect(screen.getByTestId(sampleComponentTestID).value).toBe('');
    expect(screen.getByText('field is mandatory')).toHaveStyle(
      `color:${primaryColor}`,
    );
  });
  it('should render component without  values for type password', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      type: 'password',
      defaultValue: '',
      error: true,
      errorText: 'field is empty',
    });

    expect(screen.getByTestId(sampleComponentTestID).value).toBe('');
    expect(screen.getByText('field is empty')).toBeInTheDocument();
  });

  it('should render the component with the changed values', async () => {
    const screen = RenderAsync();
    fireEvent.change(screen.getByTestId(sampleComponentTestID), {
      target: { value: 'testuser' },
    });

    expect(screen.getByTestId(sampleComponentTestID).value).toStrictEqual(
      'testuser',
    );
  });
  it('should display error message if the field is not filled', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      error: true,
      errorText: 'Username is required',
    });
    expect(screen.getByText('Username is required')).toBeInTheDocument();
  });
  it('should render input box for password with eye icon', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      type: 'password',
      id: 'Password',
      label: 'Password',
      name: 'Password',
      defaultValue: 'Password',
    });
    expect(screen.getByTestId(sampleComponentTestID).value).toStrictEqual(
      'Password',
    );
    expect(
      screen.getByRole('button', { name: 'toggle password visibility' }),
    ).toBeInTheDocument();
  });
  it('should change type to text/password on click of eye icon', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      type: 'password',
      id: 'Password',
      label: 'Password',
      name: 'Password',
      defaultValue: 'Password',
    });
    await act(async () =>
      fireEvent.click(screen.getByTestId('Password-toggle')),
    );
    expect(screen.getByTestId(sampleComponentTestID).type).not.toBe('password');
    expect(screen.getByTestId(sampleComponentTestID).type).toStrictEqual(
      'text',
    );
    await act(async () =>
      fireEvent.click(screen.getByTestId('Password-toggle')),
    );
    expect(screen.getByTestId(sampleComponentTestID).type).not.toBe('text');
    expect(screen.getByTestId(sampleComponentTestID).type).toStrictEqual(
      'password',
    );
  });

  it('should change type to text/password on mouseleave of eye icon', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      type: 'password',
      id: 'Password',
      label: 'Password',
      name: 'Password',
      defaultValue: 'Password',
    });
    await act(async () =>
      fireEvent.click(screen.getByTestId('Password-toggle')),
    );
    expect(screen.getByTestId(sampleComponentTestID).type).not.toBe('password');
    expect(screen.getByTestId(sampleComponentTestID).type).toStrictEqual(
      'text',
    );
    await act(async () =>
      fireEvent.mouseLeave(screen.getByTestId('Password-toggle')),
    );
    expect(screen.getByTestId(sampleComponentTestID).type).not.toBe('text');
    expect(screen.getByTestId(sampleComponentTestID).type).toStrictEqual(
      'password',
    );
  });

  it('should change type to text/password on blur of eye icon', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      type: 'password',
      id: 'Password',
      label: 'Password',
      name: 'Password',
      defaultValue: 'Password',
    });
    await act(async () =>
      fireEvent.click(screen.getByTestId('Password-toggle')),
    );
    expect(screen.getByTestId(sampleComponentTestID).type).not.toBe('password');
    expect(screen.getByTestId(sampleComponentTestID).type).toStrictEqual(
      'text',
    );
    await act(async () =>
      fireEvent.blur(screen.getByTestId('Password-toggle')),
    );
    expect(screen.getByTestId(sampleComponentTestID).type).not.toBe('text');
    expect(screen.getByTestId(sampleComponentTestID).type).toStrictEqual(
      'password',
    );
  });
});
