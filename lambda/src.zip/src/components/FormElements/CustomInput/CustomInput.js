import {
  FormControl,
  FormHelperText,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Typography,
} from '@mui/material';
import { visuallyHidden } from '@mui/utils';
import { useState } from 'react';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';

import { ReactComponent as Eye } from 'assets/svg/eye.svg';
import { ReactComponent as EyeOff } from 'assets/svg/eye-off.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { primaryColor, getAriaDescribedBy } from 'utils';
import strings from 'localization/translation';

const { error: ERROR } = strings;

const CustomInput = (props) => {
  const {
    label,
    optionalLabel,
    classes,
    errorText,
    margin,
    dataTestid,
    placeholder,
    inputProps = {},
    control,
    defaultValue,
    helperText,
    rightHlprNode,
    ...rest
  } = props;

  const { error, id, type, name, fullWidth } = props;

  const [showPassword, setShowPassword] = useState(false);

  const toggleShowPassword = (event) => {
    event.preventDefault();
    setShowPassword((prevVal) => !prevVal);
  };

  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;

  const describedBy = getAriaDescribedBy({
    error: errorText,
    hint: helperText,
    errorId,
    hintId,
  });

  const helperTextNode = (
    <>
      {(errorText || Object.keys(rightHlprNode.props).length > 0) && (
        <FormHelperText id={errorId}>
          {errorText && (
            <>
              <span style={visuallyHidden}>{ERROR}</span>
              {errorText}
            </>
          )}
          {rightHlprNode}
        </FormHelperText>
      )}
      {helperText && (
        <Typography
          component="p"
          id={hintId}
          style={{ color: primaryColor }}
          variant="p2"
          mt="3px"
        >
          {helperText}
        </Typography>
      )}
    </>
  );

  const displayField = (field) => {
    if (type === 'password') {
      return (
        <FormControl fullWidth={fullWidth} margin={margin} error={error}>
          <OutlinedInput
            {...rest}
            {...field}
            value={field?.value || ''}
            type={showPassword ? 'text' : 'password'}
            autoComplete="off"
            className={classes}
            aria-describedby={describedBy}
            inputProps={{ 'data-testid': dataTestid, ...inputProps }}
            endAdornment={
              <InputAdornment position="end" disableTypography>
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={toggleShowPassword}
                  onMouseLeave={() => setShowPassword(false)}
                  onBlur={() => setShowPassword(false)}
                  data-testid={`${id}-toggle`}
                  size="large"
                >
                  {showPassword ? (
                    <CustomIcon
                      component={EyeOff}
                      inheritViewBox
                      color="grey.800"
                      sx={{ fontSize: '20px' }}
                    />
                  ) : (
                    <CustomIcon
                      component={Eye}
                      inheritViewBox
                      color="grey.800"
                      sx={{ fontSize: '20px' }}
                    />
                  )}
                </IconButton>
              </InputAdornment>
            }
          />
          {helperTextNode}
        </FormControl>
      );
    }

    return (
      <>
        <FormControl fullWidth={fullWidth} margin={margin} error={error}>
          <OutlinedInput
            {...rest}
            {...field}
            placeholder={placeholder}
            value={field?.value || ''}
            autoComplete="off"
            size="small"
            className={classes}
            aria-describedby={describedBy}
            inputProps={{ 'data-testid': dataTestid, ...inputProps }}
          />
          {helperTextNode}
        </FormControl>
      </>
    );
  };

  return (
    <>
      {label && (
        <InputLabel htmlFor={id}>
          {label}
          {optionalLabel && (
            <Typography
              component="span"
              variant="caption"
              position="absolute"
              right="0"
              bottom="0"
            >
              {optionalLabel}
            </Typography>
          )}
        </InputLabel>
      )}
      <Controller
        name={name}
        control={control}
        defaultValue={defaultValue}
        render={({ field }) => displayField(field)}
      />
    </>
  );
};

export default CustomInput;

CustomInput.propTypes = {
  name: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  type: PropTypes.string,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Object)]),
  error: PropTypes.bool,
  errorText: PropTypes.string,
  helperText: PropTypes.string,
  fullWidth: PropTypes.bool,
  classes: PropTypes.string,
  placeholder: PropTypes.string,
  margin: PropTypes.oneOf(['dense', 'none', 'normal']),
  dataTestid: PropTypes.string,
  defaultValue: PropTypes.string,
  control: PropTypes.instanceOf(Object).isRequired,
  inputProps: PropTypes.instanceOf(Object),
  readOnly: PropTypes.bool,
  rightHlprNode: PropTypes.node,
  optionalLabel: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
  ]),
};

CustomInput.defaultProps = {
  type: 'text',
  error: false,
  errorText: '',
  label: '',
  placeholder: '',
  helperText: '',
  fullWidth: true,
  classes: '',
  margin: 'dense',
  dataTestid: '',
  defaultValue: '',
  inputProps: {},
  readOnly: false,
  rightHlprNode: <></>,
  optionalLabel: '',
};
