import { fireEvent, render } from '@testing-library/react';
import { useForm } from 'react-hook-form';

import CustomTextArea from '../CustomTextArea';

describe('render <CustomTextArea /> component', () => {
  const defaultProps = {
    id: 'message',
    label: 'Message',
    error: false,
    errorText: '',
    margin: 'none',
    name: 'message',
    defaultValue: '',
  };

  beforeEach(() => render);

  const SampleComponent = (extraProps) => {
    const { control } = useForm();
    const currentProps = {
      ...defaultProps,
      ...extraProps,
      control,
    };

    return <CustomTextArea {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };
  it('should render custom textarea component', async () => {
    const screen = RenderAsync({});

    expect(screen.getByLabelText('Message')).toBeInTheDocument();
  });

  it('should render component without  values for type text', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      defaultValue: '',
      helperText: 'field is mandatory',
    });

    expect(screen.getByLabelText('Message').value).toBe('');
  });

  it('should render the component with the changed values', async () => {
    const screen = RenderAsync();
    fireEvent.change(screen.getByLabelText('Message'), {
      target: { value: 'testuser' },
    });

    expect(screen.getByLabelText('Message').value).toStrictEqual('testuser');
  });
  it('should display error message if the field is not filled', async () => {
    const screen = RenderAsync({
      ...defaultProps,
      error: true,
      errorText: 'Username is required',
    });
    expect(screen.getByText('Username is required')).toBeInTheDocument();
  });
});
