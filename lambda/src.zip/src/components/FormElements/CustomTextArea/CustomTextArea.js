import {
  FormControl,
  FormHelperText,
  InputLabel,
  TextareaAutosize,
  Typography,
} from '@mui/material';
import { visuallyHidden } from '@mui/utils';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';

import { primaryColor } from 'utils';
import strings from 'localization/translation';
import globalClasses from 'style/globalStyle.module.scss';

const { error: ERROR } = strings;

const CustomTextArea = (props) => {
  const {
    label,
    optionalLabel,
    classes,
    errorText,
    margin,
    dataTestid,
    control,
    defaultValue,
    helperText,
    minRows,
    maxRows,
    maxLength,
  } = props;

  const { error, id, name, fullWidth } = props;

  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;

  const helperTextNode = (
    <>
      {errorText && (
        <FormHelperText id={errorId}>
          <span style={visuallyHidden}>{ERROR}</span>
          {errorText}
        </FormHelperText>
      )}
      {helperText && (
        <FormHelperText id={hintId} style={{ color: primaryColor }}>
          {helperText}
        </FormHelperText>
      )}
    </>
  );

  const displayField = (field) => (
    <>
      <FormControl fullWidth={fullWidth} margin={margin} error={error}>
        <TextareaAutosize
          minRows={minRows}
          maxRows={maxRows}
          maxLength={maxLength}
          {...field}
          value={field?.value || ''}
          id={id}
          className={classes}
          data-testid={dataTestid}
        />
        {helperTextNode}
      </FormControl>
    </>
  );

  return (
    <>
      {label && (
        <InputLabel htmlFor={id}>
          {label}{' '}
          {optionalLabel && (
            <Typography
              component="span"
              variant="p2"
              className={globalClasses.optionalLabel}
            >
              {optionalLabel}
            </Typography>
          )}
        </InputLabel>
      )}
      <Controller
        name={name}
        control={control}
        defaultValue={defaultValue}
        render={({ field }) => displayField(field)}
      />
    </>
  );
};

export default CustomTextArea;

CustomTextArea.propTypes = {
  name: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  label: PropTypes.string,
  error: PropTypes.bool,
  errorText: PropTypes.string,
  helperText: PropTypes.string,
  fullWidth: PropTypes.bool,
  classes: PropTypes.string,
  margin: PropTypes.oneOf(['dense', 'none', 'normal']),
  dataTestid: PropTypes.string,
  defaultValue: PropTypes.string,
  control: PropTypes.instanceOf(Object).isRequired,
  inputProps: PropTypes.instanceOf(Object),
  optionalLabel: PropTypes.string,
  minRows: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  maxRows: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  maxLength: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

CustomTextArea.defaultProps = {
  error: false,
  errorText: '',
  label: '',
  helperText: '',
  fullWidth: true,
  classes: '',
  margin: 'dense',
  dataTestid: '',
  defaultValue: '',
  inputProps: {},
  optionalLabel: '',
  minRows: 5,
  maxRows: 6,
  maxLength: 150,
};
