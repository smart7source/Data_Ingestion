import {
  Checkbox,
  FormControl,
  FormControlLabel,
  FormHelperText,
  Typography,
} from '@mui/material';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';

const CustomCheckbox = (props) => {
  const {
    classes,
    errorText,
    control,
    error,
    defaultValue,
    margin,
    color,
    ...rest
  } = props;
  const { label, name, id } = props;
  const helperTextNode = error && <FormHelperText>{errorText}</FormHelperText>;
  const checkbox = (field) => (
    <Checkbox
      {...rest}
      {...field}
      checked={field.value}
      onChange={(e) => field.onChange(e.target.checked)}
      color={color}
      id={id}
    />
  );
  const displayField = (field) => {
    if (label) {
      const opts = { label };
      return (
        <FormControl error={error} margin={margin}>
          <FormControlLabel
            labelPlacement="end"
            htmlFor={id}
            className={classes}
            control={checkbox(field)}
            {...opts}
            label={<Typography variant="h3">{label}</Typography>}
          />
          {helperTextNode}
        </FormControl>
      );
    }
    return (
      <FormControl error={error} margin={margin}>
        {checkbox(field)}
        {helperTextNode}
      </FormControl>
    );
  };

  return (
    <Controller
      name={name}
      control={control}
      defaultValue={defaultValue}
      render={({ field }) => displayField(field)}
    />
  );
};

export default CustomCheckbox;

CustomCheckbox.propTypes = {
  name: PropTypes.string.isRequired,
  id: PropTypes.string,
  defaultValue: PropTypes.bool,
  color: PropTypes.string,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Object)]),
  error: PropTypes.bool,
  errorText: PropTypes.string,
  classes: PropTypes.string,
  margin: PropTypes.string,
  control: PropTypes.instanceOf(Object).isRequired,
};

CustomCheckbox.defaultProps = {
  id: '',
  defaultValue: false,
  color: 'primary',
  error: false,
  errorText: '',
  label: '',
  classes: '',
  margin: 'normal',
};
