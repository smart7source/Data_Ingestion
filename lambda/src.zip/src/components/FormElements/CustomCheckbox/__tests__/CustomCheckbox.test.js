import { fireEvent, render } from '@testing-library/react';
import CustomCheckbox from 'components/FormElements/CustomCheckbox/CustomCheckbox';
import { useForm } from 'react-hook-form';

describe('should render <CustomCheckbox /> component', () => {
  const defaultProps = {
    name: 'accept',
    id: 'accept',
    defaultValue: false,
    label: 'accept',
    error: false,
    errorText: '',
    margin: 'normal',
  };

  const SampleComponent = (props = defaultProps) => {
    const { control } = useForm();
    const currentProps = {
      ...props,
      control,
    };

    return <CustomCheckbox {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };

  it('should render checkbox', () => {
    const screen = RenderAsync();
    expect(
      screen.getByRole('checkbox', { name: 'accept' }),
    ).toBeInTheDocument();
  });
  it('should get enabled when checkbox is clicked', () => {
    const screen = RenderAsync();
    expect(screen.getByRole('checkbox')).not.toBeChecked();
    fireEvent.click(screen.getByRole('checkbox'));
    expect(screen.getByRole('checkbox')).toBeChecked();
  });
  it('should be enabled by default if defaultvalue passed is true', () => {
    const screen = RenderAsync({ ...defaultProps, defaultValue: true });
    expect(screen.getByRole('checkbox')).toBeChecked();
  });
  it('should render checkbox component with label if label prop is not empty', () => {
    const screen = RenderAsync();
    expect(screen.getByText('accept')).toBeInTheDocument();
  });
  it('should get checked on change', () => {
    const screen = RenderAsync({
      ...defaultProps,
      label: '',
      error: true,
      errorText: 'should be checked',
    });
    fireEvent.click(screen.getByRole('checkbox'));
    expect(screen.getByRole('checkbox')).toBeChecked();
    fireEvent.click(screen.getByRole('checkbox'));
    expect(screen.getByRole('checkbox')).not.toBeChecked();
    expect(screen.getByText('should be checked')).toBeInTheDocument();
  });
  it('should show error text incase of errors', () => {
    const screen = RenderAsync({
      ...defaultProps,
      error: true,
      errorText: 'should be checked',
    });
    expect(screen.getByText('should be checked')).toBeInTheDocument();
  });
  it('should show checkbox without label', () => {
    const screen = RenderAsync({ ...defaultProps, label: '' });
    expect(screen.queryByLabelText('accept')).not.toBeInTheDocument();
  });
});
