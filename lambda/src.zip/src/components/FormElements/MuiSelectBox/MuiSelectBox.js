import { InputLabel, MenuItem, TextField, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

import globalClasses from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

const MuiSelectBox = (props) => {
  const {
    label,
    classes,
    errorText,
    options,
    defaultValue,
    dataTestid,
    inputProps = {},
    hideSelect,
    defaultOption,
    defaultOptionValue,
    getOptionLabel,
    getOptionValue,
    optionalLabel,
    callback,
    value,
    ...rest
  } = props;

  const { id, name } = props;

  const displayField = () => (
    <TextField
      {...rest}
      value={value}
      id={id}
      name={name}
      autoComplete="off"
      variant="outlined"
      className={classes}
      helperText={errorText}
      select
      inputProps={{ 'data-testid': dataTestid, ...inputProps }}
      SelectProps={{
        displayEmpty: true,
        IconComponent: KeyboardArrowDownIcon,
        classes: {
          select: value !== '' ? '' : globalClasses.defaultSelectPlaceholder,
        },
      }}
      onChange={callback}
    >
      {!hideSelect && (
        <MenuItem
          className={globalClasses.selectMenuItem}
          value={defaultOptionValue}
        >
          {defaultOption}
        </MenuItem>
      )}
      {options.map((ele, index) => (
        <MenuItem
          className={globalClasses.selectMenuItem}
          value={getOptionValue ? getOptionValue(ele) : ele.value}
          key={index}
        >
          {getOptionLabel ? getOptionLabel(ele) : ele.name}
        </MenuItem>
      ))}
    </TextField>
  );

  return (
    <>
      {label && (
        <InputLabel htmlFor={id}>
          {label}
          {optionalLabel && (
            <Typography
              component="span"
              variant="p2"
              className={globalClasses.optionalLabel}
            >
              {optionalLabel}
            </Typography>
          )}
        </InputLabel>
      )}
      {displayField()}
    </>
  );
};

export default MuiSelectBox;

MuiSelectBox.propTypes = {
  id: PropTypes.string,
  fullWidth: PropTypes.bool,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Object)]),
  classes: PropTypes.string,
  error: PropTypes.bool,
  errorText: PropTypes.string,
  options: PropTypes.arrayOf(PropTypes.any),
  name: PropTypes.string,
  value: PropTypes.any,
  defaultValue: PropTypes.string,
  dataTestid: PropTypes.string,
  margin: PropTypes.string,
  hideSelect: PropTypes.bool,
  defaultOption: PropTypes.string,
  defaultOptionValue: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
  inputProps: PropTypes.instanceOf(Object),
  getOptionLabel: PropTypes.oneOfType([
    PropTypes.instanceOf(Object),
    PropTypes.func,
  ]),
  getOptionValue: PropTypes.oneOfType([
    PropTypes.instanceOf(Object),
    PropTypes.func,
  ]),
  optionalLabel: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
  ]),
  callback: PropTypes.func,
};
MuiSelectBox.defaultProps = {
  id: '',
  fullWidth: true,
  label: '',
  classes: '',
  error: false,
  errorText: '',
  options: [],
  dataTestid: '',
  name: '',
  defaultValue: '',
  margin: 'dense',
  hideSelect: false,
  defaultOptionValue: '',
  defaultOption: 'Select',
  disabled: false,
  size: 'small',
  inputProps: {},
  getOptionLabel: null,
  getOptionValue: null,
  optionalLabel: null,
  callback: defaultFnPropTypes,
  value: '',
};
