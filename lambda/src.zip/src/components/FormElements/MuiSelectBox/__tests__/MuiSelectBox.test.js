import { fireEvent, render } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import MuiSelectBox from '../MuiSelectBox';

describe('should render <CustomSelectBox /> component', () => {
  const selectList = [
    { value: 'one-time', name: 'One-Time' },
    { value: '1D', name: 'Daily' },
    { value: '7D', name: 'Weekly' },
  ];
  const selectTestId = 'select';
  const defaultProps = {
    label: 'Lable',
    id: 'sample',
    name: 'sample',
    options: selectList,
    error: false,
    errorText: '',
    dataTestid: selectTestId,
    hideSelect: false,
    inputProps: { 'data-testid': selectTestId },
  };

  const SampleComponent = (extraProps) => {
    const { control } = useForm();
    const currentProps = {
      ...defaultProps,
      ...extraProps,
      control,
    };

    return <MuiSelectBox {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };

  it('should render selectbox component', () => {
    const screen = RenderAsync();
    expect(screen.getByTestId('select')).toBeInTheDocument();
  });

  it('should change selected option from list', () => {
    const getoption = jest.fn().mockReturnValue('1D');
    const getvalue = jest.fn().mockReturnValue('1D');

    const screen = RenderAsync({
      getOptionLabel: getoption,
      getOptionValue: getvalue,
    });
    const selectbox = screen.getByTestId('select');
    fireEvent.change(screen.getByTestId('select'), {
      target: { name: 'Daily', value: '1D' },
    });
    expect(selectbox.name).toBe('Daily');
  });
  it('should change selected option from list', () => {
    const screen = RenderAsync();
    const selectbox = screen.getByTestId('select');
    fireEvent.change(screen.getByTestId('select'), {
      target: { name: 'Daily', value: '1D' },
    });
    expect(selectbox.name).toBe('Daily');
    // expect(selectbox.value).toBe('1D');
  });
});
