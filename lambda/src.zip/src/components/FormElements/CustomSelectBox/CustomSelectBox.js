import { InputLabel, MenuItem, TextField, Typography } from '@mui/material';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import globalClasses from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

const SelectIcon = () => (
  <>
    <CustomIcon
      component={ChevronDown}
      inheritViewBox
      color="grey.800"
      sx={{ fontSize: 11, position: 'absolute', inset: 'auto 10px auto auto' }}
    />
  </>
);

const CustomSelectBox = (props) => {
  const {
    label,
    classes,
    errorText,
    options,
    control,
    defaultValue,
    dataTestid,
    inputProps = {},
    hideSelect,
    defaultOption,
    defaultOptionValue,
    getOptionLabel,
    getOptionValue,
    optionalLabel,
    callback,
    placeHolderText,
    ...rest
  } = props;

  const { id, name } = props;

  const renderValue = (value) => value || placeHolderText;

  const displayField = (field) => (
    <TextField
      {...rest}
      {...field}
      value={field?.value || ''}
      autoComplete="off"
      variant="outlined"
      className={classes}
      helperText={errorText}
      select
      inputProps={{ 'data-testid': dataTestid, ...inputProps }}
      SelectProps={{
        displayEmpty: true,
        renderValue: placeHolderText ? renderValue : null,
        IconComponent: KeyboardArrowDownIcon,
        classes: {
          select:
            field.value !== '' ? '' : globalClasses.defaultSelectPlaceholder,
        },
      }}
      onChange={(e) => {
        field.onChange(e.target.value);
        if (callback) {
          callback(e.target.value);
        }
      }}
    >
      {!hideSelect && (
        <MenuItem
          className={globalClasses.selectMenuItem}
          value={defaultOptionValue}
        >
          {defaultOption}
        </MenuItem>
      )}
      {options.map((ele, index) => (
        <MenuItem
          className={globalClasses.selectMenuItem}
          value={getOptionValue ? getOptionValue(ele) : ele.value}
          key={index}
        >
          {getOptionLabel ? getOptionLabel(ele) : ele.name}
        </MenuItem>
      ))}
    </TextField>
  );

  return (
    <>
      {label && (
        <InputLabel htmlFor={id}>
          {label}
          {optionalLabel && (
            <Typography
              component="span"
              variant="p2"
              className={globalClasses.optionalLabel}
            >
              {optionalLabel}
            </Typography>
          )}
        </InputLabel>
      )}
      <Controller
        name={name}
        control={control}
        defaultValue={defaultValue}
        render={({ field }) => displayField(field)}
      />
    </>
  );
};

export default CustomSelectBox;

CustomSelectBox.propTypes = {
  id: PropTypes.string,
  fullWidth: PropTypes.bool,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Object)]),
  classes: PropTypes.string,
  error: PropTypes.bool,
  errorText: PropTypes.string,
  options: PropTypes.arrayOf(PropTypes.any),
  name: PropTypes.string,
  defaultValue: PropTypes.string,
  dataTestid: PropTypes.string,
  margin: PropTypes.string,
  hideSelect: PropTypes.bool,
  defaultOption: PropTypes.string,
  defaultOptionValue: PropTypes.string,
  disabled: PropTypes.bool,
  control: PropTypes.instanceOf(Object).isRequired,
  size: PropTypes.string,
  inputProps: PropTypes.instanceOf(Object),
  getOptionLabel: PropTypes.oneOfType([
    PropTypes.instanceOf(Object),
    PropTypes.func,
  ]),
  getOptionValue: PropTypes.oneOfType([
    PropTypes.instanceOf(Object),
    PropTypes.func,
  ]),
  optionalLabel: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
  ]),
  callback: PropTypes.func,
  placeHolderText: PropTypes.string,
};
CustomSelectBox.defaultProps = {
  id: '',
  fullWidth: true,
  label: '',
  classes: '',
  error: false,
  errorText: '',
  options: [],
  dataTestid: '',
  name: '',
  defaultValue: '',
  margin: 'dense',
  hideSelect: false,
  defaultOptionValue: '',
  defaultOption: 'Select',
  disabled: false,
  size: 'small',
  inputProps: {},
  getOptionLabel: null,
  getOptionValue: null,
  optionalLabel: null,
  placeHolderText: '',
  callback: defaultFnPropTypes,
};
