import { InputLabel, TextField } from '@mui/material';
import { DatePicker as DatePickerMUI, LocalizationProvider } from '@mui/lab';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';
import moment from 'moment';

import { ReactComponent as Calender } from 'assets/svg/calender.svg';
import {
  dateFormat,
  datePlaceholder,
  minDate,
  maxDate,
  defaultFnPropTypes,
  isValidDate,
} from 'utils';
import classess from 'style/globalStyle.module.scss';

const DatePicker = (props) => {
  const {
    id,
    label,
    optionalLabel,
    error,
    errorText,
    margin,
    dataTestid,
    inputProps,
    name,
    control,
    placeHolder,
    minDateValue,
    maxDateValue,
    shouldDisableDate,
    returnDateFormat,
    callback,
    classes,
    ...rest
  } = props;

  return (
    <>
      {label && (
        <InputLabel htmlFor={id}>
          {label}
          {optionalLabel && <>{optionalLabel}</>}
        </InputLabel>
      )}

      <Controller
        render={({ field }) => (
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DatePickerMUI
              {...field}
              {...rest}
              value={field.value || null}
              DialogProps={{ className: classess.datePicker }}
              inputFormat={dateFormat}
              minDate={minDateValue}
              maxDate={maxDateValue}
              allowSameDateSelection
              shouldDisableDate={shouldDisableDate}
              onChange={(value) => {
                if (isValidDate(value, false)) {
                  returnDateFormat
                    ? field.onChange(
                        moment(new Date(value)).format(returnDateFormat),
                      )
                    : field?.onChange?.(value);
                  if (callback) {
                    callback(value);
                  }
                } else {
                  field?.onChange?.(value);
                }
              }}
              components={{
                OpenPickerIcon: Calender,
              }}
              renderInput={(textProps) => (
                <TextField
                  {...textProps}
                  className={classes}
                  margin={margin}
                  id={id}
                  fullWidth
                  error={error}
                  helperText={errorText}
                  inputProps={{
                    ...textProps.inputProps,
                    ...inputProps,
                    'data-testid': dataTestid,
                    placeholder: placeHolder,
                  }}
                  onBlur={(e) => {
                    if (isValidDate(e.target.value, true)) {
                      e.target.value = new Date(
                        e.target.value,
                      ).toLocaleDateString('en', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                      });
                      textProps?.inputProps?.onChange?.(e);
                    }
                    textProps?.inputProps?.onBlur?.(e);
                  }}
                />
              )}
            />
          </LocalizationProvider>
        )}
        name={name}
        control={control}
      />
    </>
  );
};

export default DatePicker;

DatePicker.propTypes = {
  id: PropTypes.string,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Object)]),
  optionalLabel: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
  ]),
  error: PropTypes.bool,
  errorText: PropTypes.string,
  margin: PropTypes.string,
  dataTestid: PropTypes.string,
  name: PropTypes.string,
  placeHolder: PropTypes.string,
  control: PropTypes.instanceOf(Object).isRequired,
  minDateValue: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
  ]),
  maxDateValue: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
  ]),
  shouldDisableDate: PropTypes.oneOfType([PropTypes.bool, PropTypes.func]),
  inputProps: PropTypes.instanceOf(Object),
  returnDateFormat: PropTypes.string,
  callback: PropTypes.func,
  classes: PropTypes.string,
};
DatePicker.defaultProps = {
  id: '',
  label: '',
  optionalLabel: '',
  error: false,
  errorText: '',
  margin: 'dense',
  dataTestid: '',
  name: '',
  placeHolder: datePlaceholder,
  minDateValue: new Date(minDate),
  maxDateValue: new Date(maxDate),
  shouldDisableDate: defaultFnPropTypes,
  inputProps: {},
  returnDateFormat: '',
  callback: defaultFnPropTypes,
  classes: '',
};
