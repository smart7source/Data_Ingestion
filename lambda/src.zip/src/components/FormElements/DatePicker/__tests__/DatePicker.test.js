import { fireEvent, render } from '@testing-library/react';
import DatePicker from 'components/FormElements/DatePicker/DatePicker';
import { useForm } from 'react-hook-form';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import { dateFormat, datePlaceholder, minDate } from 'utils';
import userEvent from '@testing-library/user-event';

describe('should render <DatePicker /> component', () => {
  const selectTestId = 'date-picker';
  const defaultProps = {
    id: 'sampledate',
    label: 'Date-selector',
    error: false,
    errorText: '',
    dataTestid: selectTestId,
    name: 'sampledate',
    disableFuture: true,
    disablePast: false,
    placeHolder: datePlaceholder,
    minDateValue: minDate,
    maxDateValue: Date(dateFormat),
  };

  const SampleComponent = (props = defaultProps) => {
    const { control } = useForm();
    const currentProps = {
      ...props,
      control,
    };

    return <DatePicker {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };

  it('should render datepicker', () => {
    const screen = RenderAsync();
    expect(screen.getByTestId(selectTestId)).toBeInTheDocument();
  });
  it('should render datepicker with label', () => {
    const screen = RenderAsync();
    expect(screen.getByLabelText('Date-selector')).toBeInTheDocument();
  });

  it('should render error if error prop is true', () => {
    const screen = RenderAsync({
      ...defaultProps,
      error: true,
      errorText: 'render error',
    });
    expect(screen.getByText('render error')).toBeInTheDocument();
  });
});
