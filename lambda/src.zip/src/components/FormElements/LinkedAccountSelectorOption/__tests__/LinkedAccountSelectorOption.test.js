import { render, screen } from '@testing-library/react';

import LinkedAccountSelectorOption from '../LinkedAccountSelectorOption';

describe('Testing <LinkedAccountSelectorOption /> component', () => {
  it('should render props into component', async () => {
    const props = {
      name: 'selector option',
      amount: 200,
    };
    render(<LinkedAccountSelectorOption {...props} />);
    expect(screen.getByText(/selector option/i)).toBeInTheDocument();
    expect(screen.getByText(/200/i)).toBeInTheDocument();
  });
});
