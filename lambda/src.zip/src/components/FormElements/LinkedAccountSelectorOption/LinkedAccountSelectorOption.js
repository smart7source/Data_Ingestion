import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';
import { memo } from 'react';

import strings from 'localization/translation';

import classes from '../../../containers/OneAccount/OneAccount.module.scss';

const { balance: BALANCE } = strings;

const LinkedAccountSelectorOption = (props) => {
  const { imgSrc, alt, name, amount, balanceProps } = props;
  const { className = '', amountVariant = 'p2' } = balanceProps;
  return (
    <Box className={classes.linkedAccountSelectorMenuOption}>
      <img
        width="25px"
        height="25px"
        style={{ alignSelf: 'center' }}
        src={imgSrc}
        alt={alt}
      />
      <Box className={classes.linkedAccountSelectorMenuOptionValue}>
        <Typography variant="p1" color="#464646">
          {name}
        </Typography>
        {!!amount && (
          <Box
            display="flex"
            alignItems="center"
            gap="3px"
            className={className}
          >
            <Typography
              component="span"
              variant="p2"
              className={classes.linkedAccountSelectorBalanceText}
              color="grey.600"
            >
              {`${BALANCE}:`}
            </Typography>
            <Typography
              component="span"
              variant={amountVariant}
              className={classes.linkedAccountSelectorBalance}
            >
              <NumberFormat
                value={amount}
                displayType="text"
                thousandSeparator
                prefix="$ "
                decimalScale="2"
                fixedDecimalScale
              />
            </Typography>
          </Box>
        )}
      </Box>
    </Box>
  );
};

LinkedAccountSelectorOption.propTypes = {
  imgSrc: PropTypes.string,
  alt: PropTypes.string,
  name: PropTypes.string,
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  balanceProps: PropTypes.instanceOf(Object),
};

LinkedAccountSelectorOption.defaultProps = {
  imgSrc: '',
  alt: '',
  name: '',
  amount: '',
  balanceProps: {},
};

export default memo(LinkedAccountSelectorOption);
