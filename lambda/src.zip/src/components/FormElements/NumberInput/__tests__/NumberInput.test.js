import React from 'react';
import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useForm } from 'react-hook-form';
import NumberInput from '../NumberInput';

describe('render NumberInput component', () => {
  const defaultProps = {
    id: '',
    label: '',
    fullWidth: true,
    error: false,
    errorText: '',
    name: 'NumberInputComponent',
    defaultValue: '',
    prefix: '',
    suffix: '',
    allowNegative: false,
    decimalScale: 2,
  };

  const SampleComponent = (props = defaultProps) => {
    const { control } = useForm();
    const currentProps = {
      ...props,
      control,
    };
    return <NumberInput {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };

  it('should render the component with the default props ', async () => {
    const { screen } = await RenderAsync();
    expect(screen).toMatchSnapshot();
  });

  it('render with Label Props', async () => {
    const labelProps = {
      ...defaultProps,
      label: 'Number Input Label',
      id: 'numberId',
    };
    const { getByLabelText } = await RenderAsync(labelProps);
    expect(getByLabelText('Number Input Label')).toBeInTheDocument();
  });

  it('render with Defined Error Props', async () => {
    const definedProps = {
      ...defaultProps,
      error: true,
      errorText: 'Number Input Error Text',
    };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText('Number Input Error Text')).toBeInTheDocument();
  });

  it('render with Defined Function Props', async () => {
    const mockfn = jest.fn();
    const definedProps = {
      ...defaultProps,
      inputProps: { value: 100, onChange: mockfn },
      dataTestId: 'test-id',
      prefix: '$',
    };
    const { getByTestId } = await RenderAsync(definedProps);
    expect(getByTestId('test-id').value).toEqual('100');
    await userEvent.type(getByTestId('test-id'), '300');
    expect(mockfn).toHaveBeenCalled();
  });
});
