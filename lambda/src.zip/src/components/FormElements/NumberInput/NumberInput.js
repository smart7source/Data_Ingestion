import { FormControl, InputLabel, TextField } from '@mui/material';
import NumberFormat from 'react-number-format';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';

const NumberInput = (props) => {
  const {
    id,
    label,
    fullWidth,
    error,
    errorText,
    name,
    placeHolder = '',
    control,
    defaultValue,
    inputProps,
    dataTestId,
    prefix,
    suffix,
    disabled = false,
    allowNegative = false,
    decimalScale = 2,
    isAllowed,
    thousandSeparator,
    margin = 'dense',
    fixedDecimalScale,
    allowLeadingZeros,
    ...rest
  } = props;

  return (
    <>
      {label && <InputLabel htmlFor={id}>{label}</InputLabel>}
      <FormControl margin={margin} fullWidth={fullWidth}>
        <Controller
          render={({ field }) => (
            <NumberFormat
              {...rest}
              {...field}
              id={id}
              prefix={prefix}
              disabled={disabled}
              suffix={suffix}
              placeholder={placeHolder}
              thousandSeparator={thousandSeparator}
              allowNegative={allowNegative}
              decimalScale={decimalScale}
              defaultValue={defaultValue}
              customInput={TextField}
              variant="outlined"
              size="small"
              error={error}
              helperText={errorText}
              inputProps={{
                'data-testid': dataTestId,
                ...inputProps,
              }}
              isAllowed={isAllowed}
              fixedDecimalScale={fixedDecimalScale}
              allowLeadingZeros={allowLeadingZeros}
            />
          )}
          control={control}
          name={name}
        />
      </FormControl>
    </>
  );
};

export default NumberInput;

NumberInput.propTypes = {
  id: PropTypes.string,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Object)]),
  fullWidth: PropTypes.bool,
  error: PropTypes.bool,
  errorText: PropTypes.string,
  name: PropTypes.string,
  defaultValue: PropTypes.string,
  prefix: PropTypes.string,
  placeHolder: PropTypes.string,
  suffix: PropTypes.string,
  disabled: PropTypes.bool,
  allowNegative: PropTypes.bool,
  decimalScale: PropTypes.number,
  control: PropTypes.instanceOf(Object).isRequired,
  isAllowed: PropTypes.func,
  thousandSeparator: PropTypes.bool,
  margin: PropTypes.string,
  inputProps: PropTypes.instanceOf(Object),
  dataTestId: PropTypes.string,
  fixedDecimalScale: PropTypes.bool,
  allowLeadingZeros: PropTypes.bool,
};

NumberInput.defaultProps = {
  id: '',
  label: '',
  fullWidth: true,
  error: false,
  errorText: '',
  placeHolder: '',
  name: '',
  disabled: false,
  defaultValue: '',
  prefix: '',
  suffix: '',
  allowNegative: false,
  decimalScale: 2,
  isAllowed: () => true,
  thousandSeparator: true,
  margin: 'dense',
  inputProps: {},
  dataTestId: '',
  fixedDecimalScale: false,
  allowLeadingZeros: false,
};
