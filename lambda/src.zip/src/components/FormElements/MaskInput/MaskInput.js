import { FormControl, InputLabel, TextField } from '@mui/material';
import { Controller } from 'react-hook-form';
import InputMask from 'react-input-mask';
import PropTypes from 'prop-types';

import { beforeMaskedValueChange } from 'utils';

const MaskInput = (props) => {
  const {
    label,
    errorText,
    dataTestid,
    inputProps,
    control,
    defaultValue,
    mask,
    maskChar,
    isZipCode = false,
    alwaysShowMask = false,
    disabled = false,
    margin,
    outputMasked,
    withoutCntryCode,
    ...rest
  } = props;

  const { id, fullWidth, name } = props;

  return (
    <>
      {label && <InputLabel htmlFor={id}>{label}</InputLabel>}
      <FormControl margin={margin} fullWidth={fullWidth}>
        <Controller
          defaultValue={defaultValue}
          render={({ field }) => {
            const opts = {};
            if (isZipCode) {
              opts.beforeMaskedValueChange = beforeMaskedValueChange;
            }
            return (
              <InputMask
                {...rest}
                {...field}
                mask={mask}
                maskChar={maskChar}
                alwaysShowMask={alwaysShowMask}
                {...opts}
                onChange={(e) => {
                  let { value } = e.target;
                  if (!outputMasked) {
                    value = value.replace(/[^\d]/g, '');
                    if (withoutCntryCode) {
                      value = value.slice(1);
                    }
                  }
                  field.onChange(value);
                }}
                disabled={disabled}
              >
                {(inputPropsValue) => (
                  <TextField
                    {...rest}
                    {...inputPropsValue}
                    autoComplete="off"
                    variant="outlined"
                    size="small"
                    helperText={errorText}
                    margin="none"
                    inputProps={{ 'data-testid': dataTestid, ...inputProps }}
                    disabled={disabled}
                  />
                )}
              </InputMask>
            );
          }}
          control={control}
          name={name}
        />
      </FormControl>
    </>
  );
};

export default MaskInput;

MaskInput.propTypes = {
  id: PropTypes.string,
  fullWidth: PropTypes.bool,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Object)]),
  error: PropTypes.bool,
  errorText: PropTypes.string,
  margin: PropTypes.string,
  dataTestid: PropTypes.string,
  name: PropTypes.string,
  defaultValue: PropTypes.string,
  mask: PropTypes.string,
  maskChar: PropTypes.string,
  isZipCode: PropTypes.bool,
  alwaysShowMask: PropTypes.bool,
  control: PropTypes.instanceOf(Object).isRequired,
  disabled: PropTypes.bool,
  inputProps: PropTypes.instanceOf(Object),
  outputMasked: PropTypes.bool,
  withoutCntryCode: PropTypes.bool,
};

MaskInput.defaultProps = {
  id: '',
  fullWidth: true,
  label: '',
  error: false,
  errorText: '',
  margin: 'dense',
  dataTestid: '',
  name: '',
  defaultValue: '',
  mask: '+1-999-999-9999',
  maskChar: '',
  isZipCode: false,
  alwaysShowMask: false,
  disabled: false,
  inputProps: {},
  outputMasked: false,
  withoutCntryCode: false,
};
