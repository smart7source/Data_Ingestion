import React from 'react';
import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useForm } from 'react-hook-form';
import MaskInput from '../MaskInput';

describe('render MaskInput component', () => {
  const defaultProps = {
    type: 'text',
    id: '',
    fullWidth: true,
    label: '',
    error: false,
    errorText: '',
    margin: 'dense',
    dataTestid: '',
    name: 'MaskInputSample',
    defaultValue: '',
    mask: '',
    maskChar: '',
    isZipCode: false,
    alwaysShowMask: false,
  };

  const SampleComponent = (props = defaultProps) => {
    const { control } = useForm();
    const currentProps = {
      ...props,
      control,
    };
    return <MaskInput {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };

  it('should render the component with the default props ', async () => {
    const { screen } = await RenderAsync();
    expect(screen).toMatchSnapshot();
  });

  it('render with Label Props', async () => {
    const labelProps = {
      ...defaultProps,
      label: 'Mask Input Label',
      id: 'maskId',
    };
    const { getByLabelText } = await RenderAsync(labelProps);
    expect(getByLabelText('Mask Input Label')).toBeInTheDocument();
  });

  it('render with Defined Error Props', async () => {
    const definedProps = {
      ...defaultProps,
      error: true,
      errorText: 'Mask Input Error Text',
    };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText('Mask Input Error Text')).toBeInTheDocument();
  });

  it('render with Custom Props', async () => {
    const definedProps = {
      ...defaultProps,
      inputProps: { value: '123-123-123d' },
      dataTestid: 'test-id',
    };
    const { getByTestId } = await RenderAsync(definedProps);
    expect(getByTestId('test-id').value).toEqual('123-123-123d');
  });

  it('render with Defined Function Props', async () => {
    const mockfn = jest.fn();
    const definedProps = {
      ...defaultProps,
      isZipCode: true,
      inputProps: { onChange: mockfn },
      dataTestid: 'test-id',
    };
    const { getByRole } = await RenderAsync(definedProps);
    userEvent.type(getByRole('textbox'), '123-123-XXX');
    expect(mockfn).toHaveBeenCalled();
    expect(getByRole('textbox')).toHaveValue('123-123-XXX');
  });

  it('render with Function Props', async () => {
    const mockfn = jest.fn();
    const definedProps = {
      ...defaultProps,
      isZipCode: true,
      inputProps: { onChange: mockfn },
      dataTestid: 'test-id',
      mask: '99/99/9999',
      maskChar: 'X',
    };
    const { getByRole } = await RenderAsync(definedProps);
    userEvent.type(getByRole('textbox'), '1233456D');
    expect(getByRole('textbox')).toHaveValue('XX/XX/XXXX');
  });
});
