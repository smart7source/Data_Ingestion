import {
  InputLabel,
  Select,
  FormControl,
  MenuItem,
  FormHelperText,
  Typography,
} from '@mui/material';
import PropTypes from 'prop-types';
import { Controller } from 'react-hook-form';
import { memo } from 'react';

import strings from 'localization/translation';
import { maskAccountNumber, getAccountName } from 'utils';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';
import serviceUrl from 'api/UrlHelper';

import classes from '../../../containers/OneAccount/OneAccount.module.scss';
import LinkedAccountSelectorOption from '../LinkedAccountSelectorOption';

const { selectBankAccount: SELECT_BANK_ACCOUNT } = strings;

const LinkedAccountSimpleSelector = (props) => {
  const {
    label,
    bankAccounts,
    control,
    name,
    hideSelect,
    defaultOption,
    defaultOptionValue,
    mmFlag,
    error,
    errorText,
    dataTestid,
    ...rest
  } = props;
  return (
    <>
      <InputLabel id="lined-account-selector-label">
        <Typography component="span" variant="h3">
          {label || SELECT_BANK_ACCOUNT}
        </Typography>
      </InputLabel>
      <Controller
        control={control}
        name={name}
        render={({ field }) => (
          <FormControl
            className={classes.dropDownSelectorFormControl}
            error={error}
          >
            <Select
              {...rest}
              {...field}
              className={classes.linkedAccountSelectorSelect}
              defaultValue={1}
              id="lined-account-selector"
              labelId="lined-account-selector-label"
              IconComponent={ChevronDown}
              displayEmpty
              inputProps={{ 'data-testid': dataTestid }}
            >
              {!hideSelect && (
                <MenuItem value={defaultOptionValue}>{defaultOption}</MenuItem>
              )}
              {bankAccounts.map((eachItem, index) => {
                const {
                  instId = 'chaseplus',
                  logoFormat = 'png',
                  bankNm,
                  accNickName,
                  accNm,
                  accNbr,
                  posnId,
                  institutionId = 'chaseplus',
                } = eachItem;

                const bankName = getAccountName({ bankNm, accNickName, accNm });

                const maskLastFourDigitAccNbr = maskAccountNumber(accNbr);
                const nameAndNumber = `${bankName} ${maskLastFourDigitAccNbr}`;
                const selectedValue = mmFlag ? posnId : accNbr;

                return (
                  <MenuItem key={index} value={selectedValue}>
                    <LinkedAccountSelectorOption
                      imgSrc={`${serviceUrl.externalBankImagesPath}${
                        !mmFlag ? instId : institutionId
                      }.${logoFormat}`}
                      alt=""
                      name={nameAndNumber}
                    />
                  </MenuItem>
                );
              })}
            </Select>
            <FormHelperText>{errorText}</FormHelperText>
          </FormControl>
        )}
      />
    </>
  );
};

export default memo(LinkedAccountSimpleSelector);

LinkedAccountSimpleSelector.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  name: PropTypes.string.isRequired,
  bankAccounts: PropTypes.instanceOf(Object),
  label: PropTypes.string,
  hideSelect: PropTypes.bool,
  defaultOption: PropTypes.string,
  defaultOptionValue: PropTypes.string,
  mmFlag: PropTypes.bool,
  error: PropTypes.bool,
  errorText: PropTypes.string,
  disabled: PropTypes.bool,
  dataTestid: PropTypes.string,
};

LinkedAccountSimpleSelector.defaultProps = {
  bankAccounts: [],
  label: '',
  hideSelect: false,
  defaultOptionValue: '',
  defaultOption: 'Select',
  mmFlag: false,
  error: false,
  errorText: '',
  disabled: false,
  dataTestid: '',
};
