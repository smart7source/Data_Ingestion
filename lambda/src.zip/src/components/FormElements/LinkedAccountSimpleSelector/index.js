export { default } from './LinkedAccountSimpleSelector';
