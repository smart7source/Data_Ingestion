import {
  FormControl,
  FormHelperText,
  InputAdornment,
  InputLabel,
  OutlinedInput,
} from '@mui/material';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';

const PercentageInput = (props) => {
  const {
    errorText,
    inputProps,
    control,
    defaultValue,
    label,
    margin,
    ...rest
  } = props;

  const { id, error, fullWidth, name } = props;

  return (
    <>
      {label && <InputLabel htmlFor={id}>{label}</InputLabel>}

      <Controller
        defaultValue={defaultValue}
        render={({ field }) => (
          <FormControl error={error} margin={margin} fullWidth={fullWidth}>
            <OutlinedInput
              {...rest}
              {...field}
              type="number"
              inputProps={{
                min: 0,
                max: 100,
                ...inputProps,
              }}
              endAdornment={
                <InputAdornment
                  position="end"
                  component="div"
                  disableTypography
                >
                  %
                </InputAdornment>
              }
            />
            {error && <FormHelperText>{errorText}</FormHelperText>}
          </FormControl>
        )}
        name={name}
        control={control}
      />
    </>
  );
};

export default PercentageInput;

PercentageInput.propTypes = {
  id: PropTypes.string,
  label: PropTypes.string,
  error: PropTypes.bool,
  errorText: PropTypes.string,
  margin: PropTypes.string,
  name: PropTypes.string,
  disabled: PropTypes.bool,
  defaultValue: PropTypes.string,
  control: PropTypes.instanceOf(Object).isRequired,
  inputProps: PropTypes.instanceOf(Object),
  fullWidth: PropTypes.bool,
};

PercentageInput.defaultProps = {
  id: '',
  label: '',
  error: false,
  errorText: '',
  margin: 'dense',
  name: '',
  disabled: true,
  defaultValue: '',
  inputProps: {},
  fullWidth: true,
};
