import React from 'react';
import { render } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import PercentageInput from '../PercentageInput';

describe('render PercentageInput component', () => {
  const defaultProps = {
    id: 'amount1',
    label: 'Amount Label',
    error: false,
    errorText: '',
    margin: 'dense',
    name: 'name',
    disabled: true,
    defaultValue: '',
  };

  const SampleComponent = (props = defaultProps) => {
    const { control } = useForm();
    const currentProps = {
      ...props,
      control,
    };
    return <PercentageInput {...currentProps} />;
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<SampleComponent {...props} />);
  };

  it('should render the component with the default props ', async () => {
    const { screen } = RenderAsync();
    expect(screen).toMatchSnapshot();
  });

  it('render with Default Props', async () => {
    const { getByLabelText } = RenderAsync();
    expect(getByLabelText('Amount Label')).toBeInTheDocument();
  });

  it('render with Defined Error Props', async () => {
    const definedProps = {
      ...defaultProps,
      error: true,
      errorText: 'Error Text',
    };
    const { getByText } = RenderAsync(definedProps);
    expect(getByText('Error Text')).toBeInTheDocument();
  });

  it('render with Defined Props', async () => {
    const definedProps = {
      ...defaultProps,
      inputProps: { value: 100, 'data-testid': 'test-id' },
      disabled: false,
    };
    const { getByTestId } = RenderAsync(definedProps);
    expect(getByTestId('test-id').value).toEqual('100');
    expect(getByTestId('test-id').getAttribute('disabled')).toBeFalsy();
  });

  it('render with Defined Props', async () => {
    const definedProps = {
      name: 'name2',
      label: 'Amount Label',
      disabled: true,
      error: false,
      errorText: '',
      id: 'name2',
      label: '',
      margin: 'normal',
      defaultValue: '500',
    };
    const { getByRole } = RenderAsync(definedProps);
    expect(getByRole('spinbutton').getAttribute('value')).toBe('500');
  });

  it('render with default proptypes props', async () => {
    const definedProps = {
      name: 'name2',
      label: 'Amount Label',
      disabled: true,
      error: false,
      id: 'name2',
      label: '',
      margin: 'normal',
    };
    const { getByLabelText } = RenderAsync(definedProps);
  });
});
