import { screen, render } from '@testing-library/react';

import ErrorHelper from '../UIElements/ErrorHelper';

describe('ErrorHelper renders correctly', () => {
  it('renders the component correctly without password', () => {
    render(<ErrorHelper value="" />);
    expect(screen.getByText(/8-16 characters/i)).toBeInTheDocument();
    expect(screen.getByText(/Numbers/i)).toBeInTheDocument();
    expect(
      screen.getByText(/Capital and lower case letters/i),
    ).toBeInTheDocument();
    expect(screen.getByText(/Special characters/i)).toBeInTheDocument();
  });

  it('renders the helper text with incorrect class', () => {
    render(<ErrorHelper value="Qwerty12345$" />);
    expect(screen.getByText(/8-16 characters/i)).toBeInTheDocument();
    expect(screen.getByText(/Numbers/i)).toBeInTheDocument();
    expect(
      screen.getByText(/Capital and lower case letters/i),
    ).toBeInTheDocument();
    expect(screen.getByText(/Special characters/i)).toBeInTheDocument();
  });
});
