import { render, screen, fireEvent, act } from '@testing-library/react';

import GetStartedDialog from '../GetStartedDialog';

describe('render <GetStartedDialog /> component', () => {
  it('should render heading', () => {
    const props = {
      open: true,
      handleClose: jest.fn(),
      handleGetStarted: jest.fn(),
    };
    render(<GetStartedDialog {...props} />);
    expect(
      screen.getByText(/You Can Finally Get Back to Business/i),
    ).toBeInTheDocument();
  });
});
