import { useEffect, useState, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { Box, Grid, IconButton, Paper } from '@mui/material';
import { useHistory, useLocation } from 'react-router-dom';
import PropTypes from 'prop-types';

import { ReactComponent as Sync } from 'assets/svg/sync.svg';
import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle-2.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as ArrowCircleRight } from 'assets/svg/arrow-circle-right.svg';
import { routePath } from 'routes';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import { setLoader } from 'store/actions';
import { defaultFnPropTypes } from 'utils';

const { onlyOneSoft, softNotAvail } = strings;
const { getCodatSoftwaresApi, linkIndSoftApi } = serviceUrl;
const LinkCodatSoftware = ({ onError }) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [softwares, setSoftwares] = useState([]);
  const query = new URLSearchParams(useLocation().search);

  const updateSoftwares = useCallback((softParams, linkedSoftParam) => {
    if (linkedSoftParam?.length > 0) {
      const [firstObj] = linkedSoftParam;
      const cloneResults = softParams.map((ele) => {
        if (ele.integrationId === firstObj.integrationID) {
          return {
            ...ele,
            integrationStatus: firstObj.integrationStatus,
            codatLinkUrl: firstObj.codatLinkUrl,
          };
        }
        return ele;
      });
      setSoftwares(cloneResults);
    } else {
      setSoftwares(softParams);
    }
  }, []);

  const putSoftwares = useCallback(
    async (sftData, data) => {
      try {
        dispatch(setLoader(true));
        const response = await ApiClient.put(linkIndSoftApi, data);
        const {
          body: { CDT_LINK = [] },
        } = response;
        updateSoftwares(sftData, CDT_LINK);
      } catch (e) {
        onError(e);
      } finally {
        dispatch(setLoader(false));
      }
    },
    [dispatch, onError, updateSoftwares],
  );

  const getSoftwares = async () => {
    try {
      dispatch(setLoader(true));
      const response = await ApiClient.get(getCodatSoftwaresApi);
      const {
        body: { results = [], CDT_LINK = [] },
      } = response;
      if (results?.length > 0) {
        if (query.get('companyID') !== null && query.get('companyID')) {
          putSoftwares(results, { id: query.get('companyID') });
        } else {
          updateSoftwares(results, CDT_LINK);
        }
      }
    } catch (e) {
      onError(e);
    } finally {
      dispatch(setLoader(false));
    }
  };

  const openCodat = (url) => {
    const win = window.open(url, '_blank');
    win.focus();
  };

  const handleLinking = async (element) => {
    const linkedAlready = softwares.some((ele) => ele.integrationStatus);
    onError({});
    if (element?.integrationStatus === 'PendingAuth' && linkedAlready) {
      openCodat(element.codatLinkUrl);
    }
    if (!linkedAlready && element?.integrationStatus !== 'PendingAuth') {
      try {
        dispatch(setLoader(true));
        const response = await ApiClient.post(linkIndSoftApi, {
          name: element.name,
          platformType: element.key,
        });
        const {
          body: { CDT_LINK = [] },
        } = response;
        const [firstObj] = CDT_LINK;
        openCodat(firstObj.codatLinkUrl);
      } catch (e) {
        // console.log(e);
      } finally {
        dispatch(setLoader(false));
      }
    } else if (element?.integrationStatus !== 'PendingAuth') {
      onError({ message: onlyOneSoft, severity: 'info' });
    }
  };

  useEffect(() => {
    getSoftwares();
  }, []);

  const renderStatus = (integrationStatus) => {
    let component = ArrowCircleRight;
    let dataTestId = 'notLinked';
    if (integrationStatus === 'PendingAuth') {
      component = Sync;
      dataTestId = 'pending';
    } else if (integrationStatus === 'Linked') {
      component = CheckmarkCircle;
      dataTestId = 'linked';
    }
    return (
      <CustomIcon
        component={component}
        color="grey.800"
        inheritViewBox
        sx={{ fontSize: '29px' }}
        data-testid={dataTestId}
      />
    );
  };

  return (
    <>
      <Grid container spacing={3}>
        {softwares.map((element, index) => (
          <Grid item xs={12} sm={4} key={index}>
            <Paper
              className={classes.softBox}
              component={Box}
              display="flex"
              flexDirection="column"
              gap="20px"
            >
              <Box display="flex" justifyContent="center">
                <img
                  src={element.logoUrl}
                  alt={element.name}
                  className={classes.maxWidth}
                />
              </Box>
              <Box display="flex" justifyContent="center">
                <IconButton
                  aria-label="link"
                  className={classes.linkAvatar}
                  onClick={() => handleLinking(element)}
                >
                  {renderStatus(element?.integrationStatus)}
                </IconButton>
              </Box>
            </Paper>
          </Grid>
        ))}
        {softwares.length > 0 && (
          <Grid item xs={12} sm={4}>
            <Paper
              className={classes.softBox}
              component={Box}
              display="flex"
              flexDirection="column"
              gap="20px"
            >
              <Box
                textAlign="center"
                display="flex"
                flexGrow="1"
                justifyContent="center"
              >
                {softNotAvail}
              </Box>
              <Box display="flex" justifyContent="center">
                <IconButton
                  aria-label="link"
                  className={classes.linkAvatar}
                  onClick={() => history.push(routePath.WELCOME_CHELLO)}
                >
                  <CustomIcon
                    component={ArrowCircleRight}
                    color="grey.800"
                    inheritViewBox
                    sx={{ fontSize: '29px' }}
                  />
                </IconButton>
              </Box>
            </Paper>
          </Grid>
        )}
      </Grid>
    </>
  );
};

export default LinkCodatSoftware;
LinkCodatSoftware.propTypes = {
  onError: PropTypes.func,
};
LinkCodatSoftware.defaultProps = {
  onError: defaultFnPropTypes,
};
