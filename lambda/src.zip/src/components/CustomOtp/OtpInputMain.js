import { Component } from 'react';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';

import SingleOtpInput from './SingleOtpInput';
import Constants from './utility';

const isStyleObject = (obj) => typeof obj === 'object';

class OtpInput extends Component {
  state = {
    activeInput: 0,
  };

  getOtpValue = () => {
    const { value } = this.props;

    return value ? value.toString().split('') : [];
  };

  getPlaceholderValue = () => {
    const { placeholder, numInputs } = this.props;

    if (typeof placeholder === 'string') {
      if (placeholder.length === numInputs) {
        return placeholder;
      }

      if (placeholder.length > 0) {
        // console.error(
        //   'Length of the placeholder should be equal to the number of inputs.',
        // );
      }
    }
    return null;
  };

  // Helper to return OTP from input
  handleOtpChange = (otp) => {
    const { onChange } = this.props;
    const otpValue = otp.join('');

    onChange(otpValue);
  };

  isInputValueValid = (value) => {
    const { isInputNum } = this.props;

    const isTypeValid = isInputNum
      ? !isNaN(parseInt(value, 10))
      : typeof value === 'string';

    return isTypeValid && value.trim().length === 1;
  };

  // Focus on input by index
  focusInput = (input) => {
    const { numInputs } = this.props;
    const activeInput = Math.max(Math.min(numInputs - 1, input), 0);

    this.setState({ activeInput });
  };

  // Focus on next input
  focusNextInput = () => {
    const { activeInput } = this.state;
    this.focusInput(activeInput + 1);
  };

  // Focus on previous input
  focusPrevInput = () => {
    const { activeInput } = this.state;
    this.focusInput(activeInput - 1);
  };

  // Change OTP value at focused input
  changeCodeAtFocus = (value) => {
    const { activeInput } = this.state;
    const otp = this.getOtpValue();
    otp[activeInput] = value;

    this.handleOtpChange(otp);
  };

  // Handle pasted OTP
  handleOnPaste = (e) => {
    e.preventDefault();

    const { activeInput } = this.state;
    const { numInputs, isDisabled, isInputNum } = this.props;
    if (isDisabled) {
      return;
    }

    // existed fucntion

    // if (isInputNum) {
    //   const isNumeric = pastedData.every((c) => '0123456789'.includes(c));
    //   if (!isNumeric) return;
    // }
    const otp = this.getOtpValue();
    let nextActiveInput = activeInput;

    // Get pastedData in an array of max size (num of inputs - current position)
    const pastedData = e.clipboardData
      .getData('text/plain')
      .slice(0, numInputs - activeInput)
      .split('');

    //

    if (isInputNum) {
      const isNumeric = pastedData.every((c) => '0123456789'.includes(c));
      if (!isNumeric) return;
    }
    // Paste data from focused input onwards
    for (let pos = 0; pos <= numInputs; pos += 1) {
      if (pos >= activeInput && pastedData.length > 0) {
        otp[pos] = pastedData.shift();
        nextActiveInput += 1;
      }
    }

    this.setState({ activeInput: nextActiveInput }, () => {
      this.focusInput(nextActiveInput);
      this.handleOtpChange(otp);
    });
  };

  handleOnChange = (e) => {
    const { value } = e.target;

    if (this.isInputValueValid(value)) {
      this.changeCodeAtFocus(value);
    }
  };

  // Handle cases of backspace, delete, left arrow, right arrow, space
  handleOnKeyDown = (e) => {
    if (e.keyCode === Constants.BACKSPACE || e.key === 'Backspace') {
      e.preventDefault();
      this.changeCodeAtFocus('');
      this.focusPrevInput();
    } else if (e.keyCode === Constants.DELETE || e.key === 'Delete') {
      e.preventDefault();
      this.changeCodeAtFocus('');
    } else if (e.keyCode === Constants.LEFT_ARROW || e.key === 'ArrowLeft') {
      e.preventDefault();
      this.focusPrevInput();
    } else if (e.keyCode === Constants.RIGHT_ARROW || e.key === 'ArrowRight') {
      e.preventDefault();
      this.focusNextInput();
    } else if (
      e.keyCode === Constants.consoleSPACEBAR ||
      e.key === ' ' ||
      e.key === 'Spacebar' ||
      e.key === 'Space'
    ) {
      e.preventDefault();
    }
  };

  // The content may not have changed, but some input took place hence change the focus
  handleOnInput = (e) => {
    const { isInputNum } = this.props;
    if (this.isInputValueValid(e.target.value)) {
      this.focusNextInput();
    }
    // This is a workaround for dealing with keyCode "229 Unidentified" on Android.
    else if (!isInputNum) {
      const { nativeEvent } = e;

      if (
        nativeEvent.data === null &&
        nativeEvent.inputType === 'deleteContentBackward'
      ) {
        e.preventDefault();
        this.changeCodeAtFocus('');
        this.focusPrevInput();
      }
    }
  };

  renderInputs = () => {
    const { activeInput } = this.state;
    const { 'data-cy': dataCy, 'data-testid': dataTestId } = this.props;
    const {
      numInputs,
      inputStyle,
      focusStyle,
      separator,
      isDisabled,
      disabledStyle,
      hasErrored,
      errorStyle,
      shouldAutoFocus,
      isInputNum,
      isInputSecure,
      className,
    } = this.props;

    const inputs = [];
    const otp = this.getOtpValue();
    const placeholder = this.getPlaceholderValue();
    // const dataCy = this.props.data - cy;
    // const dataTestId = this.props.data - testid;

    for (let i = 0; i < numInputs; i += 1) {
      inputs.push(
        <SingleOtpInput
          placeholder={placeholder && placeholder[i]}
          key={i}
          index={i}
          focus={activeInput === i}
          value={otp && otp[i]}
          onChange={this.handleOnChange}
          onKeyDown={this.handleOnKeyDown}
          onInput={this.handleOnInput}
          onPaste={this.handleOnPaste}
          onFocus={(e) => {
            this.setState({ activeInput: i });
            e.target.select();
          }}
          onBlur={() => this.setState({ activeInput: -1 })}
          separator={separator}
          inputStyle={inputStyle}
          focusStyle={focusStyle}
          isLastChild={i === numInputs - 1}
          isDisabled={isDisabled}
          disabledStyle={disabledStyle}
          hasErrored={hasErrored}
          errorStyle={errorStyle}
          shouldAutoFocus={shouldAutoFocus}
          isInputNum={isInputNum}
          isInputSecure={isInputSecure}
          className={className}
          data-cy={dataCy && `${dataCy}-${i}`}
          data-testid={dataTestId && `${dataTestId}-${i}`}
        />,
      );
    }

    return inputs;
  };

  render() {
    const { containerStyle } = this.props;

    return (
      <div
        style={{
          display: 'flex',
          ...(isStyleObject(containerStyle) && containerStyle),
        }}
        className={!isStyleObject(containerStyle) ? containerStyle : ''}
      >
        {this.renderInputs()}
      </div>
    );
  }
}

OtpInput.propTypes = {
  placeholder: PropTypes.string,
  numInputs: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  isInputNum: PropTypes.bool,
  isDisabled: PropTypes.bool,
  value: PropTypes.string,
  shouldAutoFocus: PropTypes.bool,
  onChange: PropTypes.func,
  isInputSecure: PropTypes.bool,
  inputStyle: PropTypes.string,
  focusStyle: PropTypes.string,
  containerStyle: PropTypes.string,
  hasErrored: PropTypes.bool,
  errorStyle: PropTypes.string,
  separator: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.oneOf([undefined]),
  ]),
  disabledStyle: PropTypes.bool,
  className: PropTypes.string,
  'data-testid': PropTypes.string,
  'data-cy': PropTypes.string,
};

OtpInput.defaultProps = {
  placeholder: '',
  isInputNum: false,
  onChange: defaultFnPropTypes,
  isInputSecure: false,
  inputStyle: '',
  focusStyle: '',
  containerStyle: '',
  hasErrored: false,
  errorStyle: '',
  separator: '',
  disabledStyle: false,
  className: '',
  numInputs: 4,
  isDisabled: false,
  shouldAutoFocus: false,
  value: '',
  'data-testid': '',
  'data-cy': '',
};

export default OtpInput;
