import React, { Component } from 'react';

import OtpInput from './OtpInputMain';

class CustomOtp extends Component {
  constructor(props) {
    super(props);
    this.input = React.createRef();
  }

  render() {
    return (
      <>
        <OtpInput {...this.props} />
      </>
    );
  }
}
export default CustomOtp;
