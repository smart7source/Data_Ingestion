import {
  Button,
  Box,
  Dialog,
  DialogContent,
  IconButton,
  Typography,
  DialogActions,
  Grid,
  DialogTitle,
} from '@mui/material';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

const {
  joinChello,
  withMsg,
  getStarted,
  getStartedMsg1,
  getStartedMsg2,
  getStartedMsg3,
  getStartedMsg4,
  getStartedMsg5,
  getStartedMsg6,
} = strings;

const GetStartedDialog = ({ open, handleClose, handleGetStarted }) => (
  <Dialog
    aria-labelledby="customized-dialog-title"
    open={open}
    fullWidth
    maxWidth="sm"
  >
    <DialogTitle>
      {withMsg}{' '}
      <Typography variant="h1" component="span" color="primary">
        {joinChello}
      </Typography>
      {getStartedMsg1}
      <IconButton
        aria-label="close"
        sx={{
          position: 'absolute',
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[900],
        }}
        onClick={handleClose}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          sx={{ width: '14px', height: '14px' }}
        />
      </IconButton>
    </DialogTitle>

    <DialogContent>
      <Box mt={5} mb={2.5}>
        <Typography variant="p1SemiBold">{getStartedMsg2}</Typography>
        <ul className={classes.getStartedList}>
          <li>{getStartedMsg3}</li>
          <li>{getStartedMsg4}</li>
          <li>{getStartedMsg5}</li>
        </ul>
      </Box>
    </DialogContent>
    <DialogActions>
      <Grid container>
        <Grid item sm={6} container>
          <Button
            variant="contained"
            onClick={handleGetStarted}
            disableElevation
            size="OnbCBtn"
            sx={{
              marginBottom: {
                xs: 2, // theme.breakpoints.up('xs')
                sm: 0, // theme.breakpoints.up('sm')
              },
              width: {
                xs: '100%',
                sm: '130px',
              },
            }}
          >
            {getStartedMsg6}
          </Button>
        </Grid>
        <Grid item sm={6} container justifyContent={['flex-start', 'flex-end']}>
          <Button
            variant="contained"
            color="primary"
            onClick={handleGetStarted}
            disableElevation
            sx={{
              marginBottom: {
                xs: 2, // theme.breakpoints.up('xs')
                sm: 0, // theme.breakpoints.up('sm')
              },
              width: {
                xs: '100%',
                sm: '130px',
              },
            }}
          >
            {getStarted}
          </Button>
        </Grid>
      </Grid>
    </DialogActions>
  </Dialog>
);

export default GetStartedDialog;

GetStartedDialog.propTypes = {
  open: PropTypes.bool,
  handleClose: PropTypes.func.isRequired,
  handleGetStarted: PropTypes.func.isRequired,
};

GetStartedDialog.defaultProps = {
  open: false,
};
