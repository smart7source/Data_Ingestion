import { useRef, useState, useCallback, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Box,
} from '@mui/material';

import { useFetchUser } from 'hooks';
import { handleLogout, millisToMinutesAndSeconds } from 'utils';
import { updateAuthenticatedStatus } from 'store/actions';

import strings from '../localization/translation';

const { sessionExpireTitle, sessionExpireMessage, logOff, logOutIn } = strings;

const SavanaTimerComponent = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const savanaTimerPopup = useSelector((state) => state.global.showSavanaModal);
  const [Open, setOpen] = useState(false);
  const isHardLogout = useRef(false);
  const sessionTimeoutRef = useRef(null);
  const timerRef = useRef(null);
  const [timeObj, setTimeObj] = useState({
    time: 120000,
    displayTime: '2:00',
  });

  const modalTimer = 120000; // 2mins

  const { isAuthenticated } = useFetchUser();

  const onLogout = useCallback(() => {
    clearTimeout(sessionTimeoutRef.current);
    setOpen(false);
    handleLogout({
      history,
      historyState: {
        isIdle: isHardLogout.current,
        message: [
          {
            message: strings?.autoSessionOutMsg,
            severity: 'info',
          },
        ],
      },
      onLogout: () => {
        dispatch(updateAuthenticatedStatus(false));
        dispatch({
          type: 'USER_LOGGED_OUT',
        });
      },
    });
  }, [dispatch, history]);

  const clearSession = useCallback(() => {
    isHardLogout.current = true;
    clearTimeout(sessionTimeoutRef.current);
    clearTimeout(timerRef.current);
    onLogout();
    setOpen(false);
  }, [onLogout]);

  const interValFun = useCallback(() => {
    if (timeObj?.time >= 0) {
      setTimeObj((c) => ({
        time: c.time - 1000,
        displayTime: millisToMinutesAndSeconds(c.time - 1000),
      }));
    } else {
      clearSession();
    }
  }, [clearSession, timeObj]);

  useEffect(() => {
    if (Open) {
      timerRef.current = setTimeout(interValFun, 1000);
    }
  }, [Open, interValFun]);

  useEffect(() => {
    if (savanaTimerPopup) {
      setOpen(true);
      sessionTimeoutRef.current = setTimeout(() => {
        setTimeObj({ time: 0, displayTime: '0:00' });
        isHardLogout.current = true;
        onLogout();
      }, modalTimer);
    }
  }, [isAuthenticated, onLogout, savanaTimerPopup]);

  return (
    <>
      <>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={Open}
          maxWidth="xs"
          data-testid="dialog"
        >
          <DialogTitle id="customized-dialog-title">
            <Typography
              data-testid="title"
              component="span"
              variant="h1"
              gutterBottom
            >
              {sessionExpireTitle}
            </Typography>
          </DialogTitle>
          <DialogContent sx={{ paddingBottom: '8px' }}>
            <Typography variant="p1" component="span" data-testid="message">
              {sessionExpireMessage}
            </Typography>
            <Typography
              variant="h3"
              component="span"
              justifyContent="center"
              display="flex"
              alignItems="center"
              mt={2}
              data-testid="timerMessage"
            >
              {logOutIn}
              <Typography
                variant="h1"
                component="span"
                ml="10px"
                data-testid="timerValue"
              >
                {timeObj?.displayTime}
              </Typography>
            </Typography>
          </DialogContent>
          <DialogActions>
            <Box justifyContent="flex-end" display="flex" mt={4}>
              <Button
                variant="contained"
                color="primary"
                data-testid="dialog-logoff-btn"
                onClick={onLogout}
                style={{ width: '130px' }}
              >
                {logOff}
              </Button>
            </Box>
          </DialogActions>
        </Dialog>
      </>
    </>
  );
};

export default SavanaTimerComponent;
