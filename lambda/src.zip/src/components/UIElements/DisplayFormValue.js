import { Typography, Box } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';

const DisplayFormValue = ({ name, value, showSeparator, showImage }) => (
  <Box
    className={showSeparator ? classes.displayFormValueBox : ''}
    height="100%"
  >
    {showImage && (
      <img
        src={`${process.env.PUBLIC_URL}/svg/ReviewTeamUserIcon.svg`}
        alt="info"
        data-testid="info-icon"
        className={classes.displayFormValuImg}
      />
    )}
    <Box>
      {name && (
        <Typography variant="p1" gutterBottom component="p">
          {name}
        </Typography>
      )}
      <Typography variant="p1SemiBold" sx={{ wordBreak: 'break-all' }}>
        {value}
      </Typography>
    </Box>
  </Box>
);

export default DisplayFormValue;

DisplayFormValue.propTypes = {
  name: PropTypes.string,
  value: PropTypes.node,
  showSeparator: PropTypes.bool,
  showImage: PropTypes.bool,
};

DisplayFormValue.defaultProps = {
  name: '',
  value: <></>,
  showSeparator: false,
  showImage: false,
};
