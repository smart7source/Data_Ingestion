import { Box, Typography, Link } from '@mui/material';

import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

export default function AppFooter() {
  const {
    appFooterContent,
    appFooterContent2,
    appFooterContent3,
    termsOfUse,
    onlinePrivacy,
    securityPolicy,
  } = strings;
  return (
    <footer className={classes.appFooter}>
      <Box className={classes.footerWrapper}>
        <Box className={classes.footerContent}>
          <Typography variant="string" className={classes.footerContent}>
            {`${appFooterContent}`}
          </Typography>
          <br />
          <Typography variant="string" className={classes.footerContent}>
            {`${appFooterContent2} `}
            <span className={classes.footerContentDecorated}>
              {appFooterContent3}
            </span>
          </Typography>
        </Box>
        <Box className={classes.footerLink}>
          <Link to="#">{termsOfUse}</Link>
          <Link to="#">{onlinePrivacy}</Link>
          <Link to="#">{securityPolicy}</Link>
        </Box>
        <Box>
          <img
            src={`${process.env.PUBLIC_URL}/svg/app-footer-logo.svg`}
            alt="logo"
          />
        </Box>
      </Box>
    </footer>
  );
}
