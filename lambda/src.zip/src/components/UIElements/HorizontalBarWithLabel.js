import PropTypes from 'prop-types';
import { Typography, Box, LinearProgress } from '@mui/material';

import classes from 'style/DashboardStyle.module.scss';

const HorizontalBarWithLabel = ({
  labelPosition = 'up',
  value,
  showValue,
  prefix,
  suffix,
  ...rest
}) => (
  <Box display="flex" alignItems="center" flexDirection="column" gap={1}>
    {labelPosition === 'up' ? (
      <Box width="100%" display="flex" textAlign="left" minHeight="42px">
        <Typography
          variant="h2"
          component={Box}
          display="flex"
          alignItems="center"
          color="grey.900"
        >
          {prefix}
          {showValue || value}
          {suffix}
        </Typography>
      </Box>
    ) : (
      <Box
        sx={{
          minWidth: 35,
          position: 'absolute',
          left: `${value + 1}%`,
          bottom: `-5px`,
        }}
      >
        <Typography variant="body2" component={Box} color="text.secondary">
          {prefix}
          {showValue || value}
          {suffix}
        </Typography>
      </Box>
    )}
    <Box sx={{ width: '100%' }}>
      <LinearProgress
        variant="determinate"
        classes={{
          colorPrimary: classes.progressBarPrimary,
          colorSecondary: classes.progressBarSecondary,
        }}
        value={value}
        {...rest}
      />
    </Box>
  </Box>
);

export default HorizontalBarWithLabel;

HorizontalBarWithLabel.propTypes = {
  value: PropTypes.number.isRequired,
  labelPosition: PropTypes.string,
  showValue: PropTypes.node,
  prefix: PropTypes.string,
  suffix: PropTypes.string,
};

HorizontalBarWithLabel.defaultProps = {
  labelPosition: 'up',
  showValue: '',
  prefix: '',
  suffix: '',
};
