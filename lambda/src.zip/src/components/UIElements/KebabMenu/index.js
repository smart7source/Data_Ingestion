import React, { useState } from 'react';
import { Divider, IconButton, Menu, MenuItem } from '@mui/material';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as MoreVertical } from 'assets/svg/more-vertical.svg';
import { defaultFnPropTypes } from 'utils';

const KebabMenu = (props) => {
  const { options, ariaLabel, id, onMenuOptionClick } = props;

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOptionClick = (option) => (event) => {
    onMenuOptionClick(option, event);
    handleClose();
  };

  const kebabBtnLabel = `more options on ${ariaLabel}`;
  const kebabBtnId = `kebab-menu-${id}-btn`;
  const optionsMenuId = `kebab-menu-${id}-menu`;

  return (
    <>
      <IconButton
        aria-label={kebabBtnLabel}
        id={kebabBtnId}
        data-testid={kebabBtnId}
        aria-controls={open ? optionsMenuId : undefined}
        aria-expanded={open ? 'true' : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <CustomIcon
          component={MoreVertical}
          color="grey.800"
          inheritViewBox
          sx={{ width: '16px', height: '16px' }}
        />
      </IconButton>
      <Menu
        id={optionsMenuId}
        MenuListProps={{
          'aria-labelledby': kebabBtnId,
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
      >
        {options.map((option, index) => {
          const { name, isDisabled = false } = option;

          const optionsMenuItemId = `kebab-menu-${id}-item-${index}`;
          return (
            <div key={index}>
              <MenuItem
                key={index}
                disabled={isDisabled}
                onClick={handleOptionClick(option)}
                id={optionsMenuItemId}
                data-testid={optionsMenuItemId}
              >
                {name}
              </MenuItem>
              {option?.addDivider && <Divider variant="middle" />}
            </div>
          );
        })}
      </Menu>
    </>
  );
};

export default KebabMenu;

KebabMenu.propTypes = {
  options: PropTypes.instanceOf(Object),
  ariaLabel: PropTypes.string,
  id: PropTypes.string,
  onMenuOptionClick: PropTypes.func,
};

KebabMenu.defaultProps = {
  options: [],
  ariaLabel: '',
  id: '',
  onMenuOptionClick: defaultFnPropTypes,
};
