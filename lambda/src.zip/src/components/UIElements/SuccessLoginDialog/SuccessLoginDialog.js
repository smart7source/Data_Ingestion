import {
  Button,
  Dialog,
  DialogContent,
  Typography,
  DialogActions,
  IconButton,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';

import { routePath } from 'routes';
import classes from 'style/globalStyle.module.scss';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import strings from 'localization/translation';
import { getRouteInfo } from 'utils';
import { updateCurPageId } from 'store/actions';

const {
  goToDashboard,
  continue: continueBtnName,
  chelloHeadingText,
  niceToSeeText,
  onboardingLeftOffText,
  startFromBeginningText,
} = strings;

const SuccessLoginDialog = ({ pageNo = '2', applicationSubmitted }) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const handleRedirect = (flag) => {
    const { path: rediectPath = '' } = getRouteInfo(pageNo);
    const { CONFIRM_PRACTICE_INFO } = routePath;
    let path = '';
    dispatch(updateCurPageId(pageNo));
    if (flag === 'continue') {
      path = rediectPath;
    } else {
      path = CONFIRM_PRACTICE_INFO;
    }
    history.push(path);
  };
  return (
    <Dialog
      data-testid="success-login-dialog"
      aria-labelledby="customized-dialog-title"
      open
      maxWidth="sm"
    >
      <DialogContent>
        <Typography variant="h1" className={classes.boldText} gutterBottom>
          <Typography
            variant="h1"
            component="span"
            color="primary"
            className={classes.logoStyle}
            gutterBottom
          >
            {chelloHeadingText}
          </Typography>{' '}
          {niceToSeeText}
        </Typography>
        <Typography gutterBottom className={classes.contentTypo}>
          {onboardingLeftOffText}
        </Typography>
      </DialogContent>
      <DialogActions
        className={classes.spacing}
        sx={{ justifyContent: 'flex-start' }}
      >
        <Button
          variant="contained"
          color="primary"
          onClick={() => handleRedirect('continue')}
          autoFocus
          className={classes.setWidth}
          disableElevation
          data-testid="success-login-dialog-continue"
        >
          {continueBtnName}
        </Button>
        {!applicationSubmitted && (
          <Button
            variant="contained"
            onClick={() => handleRedirect('start')}
            disableElevation
            data-testid="success-login-dialog-start-from-begning"
            className={classes.setWidth}
            sx={{ padding: 0 }}
          >
            {startFromBeginningText}
          </Button>
        )}
        <Button
          variant="contained"
          onClick={() => history.push(routePath.DASHBOARD)}
          disableElevation
          data-testid="success-login-dialog-go-to-dashboard"
          className={classes.setWidth}
        >
          {goToDashboard}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default SuccessLoginDialog;

SuccessLoginDialog.propTypes = {
  pageNo: PropTypes.string.isRequired,
  applicationSubmitted: PropTypes.bool,
};

SuccessLoginDialog.defaultProps = {
  applicationSubmitted: false,
};
