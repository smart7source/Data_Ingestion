import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Router, screen } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import SuccessLoginDialog from '../SuccessLoginDialog';
import strings from 'localization/translation';
import { routePath } from 'routes';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import { onBoardingStateEmptyMock } from 'testHelpers';

const {
  goToDashboard,
  continue: continueBtnName,
  chelloHeadingText,
  niceToSeeText,
  startFromBeginningText,
} = strings;
const { DASHBOARD } = routePath;

describe('render SuccessLoginDialog component', () => {
  const defaultProps = {
    open: false,
    pageNo: '3',
  };

  const history = createMemoryHistory();
  const mockStore = configureStore(onBoardingStateEmptyMock);
  const RenderAsync = (props = defaultProps) => {
    return render(
      <Provider store={mockStore}>
        <Router history={history}>
          <SuccessLoginDialog {...props} />
        </Router>
      </Provider>,
    );
  };

  it('should render the component with the default props ', async () => {
    const { screen } = await RenderAsync();
    expect(screen).toMatchSnapshot();
  });

  it('render with Defined Props', async () => {
    const definedProps = { ...defaultProps, open: true };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText(chelloHeadingText)).toBeInTheDocument();
    expect(getByText(niceToSeeText)).toBeInTheDocument();
  });

  it('check Continue button functionality ', async () => {
    const definedProps = { ...defaultProps, open: true };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText(continueBtnName)).toBeInTheDocument();
    userEvent.click(getByText(continueBtnName));
  });

  it('check startFromBeginningText button functionality ', async () => {
    const definedProps = { ...defaultProps, open: true };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText(startFromBeginningText)).toBeInTheDocument();
    userEvent.click(getByText(startFromBeginningText));
  });

  it('Upon Submit Application, check startFromBeginningText button functionality ', async () => {
    const definedProps = {
      ...defaultProps,
      open: true,
      applicationSubmitted: true,
    };
    const { queryByText } = await RenderAsync(definedProps);
    expect(queryByText(startFromBeginningText)).toBeNull();
  });

  it('check goToDashboard button functionality ', async () => {
    const definedProps = { ...defaultProps, open: true };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText(goToDashboard)).toBeInTheDocument();
    userEvent.click(getByText(goToDashboard));
    expect(history.location.pathname).toBe(DASHBOARD);
  });
});
