import { Box, Alert, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';

const SingleNotification = ({
  error: { severity = 'error', message = '' },
}) => {
  if (message) {
    return (
      <Box marginBottom={1}>
        <Alert
          severity={severity}
          role="alert"
          icon={false}
          classes={{
            root: classes.alertRoot,
            standardError: classes.alertStandardError,
            standardSuccess: classes.alertStandardSuccess,
            standardInfo: classes.alertStandardInfo,
          }}
          data-testid="single-notification-alert"
        >
          <Typography component="span" variant="p2SemiBold">
            {message}
          </Typography>
        </Alert>
      </Box>
    );
  }
  return null;
};

export default SingleNotification;

SingleNotification.propTypes = {
  error: PropTypes.shape({
    severity: PropTypes.string,
    message: PropTypes.string,
    code: PropTypes.string,
  }),
};

SingleNotification.defaultProps = {
  error: { message: '', severity: 'error', code: '' },
};
