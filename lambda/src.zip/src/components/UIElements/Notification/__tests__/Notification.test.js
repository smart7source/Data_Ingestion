import { render, screen } from '@testing-library/react';
import strings from 'localization/translation';
import Notification from '../Notification';

describe('render Notification component', () => {
  const defaultProps = {
    errors: [],
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<Notification {...props} />);
  };

  it('should render the component with the default props ', async () => {
    const { screen } = await RenderAsync();
    expect(screen).toMatchSnapshot();
  });

  it('should render the component with the defined props ', async () => {
    const definedProps = {
      errors: [
        { message: strings.resendCodeMsg, severity: 'error' },
        { message: 'Code has been deleted!', severity: 'warning' },
      ],
    };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText(strings.resendCodeMsg)).toBeInTheDocument();
  });
});
