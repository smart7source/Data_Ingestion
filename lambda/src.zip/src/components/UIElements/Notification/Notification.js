import { Box, Alert } from '@mui/material';
import PropTypes from 'prop-types';
import { useRef, useEffect } from 'react';

import classes from 'style/globalStyle.module.scss';

const Notification = ({ errors, needFocus }) => {
  const itemsRef = useRef([]);

  useEffect(() => {
    itemsRef.current = itemsRef.current.slice(0, errors.length);
    if (needFocus) {
      itemsRef?.current?.[0]?.focus?.();
    }
  }, [errors, needFocus]);

  return (
    <>
      {errors.map((item, index) => {
        const { severity = 'error', message = '' } = item;
        if (message) {
          return (
            <Box marginBottom={1} key={index}>
              <Alert
                severity={severity}
                role="alert"
                icon={false}
                ref={(el) => {
                  itemsRef.current[index] = el;
                }}
                classes={{
                  root: classes.alertRoot,
                  standardError: classes.alertStandardError,
                  standardSuccess: classes.alertStandardSuccess,
                  standardInfo: classes.alertStandardInfo,
                }}
                data-testid="notification-alert"
                tabIndex="-1"
              >
                {message}
              </Alert>
            </Box>
          );
        }
        return null;
      })}
    </>
  );
};

export default Notification;

Notification.propTypes = {
  errors: PropTypes.instanceOf(Object),
  needFocus: PropTypes.bool,
};

Notification.defaultProps = {
  errors: [],
  needFocus: false,
};
