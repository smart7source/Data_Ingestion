import { render, screen } from '@testing-library/react/pure';

import HorizontalBarWithLabel from '../HorizontalBarWithLabel';

const renderComponent = (props) =>
  render(<HorizontalBarWithLabel {...props} />);

describe('render <HorizontalBarWithLabel /> component', () => {
  it('should render value into component', () => {
    const props = {
      value: 200,
    };
    renderComponent(props);
    expect(screen.getByText(/200/i)).toBeInTheDocument();
  });

  it('should render value into component without labelPosition', () => {
    const props = {
      value: 300,
      labelPosition: 'down',
    };
    renderComponent(props);
    expect(screen.getByText(/300/i)).toBeInTheDocument();
  });

  it('should render value into component with prefix', () => {
    const props = {
      value: 300,
      labelPosition: 'down',
      prefix: 'prefix',
    };
    renderComponent(props);
    expect(screen.getByText(/prefix/i)).toBeInTheDocument();
  });
});
