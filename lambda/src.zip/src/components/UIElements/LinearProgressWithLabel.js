import { LinearProgress, Typography, Box } from '@mui/material';
import PropTypes from 'prop-types';

const LinearProgressWithLabel = (props) => {
  const { value } = props;
  return (
    <>
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <Box sx={{ width: '100%', mr: 1 }}>
          <LinearProgress variant="determinate" {...props} />
        </Box>
      </Box>
      <Box sx={{ minWidth: 35 }} mt={1}>
        <Typography variant="p3" color="primary">{`${Math.round(
          value,
        )}% uploaded`}</Typography>
      </Box>
    </>
  );
};

LinearProgressWithLabel.propTypes = {
  /**
   * The value of the progress indicator for the determinate and buffer variants.
   * Value between 0 and 100.
   */
  value: PropTypes.number.isRequired,
};

export default LinearProgressWithLabel;
