import { render } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import Spinner from '../Spinner';

describe('render Spinner component', () => {
  const defaultProps = {
    open: false,
    errorMessage: '',
  };

  const RenderAsync = (props = defaultProps) => {
    return render(
      <StyledEngineProvider injectFirst>
        <ThemeProvider theme={theme}>
          <Spinner {...props} />
        </ThemeProvider>
      </StyledEngineProvider>,
    );
  };

  it('should render the component with the default props ', async () => {
    const { screen } = await RenderAsync();
    expect(screen).toMatchSnapshot();
  });

  it('render with Defined Error Props', async () => {
    const definedProps = {
      ...defaultProps,
      open: true,
      errorMessage: 'Error Text',
    };
    const { getByText, getByAltText } = await RenderAsync(definedProps);
    expect(getByText('Error Text')).toBeInTheDocument();
    expect(getByAltText('loader')).toBeInTheDocument();
  });
});
