import PropTypes from 'prop-types';

import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle.svg';
import { ReactComponent as AlertCircle } from 'assets/svg/alert-circle.svg';
import { ReactComponent as RadioBtnOff } from 'assets/svg/radio-button-off.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { whiteToBlackColor } from 'style/variables';

const PasswordHelperIcon = (props) => {
  const { isPassword, isMatching } = props;
  if (!isPassword)
    return (
      <CustomIcon
        component={RadioBtnOff}
        inheritViewBox
        sx={{ color: whiteToBlackColor[900], fontSize: '16px' }}
      />
    );
  return (
    <>
      {isMatching ? (
        <CustomIcon
          component={CheckmarkCircle}
          color="success"
          inheritViewBox
          sx={{ fontSize: '16px' }}
        />
      ) : (
        <CustomIcon
          component={AlertCircle}
          color="error"
          inheritViewBox
          sx={{ fontSize: '16px' }}
        />
      )}
    </>
  );
};

PasswordHelperIcon.propTypes = {
  isPassword: PropTypes.bool,
  isMatching: PropTypes.bool,
};

PasswordHelperIcon.defaultProps = {
  isPassword: false,
  isMatching: false,
};

export default PasswordHelperIcon;
