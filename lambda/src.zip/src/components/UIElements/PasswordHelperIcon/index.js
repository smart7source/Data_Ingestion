import PasswordHelperIcon from './PasswordHelperIcon';

export default PasswordHelperIcon;
