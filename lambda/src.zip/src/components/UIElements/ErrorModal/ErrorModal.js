import { Dialog, DialogContent, DialogTitle, Typography } from '@mui/material';
import { useSelector } from 'react-redux';

import { defaultFnPropTypes } from 'utils';

const ErrorModal = () => {
  const error = useSelector((state) => state.global.error);
  const errorMessage = useSelector((state) => state.global.errorMessage);
  const dialogView = () => (
    <Dialog
      aria-labelledby="customized-dialog-title"
      open={error}
      maxWidth="sm"
      fullWidth
    >
      <DialogTitle id="customized-dialog-title" onClose={defaultFnPropTypes}>
        Error
      </DialogTitle>

      <DialogContent dividers>
        <Typography style={{ marginBottom: '4rem' }}>{errorMessage}</Typography>
      </DialogContent>
    </Dialog>
  );
  return <>{dialogView()}</>;
};

export default ErrorModal;
