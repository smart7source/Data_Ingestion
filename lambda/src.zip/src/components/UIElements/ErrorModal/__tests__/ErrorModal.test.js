import { render, screen } from '@testing-library/react';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import ErrorModal from '../ErrorModal';

const store = configureStore();
const initialState = {
  global: {
    error: true,
    errorMessage: 'Error Text',
    isAuthenticated: false,
    floatingChatbot: {
      enableFloatingChatbot: false,
      maximize: true,
    },
  },
};
const history = createMemoryHistory();
describe('render ErrorModal component', () => {
  beforeEach(() => {
    render(
      <Provider store={store(initialState)}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <Router history={history}>
              <ErrorModal />
            </Router>
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
  });

  it('should render the component with the default props ', async () => {
    expect(screen).toMatchSnapshot();
  });

  it('should render Message ', async () => {
    const msg = screen.getByText('Error Text');
    expect(msg).toBeInTheDocument();
  });
});
