import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Router } from 'react-router-dom';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import { Auth, Amplify } from 'aws-amplify';
import awsConfig from 'aws-exports';
import { createMemoryHistory } from 'history';
import NavBar from '../NavBar';
import strings from 'localization/translation';

Amplify.configure(awsConfig);
const { logoutButtonText } = strings;

const history = createMemoryHistory();
const store = configureStore();

describe('render <NavBar/> component', () => {
  beforeEach(() => {
    render(
      <Router history={history}>
        <Provider store={store({})}>
          <StyledEngineProvider injectFirst>
            <ThemeProvider theme={theme}>
              <NavBar />
            </ThemeProvider>
          </StyledEngineProvider>
        </Provider>
      </Router>,
    );
  });

  it('should render help button', () => {
    const getHelpButton = screen.getByText('Questions? Get help');
    expect(getHelpButton).toBeInTheDocument();
    fireEvent.click(getHelpButton);
  });
});

describe('check useeffect', () => {
  it('check if logout Button Renders', async () => {
    const mockSignOut = jest.fn().mockResolvedValue({});
    Auth.signOut = mockSignOut;
    Auth.currentAuthenticatedUser = jest.fn().mockImplementation(
      () =>
        new Promise((resolve, reject) => {
          const user = {
            username: 'abc123',
            email: 'demo@test.com',
            accessToken: '123cvb123',
            name: 'John Rambo',
            phone: '+46761022312',
            phoneVerified: false,
            attributes: {
              sub: 'abc123',
            },
          };
          return resolve(user);
        }),
    );
    const { getByText } = render(
      <Router history={history}>
        <Provider store={store({})}>
          <StyledEngineProvider injectFirst>
            <ThemeProvider theme={theme}>
              <NavBar />
            </ThemeProvider>
          </StyledEngineProvider>
        </Provider>
      </Router>,
    );
    const logOutButton = await waitFor(() => getByText(logoutButtonText));
    fireEvent.click(logOutButton);
    expect(history.location.pathname).toBe('/');
  });
});
