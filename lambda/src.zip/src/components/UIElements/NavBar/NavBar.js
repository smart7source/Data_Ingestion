import { useHistory, useLocation } from 'react-router-dom';
import React, { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { AppBar, Box, Button, IconButton, Toolbar, Link } from '@mui/material';
import { Auth } from 'aws-amplify';

import { ReactComponent as Power } from 'assets/svg/power.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as QuestionMarkCircle } from 'assets/svg/question-mark-circle.svg';
import classes from 'style/globalStyle.module.scss';
import routePath from 'routes/routePath';
import strings from 'localization/translation';
import { handleLogout } from 'utils';
import { updateAuthenticatedStatus } from 'store/actions';

const { logoutButtonText, navbarHelpText } = strings;

const NavBar = () => {
  const history = useHistory();
  const location = useLocation();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    (async () => {
      try {
        const user = await Auth.currentAuthenticatedUser();
        if (user) {
          setIsLoggedIn(true);
        }
      } catch (e) {
        setIsLoggedIn(false);
      }
    })();
  }, []);

  const onLogoutClick = useCallback(() => {
    handleLogout({
      history,
      onLogout: () => {
        dispatch(updateAuthenticatedStatus(false));
        dispatch({
          type: 'USER_LOGGED_OUT',
        });
      },
    });
  }, [dispatch, history]);

  const onLogoClick = (e) => {
    e.preventDefault();
    if (location?.pathname === routePath.LOGIN) {
      history.go(0);
    } else history.push(routePath.LOGIN);
  };

  return (
    <AppBar position="sticky">
      <Toolbar sx={{ bgcolor: 'grey.100' }} variant="regular">
        <Box border={1} flexGrow="1">
          <Link
            onClick={onLogoClick}
            to="#"
            sx={{ letterSpacing: 0, fontSize: '26px', cursor: 'pointer' }}
            color="primary"
            underline="none"
          >
            Chello=
          </Link>
        </Box>
        <Box>
          <Button
            variant="outlined"
            size="large"
            className={classes.helpBtn}
            endIcon={
              <CustomIcon
                component={QuestionMarkCircle}
                color="grey.800"
                inheritViewBox
                sx={{ fontSize: '16px' }}
              />
            }
          >
            {navbarHelpText}
          </Button>
          {isLoggedIn && (
            <>
              <Button
                variant="contained"
                color="primary"
                onClick={onLogoutClick}
                disableElevation
                sx={{
                  display: {
                    xs: 'none', // theme.breakpoints.up('xs')
                    sm: 'inline-flex', // theme.breakpoints.up('sm')
                  },
                  marginLeft: '8px',
                }}
              >
                {logoutButtonText}
              </Button>
              <IconButton
                onClick={onLogoutClick}
                sx={{
                  display: {
                    xs: 'inline-flex', // theme.breakpoints.up('xs')
                    sm: 'none', // theme.breakpoints.up('sm')
                  },
                }}
                size="large"
              >
                <CustomIcon
                  component={Power}
                  color="primary"
                  inheritViewBox
                  sx={{ fontSize: '20px' }}
                />
              </IconButton>
            </>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default React.memo(NavBar);
