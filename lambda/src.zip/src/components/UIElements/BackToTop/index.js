import { Link, Typography, Box } from '@mui/material';
import { styled } from '@mui/material/styles';
import { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import upArrow from 'assets/arrow-up.svg';

const { backToTop: BACK_TO_TOP } = strings;

const StyledLink = styled(Link)(
  ({ theme }) => `
  position: fixed;
  border-radius: 8px;
  padding: 8px;
  inset: auto 2rem 2rem auto;
  background: ${theme.palette.brand[200]};
  color: ${theme.palette.grey[800]};
  display: flex;
  align-items: center;
  gap: 5px;
  
  .up-arrow{
    width: 16px;
    height: 16px;
    background: url(${upArrow}) no-repeat;
    background-position: center;
  }
  z-index: 999;
`,
);

const BackToTop = (props) => {
  const { scrollContainer, scrollToPx, showAtPx } = props;

  const [showButton, setShowButton] = useState(false);

  const backToTopRef = useRef(null);

  useEffect(() => {
    const onScroll = () => {
      if (scrollContainer.scrollTop > showAtPx) {
        setShowButton(true);
      } else {
        setShowButton(false);
      }
    };

    document.addEventListener('scroll', onScroll);

    return () => {
      document.removeEventListener('scroll', onScroll);
    };
  }, [showAtPx, scrollContainer]);

  const goToTop = (e) => {
    e.preventDefault();
    scrollContainer.scrollTo(0, scrollToPx - 50);
  };

  return showButton ? (
    <StyledLink ref={backToTopRef} href="#" onClick={goToTop} underline="none">
      <Typography component="span" variant="buttonSmall">
        {BACK_TO_TOP}
      </Typography>
      <Box component="span" className="up-arrow" />
    </StyledLink>
  ) : null;
};

export default BackToTop;

BackToTop.propTypes = {
  scrollContainer: PropTypes.oneOfType([
    PropTypes.instanceOf(Object),
    PropTypes.node,
    PropTypes.instanceOf(Element),
  ]),
  scrollToPx: PropTypes.number,
  showAtPx: PropTypes.number,
};

BackToTop.defaultProps = {
  scrollContainer: document.documentElement || document.body,
  scrollToPx: 100,
  showAtPx: 0,
};
