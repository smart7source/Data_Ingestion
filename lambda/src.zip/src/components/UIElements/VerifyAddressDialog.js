import {
  Button,
  Dialog,
  DialogContent,
  Typography,
  DialogActions,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  FormLabel,
  Box,
  DialogTitle,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useState } from 'react';
import { NavLink } from 'react-router-dom';

import strings from 'localization/translation';
import { routePath } from 'routes';
import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';

const {
  continueBtnName,
  verifyAddDlogHeading,
  verifyAddDlogSubHeading,
  crntAddressLbl,
  sgstdAddressLbl,
  editAdddress,
  status,
} = strings;

const VerifyAddressDialog = ({
  crntFullAdd,
  suggestedAdd,
  handleContinue,
  page,
  handleClose,
  addressStatus,
}) => {
  const [prefAddress, setPrefAddress] = useState('C');
  return (
    <Dialog
      aria-labelledby="customized-dialog-title"
      open
      fullWidth
      maxWidth="sm"
    >
      <DialogTitle>
        {verifyAddDlogHeading}
        <Typography>{verifyAddDlogSubHeading}</Typography>
      </DialogTitle>
      <DialogContent>
        <Box>
          <FormControl>
            <RadioGroup
              aria-label="verify address"
              name="address"
              defaultValue="C"
              data-testid="prefAddRadio"
              onChange={(e) => setPrefAddress(e.target.value)}
            >
              <FormLabel
                sx={{
                  marginTop: 0,
                  marginBottom: '5px',
                  color: 'grey.800',
                }}
              >
                {crntAddressLbl} {`( ${status}: ${addressStatus} )`}
              </FormLabel>
              <FormControlLabel
                value="C"
                control={<Radio className={classes.radioLabelAlignment} />}
                label={crntFullAdd}
              />
              <FormLabel
                sx={{
                  marginTop: '10px',
                  marginBottom: '5px',
                  color: 'grey.800',
                }}
              >
                {sgstdAddressLbl}
              </FormLabel>
              <FormControlLabel
                value="S"
                control={<Radio className={classes.radioLabelAlignment} />}
                label={suggestedAdd}
              />
            </RadioGroup>
          </FormControl>
        </Box>
      </DialogContent>
      <DialogActions className={classes.spacing}>
        {page === '' ? (
          <Button
            variant="contained"
            component={NavLink}
            to={routePath.EDIT_PRACTICE_INFO}
            fullWidth
            disableElevation
          >
            {editAdddress}
          </Button>
        ) : (
          <Button
            variant="contained"
            onClick={handleClose}
            fullWidth
            disableElevation
            data-testid="editPrac-edit-address"
          >
            {editAdddress}
          </Button>
        )}

        <Button
          variant="contained"
          color="primary"
          onClick={() => handleContinue(prefAddress)}
          fullWidth
          disableElevation
          data-testid="continue_btn"
        >
          {continueBtnName}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default VerifyAddressDialog;

VerifyAddressDialog.propTypes = {
  handleContinue: PropTypes.func.isRequired,
  crntFullAdd: PropTypes.node,
  suggestedAdd: PropTypes.node,
  page: PropTypes.string,
  handleClose: PropTypes.func,
  addressStatus: PropTypes.string,
};

VerifyAddressDialog.defaultProps = {
  crntFullAdd: <></>,
  suggestedAdd: <></>,
  page: '',
  handleClose: defaultFnPropTypes,
  addressStatus: '',
};
