import { Typography, Grid } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

import PasswordHelperIcon from './PasswordHelperIcon';

const ErrorHelper = ({ value }) => {
  let hasCharLmt = false;
  let hasNum = false;
  let hasBothCaseChar = false;
  let hasAllowedSpecialChar = false;
  let hasNotAllowedSpecialChar = false;

  if (value) {
    hasCharLmt = value.length >= 8 && value.length <= 16;
    hasNum = /\d/.test(value);
    hasBothCaseChar = /[a-z].*[A-Z]|[A-Z].*[a-z]/.test(value);
    hasAllowedSpecialChar = /[@#$%&*]/.test(value);
    hasNotAllowedSpecialChar = /[^A-Za-z\d@$%*#&]/.test(value);
  }

  const isPassword = value !== null && !!value.length;

  return (
    <Grid
      container
      justifyContent="center"
      className={classes.passwordCondionContainer}
      rowSpacing={1}
      sx={{ backgroundColor: 'grey.200', gap: '10px' }}
    >
      <Grid
        item
        xs={6}
        sm={6}
        sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}
      >
        <PasswordHelperIcon isPassword={isPassword} isMatching={hasCharLmt} />
        <Typography variant="p2SemiBold" color="grey.900">
          {strings.regPasswordCharacterLimit}
        </Typography>
      </Grid>
      <Grid
        item
        xs={6}
        sm={5}
        sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}
      >
        <PasswordHelperIcon isPassword={isPassword} isMatching={hasNum} />
        <Typography variant="p2SemiBold" color="grey.900">
          {strings.regNumbers}
        </Typography>
      </Grid>
      <Grid
        item
        xs={6}
        sm={6}
        sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}
      >
        <PasswordHelperIcon
          isPassword={isPassword}
          isMatching={hasBothCaseChar}
        />
        <Typography variant="p2SemiBold" color="grey.900">
          {strings.regCapitalAndLowerCaseLetters}
        </Typography>
      </Grid>
      <Grid
        item
        xs={6}
        sm={5}
        sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}
      >
        <PasswordHelperIcon
          isPassword={isPassword}
          isMatching={hasAllowedSpecialChar && !hasNotAllowedSpecialChar}
        />
        <Typography variant="p2SemiBold" color="grey.900">
          {strings.regSpecialCharacters}
        </Typography>
      </Grid>
    </Grid>
  );
};

export default ErrorHelper;

ErrorHelper.propTypes = {
  value: PropTypes.string,
};

ErrorHelper.defaultProps = {
  value: null,
};
