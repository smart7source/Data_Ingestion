import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Typography,
  Grid,
} from '@mui/material';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

const DialogBox = ({
  Open,
  buttonOneFn,
  buttonTwoFn,
  buttonOne,
  buttonTwo,
  title,
  message,
  timerMessage,
  timer,
}) => (
  <>
    <Dialog
      aria-labelledby="customized-dialog-title"
      open={Open}
      maxWidth="xs"
      data-testid="dialog"
    >
      <IconButton
        aria-label="close"
        onClick={buttonTwoFn}
        size="large"
        className={classes.closeIcon}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          sx={{ width: '14px', height: '14px' }}
        />
      </IconButton>
      <DialogTitle id="customized-dialog-title">
        <Typography
          data-testid="title"
          component="span"
          variant="h1"
          gutterBottom
        >
          {title}
        </Typography>
      </DialogTitle>
      <DialogContent sx={{ paddingBottom: '8px' }}>
        <Typography variant="p1" component="span" data-testid="message">
          {message}
        </Typography>
        <Typography
          variant="h3"
          component="span"
          justifyContent="center"
          display="flex"
          alignItems="center"
          mt={2}
          data-testid="timerMessage"
        >
          {timerMessage}
          <Typography
            variant="h1"
            component="span"
            ml="10px"
            data-testid="timerValue"
          >
            {timer}
          </Typography>
        </Typography>
      </DialogContent>
      <DialogActions>
        <Grid container spacing={2} item justifyContent="space-between">
          <Grid item>
            <Button
              variant="contained"
              onClick={buttonOneFn}
              data-testid="dialog-secondary-btn"
              fullWidth
              disableElevation
            >
              <Typography
                component="span"
                color="primary"
                className={classes.logoStyle}
              >
                {buttonOne}
              </Typography>
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              color="primary"
              data-testid="dialog-primary-btn"
              onClick={buttonTwoFn}
              fullWidth
              className={classes.textTransformFirstLetter}
            >
              {buttonTwo}
            </Button>
          </Grid>
        </Grid>
      </DialogActions>
    </Dialog>
  </>
);

export default DialogBox;

DialogBox.propTypes = {
  Open: PropTypes.bool,
  buttonOneFn: PropTypes.func,
  buttonTwoFn: PropTypes.func,
  buttonOne: PropTypes.string,
  buttonTwo: PropTypes.string,
  title: PropTypes.string,
  message: PropTypes.string,
  timerMessage: PropTypes.string,
  timer: PropTypes.string,
};

DialogBox.defaultProps = {
  Open: false,
  buttonOneFn: defaultFnPropTypes,
  buttonTwoFn: defaultFnPropTypes,
  buttonOne: '',
  buttonTwo: '',
  title: '',
  message: '',
  timerMessage: '',
  timer: '0:00',
};
