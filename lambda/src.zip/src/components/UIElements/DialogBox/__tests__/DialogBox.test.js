import { render, screen, act, fireEvent } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import DialogBox from '../DialogBox';

describe('render dialog box when called', () => {
  let mockbuttonOneFn = jest.fn();
  let mockbuttonTwoFn = jest.fn();
  beforeEach(() => {
    const props = {
      Open: true,
      buttonOne: 'Logout',
      buttonTwo: 'Continue Session',
      title: 'Your session is going to expire',
      message: 'Your session will expire in sometime',
      buttonOneFn: mockbuttonOneFn,
      buttonTwoFn: mockbuttonTwoFn,
    };
    render(
      <StyledEngineProvider injectFirst>
        <ThemeProvider theme={theme}>
          <DialogBox
            Open={props.Open}
            buttonTwoFn={props.buttonTwoFn}
            buttonOneFn={props.buttonOneFn}
            buttonOne={props.buttonOne}
            buttonTwo={props.buttonTwo}
            title={props.title}
            message={props.message}
          />
        </ThemeProvider>
      </StyledEngineProvider>,
    );
  });

  it('render title and message of dialog box', () => {
    expect(screen.getByTestId(/title/i)).toBeInTheDocument();
  });

  it('call function on button1 click', async () => {
    await act(async () => {
      fireEvent.click(screen.getByTestId(/dialog-secondary-btn/i));
    });
    await expect(mockbuttonOneFn).toHaveBeenCalled();
  });

  it('call function on button2 click', async () => {
    await act(async () => {
      fireEvent.click(screen.getByTestId(/dialog-primary-btn/i));
    });
    await expect(mockbuttonTwoFn).toHaveBeenCalled();
  });
});
