import {
  Button,
  Dialog,
  DialogActions,
  DialogTitle,
  Radio,
  Link,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  FormControlLabel,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useState } from 'react';

import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

const {
  verifyTeamAddress,
  verifyTeamEditBtn,
  verifyTeamEditAddBtn,
  verifyTeamContAddBtn,
  verifyTeamUser,
  crntAddressLbl,
  sgstdAddressLbl,
  verifyTeamAction,
} = strings;

const completedAddressFormat = (street, street2, city, state, zip) => (
  <Typography
    varaint="p"
    sx={{ display: 'flex', flexDirection: 'column' }}
    className={classes.contentTypo}
  >
    <span>{street}</span>
    <span>{street2}</span>
    <span style={{ marginTop: '5px' }}>
      {city}, {state} {zip}
    </span>
  </Typography>
);

const VerifyTeamAddressDialog = (props) => {
  const {
    open,
    openAcc,
    handleCLose,
    users,
    prefAdds,
    setPrefAdds,
    sugAdds,
    onModalContinue,
  } = props;
  const [selAdds, setSelAdds] = useState(prefAdds);

  const handleChange = (id) => (e) => {
    setSelAdds((prevState) => ({ ...prevState, [id]: e.target.value }));
    setPrefAdds({ ...selAdds, [id]: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    const editedUsers = users.map((user, index) => {
      if (prefAdds?.[user.tpsMemberId]?.slice(-1) === 'S') {
        return {
          ...user,
          address: sugAdds?.[index].street,
          city: sugAdds?.[index].city,
          state: sugAdds?.[index].region,
          zip: sugAdds?.[index].postCode,
        };
      }

      return user;
    });
    onModalContinue(editedUsers);
    handleCLose();
  };

  const editAddress = (e, i) => {
    e.preventDefault();
    openAcc(`panel${i}`)(e, true);
    handleCLose();
  };

  return (
    <Dialog open={open} scroll="paper" fullWidth maxWidth="lg">
      <DialogTitle id="verify-team-address">{verifyTeamAddress}</DialogTitle>
      <Table className={classes.verifyTeamAddressTable}>
        <TableHead>
          <TableRow>
            <TableCell>{verifyTeamUser}</TableCell>
            <TableCell colSpan={2}>{crntAddressLbl}</TableCell>
            <TableCell colSpan={2}>{sgstdAddressLbl}</TableCell>
            <TableCell>{verifyTeamAction}</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map((user, index) => (
            <TableRow key={`user-${index}`}>
              <TableCell>{`${user.firstName} ${user.lastName}`}</TableCell>
              <TableCell colSpan={2}>
                <FormControlLabel
                  value={`${user.tpsMemberId}-C`}
                  checked={
                    selAdds[user.tpsMemberId] !== `${user.tpsMemberId}-S`
                  }
                  onChange={handleChange(user.tpsMemberId)}
                  control={
                    <Radio
                      className={classes.radioLabelAlignment}
                      sx={{ paddingLeft: 0 }}
                    />
                  }
                  label={completedAddressFormat(
                    user.address,
                    user.address2,
                    user.city,
                    user.state,
                    user.zip,
                  )}
                />
              </TableCell>
              <TableCell colSpan={2}>
                <FormControlLabel
                  value={`${user.tpsMemberId}-S`}
                  checked={
                    selAdds[user.tpsMemberId] === `${user.tpsMemberId}-S`
                  }
                  onChange={handleChange(user.tpsMemberId)}
                  control={
                    <Radio
                      className={classes.radioLabelAlignment}
                      sx={{ paddingLeft: 0 }}
                    />
                  }
                  label={completedAddressFormat(
                    sugAdds?.[index]?.street || '',
                    sugAdds?.[index]?.street2 || '',
                    sugAdds?.[index]?.city || '',
                    sugAdds?.[index]?.region || '',
                    sugAdds?.[index]?.postCode || '',
                  )}
                />
              </TableCell>
              <TableCell>
                <Link component="button" onClick={(e) => editAddress(e, index)}>
                  {verifyTeamEditBtn}
                </Link>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <DialogActions className={classes.spacing}>
        <Button
          data-testid="verify-team-edit-address"
          variant="contained"
          disableElevation
          onClick={handleCLose}
        >
          {verifyTeamEditAddBtn}
        </Button>
        <Button
          color="primary"
          variant="contained"
          disableElevation
          onClick={handleSubmit}
          data-testid="continue_btn"
        >
          {verifyTeamContAddBtn}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default VerifyTeamAddressDialog;

VerifyTeamAddressDialog.propTypes = {
  open: PropTypes.bool,
  users: PropTypes.instanceOf(Array),
  sugAdds: PropTypes.instanceOf(Array),
  prefAdds: PropTypes.instanceOf(Object),
  openAcc: PropTypes.func,
  handleCLose: PropTypes.func,
  setPrefAdds: PropTypes.func,
  onModalContinue: PropTypes.func,
};

VerifyTeamAddressDialog.defaultProps = {
  open: false,
  users: [],
  sugAdds: [],
  prefAdds: {},
  openAcc: defaultFnPropTypes,
  handleCLose: defaultFnPropTypes,
  setPrefAdds: defaultFnPropTypes,
  onModalContinue: defaultFnPropTypes,
};
