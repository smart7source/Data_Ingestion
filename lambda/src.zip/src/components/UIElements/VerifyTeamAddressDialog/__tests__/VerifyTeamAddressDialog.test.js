import { render, screen } from '@testing-library/react';
import strings from 'localization/translation';
import VerifyTeamAddressDialog from '../VerifyTeamAddressDialog';

describe('renders the <TableHeader /> component correctly', () => {
  render(<VerifyTeamAddressDialog open />);
  test('the dialog box renders correctly', () => {
    expect(screen.getByText(strings.verifyTeamAddress)).toBeInTheDocument();
    expect(screen.getByText(strings.verifyTeamUser)).toBeInTheDocument();
    expect(screen.getByText(strings.verifyTeamEditAddBtn)).toBeInTheDocument();
    expect(screen.getByText(strings.verifyTeamContAddBtn)).toBeInTheDocument();
  });
});
