import { Backdrop, Box } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';

const Spinner = ({ open, errorMessage }) => (
  <>
    <Backdrop open={open} className={classes.backdrop} data-testid="spinner">
      {open && (
        <img
          src={`${process.env.PUBLIC_URL}/images/transition/loader.gif`}
          alt="loader"
          width="75"
        />
      )}
      {errorMessage && (
        <Box display="flex" paddingLeft={1}>
          {errorMessage}
        </Box>
      )}
    </Backdrop>
  </>
);

export default Spinner;

Spinner.propTypes = {
  open: PropTypes.bool,
  errorMessage: PropTypes.string,
};

Spinner.defaultProps = {
  open: false,
  errorMessage: '',
};
