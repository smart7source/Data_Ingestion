import { Box } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';

import Spinner from '../Spinner/Spinner';

// To use this component you have to make sure the parent of this component has position relative style
const ComponentSpinner = ({ open, dataTestId }) => (
  <Box className={classes.componentSpinnerWrapper} height="100%" width="100%">
    <Spinner dataTestId={dataTestId} open={open} />
  </Box>
);

export default ComponentSpinner;

ComponentSpinner.propTypes = {
  open: PropTypes.bool,
  dataTestId: PropTypes.string,
};

ComponentSpinner.defaultProps = {
  open: false,
  dataTestId: '',
};
