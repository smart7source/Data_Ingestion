import { SvgIcon } from '@mui/material';
import { styled } from '@mui/material/styles';

const CustomizedIcon = styled(SvgIcon)(({ theme, color = '' }) => {
  const colorKeys = color.split('.');
  let exactColor = color;
  if (colorKeys.length > 1) {
    exactColor = colorKeys.reduce((acc, curr) => acc?.[curr], theme.palette);
  }
  return !exactColor ? '' : `${`color: ${exactColor};`}`;
});

const CustomIcon = (props) => <CustomizedIcon {...props} />;

export default CustomIcon;
