import { Box } from '@mui/material';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Checkmark } from 'assets/svg/checkmark.svg';
import classes from 'style/globalStyle.module.scss';

const LeftPanel = ({ curPageId, menu, hideLeftMenu }) => {
  const renderMenu = (item, index) => {
    let classesCustom = classes.leftMenuList;
    let icon = '';
    const eleIndex =
      menu.findIndex((ele) => ele.curPageIds.includes(curPageId)) || {};
    if (item.curPageIds.indexOf(curPageId) === -1) {
      if (Number(index + 1) < eleIndex + 1) {
        classesCustom = classes.fullActive;
        icon = (
          <CustomIcon
            component={Checkmark}
            color="grey.100"
            inheritViewBox
            className={classes.checkIcon}
          />
        );
      }
    } else {
      classesCustom = classes.active;
    }
    return (
      <li key={index} className={classesCustom}>
        {icon}
        {item.title}
      </li>
    );
  };
  return (
    <Box className={classes.leftBox}>
      {!hideLeftMenu && (
        <ul className={classes.leftUl}>
          {menu.map((item, index) => renderMenu(item, index))}
        </ul>
      )}
    </Box>
  );
};

export default LeftPanel;
LeftPanel.propTypes = {
  curPageId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  menu: PropTypes.arrayOf(PropTypes.any),
  hideLeftMenu: PropTypes.bool,
};
LeftPanel.defaultProps = {
  curPageId: 0,
  menu: [],
  hideLeftMenu: false,
};
