import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';

export const getOnBoardingStatus = rest.post(
  serviceUrl.loginApiPath,
  (req, res, ctx) =>
    res(
      ctx.status(200),
      ctx.json({
        body: {
          pageId: '3',
          onBoardingCompletionStatus: 'N',
          relationshipManagerLinked: 'N',
          accountCreated: 'N',
        },
      }),
    ),
);

const userManagementApiHandlers = [getOnBoardingStatus];

export default userManagementApiHandlers;
