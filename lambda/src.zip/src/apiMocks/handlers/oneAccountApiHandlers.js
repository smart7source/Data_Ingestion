import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';
import {
  chelloAccountsMock,
  allAccountsMock,
  oneAccountTransactionsMock,
  linkedAccountsMock,
  refDataMock,
  postDisputeApiMock,
  postOneAccountTransferMock,
  unlinkExternalBankAccountMock,
  exportedDataMock,
  linkedExportMock,
} from 'testHelpers';

export const getAllAccountDetails = rest.get(
  serviceUrl.getAllAccountDetails,
  (req, res, ctx) => res(ctx.json(allAccountsMock)),
);
export const getChelloAccountDetails = rest.get(
  serviceUrl.getChelloAccountDetails,
  (req, res, ctx) => res(ctx.json(chelloAccountsMock)),
);
export const getInternalAccountTransactions = rest.get(
  serviceUrl.getInternalAccountTransactions,
  (req, res, ctx) => res(ctx.json(oneAccountTransactionsMock)),
);
export const getExternalAccountTransactions = rest.get(
  serviceUrl.getExternalAccountTransactions,
  (req, res, ctx) => res(ctx.json(oneAccountTransactionsMock)),
);
export const getLinkedAccountDetails = rest.get(
  serviceUrl.getLinkedAccountDetails,
  (req, res, ctx) => res(ctx.json(linkedAccountsMock)),
);

export const getRefData = rest.get(
  serviceUrl.getReferenceData,
  (req, res, ctx) => {
    const refDataKey = req.url.searchParams.get('refDataKey');
    return res(ctx.json(refDataMock[refDataKey]));
  },
);

export const postDisputeApi = rest.post(
  serviceUrl.postDispute,
  (req, res, ctx) => res(ctx.json(postDisputeApiMock)),
);
export const postDisputeFileApi = rest.post(
  serviceUrl.postDisputeFiles,
  (req, res, ctx) => res(ctx.status(201)),
);

export const updateNickname = rest.put(
  serviceUrl.updateNickname,
  (req, res, ctx) => res(ctx.status(200)),
);

export const postOneAccountTransfer = rest.post(
  serviceUrl.postOneAccountTransfer,
  (req, res, ctx) => res(ctx.json(postOneAccountTransferMock)),
);

export const unlinkExternalBankAccount = rest.put(
  `${serviceUrl.unlinkExternalBankAccount}:id`,
  (req, res, ctx) => res(ctx.json(unlinkExternalBankAccountMock)),
);

export const getExportTransaction = rest.get(
  serviceUrl.getExportTransaction,
  (req, res, ctx) => res(ctx.json(exportedDataMock)),
);

export const getExportLinkedTransaction = rest.post(
  serviceUrl.getExportLinkedTransaction,
  (req, res, ctx) => res(ctx.json(linkedExportMock)),
);

const OneAccountApiHandlers = [
  getAllAccountDetails,
  getChelloAccountDetails,
  getInternalAccountTransactions,
  getExternalAccountTransactions,
  getLinkedAccountDetails,
  getRefData,
  postDisputeApi,
  postDisputeFileApi,
  updateNickname,
  unlinkExternalBankAccount,
  postOneAccountTransfer,
  getExportTransaction,
  getExportLinkedTransaction,
];

export default OneAccountApiHandlers;
