import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';

import FaqsMock from '../../testHelpers/mocks/FAQMocks';

const fetchFAQsData = rest.get(serviceUrl.helpcenterFaq, (req, res, ctx) =>
  res(ctx.json(FaqsMock)),
);

const helpdeskApiHandlers = [fetchFAQsData];

export default helpdeskApiHandlers;
