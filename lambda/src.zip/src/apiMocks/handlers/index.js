import oneAccountApiHandlers from './oneAccountApiHandlers';
import userManagementApiHandlers from './userManagementApiHandlers';
import fundingApiHandlers from './fundingApiHandlers';
import onBoardingApiHandlers from './onBoardingApiHandlers';
import helpCenterApiHandlers from './helpCenterApiHandlers';
import moneyMovementApiHandlers from './moneyMovementApiHandlers';
import settingsApiHandlers from './settingsApiHandlers';
import helpdeskApiHandlers from './helpdeskApiHandlers';

const handlers = [
  ...oneAccountApiHandlers,
  ...userManagementApiHandlers,
  ...fundingApiHandlers,
  ...onBoardingApiHandlers,
  ...helpCenterApiHandlers,
  ...moneyMovementApiHandlers,
  ...settingsApiHandlers,
  ...helpdeskApiHandlers,
];

export default handlers;
