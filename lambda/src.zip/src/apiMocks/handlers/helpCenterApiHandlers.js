import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';
import { getServiceTicketsMock, BookAppointmentMocks } from 'testHelpers';

const sendMessage = rest.post(serviceUrl.lexbotApi, (req, res, ctx) =>
  res(
    ctx.json({
      responseBody: {
        messages: [
          {
            contentType: 'PlainText',
            content: 'Hi im bot available 24/7',
          },
          {
            contentType: 'ImageResponseCard',
            imageResponseCard: {
              title: 'FAQ Response Card\u0003WELCOME',
              buttons: [
                {
                  text: 'How do I change my password?',
                  value: 'How to Change my Password?',
                },
              ],
            },
          },
        ],
      },
      sessionState: {
        sessionAttributes: {},
      },
    }),
  ),
);

export const getServiceTickets = rest.get(
  serviceUrl.getServiceTickets,
  (req, res, ctx) => res(ctx.json(getServiceTicketsMock)),
);

export const getDateTimeSlots = rest.post(
  serviceUrl.getDateTimeSlots,
  (req, res, ctx) => res(ctx.json(BookAppointmentMocks)),
);

export const postBookingAppointment = rest.post(
  serviceUrl.postBookingAppointment,
  (req, res, ctx) => req(ctx.json({})),
);

const helpCenterApiHandlers = [
  sendMessage,
  getDateTimeSlots,
  getServiceTickets,
];

export default helpCenterApiHandlers;
