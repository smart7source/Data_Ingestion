import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';
import {
  activeAccountsMock,
  getAllTransfersMock,
  putPostTransferMock,
  transferHistoryAPIMock,
  mmLinkedAccountsMock,
} from 'testHelpers';

export const getActiveAccounts = rest.get(
  serviceUrl.getActiveAccounts,
  (req, res, ctx) => res(ctx.json(activeAccountsMock)),
);

export const getAllTransfers = rest.get(
  serviceUrl.makeTransfer,
  (req, res, ctx) => res(ctx.json(getAllTransfersMock)),
);

export const postTransfer = rest.post(
  serviceUrl.makeTransfer,
  (req, res, ctx) => res(ctx.json(putPostTransferMock)),
);

export const putTransfer = rest.put(serviceUrl.makeTransfer, (req, res, ctx) =>
  res(ctx.json(putPostTransferMock)),
);

export const cancelTransfer = rest.delete(
  `${serviceUrl.cancelTransfer}/4hh3-ofwr80RFV--1F9F-8w-`,
  (req, res, ctx) => res(ctx.json(putPostTransferMock)),
);

export const transferHistoryAPI = rest.get(
  serviceUrl.getTransferActivity,
  (req, res, ctx) => res(ctx.json(transferHistoryAPIMock)),
);

export const getExternalBankAccountsMockAPI = rest.get(
  serviceUrl.getExternalBankAccounts,
  (req, res, ctx) => res(ctx.json(mmLinkedAccountsMock)),
);

const MoneyMovementApiHandlers = [
  getActiveAccounts,
  getAllTransfers,
  postTransfer,
  putTransfer,
  cancelTransfer,
  transferHistoryAPI,
  getExternalBankAccountsMockAPI,
];

export default MoneyMovementApiHandlers;
