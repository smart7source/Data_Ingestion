import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';

export const getPlaidToken = rest.post(
  serviceUrl.getPlaidToken,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          vendor: 'Plaid',
          token: 'link-sandbox-f56d49a7-77fc-4202-87ad-0c0298808efd',
          expiration: '2021-12-09T15:49:04Z',
          request_id: 'zwbWXLGE43Sy8dR',
        },
      }),
    ),
);

export const getLinkedAccounts = rest.get(
  serviceUrl.getLinkedAccountDetails,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: [],
      }),
    ),
);

export const getSoftwares = rest.get(
  serviceUrl.getCodatSoftwaresApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: { results: [{ logoUrl: 'logoUrl', name: 'xero' }] },
      }),
    ),
);

export const linkSoftware = rest.get(
  serviceUrl.linkIndSoftApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: { CDT_LINK: [{ codatLinkUrl: 'linkurl' }] },
      }),
    ),
);

const fundingApiHandlers = [getPlaidToken, getLinkedAccounts, getSoftwares];

export default fundingApiHandlers;
