import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';

const fetchPersonalInfo = rest.get(
  serviceUrl.getPersonalInfoApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        status: {
          code: '200',
          description: '',
        },
        body: {
          firstName: 'Andrew',
          lastName: 'Michael',
          phone: '16513325675',
          email: 'mandradi@lakewood.com',
          dob: '1982-04-12',
          ssn: '129343820',
          address: '21 Crest Ave',
          city: 'Lakewood',
          state: 'CA',
          zip: '92122',
          country: 'US',
          resStatus: '1',
          addrId: '4gpxGZkv4wTb1-----1F--o-',
        },
        header: {},
      }),
    ),
);

const updatePersonalInfo = rest.put(
  serviceUrl.getPersonalInfoApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          errorResponseList: [],
          successResponseList: [],
        },
      }),
    ),
);

const fetchPracticeInfo = rest.get(
  serviceUrl.getPracticeInfoAPi,
  (req, res, ctx) =>
    res(
      ctx.json({
        status: {
          code: '200',
          description: '',
        },
        body: {
          orgPhoneType: '1212',
          orgId: '6zViEzlHFUvXbdulEBB4LVQ6DkKWLBXgq7a0yiTIYnyDyGXXN5JZwA==',
          addrId: '4gpibkeC3coXXV----LF--o-',
          orgAddressLine1: '3700 Lake South Street',
          orgAddressLine2: 'line2tt',
          orgCityName: 'Lakewood',
          orgStateCode: 'CA',
          orgZipCode: '92312',
          orgPhoneNumber: '651-238-6535',
          orgTaxId: '78-8753244',
          orgEmail: 'info@lakewood.com',
          orgName: 'Lakewood Clinic',
          dbaName: 'The Clinic',
          percentOwnership: '51',
          establishedDate: '2000-12-12',
          opnStartDate: '2020-12-12',
          businessType: 'Clinic',
          opnCountry: 'USSA',
          naicNumber: '532',
          stateLegalInfo: 'CA',
          legalStructure: '1',
        },
        header: {},
      }),
    ),
);

const updatePracticeInfo = rest.put(
  serviceUrl.getPracticeInfoAPi,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          errorResponseList: [],
          successResponseList: [],
        },
      }),
    ),
);

const settingsApiHandlers = [
  fetchPersonalInfo,
  fetchPracticeInfo,
  updatePracticeInfo,
  updatePersonalInfo,
];

export default settingsApiHandlers;
