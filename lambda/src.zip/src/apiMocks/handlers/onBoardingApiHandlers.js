import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';
import {
  onBoardingStateMock,
  buildTeamData,
  signUpMock,
  teamPutPostAPIMockResponse,
  addOneAccountSuccessApiMock,
  getIntegrationsAPIMock,
  putCompaniesAPIMock,
} from 'testHelpers';

let response = onBoardingStateMock.onBoarding.payload.ADD_DOC_INFO;
response = response.map((item) => ({ ...item, uploadStatus: true }));

const responseHandler1 = (req, res, ctx) =>
  res(
    ctx.json({
      status: { code: '200', description: 'Record Edited' },
    }),
  );

const responseHandler2 = (req, res, ctx) =>
  res(
    ctx.json({
      body: {},
    }),
  );

const teamAPIResponseHandler = (req, res, ctx) =>
  res(
    ctx.json({
      body: teamPutPostAPIMockResponse.body,
    }),
  );

export const getUploadDocs = rest.get(
  serviceUrl.getUploadDocs,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: onBoardingStateMock.onBoarding.payload.ADD_DOC_INFO,
      }),
    ),
);

export const uploadSingleDoc = rest.post(
  serviceUrl.uploadSingleDoc,
  responseHandler1,
);

export const getAddPracinfoApiPath = rest.get(
  serviceUrl.getAddPracinfoApiPath,
  (req, res, ctx) =>
    res(
      ctx.json({
        status: { code: '200', description: 'Record Retrieved' },
        body: {
          establishedDate: '2022-01-04',
          opnStartDate: '2022-01-05',
          stateLegalInfo: '',
          legalStructure: '',
          businessType: '',
          naicNumber: '',
          opnCountry: 'US',
          certifyPracticeFlag: 'Y',
        },
      }),
    ),
);

export const getAuthTokenApi = rest.post(
  serviceUrl.authTokenApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        status: { code: '200', description: 'Record Retrieved' },
        body: {
          tpsUserEmail: 'tpsUserEmail@email.com',
          taxId: '123456789',
          tpsSiteId: 'tpsSiteId',
          tpsUserId: 'D025 ',
        },
      }),
    ),
);

export const putAddPracinfoApiPath = rest.put(
  serviceUrl.getAddPracinfoApiPath,
  (req, res, ctx) =>
    res(
      ctx.json({
        status: { code: '201', description: 'Record Edited' },
      }),
    ),
);

export const updatedPageNo = rest.put(
  serviceUrl.updatedPageNo,
  responseHandler1,
);

export const getTeamInfoApi = rest.get(
  serviceUrl.getTeamInfoApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        status: { code: '200', description: 'Record Edited' },
        body: buildTeamData,
      }),
    ),
);
export const postTeamInfoApi = rest.post(
  serviceUrl.getTeamInfoApi,
  teamAPIResponseHandler,
);

export const putTeamInfoApi = rest.put(
  serviceUrl.getTeamInfoApi,
  teamAPIResponseHandler,
);

export const delteTeamInfoApi = rest.delete(
  serviceUrl.getTeamInfoApi,
  responseHandler1,
);

export const getPracinfoApiPath = rest.get(
  serviceUrl.getPracinfoApiPath,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          ...onBoardingStateMock.onBoarding.payload.PRAC_INFO,
          action: 'edit',
        },
      }),
    ),
);

export const putPracinfoApiPath = rest.put(
  serviceUrl.getPracinfoApiPath,
  responseHandler2,
);

export const postPracinfoApiPath = rest.post(
  serviceUrl.getPracinfoApiPath,
  responseHandler2,
);

export const postPractieValidateApi = rest.post(
  serviceUrl.practieValidateApi,
  responseHandler2,
);

export const saveTpsProfileApiPath = rest.post(
  serviceUrl.saveTpsProfileApiPath,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: { message: 'Data saved successfully' },
      }),
    ),
);

export const getChelloTerms = rest.get(
  serviceUrl.consentChello,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          chelloTncFlag: false,
          chelloPvcyFlag: false,
        },
      }),
    ),
);

export const postChelloTerms = rest.post(
  serviceUrl.consentChello,
  responseHandler2,
);

export const getAccountTerms = rest.get(
  serviceUrl.consentAccount,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          acctTncFlag: false,
          acctPvcyFlag: false,
        },
      }),
    ),
);

export const postAccountTerms = rest.post(
  serviceUrl.consentAccount,
  responseHandler2,
);

export const submitApplication = rest.post(
  serviceUrl.submitApplicationApi,
  responseHandler2,
);

export const signUpApiPath = rest.post(
  serviceUrl.signUpApiPath,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: signUpMock,
      }),
    ),
);
export const verifyAddress = rest.post(
  serviceUrl.verifyAddress,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          address: {
            street: 'street1',
            city: 'city',
            region: 'state',
            zip: '12345',
          },
        },
      }),
    ),
);

export const registerAPI = rest.post(serviceUrl.setToken, responseHandler2);

export const getOnboardingStatus = rest.get(
  serviceUrl.onboardingStatusApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        status: { code: '200', description: 'Record Retrieved' },
        body: {
          accountCreated: 'N',
          kycKybResponseReceived: 'N',
          overallStatus: 'ACCOUNT_NOT_CREATED',
        },
      }),
    ),
);

export const verifyMember = rest.post(
  serviceUrl.verifyAddMember,
  responseHandler1,
);

export const addOneAccountApiMock = rest.post(
  serviceUrl.addOneAccountApi,
  (req, res, ctx) =>
    res(
      ctx.json({
        ...addOneAccountSuccessApiMock,
      }),
    ),
);

export const getCodatSoftwaresApiMock = rest.get(
  serviceUrl.getCodatSoftwaresApi,
  (req, res, ctx) => res(ctx.json({ body: getIntegrationsAPIMock.body })),
);

export const postCompaniesApiMock = rest.post(
  serviceUrl.linkIndSoftApi,
  responseHandler2,
);

export const putCompaniesApiMock = rest.put(
  serviceUrl.linkIndSoftApi,
  (req, res, ctx) => res(ctx.json({ body: putCompaniesAPIMock.body })),
);

export const getRelationshipmanagerDetails = rest.get(
  serviceUrl.getRelationshipmanager,
  (req, res, ctx) =>
    res(
      ctx.json({
        body: {
          businessPhones: ['91-8978046204'],
          displayName: 'Hemanth Palaka',
          givenName: 'Hemanth',
          jobTitle: 'Cognizant PEGA Resources',
          mail: 'co01906@orientalbank.com',
          surname: 'Palaka',
          userPrincipalName: 'co01906@orientalbank.com',
          id: '325cda5a-28ee-4e22-80ca-8bc1c4436fbe',
        },
      }),
    ),
);

const onBoardingApiHandlers = [
  getUploadDocs,
  uploadSingleDoc,
  getAddPracinfoApiPath,
  putAddPracinfoApiPath,
  updatedPageNo,
  getTeamInfoApi,
  postTeamInfoApi,
  putTeamInfoApi,
  delteTeamInfoApi,
  getPracinfoApiPath,
  putPracinfoApiPath,
  postPractieValidateApi,
  getAuthTokenApi,
  getChelloTerms,
  postChelloTerms,
  getAccountTerms,
  postAccountTerms,
  saveTpsProfileApiPath,
  signUpApiPath,
  submitApplication,
  registerAPI,
  verifyAddress,
  getOnboardingStatus,
  verifyMember,
  addOneAccountApiMock,
  postPracinfoApiPath,
  getCodatSoftwaresApiMock,
  postCompaniesApiMock,
  putCompaniesApiMock,
  getRelationshipmanagerDetails,
];

export default onBoardingApiHandlers;
