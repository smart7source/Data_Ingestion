import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';

import { accountTermsSchema } from 'helpers/ValidationSchema';
import strings from 'localization/translation';
import TermsNPolicy from 'containers/OnBoarding/components/TermsNPolicy';
import Footer from 'containers/OnBoarding/components/Footer';
import FormHead from 'containers/OnBoarding/components/FormHead';
import { routePath } from 'routes';
import { setLoader } from 'store/actions';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import RightPanelLayout from 'containers/OnBoarding/components/RightPanelLayout';
import { SingleNotification } from 'components';

const {
  tNcLable,
  tNcData,
  policyLabel,
  chelloTermsOfUse,
  chellopolicy,
  addUserFinalStep,
  addUserSubHeading,
  Viewfullterms,
  ViewfullPolicy,
  goToDashboard,
} = strings;

const termsCheckboxPropsRef = {
  id: 'acctTncFlag',
  name: 'acctTncFlag',
  label: chelloTermsOfUse,
};

const policyCheckboxPropsRef = {
  id: 'acctPvcyFlag',
  name: 'acctPvcyFlag',
  label: chellopolicy,
};

const termsTextAreaPropsRef = {
  id: 'tnc',
  label: tNcLable,
  name: 'tnc',
  data: tNcData,
};

const policyTextAreaPropsRef = {
  id: 'pnc',
  label: policyLabel,
  name: 'pnc',
  data: tNcData,
};
const { consentAccount } = serviceUrl;
const FinalStepComponent = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [error, setError] = useState({});
  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(accountTermsSchema),
  });

  const submitHandler = async (data) => {
    try {
      dispatch(setLoader(true));
      await ApiClient.post(consentAccount, data);
      history.push(routePath.DASHBOARD);
    } catch (err) {
      setError(err);
    } finally {
      dispatch(setLoader(false));
    }
  };
  return (
    <form
      onSubmit={handleSubmit(submitHandler)}
      data-testid="addUserFinalStepForm"
    >
      <RightPanelLayout maxWidth="600px">
        <SingleNotification error={error} />
        <FormHead heading={addUserFinalStep} subHeading={addUserSubHeading} />

        <TermsNPolicy
          control={control}
          errors={errors}
          textareaProps={termsTextAreaPropsRef}
          checkboxProps={termsCheckboxPropsRef}
          linkName={Viewfullterms}
        />
        <TermsNPolicy
          control={control}
          errors={errors}
          textareaProps={policyTextAreaPropsRef}
          checkboxProps={policyCheckboxPropsRef}
          linkName={ViewfullPolicy}
        />
      </RightPanelLayout>
      <Footer
        exitBtn={false}
        continueEnable={isValid}
        continueBtnName={goToDashboard}
      />
    </form>
  );
};

export default FinalStepComponent;
