import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import FinalStepComponent from '../FinalStepComponent';
import { createMemoryHistory } from 'history';
import { cognitoCurrentSessionMock, cognitoUserMock } from 'testHelpers';
import Auth from '@aws-amplify/auth';
import { Router } from 'react-router-dom';

const history = createMemoryHistory();
const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const initialState = {
  onBoarding: {
    payload: {
      siteId: '',
      curPageId: '22',
      AGRMNT_INFO: {
        acctTncFlag: true,
        acctPvcyFlag: true,
      },
    },
  },
};
const store = configureStore(initialState);

describe('Testing FinalStepComponent screen', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    await act(async () =>
      render(
        <Provider store={store}>
          <Router history={history}>
            <FinalStepComponent />
          </Router>
        </Provider>,
      ),
    );
  });

  it('should render initial filled data', () => {
    const heading = screen.getByText(strings.addUserFinalStep);
    expect(heading).toBeInTheDocument();
    const subHeading = screen.getByText(strings.addUserSubHeading);
    expect(subHeading).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', {
      name: strings.goToDashboard,
    });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).toBeDisabled();
  });

  test('enable checkbox and disable', async () => {
    const checkbox = screen.getByRole('checkbox', {
      name: strings.chelloTermsOfUse,
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    expect(
      screen.getByText(strings.acceptFieldRequiredMsg),
    ).toBeInTheDocument();
  });

  test('enable checkbox and disable policy', async () => {
    const checkbox = screen.getByRole('checkbox', {
      name: strings.chellopolicy,
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    expect(
      screen.getByText(strings.policyFieldRequiredMsg),
    ).toBeInTheDocument();
  });

  test('submit form', async () => {
    const terms = screen.getByRole('checkbox', {
      name: strings.chellopolicy,
    });

    const policy = screen.getByRole('checkbox', {
      name: strings.chelloTermsOfUse,
    });
    await act(async () => {
      fireEvent.click(terms);
      fireEvent.click(policy);
    });
    const continueBtn = screen.getByRole('button', {
      name: strings.goToDashboard,
    });
    expect(continueBtn).toBeEnabled();
    await act(async () => fireEvent.click(continueBtn));

    await waitFor(() => {
      expect(history.location.pathname).toBe(routePath.DASHBOARD);
    });
  });
});
