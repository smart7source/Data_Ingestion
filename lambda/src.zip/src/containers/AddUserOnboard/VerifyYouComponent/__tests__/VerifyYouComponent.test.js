import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { rest } from 'msw';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import VerifyYouComponent from '../VerifyYouComponent';
import { createMemoryHistory } from 'history';
import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  mockMatchMediaToDesktop,
} from 'testHelpers';
import Auth from '@aws-amplify/auth';
import { Router } from 'react-router-dom';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';

const history = createMemoryHistory();
const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const initialState = {
  onBoarding: {
    payload: {
      siteId: '',
      curPageId: '21',
    },
  },
};
const store = configureStore(initialState);

describe('Testing VerifyYouComponent screen', () => {
  beforeAll(async () => {
    mockMatchMediaToDesktop();
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    await act(async () =>
      render(
        <Provider store={store}>
          <Router history={history}>
            <VerifyYouComponent />
          </Router>
        </Provider>,
      ),
    );
  });

  it('should render heading and labels ', () => {
    const heading = screen.getByText(strings.verifyYouHeading);
    expect(heading).toBeInTheDocument();

    const dateOfBirth = screen.getByLabelText(strings.birthDate);
    expect(dateOfBirth).toBeInTheDocument();
    expect(dateOfBirth).toHaveValue('');
    const lastSSN = screen.getByLabelText(strings.last4DigitSSN);
    expect(lastSSN).toBeInTheDocument();
    expect(lastSSN).toHaveValue('');
    const continueBtn = screen.getByRole('button', {
      name: strings.continue,
    });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).toBeDisabled();
  });

  it('continue to be disbaled if DOB is a minor', async () => {
    fireEvent.click(screen.getByLabelText('Choose date'));
    await waitFor(() => expect(screen.getByRole('dialog')).toBeInTheDocument());
    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    const today = new Intl.DateTimeFormat('en-US', options).format(new Date());
    await act(async () => fireEvent.click(screen.getByLabelText(today)));
    const continueBtn = screen.getByTestId('footer-nav-continue-btn');
    expect(continueBtn).not.toBeEnabled();
  });

  it('fill the form continue to be disbaled as DOB is not Valid', async () => {
    const dateField = screen.getByTestId('addUserBirthDate');
    userEvent.clear(dateField);
    userEvent.type(dateField, '01/01/1990');
    const ssnField = screen.getByLabelText(strings.last4DigitSSN);
    await act(async () => {
      fireEvent.change(ssnField, {
        target: { value: '1234' },
      });
    });
    const continueBtn = screen.getByTestId('footer-nav-continue-btn');
    expect(continueBtn).toBeEnabled();
  });

  it('Should submit form and handle API failed error', async () => {
    server.use(
      rest.post(serviceUrl.verifyAddMember, (req, res, ctx) => {
        res.networkError('Failed to connect');
      }),
    );
    const form = screen.getByTestId('verifyYouForm');
    await act(async () => fireEvent.submit(form));
  });

  it('Should submit form and redirect', async () => {
    const form = screen.getByTestId('verifyYouForm');
    await act(async () => fireEvent.submit(form));
    await waitFor(() => {
      expect(history.location.pathname).toBe(routePath.ADDUSER_TERMS);
    });
  });
});
