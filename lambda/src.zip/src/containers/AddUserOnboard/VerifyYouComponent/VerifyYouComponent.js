import { useState } from 'react';
import { Box } from '@mui/material';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import moment from 'moment';

import { DatePicker, NumberInput, SingleNotification } from 'components';
import { verifyYouComponentValidationSchema } from 'helpers/ValidationSchema';
import FormHead from 'containers/OnBoarding/components/FormHead';
import NotificationLink from 'containers/OnBoarding/components/NotificationLink';
import ApiClient from 'api/ApiClient';
import strings from 'localization/translation';
import Footer from 'containers/OnBoarding/components/Footer';
import { setLoader } from 'store/actions';
import RightPanelLayout from 'containers/OnBoarding/components/RightPanelLayout';
import { routePath } from 'routes';
import { verifyYouAddUserPgInfo } from 'helpers/URLConfiguration';
import serviceUrl from 'api/UrlHelper';
import { useOnboarding } from 'hooks';
import { isValidDateofBirth } from 'utils';

const { verifyAddMember } = serviceUrl;
const {
  verifyYouHeading,
  verifyYouSubText,
  birthDate,
  last4DigitSSN,
  dobFailed,
} = strings;
const { pageId } = verifyYouAddUserPgInfo;
const VerifyYouComponent = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [error, setError] = useState({});
  const [showDOBError, setShowDOBError] = useState(false);
  const { exitHandler } = useOnboarding({ pageId });
  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(verifyYouComponentValidationSchema),
  });

  const submitHandler = async (data) => {
    try {
      dispatch(setLoader(true));
      const updatedData = {
        ...data,
        dob: moment(data.dob).format('yyyy-MM-DD'),
      };
      await ApiClient.post(verifyAddMember, updatedData);
      history.push(routePath.ADDUSER_TERMS);
    } catch (e) {
      setError(e);
    } finally {
      dispatch(setLoader(false));
    }
  };

  const handleDateofBirthChange = (value) => {
    if (value) {
      const isValidDOB = isValidDateofBirth(value);
      if (!isValidDOB) {
        setShowDOBError(true);
      } else {
        setShowDOBError(false);
      }
    }
  };

  return (
    <form onSubmit={handleSubmit(submitHandler)} data-testid="verifyYouForm">
      <RightPanelLayout maxWidth="600px">
        <SingleNotification error={error} />
        <FormHead heading={verifyYouHeading} subHeading={verifyYouSubText} />
        {showDOBError && <NotificationLink msg={dobFailed} />}
        <Box>
          <DatePicker
            dataTestid="addUserBirthDate"
            name="dob"
            id="dob"
            fullWidth={false}
            label={birthDate}
            control={control}
            error={!!errors.dob}
            errorText={errors.dob && errors.dob.message}
            maxDateValue={new Date()}
            returnDateFormat="yyyy-MM-DD"
            callback={handleDateofBirthChange}
          />
        </Box>
        <Box>
          <NumberInput
            label={last4DigitSSN}
            name="ssn"
            id="ssn"
            decimalScale={0}
            thousandSeparator={false}
            isAllowed={({ formattedValue }) => formattedValue.length <= 4}
            control={control}
            fullWidth={false}
            error={!!errors.ssn}
            errorText={errors.ssn && errors.ssn.message}
            inputProps={{ autoComplete: 'off' }}
            dataTestId="last4digitSSN"
          />
        </Box>
      </RightPanelLayout>
      <Footer
        saveHandler={() => exitHandler({ saveData: false })}
        backBtn={false}
        continueEnable={isValid && !showDOBError}
      />
    </form>
  );
};

export default VerifyYouComponent;
