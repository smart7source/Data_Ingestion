import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import { rest } from 'msw';
import { Router } from 'react-router-dom';

import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  onBoardingStateMock,
  mockUseHistory,
  onBoardingStateEmptyMock,
} from 'testHelpers';
import serviceUrl from 'api/UrlHelper';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import Auth from '@aws-amplify/auth';
import BuildTeam from '../BuildTeam';
import { createMemoryHistory } from 'history';
import server from 'apiMocks/server';
import userEvent from '@testing-library/user-event';

const history = createMemoryHistory();
const teamInfo = onBoardingStateMock.onBoarding.payload.BUILD_TEAM_INFO;

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('Render async Build Team component', () => {
  const mockStore = configureStore(onBoardingStateEmptyMock);
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <BuildTeam />
          </Router>
        </Provider>,
      ),
    );
  });
  // test('render component with inital data', async () => {
  //   await waitFor(() => {
  //     expect(screen.getByText(strings.buildTeamHeading)).toBeInTheDocument();
  //     const percentageOwnership = screen.getByTestId('percentage_0');
  //     expect(percentageOwnership).toBeEnabled();
  //     expect(percentageOwnership).toHaveValue(50);
  //     const continueBtn = screen.getByRole('button', { name: /continue/i });
  //     expect(continueBtn).toBeInTheDocument();
  //     expect(continueBtn).toBeEnabled();
  //   });
  // });

  test('should open exit dialog and save partial information', async () => {
    await waitFor(async () => {
      const exitBtn = screen.getByRole('button', { name: strings.exit });
      expect(exitBtn).toBeDefined();
      await act(async () => {
        fireEvent.click(exitBtn);
      });
      expect(screen.getByTestId('onboarding-exit-dialog')).toBeInTheDocument();
      expect(
        screen.getByText(strings.exitDialogSaveAndExit),
      ).toBeInTheDocument();
      const exitDialogSaveAndExitBtn = screen.getByRole('button', {
        name: strings.exitDialogSaveAndExit,
      });
      await act(async () => {
        fireEvent.click(exitDialogSaveAndExitBtn);
      });
    });
  });
  it('should give error message if ownership is more than 100%', async () => {
    await waitFor(async () => {
      const percentageOwnership1 = screen.getByTestId('percentage_0');
      await act(async () => {
        fireEvent.change(percentageOwnership1, { target: { value: '150' } });
      });
      const percentageOwnership2 = screen.getByTestId('percentage_0');
      expect(percentageOwnership2).toHaveValue(150);
    });
  });
  test('enable and disable percentage field on role change', async () => {
    await waitFor(async () => {
      const primaryRole = screen.getByTestId('primaryRole_0');
      await act(async () => {
        fireEvent.change(primaryRole, { target: { value: '2' } });
      });
      const percentageOwnership2 = screen.getByTestId('percentage_0');
      expect(percentageOwnership2).toBeDisabled();
    });
  });
  it('should open Add team Member form', async () => {
    await waitFor(async () => {
      const addTeamMemBtn = screen.getByRole('link', {
        name: /Add a team member not listed here/i,
      });
      expect(addTeamMemBtn).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(addTeamMemBtn);
      });

      expect(screen.getByLabelText('First name')).toBeInTheDocument();
      expect(screen.getByLabelText('Last name')).toBeInTheDocument();
      expect(screen.getByLabelText('Email')).toBeInTheDocument();
      expect(screen.getByTestId('id-role')).toBeInTheDocument();
      expect(
        screen.getByRole('button', { name: 'Cancel' }),
      ).toBeInTheDocument();
      expect(
        screen.getByRole('button', { name: 'Save team member' }),
      ).toBeInTheDocument();
    });
  });
  it('should close Add team Member form Modal', async () => {
    await waitFor(async () => {
      const addTeamMemBtn = screen.getByRole('link', {
        name: /Add a team member not listed here/i,
      });
      expect(addTeamMemBtn).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(addTeamMemBtn);
      });
      await act(async () => {
        fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
      });
      expect(screen.queryByTestId('addNewMemberFrm')).not.toBeInTheDocument();
    });
  });
  test('Api failed on submit form', async () => {
    await waitFor(async () => {
      server.use(
        rest.put(serviceUrl.getTeamInfoApi, (req, res, ctx) => {
          res.networkError('Failed to connect');
        }),
      );
      const continueBtn = screen.getByRole('button', { name: /continue/i });
      expect(continueBtn).not.toBeDisabled();
      await act(async () => {
        fireEvent.click(continueBtn);
      });
    });
  }, 30000);
  it('should open Add team Member form and submit main form', async () => {
    await waitFor(async () => {
      const addTeamMemBtn = screen.getByRole('link', {
        name: /Add a team member not listed here/i,
      });
      expect(addTeamMemBtn).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(addTeamMemBtn);
      });
      const firstName = screen.getByLabelText(strings.firstName);
      const lastName = screen.getByLabelText(strings.lastName);
      const email = screen.getByLabelText(strings.email);
      const indPrimaryRole = screen.getByTestId('indPrimaryRole');
      const percentageOwnership = screen.getByLabelText(
        strings.percentageOwnership,
      );
      await act(async () => {
        fireEvent.change(firstName, { target: { value: 'firstName' } });
        fireEvent.change(lastName, { target: { value: 'lastName' } });
        fireEvent.change(email, { target: { value: 'email@email.com' } });
        fireEvent.change(indPrimaryRole, { target: { value: '1' } });
        fireEvent.change(percentageOwnership, { target: { value: '40' } });
      });
      const form = screen.getByTestId('addNewMemberFrm');
      await act(async () => {
        fireEvent.submit(form);
      });
      expect(
        screen.getByText(new RegExp('firstName', 'i')),
      ).toBeInTheDocument();
      const mainFrm = screen.getByTestId('form');
      await act(async () => {
        fireEvent.submit(mainFrm);
      });
    });
  });
});
