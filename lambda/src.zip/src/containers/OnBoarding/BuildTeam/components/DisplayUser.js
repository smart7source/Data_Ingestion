import { Typography, Grid, Box } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';
import internalClasses from 'style/onBoarding.module.scss';

const { buildTeamYou } = strings;
export default function DisplayUser({
  ele: { firstName, lastName, email, primaryApplicant },
}) {
  return (
    <Grid item xs={6} md={4} lg={4} xl={4}>
      <Box display="flex">
        <Box className={classes.teamImg} mr={2}>
          <img
            src={`${process.env.PUBLIC_URL}/images/profile.png`}
            alt="profile"
          />
        </Box>
        <Box>
          <Typography variant="p1SemiBold" component="p">
            {firstName} {lastName}{' '}
            {primaryApplicant === 'Y' && (
              <Typography component="span" variant="p1SemiBold" color="primary">
                {buildTeamYou}
              </Typography>
            )}
          </Typography>
          <Typography variant="p2" className={internalClasses.buildTeamEmail}>
            {email}
          </Typography>
        </Box>
      </Box>
    </Grid>
  );
}

DisplayUser.propTypes = {
  ele: PropTypes.instanceOf(Object),
};
DisplayUser.defaultProps = {
  ele: {},
};
