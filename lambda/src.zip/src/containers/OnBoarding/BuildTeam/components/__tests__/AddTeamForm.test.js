import { fireEvent, render, act, screen } from '@testing-library/react';

import AddTeamForm from '../AddTeamForm';
import { onBoardingStateMock } from 'testHelpers';
import strings from 'localization/translation';

describe('should render <AddTeamForm /> component', () => {
  const jestFn = jest.fn();
  const defaultProps = {
    handleModalSubmit: jestFn,
    handleModalClose: jestFn,
    roles: onBoardingStateMock.global.refData.CHELLO_INDIVIDUAL_ROLE,
  };
  beforeEach(() => render(<AddTeamForm {...defaultProps} />));
  afterEach(() => {
    jest.clearAllMocks();
    jest.resetAllMocks();
  });

  it('should render fields in the modal', async () => {
    expect(screen.getByTestId('addNewMemberFrm')).toBeInTheDocument();
    const firstName = screen.getByLabelText(strings.firstName);
    const lastName = screen.getByLabelText(strings.lastName);
    const email = screen.getByLabelText(strings.email);
    const indPrimaryRole = screen.getByTestId('indPrimaryRole');
    const percentageOwnership = screen.getByLabelText(
      strings.percentageOwnership,
    );
    await act(async () => {
      fireEvent.change(firstName, { target: { value: 'firstName' } });
      fireEvent.change(lastName, { target: { value: 'lastName' } });
      fireEvent.change(email, { target: { value: 'email@email.com' } });
      fireEvent.change(indPrimaryRole, { target: { value: '1' } });
      fireEvent.change(percentageOwnership, { target: { value: '40' } });
    });
    await act(async () => {
      fireEvent.submit(screen.getByTestId('addNewMemberFrm'));
    });
    expect(jestFn).toHaveBeenCalled();
  });
  test('enable and disable percentage field on role change', async () => {
    const primaryRole = screen.getByTestId('indPrimaryRole');
    await act(async () => {
      fireEvent.change(primaryRole, { target: { value: '2' } });
    });
    const percentageOwnership2 = screen.getByLabelText(
      strings.percentageOwnership,
    );
    expect(percentageOwnership2).toBeDisabled();
  });
});
