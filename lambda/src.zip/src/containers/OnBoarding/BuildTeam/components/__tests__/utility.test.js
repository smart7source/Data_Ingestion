import getErrorsArr from '../utility';
import strings from '../../../../../localization/translation';

describe('Test getErrorsArr function', () => {
  it('should return no error messages when additional user info is correct', () => {
    const additionalUsers = [
      {
        firstName: 'Kate',
        lastName: 'Chow',
        email: 'kchow@lakewood.com',
        role: '1',
        percentageOwnership: 45,
        controlingPerson: true,
      },
    ];

    const expectedResult = [
      { message: false },
      // { message: false },
      // { message: false },
      { message: false },
      { message: false },
      { message: false },
    ];

    const errors = getErrorsArr(additionalUsers);
    expect(errors).toEqual(expectedResult);
  });

  it('should return correct error messages', () => {
    const additionalUsers = [
      {
        firstName: 'Kate',
        lastName: 'Chow',
        email: 'kchow@lakewood.com',
        role: '1',
        percentageOwnership: 145,
        controlingPerson: false,
      },
    ];

    const expectedResult = [
      { message: strings.atleastOne },
      // { message: false },
      // { message: false },
      { message: strings.notificationAlert1 },
      { message: false },
      { message: false },
    ];

    const errors = getErrorsArr(additionalUsers);
    expect(errors).toEqual(expectedResult);
  });

  it('should return correct error messages for owner percentage < 25', () => {
    const additionalUsers = [
      {
        firstName: 'Kate',
        lastName: 'Chow',
        email: 'kchow@lakewood.com',
        role: '1',
        percentageOwnership: 15,
        controlingPerson: true,
      },
    ];

    const expectedResult = [
      { message: false },
      // { message: false },
      // { message: false },
      { message: false },
      { message: strings.hasOwnerPer },
      { message: false },
    ];

    const errors = getErrorsArr(additionalUsers);
    expect(errors).toEqual(expectedResult);
  });
  it('should not return error messages for if primaryApplicant === "None of the above"', () => {
    const additionalUsers = [
      {
        firstName: 'Kate',
        lastName: 'Chow',
        email: 'kchow@lakewood.com',
        role: '0',
        percentageOwnership: 55,
        controlingPerson: true,
      },
    ];

    const expectedResult = [
      { message: false },
      // { message: false },
      // { message: strings.ownerRoleError },
      { message: false },
      { message: false },
      { message: false },
    ];

    const errors = getErrorsArr(additionalUsers);
    expect(errors).toEqual(expectedResult);
  });
});
