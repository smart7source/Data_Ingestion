import { screen, render } from '@testing-library/react';
import TableHeading from '../TableHeading';
import strings from '../../../../../localization/translation';

describe('Rendering <TableHeading /> component', () => {
  it('should render the compoent correctly', () => {
    render(<TableHeading />);
    expect(screen.getByText(/name and email/i)).toBeInTheDocument();
    expect(screen.getByText(/primary role/i)).toBeInTheDocument();
    expect(screen.getByText(/ownership/i)).toBeInTheDocument();
    expect(screen.getByText(/controlling person/i)).toBeInTheDocument();
  });
});
