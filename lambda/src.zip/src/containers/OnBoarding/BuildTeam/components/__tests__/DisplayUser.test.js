import { screen, render } from '@testing-library/react';
import DisplayUser from '../DisplayUser';

const user = {
  firstName: 'John',
  lastName: 'Doe',
  email: 'johndoe@gmail.com',
  primaryApplicant: 'Y',
};
describe('Rendering <DisplayUser /> component', () => {
  it('should render the compoent correctly', () => {
    render(<DisplayUser ele={user} index={1} />);
    expect(screen.getByText(/john doe/i)).toBeInTheDocument();
    expect(screen.getByText(/johndoe@gmail.com/i)).toBeInTheDocument();
    expect(screen.getByAltText(/profile/i)).toBeInTheDocument();
  });
  it('should render the compoent correctly', () => {
    render(<DisplayUser ele={user} index={0} />);
    expect(screen.getByText(/john doe/i)).toBeInTheDocument();
    expect(screen.getByText(/johndoe@gmail.com/i)).toBeInTheDocument();
    expect(screen.getByAltText(/profile/i)).toBeInTheDocument();
    expect(screen.getByText(/(You)/i)).toBeInTheDocument();
  });
});
