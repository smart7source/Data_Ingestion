import { buildTeamFormError } from 'utils';
import strings from 'localization/translation';

const {
  atleastOne,
  ownershipPerError,
  hasRoleError,
  hasOwnerPer: HAS_OWNER_PER,
} = strings;
const getErrorsArr = (users) => {
  const { hasControllingPerson, hasOwnerPer, hasRole, total } =
    buildTeamFormError(users);

  return [
    { message: !hasControllingPerson && atleastOne },
    {
      message: total > 100 && ownershipPerError,
    },
    {
      message: hasOwnerPer && HAS_OWNER_PER,
    },
    {
      message: hasRole && hasRoleError,
    },
  ];
};

export default getErrorsArr;
