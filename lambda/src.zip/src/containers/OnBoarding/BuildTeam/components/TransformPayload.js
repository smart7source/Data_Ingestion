export const transformResponse = (data) => {
  const { errorResponseList = [] } = data || {};
  return errorResponseList.map((item) => {
    const { errorMessage, value } = item;
    const { firstName, lastName } = value;
    return {
      severity: 'error',
      message: `${firstName} ${lastName} ${errorMessage}`,
    };
  });
};

export const transformAPIPayload = (
  formData,
  savedUserData,
  saveAndExit = false,
  tempRemovedMembers = [],
  teamFlag = false,
) => {
  const mergedData = [...formData, ...savedUserData];

  let allUsers = [];
  if (teamFlag) {
    allUsers = [
      ...mergedData
        .reduce((map, obj) => map.set(obj.tpsMemberId, obj), new Map())
        .values(),
    ];
  } else {
    allUsers = [
      ...mergedData
        .reduce((map, obj) => map.set(obj.uniqueId, obj), new Map())
        .values(),
    ];
  }

  const newMembers = [];
  const deletedMembers = [];
  const existingMembers = [];
  const removedMembers = tempRemovedMembers?.map((item) => {
    const { uniqueId, id, ...restItems } = item;
    return restItems;
  });

  allUsers.forEach((ele) => {
    const { uniqueId, id, ...rest } = ele;
    if (ele.memberId === '' && !ele.removed) {
      newMembers.push(rest);
    } else if (ele.removed) {
      const { removed, ...item } = rest;
      deletedMembers.push(item);
    } else if (ele.memberId !== '' && !ele.removed) {
      existingMembers.push(rest);
    }
  });

  return {
    delete: [...deletedMembers, ...removedMembers],
    put: [...existingMembers],
    post: [...newMembers],
    saveAndExit,
    ...(!saveAndExit && { allUsers }),
  };
};
