import { Grid, Button, TextField, MenuItem, InputLabel } from '@mui/material';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import PropTypes from 'prop-types';

import { addTeamValidationSchema } from 'helpers/ValidationSchema';
import strings from 'localization/translation';
import { CustomInput, CustomCheckbox, PercentageInput } from 'components';

const {
  firstName,
  lastName,
  email,
  addTeamFormPrimaryRole,
  addTeamFormSelect,
  percentageOwnership,
  controlingPerson,
  cancel,
  addTeamFormDone,
} = strings;
export default function AddTeamForm(props) {
  const { handleModalSubmit, handleModalClose, roles } = props;

  const {
    control,
    watch,
    resetField,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(addTeamValidationSchema),
  });

  const submitHandler = (data) => {
    handleModalSubmit(data);
  };
  const handleClose = () => {
    handleModalClose();
  };

  const handleOwnership = (value) => {
    if (value !== '1') {
      resetField('percentageOwnership');
    }
  };

  return (
    <form onSubmit={handleSubmit(submitHandler)} data-testid="addNewMemberFrm">
      <Grid container spacing={2}>
        <Grid item xs={6} xl={6}>
          <CustomInput
            label={firstName}
            error={!!errors.firstName}
            errorText={errors.firstName && errors.firstName.message}
            name="firstName"
            id="firstName"
            control={control}
            inputProps={{ maxLength: 50 }}
          />
        </Grid>
        <Grid item xs={6} xl={6}>
          <CustomInput
            label={lastName}
            error={!!errors.lastName}
            errorText={errors.lastName && errors.lastName.message}
            name="lastName"
            id="lastName"
            control={control}
            inputProps={{ maxLength: 50 }}
          />
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid item xs={6} xl={6}>
          <CustomInput
            label={email}
            error={!!errors.email}
            errorText={errors.email && errors.email.message}
            name="email"
            id="email"
            control={control}
          />
        </Grid>
        <Grid item xs={6} xl={3}>
          <InputLabel htmlFor="role" id="role">
            {addTeamFormPrimaryRole}
          </InputLabel>
          <Controller
            name="role"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                onChange={(e) => {
                  field.onChange(e.target.value);
                  handleOwnership(e.target.value);
                }}
                value={field?.value || ''}
                autoComplete="off"
                variant="outlined"
                size="small"
                fullWidth
                margin="dense"
                select
                inputProps={{ 'data-testid': 'indPrimaryRole' }}
                error={!!errors.role}
                helperText={errors.role && errors.role.message}
                SelectProps={{
                  SelectDisplayProps: {
                    'data-testid': 'id-role',
                  },
                }}
              >
                <MenuItem data-testid="default-option" value="" selected>
                  {addTeamFormSelect}
                </MenuItem>
                {roles.map((ele1, index1) => (
                  <MenuItem
                    data-testid="option"
                    value={ele1.value}
                    key={index1}
                  >
                    {ele1.name}
                  </MenuItem>
                ))}
              </TextField>
            )}
          />
        </Grid>
        <Grid item xs={6} xl={3}>
          <PercentageInput
            error={!!errors.percentageOwnership}
            errorText={
              errors.percentageOwnership && errors.percentageOwnership.message
            }
            name="percentageOwnership"
            id="percentageOwnership"
            control={control}
            margin="dense"
            label={percentageOwnership}
            disabled={watch('role') !== '1'}
            inputProps={{
              'data-testid': 'percentageOwnership',
            }}
          />
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid item xl={6}>
          <CustomCheckbox
            name="controlingPerson"
            id="controlingPerson"
            defaultValue={false}
            control={control}
            label={controlingPerson}
            error={!!errors.controlingPerson}
            errorText={
              errors.controlingPerson && errors.controlingPerson.message
            }
          />
        </Grid>
      </Grid>
      <Grid container>
        <Grid item xs={6}>
          <Button variant="contained" onClick={handleClose}>
            {cancel}
          </Button>
        </Grid>
        <Grid item xs={6} container justifyContent="end">
          <Button variant="contained" color="primary" type="submit">
            {addTeamFormDone}
          </Button>
        </Grid>
      </Grid>
    </form>
  );
}

AddTeamForm.propTypes = {
  handleModalSubmit: PropTypes.func.isRequired,
  handleModalClose: PropTypes.func.isRequired,
  roles: PropTypes.arrayOf(PropTypes.any),
};
AddTeamForm.defaultProps = {
  roles: [],
};
