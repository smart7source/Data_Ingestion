import { Typography, Grid } from '@mui/material';

import strings from 'localization/translation';
import internalClasses from 'style/onBoarding.module.scss';

const { nameAndEmail, primaryRole, ownership, controlingPerson } = strings;
export default function TableHeading() {
  return (
    <Grid container className={internalClasses.buildTeamTableHeading}>
      <Grid item container xs={6} md={4} lg={4} xl={4} alignItems="center">
        <Typography variant="h3">{nameAndEmail}</Typography>
      </Grid>
      <Grid item container xs={6} md={3} lg={3} xl={3} alignItems="center">
        <Typography variant="h3">{primaryRole}</Typography>
      </Grid>
      <Grid item container xs={6} md={2} lg={2} xl={2} alignItems="center">
        <Typography variant="h3">{ownership}</Typography>
      </Grid>
      <Grid item container xs={6} md={2} lg={2} xl={2} alignItems="center">
        <Typography component="p" variant="h3">
          {controlingPerson}
        </Typography>
      </Grid>
      <Grid item xs={0} md={1} lg={1} xl={1} />
    </Grid>
  );
}
