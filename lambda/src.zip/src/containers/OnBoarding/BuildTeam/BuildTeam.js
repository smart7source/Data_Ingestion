/* eslint-disable max-lines */
import { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Link,
  Grid,
  TextField,
  MenuItem,
} from '@mui/material';
import { Controller, useFieldArray, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch, useSelector } from 'react-redux';

import { buildTeamFormError, getRandomNumber } from 'utils';
import { useOnboarding, useRefData } from 'hooks';
import classes from 'style/globalStyle.module.scss';
import { buildTeamValidationSchema } from 'helpers/ValidationSchema';
import { buildTeamPgInfo } from 'helpers/URLConfiguration';
import strings from 'localization/translation';
import {
  CustomCheckbox,
  PercentageInput,
  Notification,
  CustomInput,
} from 'components';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { setLoader } from 'store/actions';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as PlusCircle } from 'assets/svg/plus-circle.svg';
import internalClasses from 'style/onBoarding.module.scss';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';

import {
  transformResponse,
  transformAPIPayload,
} from './components/TransformPayload';
import getErrorsArr from './components/utility';
import TableHeading from './components/TableHeading';
import DisplayUser from './components/DisplayUser';
import AddTeamForm from './components/AddTeamForm';

const {
  buildTeamHeading,
  buildTeamSubHeading,
  addTeamMember,
  remove: REMOVE,
} = strings;
const { pageId, pageKey } = buildTeamPgInfo;
const { getTeamInfoApi } = serviceUrl;
const BuildTeam = () => {
  const [open, setOpen] = useState(false);
  const [errMsgs, setErrMsgs] = useState([]);
  const [savedUsers, setSavedUsers] = useState([]);
  const [deletedMembers, setDeletedMembers] = useState([]);
  const payload = useSelector((state) => state.onBoarding.payload);
  const refData = useSelector((state) => state.global.refData);
  const { CHELLO_INDIVIDUAL_ROLE = [] } = refData;
  const dispatch = useDispatch();
  useRefData(['CHELLO_INDIVIDUAL_ROLE']);
  const { saveDataInRedux, exitHandler } = useOnboarding({
    pageId,
    url: getTeamInfoApi,
    pageKey,
    curPageId: payload.curPageId,
  });

  const {
    control,
    watch,
    reset,
    getValues,
    handleSubmit,
    formState: { errors },
    clearErrors,
  } = useForm({
    mode: 'all',
    resolver: yupResolver(buildTeamValidationSchema),
  });

  const { fields, append, remove, update } = useFieldArray({
    control,
    name: 'additionalUsers',
  });

  const submitHandler = async (data) => {
    const { additionalUsers: userData } = data;
    const partialPayload = transformAPIPayload(
      userData,
      savedUsers,
      false,
      deletedMembers,
    );
    const { allUsers, ...rest } = partialPayload || {};
    try {
      dispatch(setLoader(true));
      const response = await ApiClient.post(serviceUrl.getTeamInfoApi, rest);
      const { successResponseList } = response?.body;
      const parseSuccessArray = successResponseList.map((item) => item?.value);
      setSavedUsers(parseSuccessArray);
      const errorsArrAPI = transformResponse(response?.body);
      setErrMsgs(errorsArrAPI);
      const formData = {
        [pageKey]: allUsers,
        curPageId: pageId,
      };
      const moveToNext = !(errorsArrAPI && errorsArrAPI.length > 0);
      saveDataInRedux({
        formData,
        moveToNext,
      });
    } catch (err) {
      // console.log('err in Build team page', err);
      setErrMsgs([{ message: err.message }]);
    } finally {
      dispatch(setLoader(false));
    }
  };

  const handleAddTeam = (event) => {
    event.preventDefault();
    setOpen(true);
  };

  const handleModalSubmit = (data) => {
    const row = {
      ...data,
      memberId: '',
      primaryApplicant: 'N',
      percentageOwnership: data.role === '1' ? data.percentageOwnership : '',
    };
    append(row);
    setOpen(false);
  };

  const handleModalClose = () => setOpen(false);

  useEffect(() => {
    if (payload?.[pageKey]) {
      let teamInfo = [...payload?.[pageKey]];
      teamInfo = teamInfo.map((ele) => {
        const cloneEle = { ...ele };
        if (cloneEle.phone) {
          cloneEle.phoneType = '2';
        }
        if (cloneEle.memberId === '' && cloneEle?.tpsMember) {
          cloneEle.email = `chello${getRandomNumber()}@mailinator.com`;
        }
        return cloneEle;
      });
      reset({ additionalUsers: teamInfo });
    }
  }, [payload, reset]);

  const removeMember = (event, row, indexParam) => {
    event.preventDefault();
    const { tpsMemberId } = row;
    const index = getValues('additionalUsers').findIndex(
      (ele) => ele.tpsMemberId === tpsMemberId,
    );
    const { tpsMemberId: tpsId = '' } = getValues('additionalUsers')[index];
    if (index > -1 && tpsId !== '' && tpsId) {
      setDeletedMembers([
        ...deletedMembers,
        getValues('additionalUsers')[index],
      ]);
    }
    remove(indexParam);
  };

  const handleDisable = (role) => role !== '1';

  const handleOwnership = (index) => {
    const values = getValues('additionalUsers');
    values[index].percentageOwnership = '';
    clearErrors(`additionalUsers.${index}.percentageOwnership`);
    update(index, values[index]);
  };

  const additionalUsers = watch('additionalUsers') || [];

  const errorsArr = getErrorsArr(additionalUsers);
  const { hasControllingPerson, hasOwnerPer, hasRole, total } =
    buildTeamFormError(additionalUsers);

  return (
    <>
      <Box className="formBox">
        <FormHead heading={buildTeamHeading} subHeading={buildTeamSubHeading} />
        <Notification errors={[...errorsArr, ...errMsgs]} />
        <Box border={1} borderRadius="5px" borderColor="#ccc" p={2}>
          <TableHeading />
          <Box
            className={classes.teamBlock}
            pt={2}
            borderBottom="1px solid"
            borderColor="#ccc"
            pb={3}
          >
            <form onSubmit={handleSubmit(submitHandler)} data-testid="form">
              {fields?.map((ele, index) => (
                <Grid
                  container
                  key={ele.id}
                  spacing={{ xs: 1, sm: 1 }}
                  className={internalClasses.buildTeamGrid}
                >
                  <CustomInput
                    name={`additionalUsers.${index}.uniqueId`}
                    id={`additionalUsers.${index}.uniqueId`}
                    control={control}
                    classes={internalClasses.uniqueId}
                    defaultValue={ele.id}
                    margin="none"
                  />
                  <DisplayUser ele={ele} index={index} />
                  <Grid item xs={6} md={3} lg={3} xl={3}>
                    <Controller
                      name={`additionalUsers.${index}.role`}
                      control={control}
                      defaultValue={ele.role}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          onChange={(e) => {
                            field.onChange(e.target.value);
                            handleOwnership(index);
                          }}
                          value={field?.value || ''}
                          autoComplete="off"
                          variant="outlined"
                          size="small"
                          fullWidth={false}
                          className={classes.multiSelectBox}
                          margin="none"
                          select
                          inputProps={{
                            'data-testid': `primaryRole_${index}`,
                            readOnly: ele.primaryApplicant === 'Y',
                          }}
                        >
                          {CHELLO_INDIVIDUAL_ROLE.map((ele1, index1) => (
                            <MenuItem value={ele1.value} key={index1}>
                              {ele1.name}
                            </MenuItem>
                          ))}
                        </TextField>
                      )}
                    />
                  </Grid>
                  <Grid item xs={4} md={2} lg={2} xl={2}>
                    <PercentageInput
                      error={
                        !!errors.additionalUsers?.[index]?.percentageOwnership
                      }
                      errorText={
                        errors.additionalUsers?.[index]?.percentageOwnership
                          .message
                      }
                      name={`additionalUsers.${index}.percentageOwnership`}
                      id={`additionalUsers.${index}.percentageOwnership`}
                      control={control}
                      margin="none"
                      disabled={handleDisable(ele.role)}
                      inputProps={{
                        'data-testid': `percentage_${index}`,
                      }}
                    />
                  </Grid>
                  <Grid item xs={6} md={2} lg={2} xl={2}>
                    <Box textAlign="center">
                      <CustomCheckbox
                        id={`additionalUsers.${index}.controlingPerson`}
                        name={`additionalUsers.${index}.controlingPerson`}
                        control={control}
                        color="primary"
                        margin="none"
                        disabled={ele.primaryApplicant === 'Y'}
                        inputProps={{
                          'data-testid': 'controlingPerson',
                        }}
                      />
                    </Box>
                  </Grid>
                  {!ele.tpsMember > 0 && (
                    <Grid
                      item
                      xs={2}
                      md={1}
                      lg={1}
                      xl={1}
                      container
                      justifyContent="flex-end"
                      alignItems="center"
                      className={classes.remTeamColumn}
                    >
                      <Link
                        component="button"
                        data-testid={`remove_${index}`}
                        href="/#"
                        onClick={(e) => removeMember(e, ele, index)}
                      >
                        {REMOVE}
                      </Link>
                    </Grid>
                  )}
                </Grid>
              ))}
            </form>
          </Box>
          {open ? (
            <Box className={classes.teamBlock} pt={2}>
              <AddTeamForm
                handleModalSubmit={handleModalSubmit}
                handleModalClose={handleModalClose}
                roles={CHELLO_INDIVIDUAL_ROLE}
              />
            </Box>
          ) : (
            <Box className={classes.addTeamBlock} pt={2}>
              <Link
                href="/#"
                onClick={handleAddTeam}
                color="inherit"
                underline="hover"
              >
                <CustomIcon
                  component={PlusCircle}
                  className={internalClasses.buildTeamPlusIcon}
                  inheritViewBox
                />
                <Typography
                  component="span"
                  className={internalClasses.buildTeamAddTeamText}
                >
                  {addTeamMember}
                </Typography>
              </Link>
            </Box>
          )}
        </Box>
      </Box>
      <Footer
        saveHandler={() =>
          exitHandler({
            payload: transformAPIPayload(
              getValues('additionalUsers'),
              savedUsers,
              true,
              deletedMembers,
            ),
            endPoint: getTeamInfoApi,
            method: 'post',
          })
        }
        continueBtnType="button"
        handleSubmit={handleSubmit(submitHandler)}
        continueEnable={
          hasControllingPerson && !hasOwnerPer && total < 101 && !hasRole
        }
      />
    </>
  );
};

export default BuildTeam;
