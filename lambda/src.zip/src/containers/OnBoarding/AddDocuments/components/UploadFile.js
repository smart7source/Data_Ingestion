import {
  Button,
  Dialog,
  DialogContent,
  IconButton,
  Typography,
  Box,
  DialogActions,
} from '@mui/material';
import { useState } from 'react';
import { FileUploader } from 'react-drag-drop-files';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as CloudUpload } from 'assets/svg/cloud-upload.svg';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import strings from 'localization/translation';

const {
  uploadYourFiles,
  attachDocs,
  dragAndDrop,
  or,
  Browsefiles,
  upload,
  uploadFileExceedMsg,
  uploadFileTypeErrMsg,
} = strings;

const UploadFile = ({
  handleUpload,
  getSubmissionDoc,
  docInfo,
  handleClose,
}) => {
  const [selectedFile, setSelectedFile] = useState({ name: '' });
  const [error, setError] = useState();
  const fileTypes = ['PDF', 'jpeg', 'jpg', 'tiff'];

  const handleChange = (file) => {
    setError('');
    setSelectedFile(file);
  };

  const handleSubmission = () => {
    getSubmissionDoc(selectedFile);
  };

  const handleSizeError = () => {
    setError(uploadFileExceedMsg);
  };

  const handleTypeError = () => {
    setError(uploadFileTypeErrMsg);
  };
  return (
    <Dialog
      aria-labelledby="customized-dialog-title"
      open
      fullWidth
      maxWidth="xs"
      onClose={handleUpload}
    >
      <Typography className={internalClasses.uploadFilesText} variant="h1">
        {uploadYourFiles}
        <IconButton
          aria-label="close"
          onClick={handleClose}
          className={internalClasses.uploadFilesIconButton}
          data-testid="upload-close-icon"
        >
          <CustomIcon
            component={Close}
            className={internalClasses.exitDialogCloseIcon}
            inheritViewBox
          />
        </IconButton>
      </Typography>
      <DialogContent>
        <Typography
          className={internalClasses.attachDocTxt}
          variant="h3"
          component="p"
        >
          {attachDocs}
        </Typography>
        <Typography
          className={internalClasses.docNameTxt}
          variant="h3"
          component="p"
        >
          "{docInfo.docName}"
        </Typography>
        <Box className={internalClasses.uploadFileBoxBorder}>
          <FileUploader
            handleChange={handleChange}
            id="file"
            name="file"
            types={fileTypes}
            onTypeError={handleTypeError}
            classes={classes.fileUploadBox}
            onSizeError={handleSizeError}
            maxSize="5"
          >
            <Box justifyContent="center" display="flex" flexDirection="column">
              <Box justifyContent="center" textAlign="center">
                <CustomIcon
                  component={CloudUpload}
                  inheritViewBox
                  className={internalClasses.cloudIcon}
                />
              </Box>
              <Box textAlign="center" color="#ccc">
                {dragAndDrop}
              </Box>
              <Box textAlign="center" color="#ccc">
                {or}
              </Box>
              <Box justifyContent="center" textAlign="center" mt={1}>
                <Button
                  type="button"
                  onClick={(e) => e.preventDefault()}
                  variant="contained"
                  color="primary"
                  fullWidth
                >
                  {Browsefiles}
                </Button>
              </Box>
              {selectedFile && (
                <Box textAlign="center">{selectedFile.name}</Box>
              )}
            </Box>
          </FileUploader>

          {error && (
            <Typography color="error.main" variant="p3" my={1}>
              {error}
            </Typography>
          )}
        </Box>
      </DialogContent>
      <DialogActions>
        <Button
          type="button"
          onClick={handleSubmission}
          variant="contained"
          color="primary"
          fullWidth
          disabled={!selectedFile.name}
        >
          {upload}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default UploadFile;

UploadFile.propTypes = {
  handleUpload: PropTypes.func.isRequired,
  getSubmissionDoc: PropTypes.func.isRequired,
  docInfo: PropTypes.instanceOf(Object).isRequired,
  handleClose: PropTypes.func.isRequired,
};
