import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import { createMemoryHistory } from 'history';
import configureStore from 'store/configureStore';
import routePath from 'routes/routePath';
import AddDocuments from '../AddDocuments';
import { Router } from 'react-router-dom';
import strings from 'localization/translation';
import { readFileDataAsBase64 } from 'utils';
import {
  onBoardingStateMock,
  onBoardingStateEmptyMock,
  cognitoUserMock,
  cognitoCurrentSessionMock,
} from 'testHelpers';
import { rest } from 'msw';
import serviceUrl from 'api/UrlHelper';
import Auth from '@aws-amplify/auth';
import App from 'containers/App/App';
import server from 'apiMocks/server';

jest.useFakeTimers();
let testFn = readFileDataAsBase64;
const history = createMemoryHistory();
const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const renderExtBtn = () => {
  const exitBtn = screen.getByRole('button', { name: strings.exit });
  expect(exitBtn).toBeDefined();
  fireEvent.click(exitBtn);
};

const uploadFile = async () => {
  const mockFn = jest.fn();
  const docList = await screen.getAllByRole('button', { name: /Upload/i });
  fireEvent.click(docList[0], { preventDefault: mockFn });
  const uploadDialog = await waitFor(() => screen.getByRole('dialog'));
  expect(uploadDialog).toBeInTheDocument();
  const browseFilesLink = await waitFor(() => screen.getByText(/Browse/i));
  await act(async () => {
    fireEvent.click(browseFilesLink);
  });
  var fileel = document.querySelector('input');
  return fileel;
};

const renderAddDocumentComponent = async (storeValue) => {
  jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
    return promiseResolveCurrentUser;
  });
  jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
    return promiseResolveCurrentSession;
  });
  await act(async () =>
    render(
      <Provider store={storeValue}>
        <Router history={history}>
          <AddDocuments />
        </Router>
      </Provider>,
    ),
  );
};

describe('Render Add Documents component for first time user', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    await renderAddDocumentComponent(mockStore);
  });

  afterAll(() => jest.clearAllTimers());

  it('should render heading Text ', async () => {
    await waitFor(async () => {
      const heading = screen.getByText(strings.addDocumentsHeading);
      expect(heading).toBeInTheDocument();
    });
  });
  it('should render doc list for selected Business Legal Structure ', () => {
    const docList = screen.getAllByRole('button', { name: /upload/i });
    expect(docList).toHaveLength(3);
    expect(screen.getAllByTestId('file-text-upload-icon')).toHaveLength(3);
  });

  it('test close file upload modal ', async () => {
    const mockFn = jest.fn();
    const docList = await screen.getAllByRole('button', { name: /Upload/i });
    fireEvent.click(docList[0], { preventDefault: mockFn });
    const uploadDialog = await waitFor(() => screen.getByRole('dialog'));
    expect(uploadDialog).toBeInTheDocument();
    const closeButton = await waitFor(() =>
      screen.getByTestId('upload-close-icon'),
    );
    fireEvent.click(closeButton);
    expect(uploadDialog).not.toBeInTheDocument();
  });

  it('should upload file on click/drop 1', async () => {
    testFn = jest.fn().mockResolvedValue('datainbytes');
    var fileel = await uploadFile();

    fireEvent.drop(fileel, {
      dataTransfer: {
        files: [
          new File(['(⌐□_□)'], 'chucknorris.jpg', {
            type: 'image/jpg',
            name: 'chucknorris',
          }),
        ],
        clearData: jest.fn(),
      },
    });
    expect(screen.getByText(/chucknorris.jpg/i)).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /Upload/i }));
    });
    await act(async () => {
      jest.runOnlyPendingTimers();
    });
    await act(async () => {
      jest.runOnlyPendingTimers();
    });
  });
});

describe('Render Add Documents component Exit Button Functionality', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    await renderAddDocumentComponent(mockStore);
  });
  test('should render exit button and click functionality', () => {
    renderExtBtn();
    expect(screen.getByTestId('onboarding-exit-dialog')).toBeInTheDocument();
    expect(screen.getByText(strings.exitDialogSaveAndExit)).toBeInTheDocument();
    expect(screen.getByText(strings.exitDialogMessage4)).toBeInTheDocument();

    const noGoBkBtn = screen.getByRole('button', {
      name: strings.exitDialogMessage5,
    });
    expect(noGoBkBtn).toBeInTheDocument();
    fireEvent.click(noGoBkBtn);
    expect(
      screen.queryByTestId('onboarding-exit-dialog'),
    ).not.toBeInTheDocument();
  });
  test('should render exit dialog and click on save n exit', async () => {
    renderExtBtn();
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    await act(async () => {
      fireEvent.click(exitDialogSaveAndExitBtn);
    });

    expect(history.location.pathname).toBe(routePath.LOGIN);
  });
  test('should render exit dialog and click on yes and cancel', async () => {
    renderExtBtn();
    const exitDialogMessage4Btn = screen.getByRole('button', {
      name: strings.exitDialogMessage4,
    });
    await act(async () => {
      fireEvent.click(exitDialogMessage4Btn);
    });
    expect(history.location.pathname).toBe(routePath.LOGIN);
  });
});

describe('Render Add Documents component Negative Scenarios', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    await renderAddDocumentComponent(mockStore);
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.clearAllMocks();
  });

  it('should upload file unsuccessfully on click/drop ', async () => {
    server.use(
      rest.post(serviceUrl.uploadSingleDoc, (req, res, ctx) => {
        res.networkError('Failed to connect');
      }),
    );
    testFn = jest.fn().mockResolvedValue('datainbytes');
    var fileel = await uploadFile();

    fireEvent.drop(fileel, {
      dataTransfer: {
        files: [
          new File(['(⌐□_□)'], 'chucknorris1.jpg', {
            type: 'image/jpg',
            name: 'chucknorris1',
          }),
        ],
        clearData: jest.fn(),
      },
    });
    expect(screen.getByText(/chucknorris1.jpg/i)).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Upload' }));
    });
    await act(async () => {
      jest.runOnlyPendingTimers();
    });
    await act(async () => {
      jest.runOnlyPendingTimers();
    });
    expect(screen.getByTestId('file-failure-icon')).toBeInTheDocument();
  });

  it('should able to replace and delete uploaded files', async () => {
    testFn = jest.fn().mockResolvedValue('datainbytes');
    var fileel = await uploadFile();

    fireEvent.drop(fileel, {
      dataTransfer: {
        files: [
          new File(['(⌐□_□)'], 'chucknorris11.jpg', {
            type: 'image/jpg',
            name: 'chucknorris1',
          }),
        ],
        clearData: jest.fn(),
      },
    });
    expect(screen.getByText(/chucknorris11.jpg/i)).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Upload' }));
    });
    await act(async () => {
      jest.runOnlyPendingTimers();
    });
    await waitFor(async () => screen.queryByText('100% uploaded'));
    await act(async () => {
      jest.runOnlyPendingTimers();
    });
    await waitFor(async () => {
      expect(screen.getByTestId('file-success-icon')).toBeInTheDocument();
      const delItems = screen.queryAllByRole('button', { name: 'Replace' });
      expect(delItems).toHaveLength(1);
    });
  });
});

describe('Render Add Documents component Negative Scenarios', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    await renderAddDocumentComponent(mockStore);
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.clearAllMocks();
  });

  it('Erorr While Uploading file', async () => {
    testFn = jest.fn().mockResolvedValue('datainbytes');
    var fileel = await uploadFile();

    fireEvent.drop(fileel, {
      dataTransfer: {
        files: [
          new File(['(⌐□_□)'], 'chucknorris11.doc', {
            type: 'doc',
            name: 'chucknorris1',
          }),
        ],
        clearData: jest.fn(),
      },
    });
    await waitFor(async () => {
      expect(
        screen.getByText(strings.uploadFileTypeErrMsg),
      ).toBeInTheDocument();
    });
  });
});

/** describe('Submit Add Documents', () => {
  let response = onBoardingStateMock.onBoarding.payload.ADD_DOC_INFO;
  response = response.map((item) => ({ ...item, uploadStatus: true }));
  console.log('response im=n test ', response);
  const mockStore = configureStore(onBoardingStateEmptyMock);
  server.use(
    rest.get(serviceUrl.getUploadDocs, (req, res, ctx) =>
      res(
        ctx.json({
          body: response,
        }),
      ),
    ),
  );
  beforeEach(async () => {
    await renderAddDocumentComponent(mockStore);
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.clearAllMocks();
  });

  it('should submit form after uploading files ', async () => {
    await waitFor(() =>
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
    );
    await waitFor(async () => {
      expect(screen.getAllByTestId('file-success-icon')).toHaveLength(3);
    });
    const continueBtn = screen.getByRole('button', { name: 'Continue' });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).toBeEnabled();
    await act(async () => {
      fireEvent.submit(continueBtn);
    });
    expect(history.location.pathname).toBe(routePath.DOCUMENT_LOADER);
  });
}); */
