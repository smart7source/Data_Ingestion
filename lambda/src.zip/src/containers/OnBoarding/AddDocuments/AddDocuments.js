import { Box, Grid, Link, Typography, Avatar } from '@mui/material';
import { useSelector } from 'react-redux';
import { useState } from 'react';

import { readFileDataAsBase64 } from 'utils';
import { useOnboarding } from 'hooks';
import { addDocPgInfo } from 'helpers/URLConfiguration';
import routePath from 'routes/routePath';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { LinearProgressWithLabel } from 'components';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as FileText } from 'assets/svg/file-text.svg';
import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle-2.svg';
import { ReactComponent as AlertCircle } from 'assets/svg/alert-circle.svg';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';

import UploadFile from './components/UploadFile';

const {
  addDocumentsHeading,
  addDocumentsSubHeading,
  upload,
  uploadFailed,
  replace,
} = strings;

const { pageId, pageKey } = addDocPgInfo;

const AddDocuments = () => {
  const [showUploadModel, setShowUploadModel] = useState(false);
  const [uploadMethod, setUploadMethod] = useState('upload');
  const [activeDocument, setActiveDocument] = useState();
  const payload = useSelector((state) => state.onBoarding.payload);
  const [prg, setPrg] = useState({});
  const { [pageKey]: reqDocList = [] } = payload || {};
  const { saveDataInRedux, exitHandler } = useOnboarding({
    savedData: reqDocList,
    url: serviceUrl.getUploadDocs,
    pageKey,
    pageId,
    curPageId: payload.curPageId,
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    const formData = {
      curPageId: pageId,
      [pageKey]: reqDocList,
    };
    saveDataInRedux({
      formData,
      customPath: routePath.DOCUMENT_LOADER,
    });
  };

  const saveUploadedFile = (uploadFileObj) => {
    const cloneDoc = [...reqDocList];
    const obj = {
      ...cloneDoc[activeDocument],
      ...uploadFileObj,
    };
    cloneDoc[activeDocument] = obj;
    const formData = {
      [pageKey]: cloneDoc,
    };
    saveDataInRedux({
      formData,
      moveToNext: false,
    });
  };

  const uploadFile = (file, data, timer) => {
    const { uploadProgress, uploadStatus, method, ...rest } = data;
    ApiClient[method](serviceUrl.uploadSingleDoc, rest)
      .then(() => {
        clearInterval(timer);
        setPrg((preState) => ({ ...preState, [activeDocument]: 100 }));
        setTimeout(() => {
          saveUploadedFile({
            uploadStatus: true,
            documentContents: file.name,
            uploadProgress: 1,
          });
        }, 2000);
      })
      .catch(() => {
        saveUploadedFile({
          uploadStatus: false,
          documentContents: file.name,
          uploadProgress: 2,
        });
      });
  };

  const getSubmissionDoc = (file) => {
    const { type } = file;
    const ext = type.split('/');
    saveUploadedFile({ uploadProgress: 0, uploadStatus: false });
    setPrg((preState) => ({ ...preState, [activeDocument]: 0 }));
    setShowUploadModel(!showUploadModel);
    const timer = setInterval(() => {
      setPrg((preState) => {
        if (preState[activeDocument]) {
          const random = preState[activeDocument] + 10;
          return { ...preState, [activeDocument]: random > 100 ? 100 : random };
        }
        return { ...preState, [activeDocument]: 10 };
      });
    }, 1000);
    readFileDataAsBase64(file).then((response) => {
      const data = {
        ...reqDocList[activeDocument],
        docExtension: ext[1],
        documentContents: response,
        method: uploadMethod === 'upload' ? 'post' : 'put',
      };
      uploadFile(file, data, timer);
    });
  };

  const handleUpload = (methodParam, index) => (event) => {
    event.preventDefault();
    setUploadMethod(methodParam);
    setActiveDocument(index);
    setShowUploadModel(!showUploadModel);
  };

  const handleClose = (e) => {
    e.preventDefault();
    setShowUploadModel(!showUploadModel);
  };

  const disableContinueBtn =
    reqDocList && reqDocList?.some((ele) => !ele.uploadStatus);

  const showUploadProgress = (status, index) => {
    if (status === 0) {
      return (
        <Box className={internalClasses.uploadProgressAlign}>
          <LinearProgressWithLabel value={prg[index] || 0} />
        </Box>
      );
    }
    return null;
  };

  const showStatus = (ele) => {
    if (ele.uploadProgress === 2) {
      return (
        <Avatar className={internalClasses.documentAvatarFailure}>
          <CustomIcon
            component={AlertCircle}
            className={internalClasses.documentIcons}
            inheritViewBox
            data-testid="file-failure-icon"
          />
        </Avatar>
      );
    }
    if (ele.uploadProgress === 1 || ele.uploadStatus) {
      return (
        <Avatar className={internalClasses.documentAvatarSuccess}>
          <CustomIcon
            component={CheckmarkCircle}
            className={internalClasses.documentIcons}
            inheritViewBox
            data-testid="file-success-icon"
          />
        </Avatar>
      );
    }
    if (!ele.uploadStatus) {
      return (
        <Avatar className={internalClasses.documentAvatarInitial}>
          <CustomIcon
            component={FileText}
            inheritViewBox
            className={internalClasses.documentIcons}
            data-testid="file-text-upload-icon"
          />
        </Avatar>
      );
    }
    return null;
  };

  return (
    <>
      <form onSubmit={handleSubmit} data-testid="addDocumentsForm">
        <RightPanelLayout maxWidth="600px">
          <FormHead
            heading={addDocumentsHeading}
            subHeading={addDocumentsSubHeading}
          />
          {reqDocList.map((ele, index) => (
            <Grid container className={classes.uploadRow} key={index}>
              <Grid item xs={1}>
                {showStatus(ele)}
              </Grid>
              <Grid item xs={8} container alignItems="center">
                <Box>
                  <Typography variant="h3">{ele.docName}</Typography>
                  {ele?.uploadProgress !== 2 ? (
                    <Typography variant="p3" color="action.disabled">
                      {ele?.documentContents}
                    </Typography>
                  ) : (
                    <Typography variant="p3" color="error.main">
                      {uploadFailed}
                    </Typography>
                  )}
                </Box>
                {showUploadProgress(ele?.uploadProgress, index)}
              </Grid>
              <Grid
                item
                xs={3}
                container
                alignItems="center"
                justifyContent="flex-end"
              >
                {!ele?.uploadStatus ? (
                  <Link
                    component="button"
                    href="/#"
                    onClick={handleUpload('upload', index)}
                    className={classes.link}
                  >
                    {upload}
                  </Link>
                ) : (
                  <Link
                    component="button"
                    href="/#"
                    onClick={handleUpload('replace', index)}
                    className={classes.link}
                  >
                    {replace}
                  </Link>
                )}
              </Grid>
            </Grid>
          ))}
        </RightPanelLayout>
        <Footer
          backBtn
          saveHandler={() => exitHandler({ saveData: false })}
          continueEnable={!disableContinueBtn}
        />
      </form>
      {showUploadModel && (
        <UploadFile
          handleUpload={handleUpload}
          getSubmissionDoc={getSubmissionDoc}
          docInfo={reqDocList[activeDocument]}
          handleClose={handleClose}
        />
      )}
    </>
  );
};

export default AddDocuments;
