import { formatPhoneNumber, getDigits } from 'utils';

const createPayload = (data) => ({
  ...data,
  orgPhoneNumber: formatPhoneNumber(data?.orgPhoneNumber),
  orgTaxId: getDigits(data?.orgTaxId),
});

export default createPayload;
