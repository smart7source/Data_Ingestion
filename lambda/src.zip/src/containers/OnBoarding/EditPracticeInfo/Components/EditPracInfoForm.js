import { Box, Grid } from '@mui/material';
import PropTypes from 'prop-types';

import { MaskInput, CustomInput, CustomSelectBox } from 'components';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

const {
  businessLegalName,
  EIN,
  businessAddressLine1,
  businessAddressLine2,
  city,
  zipCode,
  businessPhone,
  businessEmail,
  state: STATE,
  phoneType: PHONE_TYPE,
} = strings;

const EditPracInfoForm = ({ control, errors, statesData, phoneTypeData }) => (
  <>
    <Box>
      <CustomInput
        label={businessLegalName}
        id="orgName"
        error={!!errors.orgName}
        inputProps={{ maxLength: 60 }}
        errorText={errors.orgName && errors.orgName.message}
        name="orgName"
        control={control}
      />
    </Box>
    <Box>
      <MaskInput
        label={EIN}
        name="orgTaxId"
        id="orgTaxId"
        control={control}
        mask="99-9999999"
        error={!!errors.orgTaxId}
        errorText={errors.orgTaxId && errors.orgTaxId.message}
        outputMasked
      />
    </Box>
    <Box>
      <CustomInput
        label={businessAddressLine1}
        error={!!errors.orgAddressLine1}
        inputProps={{ maxLength: 100 }}
        errorText={errors.orgAddressLine1 && errors.orgAddressLine1.message}
        id="orgAddressLine1"
        name="orgAddressLine1"
        control={control}
      />
    </Box>
    <Box>
      <CustomInput
        label={businessAddressLine2}
        error={!!errors.orgAddressLine2}
        inputProps={{ maxLength: 100 }}
        errorText={errors.orgAddressLine2 && errors.orgAddressLine2.message}
        name="orgAddressLine2"
        control={control}
        id="edit-practice-info-org-addr-2"
        optionalLabel={strings.optional}
      />
    </Box>
    <Box>
      <CustomInput
        label={city}
        inputProps={{ maxLength: 40 }}
        error={!!errors.orgCityName}
        errorText={errors.orgCityName && errors.orgCityName.message}
        name="orgCityName"
        control={control}
        id="edit-practice-info-org-city"
      />
    </Box>
    <Grid container spacing={3}>
      <Grid item xs={6}>
        <CustomSelectBox
          label={STATE}
          options={statesData}
          error={!!errors.orgStateCode}
          errorText={errors.orgStateCode && errors.orgStateCode.message}
          name="orgStateCode"
          id="stateid"
          control={control}
        />
      </Grid>
      <Grid item xs={6}>
        <MaskInput
          label={zipCode}
          name="orgZipCode"
          id="orgZipCode"
          control={control}
          mask="99999-9999"
          maskChar={null}
          error={!!errors.orgZipCode}
          errorText={errors.orgZipCode && errors.orgZipCode.message}
          isZipCode
          className={classes.zipCodeStyle}
          outputMasked
        />
      </Grid>
    </Grid>
    <Grid
      container
      direction="row"
      justifyContent="center"
      alignItems="center"
      spacing={2}
    >
      <Grid item xs={3}>
        <CustomSelectBox
          id="orgPhoneType"
          label={PHONE_TYPE}
          options={phoneTypeData}
          error={!!errors.orgPhoneType}
          errorText={errors.orgPhoneType && errors.orgPhoneType.message}
          name="orgPhoneType"
          control={control}
          hideSelect
        />
      </Grid>
      <Grid item xs={9}>
        <MaskInput
          label={businessPhone}
          name="orgPhoneNumber"
          id="orgPhoneNumber"
          control={control}
          mask="+1-999-999-9999"
          maskChar="_"
          alwaysShowMask
          error={!!errors.orgPhoneNumber}
          errorText={errors.orgPhoneNumber && errors.orgPhoneNumber.message}
          outputMasked
        />
      </Grid>
    </Grid>
    <Box>
      <CustomInput
        type="email"
        label={businessEmail}
        error={!!errors.orgEmail}
        errorText={errors.orgEmail && errors.orgEmail.message}
        name="orgEmail"
        control={control}
        id="edit-practice-info-org-email"
      />
    </Box>
  </>
);

export default EditPracInfoForm;

EditPracInfoForm.propTypes = {
  errors: PropTypes.instanceOf(Object),
  control: PropTypes.instanceOf(Object).isRequired,
  statesData: PropTypes.arrayOf(PropTypes.any),
  phoneTypeData: PropTypes.arrayOf(PropTypes.any),
};
EditPracInfoForm.defaultProps = {
  errors: {},
  statesData: [],
  phoneTypeData: [],
};
