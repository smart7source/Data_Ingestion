import { Provider } from 'react-redux';
import {
  render,
  screen,
  act,
  fireEvent,
  waitFor,
  cleanup,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import * as utilsFn from 'utils/authentication';
import { rest } from 'msw';

import configureStore from 'store/configureStore';
import serviceUrl from 'api/UrlHelper';
import strings from 'localization/translation';
import { onBoardingStateEmptyMock, onBoardingStateMock } from 'testHelpers';
import server from 'apiMocks/server';

import EditPracticeInfo from '../EditPracticeInfo';

// jest.mock('utils', () => ({
//   ...jest.requireActual('utils'),
//   handleLogout: jest.fn(),
// }));

const history = createMemoryHistory();

const { continueBtnName } = strings;

const renderEditPracticeComponent = async (storeValue) => {
  await act(async () =>
    render(
      <Provider store={storeValue}>
        <Router history={history}>
          <EditPracticeInfo />
        </Router>
      </Provider>,
    ),
  );
};

const showAddressDialog = async () => {
  const continueBtn = screen.getByTestId('edit-form');
  fireEvent.submit(continueBtn);

  await waitFor(() =>
    expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
  );
  await waitFor(() => expect(screen.queryByRole('dialog')).toBeInTheDocument());
};

describe('rendering <EditPracticeInfo /> component with action edit', () => {
  afterAll(cleanup);
  test('should render component with inital data', async () => {
    const mockStore = configureStore(onBoardingStateMock);
    await renderEditPracticeComponent(mockStore);
    expect(screen.getByText(strings.editPracticeInfo)).toBeInTheDocument();
    expect(screen.getByText(strings.siteId)).toBeInTheDocument();
    const businessLegalName = screen.getByLabelText(strings.businessLegalName);
    expect(businessLegalName).toBeInTheDocument();
    const organizationTaxIdentifier = screen.getByLabelText(strings.EIN);
    expect(organizationTaxIdentifier).toBeInTheDocument();
    const organizationAddressLine1 = screen.getByLabelText(
      strings.businessAddressLine1,
    );
    expect(organizationAddressLine1).toBeInTheDocument();
    const organizationZipCode = screen.getByLabelText(strings.zipCode);
    expect(organizationZipCode).toBeInTheDocument();
    const continueBtn = screen.getByTestId('footer-nav-continue-btn');
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).not.toBeDisabled();
  });
  test('should show address dialog, to verify address', showAddressDialog);
  test('should show error notification when InfoApi is failed', async () => {
    server.use(
      rest.post(serviceUrl.getPracinfoApiPath, (req, res, ctx) => {
        res.networkError('Failed to connect');
      }),
    );
    const continueBtnDialog = screen.getByTestId('continue_btn');
    expect(continueBtnDialog).toBeInTheDocument();
    userEvent.click(continueBtnDialog);
    await waitFor(() =>
      expect(screen.getByTestId('notification-alert')).toBeInTheDocument(),
    );
  });
});

describe('Testing edit address', () => {
  afterAll(cleanup);

  test('should render component', async () => {
    const mockStore = configureStore(onBoardingStateMock);
    await renderEditPracticeComponent(mockStore);
    expect(screen.getByText(strings.editPracticeInfo)).toBeInTheDocument();
  });

  test('should show address dialog', showAddressDialog);

  test('Should allow user to edit address when "edit address" button is clicked', async () => {
    expect(screen.queryByRole('dialog')).toBeInTheDocument();
    const EditAddsBtn = screen.getByTestId('editPrac-edit-address');
    fireEvent.click(EditAddsBtn);
    await waitFor(() =>
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument(),
    );
  });
});

describe('Testing EditPractice component Footer ', () => {
  afterAll(cleanup);
  test('Should render component ', async () => {
    const mockStore = configureStore(onBoardingStateMock);
    await renderEditPracticeComponent(mockStore);
    expect(screen.getByText(strings.editPracticeInfo)).toBeInTheDocument();
  });

  test('Should render exit dialog when exit button clicked', async () => {
    const exitBtn = screen.getByTestId('footer-nav-exit-btn');
    expect(exitBtn).toBeDefined();
    userEvent.click(exitBtn);

    const exitDialog = await screen.findByTestId('onboarding-exit-dialog');

    expect(exitDialog).toBeInTheDocument();
  });

  test('Should save and exit when save and exit button is clicked', async () => {
    const mockFn = jest.spyOn(utilsFn, 'handleLogout');
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    userEvent.click(exitDialogSaveAndExitBtn);
    await waitFor(() => expect(mockFn).toHaveBeenCalled());
  });
});

describe('Testing EditPractice component with empty data', () => {
  const practiceInfo = onBoardingStateMock.onBoarding.payload.PRAC_INFO;
  afterAll(cleanup);

  test('Should render component with empty data', async () => {
    const mockStore = configureStore(onBoardingStateEmptyMock);
    await renderEditPracticeComponent(mockStore);
    expect(screen.getByText(strings.editPracticeInfo)).toBeInTheDocument();
  });

  test('render component with inital data', async () => {
    await waitFor(async () => {
      const addressLine1 = screen.getByLabelText(strings.businessAddressLine1);
      expect(addressLine1).toBeInTheDocument();
      expect(addressLine1).toHaveValue(practiceInfo.orgAddressLine1);
    });
  });

  test('update address line 1 field with empty value', async () => {
    await waitFor(async () => {
      const addressLine1 = screen.getByLabelText(strings.businessAddressLine1);
      userEvent.clear(screen.getByLabelText(strings.businessAddressLine1));
      expect(addressLine1).toHaveValue('');
      const cntBtn = screen.getByRole('button', { name: continueBtnName });
      expect(cntBtn).toBeDisabled();
    });
  });

  test('update address line 1 field with some value', async () => {
    await waitFor(async () => {
      userEvent.clear(screen.getByLabelText(strings.businessAddressLine1));
      const addressLine1 = screen.getByLabelText(strings.businessAddressLine1);
      userEvent.type(screen.getByLabelText(strings.businessAddressLine1), 'S');

      expect(addressLine1).toHaveValue('S');
      const cntBtn = screen.getByRole('button', { name: continueBtnName });
      expect(cntBtn).toBeEnabled();
    });
  });
});
