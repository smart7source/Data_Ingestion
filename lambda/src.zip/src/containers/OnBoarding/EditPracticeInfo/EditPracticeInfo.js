import { useCallback, useEffect, useState } from 'react';
import { Box } from '@mui/material';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useSelector, useDispatch } from 'react-redux';
import { Auth } from 'aws-amplify';

import {
  Notification,
  DisplayFormValue,
  VerifyAddressDialog,
} from 'components';
import { completedAddress } from 'utils';
import { useOnboarding, useRefData } from 'hooks';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import { editPracticeInfoValidationSchemea } from 'helpers/ValidationSchema';
import { edtPracPgInfo } from 'helpers/URLConfiguration';
import strings from 'localization/translation';
import { setLoader } from 'store/actions';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';

import EditPracInfoForm from './Components/EditPracInfoForm';
import createPayload from './Components/CreatePayload';

const { editPracticeInfo, editPracticeInfoSubHeading, finalReviewSiteId } =
  strings;
const { pageId, pageKey } = edtPracPgInfo;
const { getPracinfoApiPath } = serviceUrl;
const EditPracticeInfo = () => {
  const payload = useSelector((state) => state.onBoarding.payload);
  const [errorMsgs, setErrorMsgs] = useState([]);
  const [suggestedAddress, setSuggestedAddress] = useState({});
  const [open, setOpen] = useState(false);
  const refData = useSelector((state) => state.global.refData);
  const { US_STATES: statesData, PHONE_TYPE: phoneTypeData } = refData || [];
  const dispatch = useDispatch();
  useRefData(['US_STATES', 'PHONE_TYPE']);
  const { saveDataInRedux, exitHandler } = useOnboarding({
    savedData: payload[pageKey],
    url: getPracinfoApiPath,
    pageKey,
    pageId,
    curPageId: payload.curPageId,
  });

  const {
    control,
    reset,
    getValues,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(editPracticeInfoValidationSchemea),
  });

  useEffect(() => {
    if (payload?.[pageKey]) {
      reset({
        ...payload?.[pageKey],
        orgPhoneType: payload[pageKey].orgPhoneType
          ? payload[pageKey].orgPhoneType
          : '3',
      });
    }
  }, [dispatch, reset, payload]);

  const onModalContinue = (prefAddress) => {
    setOpen(false);
    let clonedPracInfo = createPayload({ ...getValues() });
    if (prefAddress === 'S') {
      clonedPracInfo = {
        ...clonedPracInfo,
        ...suggestedAddress,
      };
    }
    const { action } = clonedPracInfo;
    if (action === 'add') {
      updateData(clonedPracInfo, 'post');
    } else if (action === 'edit') {
      updateData(clonedPracInfo, 'put');
    }
  };

  const navigateToNextPage = useCallback(
    (data) => {
      saveDataInRedux({
        formData: {
          [pageKey]: {
            ...data,
            // action: 'edit'
          },
          curPageId: pageId,
        },
      });
    },
    [saveDataInRedux],
  );

  const updateData = useCallback(
    async (data, methodParam) => {
      const { message, saveAndExit, ...restPayload } = data;
      dispatch(setLoader(true));
      if (payload?.[pageKey]?.orgTaxId !== data?.orgTaxId) {
        try {
          const user = await Auth.currentAuthenticatedUser();
          await Auth.updateUserAttributes(user, {
            'custom:ein': data.orgTaxId,
          });
        } catch (err) {
          setErrorMsgs([{ message: err.message }]);
        } finally {
          dispatch(setLoader(false));
        }
      }
      ApiClient[methodParam](getPracinfoApiPath, restPayload)
        .then(() => navigateToNextPage(data))
        .catch((err) => {
          setErrorMsgs([{ message: err.message }]);
        })
        .finally(() => dispatch(setLoader(false)));
    },
    [dispatch, navigateToNextPage, payload],
  );

  const submitHandler = useCallback(async (data) => {
    dispatch(setLoader(true));
    try {
      const {
        body: {
          deliverable,
          address: {
            street = data.orgAddressLine1,
            street2 = data.orgAddressLine2,
            city = data.orgCityName,
            region = data.orgStateCode,
            postCode = data.orgZipCode,
          },
        },
      } = await ApiClient.post(serviceUrl.verifyAddress, {
        street: data.orgAddressLine1,
        street2: data.orgAddressLine2,
        city: data.orgCityName,
        region: data.orgStateCode,
        postCode: data.orgZipCode,
      });
      setSuggestedAddress({
        orgAddressLine1: street,
        orgAddressLine2: street2,
        orgCityName: city,
        orgStateCode: region,
        orgZipCode: postCode,
        addressStatus: deliverable,
      });
      setOpen(true);
    } catch (e) {
      // console.log(e);
    } finally {
      dispatch(setLoader(false));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const method = payload[pageKey]?.action === 'add' ? 'post' : 'put';

  return (
    <>
      <form onSubmit={handleSubmit(submitHandler)} data-testid="edit-form">
        <RightPanelLayout maxWidth="600px">
          <Notification errors={errorMsgs} />
          <FormHead
            heading={editPracticeInfo}
            subHeading={editPracticeInfoSubHeading}
          />
          <Box marginBottom={2.5}>
            <DisplayFormValue
              name={finalReviewSiteId}
              value={
                localStorage.getItem('siteId') || payload?.PRAC_INFO?.orgId
              }
              showSeparator
            />
          </Box>

          <EditPracInfoForm
            control={control}
            errors={errors}
            statesData={statesData}
            phoneTypeData={phoneTypeData}
          />
        </RightPanelLayout>
        <Footer
          continueEnable={isValid}
          backBtn={false}
          saveHandler={() =>
            exitHandler({
              endPoint: getPracinfoApiPath,
              method,
              payload: { ...getValues(), saveAndExit: true },
            })
          }
        />
      </form>
      {open && (
        <VerifyAddressDialog
          crntFullAdd={completedAddress(
            getValues('orgAddressLine1'),
            getValues('orgAddressLine2'),
            getValues('orgCityName'),
            getValues('orgStateCode'),
            getValues('orgZipCode'),
          )}
          suggestedAdd={completedAddress(
            suggestedAddress?.orgAddressLine1,
            suggestedAddress?.orgAddressLine2,
            suggestedAddress?.orgCityName,
            suggestedAddress?.orgStateCode,
            suggestedAddress?.orgZipCode,
          )}
          handleContinue={onModalContinue}
          page="editPrac"
          handleClose={() => setOpen(false)}
          addressStatus={suggestedAddress?.addressStatus}
        />
      )}
    </>
  );
};

export default EditPracticeInfo;
