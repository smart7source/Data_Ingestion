import { Box, Grid } from '@mui/material';
import PropTypes from 'prop-types';

import {
  CustomInput,
  ErrorHelper,
  CustomSelectBox,
  CustomCheckbox,
} from 'components';
import strings from 'localization/translation';
import internalClasses from 'style/onBoarding.module.scss';
import { roleList } from 'utils';

const {
  username: USERNAME,
  email: EMAIL,
  otpHelperTxt,
  passwordLable,
  regRoleLabel: REG_ROLE,
  regControlPersonLabel: CONTROL_PERSON_CHECKBOX,
} = strings;

const RegistrationForm = ({ control, errors, getValues, subUser }) => (
  <>
    <Box>
      <CustomInput
        name="username"
        id="username"
        control={control}
        dataTestid="username-value"
        label={USERNAME}
        error={!!errors.username}
        errorText={errors.username && errors.username.message}
        inputProps={{ maxLength: 16 }}
      />
    </Box>
    <Box>
      <CustomInput
        name="email"
        id="email"
        control={control}
        dataTestid="email-value"
        label={EMAIL}
        error={!!errors.email}
        errorText={errors.email && errors.email.message}
        helperText={otpHelperTxt}
      />
    </Box>
    <Box>
      <CustomInput
        type="password"
        name="password"
        id="password"
        control={control}
        dataTestid="password-value"
        label={passwordLable}
        error={!!errors.password}
        errorText={errors.password && errors.password.message}
      />
    </Box>
    <ErrorHelper value={getValues('password')} />
    <Box>
      <CustomInput
        type="password"
        name="confirmPassword"
        id="confirmPassword"
        control={control}
        dataTestid="confirmPassword-value"
        label={strings.confirmPassword}
        error={!!errors.confirmPassword}
        errorText={errors.confirmPassword && errors.confirmPassword.message}
      />
    </Box>
    {!subUser && (
      <Box mb={2}>
        <Grid container spacing={2}>
          <Grid item xs={6} sm={6}>
            <CustomSelectBox
              label={REG_ROLE}
              dataTestid="role"
              options={roleList}
              error={!!errors.role}
              errorText={errors.role && errors.role.message}
              name="role"
              id="role"
              control={control}
            />
          </Grid>
          <Grid
            item
            xs={6}
            sm={6}
            className={internalClasses.registrationFormAlignment}
          >
            <CustomCheckbox
              name="controlingPerson"
              id="controlingPerson"
              defaultValue={false}
              control={control}
              label={CONTROL_PERSON_CHECKBOX}
              error={!!errors.controlingPerson}
              errorText={
                errors.controlingPerson && errors.controlingPerson.message
              }
            />
          </Grid>
        </Grid>
      </Box>
    )}
  </>
);

export default RegistrationForm;

RegistrationForm.propTypes = {
  errors: PropTypes.instanceOf(Object),
  control: PropTypes.instanceOf(Object).isRequired,
  getValues: PropTypes.func.isRequired,
  subUser: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
};
RegistrationForm.defaultProps = {
  errors: {},
  subUser: false,
};
