import { render, screen, fireEvent, act } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import { MemoryRouter, Route, Router } from 'react-router-dom';
import { rest } from 'msw';

import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';
import { Auth } from 'aws-amplify';
import strings from 'localization/translation';
import userEvent from '@testing-library/user-event';
import { routePath } from 'routes';
import App from 'containers/App/App';
import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  onBoardingRegMock,
} from 'testHelpers';
import { createMemoryHistory } from 'history';
import Registration from '../Registration';
const history = createMemoryHistory();

const secondUserValidForm = async () => {
  await act(async () => {
    fireEvent.change(screen.getByLabelText(/username/i), {
      target: { value: 'Test2001' },
    });

    fireEvent.change(screen.getByLabelText(/email/i), {
      target: { value: 'test@mailinator.com' },
    });

    fireEvent.change(screen.getByTestId('password-value'), {
      target: { value: 'Ind2021#' },
    });

    fireEvent.change(screen.getByTestId('confirmPassword-value'), {
      target: { value: 'Ind2021#' },
    });
  });

  const checkbox = screen.getByRole('checkbox', {
    name: strings.accept,
  });

  await act(async () => {
    fireEvent.click(checkbox);
  });
};
const validForm = async () => {
  await secondUserValidForm();
  await act(async () => {
    fireEvent.change(screen.getByTestId('role'), {
      target: { value: '1' },
    });
  });
};
const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);
const enterOTP = () => {
  userEvent.type(screen.getByLabelText(/Digit 1/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 2/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 3/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 4/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 5/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 6/i), '1');
};

describe('render <Registration /> component', () => {
  const mockStore = configureStore(onBoardingRegMock);
  beforeEach(async () => {
    window.localStorage.setItem('code', 'code');
    await act(async () =>
      render(
        <MemoryRouter initialEntries={[routePath.REGISTRATION]}>
          <Provider store={mockStore}>
            <App />
          </Provider>
        </MemoryRouter>,
      ),
    );
  });

  afterEach(() => window.localStorage.removeItem('code'));

  afterAll(() => {
    jest.clearAllMocks();
  });

  it('should test initial condition', () => {
    expect(screen.getByText(strings.regTitle)).toBeInTheDocument();
    expect(screen.getByText(strings.regSubTitle)).toBeInTheDocument();

    const username = screen.getByLabelText(new RegExp(strings.username, 'i'));
    expect(username).toBeInTheDocument();

    const email = screen.getByLabelText(strings.email);
    expect(email).toBeInTheDocument();

    const password = screen.getByTestId('password-value');
    expect(password).toBeInTheDocument();
    expect(password).toHaveValue('');

    const confirmPassword = screen.getByTestId('confirmPassword-value');
    expect(confirmPassword).toBeInTheDocument();
    expect(confirmPassword).toHaveValue('');

    const roleField = screen.getByTestId('role');
    expect(roleField).toBeInTheDocument();

    const controlPersonCB = screen.getByRole('checkbox', {
      name: strings.regControlPersonLabel,
    });
    expect(controlPersonCB).not.toBeChecked();

    const checkbox = screen.getByRole('checkbox', {
      name: strings.accept,
    });
    expect(checkbox).not.toBeChecked();

    const viewnPrint = screen.getByText(new RegExp(strings.viewnPrint, 'i'));
    fireEvent.click(viewnPrint);

    const exitBtn = screen.getByRole('button', { name: strings.exit });
    expect(exitBtn).toBeEnabled();

    const continueBtn = screen.getByRole('button', { name: strings.continue });
    expect(continueBtn).toBeDisabled();
  });

  it(' continue button should be Disabled if terms checkbox is checked', async () => {
    const checkbox = screen.getByRole('checkbox', {
      name: strings.accept,
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    const continueBtn = screen.getByRole('button', { name: strings.continue });
    expect(continueBtn).toBeDisabled();
  });

  it('should through required field error on form submit', async () => {
    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    expect(screen.queryByText('Password is required')).toBeInTheDocument();
  });

  it('should submit form with duplicate username', async () => {
    await validForm();
    jest.spyOn(Auth, 'signUp').mockRejectedValue({
      __type: 'UsernameExistsException',
      message: 'User already exists',
    });

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });
    expect(screen.getByTestId('notification-alert')).toBeInTheDocument();
  });

  it('should fail silent login method', async () => {
    await validForm();
    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest.spyOn(Auth, 'signIn').mockRejectedValue({
      __type: 'SystemException',
      message: 'Unable to login',
    });

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });
    expect(screen.getByTestId('notification-alert')).toBeInTheDocument();
  });

  it('should submit form when all form fields are valid', async () => {
    await validForm();

    expect(screen.getByLabelText(/username/i)).toHaveValue('Test2001');
    expect(screen.getByTestId('password-value')).toHaveValue('Ind2021#');

    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest
      .spyOn(Auth, 'signIn')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    expect(
      screen.queryByText('Please enter a valid username'),
    ).not.toBeInTheDocument();
    expect(screen.queryByText(/Password is required/i)).not.toBeInTheDocument();
  });

  it('should find verification screen and submit otp code', async () => {
    await validForm();

    expect(screen.getByLabelText(/username/i)).toHaveValue('Test2001');
    expect(screen.getByTestId('password-value')).toHaveValue('Ind2021#');

    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest
      .spyOn(Auth, 'signIn')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    jest
      .spyOn(Auth, 'sendCustomChallengeAnswer')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    expect(
      screen.queryByText('Please enter a valid username'),
    ).not.toBeInTheDocument();
    expect(screen.queryByText(/Password is required/i)).not.toBeInTheDocument();

    await enterOTP();
    expect(screen.getByText(strings.verificationMessage1)).toBeInTheDocument();

    const continueBtn = screen.getByRole('button', { name: strings.continue });
    expect(continueBtn).not.toBeDisabled();

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });
  });

  it('should resend otp to email on clicking resend code', async () => {
    await validForm();

    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest
      .spyOn(Auth, 'signIn')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    await act(async () => {
      fireEvent.click(screen.getByTestId('resend-code'));
    });
  });

  it('should enter correct otp code', async () => {
    await validForm();

    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest
      .spyOn(Auth, 'signIn')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    jest.spyOn(Auth, 'sendCustomChallengeAnswer').mockResolvedValue(true);

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    await enterOTP();

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });
  });

  it('should fail save tps', async () => {
    await validForm();

    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest
      .spyOn(Auth, 'signIn')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    jest.spyOn(Auth, 'sendCustomChallengeAnswer').mockResolvedValue(true);

    server.use(
      rest.post(serviceUrl.saveTpsProfileApiPath, (req, res, ctx) => {
        return res.networkError('Server down');
      }),
    );

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });
    await enterOTP();

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });
  });

  it('should enter in correct otp code', async () => {
    await validForm();

    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest
      .spyOn(Auth, 'signIn')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    jest.spyOn(Auth, 'sendCustomChallengeAnswer').mockRejectedValue(false);

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    await enterOTP();

    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    expect(screen.getByTestId('notification-alert')).toBeInTheDocument();
  });
}, 20000);

describe('render <Registration /> component for addition user', () => {
  const store = configureStore(onBoardingRegMock);

  let testHistory, testLocation;
  beforeEach(async () => {
    await act(async () =>
      render(
        <MemoryRouter
          initialEntries={[
            `${routePath.REGISTRATION}?subUser=true&firstName=firstName&email=email@email.com`,
          ]}
        >
          <Provider store={store}>
            <App />
          </Provider>
          <Route
            path="*"
            render={({ history, location }) => {
              testHistory = history;
              testLocation = location;
              return null;
            }}
          />
        </MemoryRouter>,
      ),
    );
  });

  afterAll(() => {
    jest.clearAllMocks();
  });

  it('should test initial condition', () => {
    expect(screen.getByText(strings.welcomeSubHeading)).toBeInTheDocument();

    const continueBtn = screen.getByRole('button', { name: strings.continue });
    expect(continueBtn).toBeDefined();
  });

  it('should find verification screen and submit otp code', async () => {
    await secondUserValidForm();
    const continueBtnT = screen.getByRole('button', { name: strings.continue });
    expect(continueBtnT).toBeEnabled();
    expect(screen.getByLabelText(/username/i)).toHaveValue('Test2001');
    expect(screen.getByTestId('password-value')).toHaveValue('Ind2021#');

    jest.spyOn(Auth, 'signUp').mockResolvedValue(true);

    jest
      .spyOn(Auth, 'signIn')
      .mockResolvedValue({ challengeName: 'CUSTOM_CHALLENGE' });

    jest.spyOn(Auth, 'sendCustomChallengeAnswer').mockResolvedValue(true);
    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });

    expect(
      screen.queryByText('Please enter a valid username'),
    ).not.toBeInTheDocument();
    expect(screen.queryByText(/Password is required/i)).not.toBeInTheDocument();

    await enterOTP();
    expect(screen.getByText(strings.verificationMessage1)).toBeInTheDocument();

    const continueBtn = screen.getByRole('button', { name: strings.continue });
    expect(continueBtn).not.toBeDisabled();
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    await act(async () => {
      fireEvent.submit(screen.getByTestId('form'));
    });
  });
});

describe('render <Registration /> component for null code', () => {
  const mockStore = configureStore(onBoardingRegMock);
  beforeEach(async () => {
    render(
      <Provider store={mockStore}>
        <Router history={history}>
          <Registration />
        </Router>
      </Provider>,
    );
  });

  afterAll(() => {
    jest.clearAllMocks();
  });

  it('should test initial condition', () => {
    expect(history.location.pathname).toBe(routePath.TRIZETTO);
  });
});

describe('render <Registration /> component on User Refresh', () => {
  const initalState = {
    onBoarding: {
      payload: {
        siteId: '',
        curPageId: '1',
        BUILD_TEAM_INFO: [],
      },
      tpsInfo: {
        tpsUserEmail: '',
        taxId: '',
        tpsSiteId: '',
        tpsUserId: '',
      },
      hideLeftMenu: false,
    },
  };
  const mockStore = configureStore(initalState);
  beforeEach(async () => {
    window.localStorage.setItem('code', 'code');
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <Registration />
          </Router>
        </Provider>,
      ),
    );
  });
  afterEach(() => window.localStorage.removeItem('code'));

  afterAll(() => {
    jest.clearAllMocks();
  });

  it('should test initial condition', () => {
    expect(screen.getByText(strings.regTitle)).toBeInTheDocument();
  });
});
