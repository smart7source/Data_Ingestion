import { useEffect, useState } from 'react';
import { Link, Box, Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { Auth } from 'aws-amplify';
import { useHistory, useLocation } from 'react-router-dom';
import queryString from 'query-string';
import { v4 as uuidv4 } from 'uuid';

import { parseError } from 'utils';
import {
  loadTpsInfo,
  setLoader,
  updateAuthenticatedStatus,
  updateLeftPanelStatus,
} from 'store/actions';
import { regValidationSchema } from 'helpers/ValidationSchema';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import strings from 'localization/translation';
import { CustomCheckbox, Notification, SingleNotification } from 'components';
import routePath from 'routes/routePath';
import { useConfirmPasswordTrigger } from 'hooks';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';

import Verification from '../Verification/Verification';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';
import Footer from '../components/Footer';

import RegistrationForm from './Components/RegistrationForm';

const {
  resendCodeMsg,
  welcomeSubUser,
  regTitle,
  welcomeSubHeading,
  regSubTitle,
  otpError,
} = strings;
const Registration = () => {
  const {
    tpsInfo: { tpsUserEmail, taxId, tpsUserId },
  } = useSelector((state) => state.onBoarding);
  const dispatch = useDispatch();
  const { search } = useLocation();
  const {
    subUser,
    firstName,
    email: getEmail,
    ein,
  } = queryString.parse(search);
  const history = useHistory();
  const [signUp, setSignUp] = useState(false);
  const [user, setUser] = useState();
  const [errorMsgs, setErrorMsgs] = useState([]);
  const [noneRoleError, setNoneRoleError] = useState({});
  const practiceEin = !subUser ? localStorage.getItem('EIN') : ein;
  const {
    control,
    watch,
    handleSubmit,
    trigger,
    getValues,
    resetField,
    setError,
    formState: { errors, isValid },
    setValue,
  } = useForm({
    defaultValues: {
      accept: false,
      username: !subUser ? tpsUserId : '',
      email: !subUser ? tpsUserEmail : getEmail,
    },
    mode: 'all',
    resolver: yupResolver(regValidationSchema),
  });
  const otp = watch('otp', '');
  const controllingPerson = watch('controlingPerson', '');
  const userRole = watch('role');
  const errorHandler = (error) => {
    dispatch(setLoader(false));
    setErrorMsgs([parseError(error)]);
  };

  useEffect(() => {
    if (controllingPerson || userRole) {
      setNoneRoleError({});
      trigger('role');
    }
    if (userRole === '0' && !controllingPerson) {
      setNoneRoleError({ message: strings.unAuthorized });
      // setError('role', { type: 'custom', message: strings.unAuthorized });
    }
  }, [userRole, trigger, setError, controllingPerson]);

  useEffect(() => {
    if (localStorage.getItem('code') && taxId === '' && !subUser) {
      dispatch(loadTpsInfo());
    } else if (localStorage.getItem('code') === null && !subUser) {
      history.replace(routePath.TRIZETTO);
    }
  }, [tpsUserEmail, tpsUserId, taxId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setValue('isNotSubUser', true);
    setValue('username', tpsUserId);
    setValue('email', !subUser ? tpsUserEmail : getEmail);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tpsUserEmail, tpsUserId, subUser, getEmail]);

  const createCognitoUser = async (data) => {
    dispatch(setLoader(true));
    const { username, password, accept, email } = data;
    try {
      await Auth.signUp({
        username,
        password,
        attributes: {
          email,
          'custom:accept_tps': accept ? '1' : '0',
          'custom:ein': practiceEin,
        },
      });
      silienLogin(data);
    } catch (err) {
      errorHandler(err);
    }
  };
  const silienLogin = async (data) => {
    const { username, password } = data;
    try {
      const response = await Auth.signIn({
        username,
        password,
      });
      const { challengeName = '' } = response;
      if (challengeName === 'CUSTOM_CHALLENGE') {
        setUser(response);
        setSignUp(true);
        setErrorMsgs([]);
        dispatch(updateLeftPanelStatus(true));
        dispatch(setLoader(false));
      }
    } catch (err) {
      errorHandler(err);
    }
  };

  const otpSubmit = async (event) => {
    event.preventDefault();
    dispatch(setLoader(true));
    try {
      const response = await Auth.sendCustomChallengeAnswer(user, otp);
      if (response.challengeName === 'CUSTOM_CHALLENGE') {
        dispatch(setLoader(false));
        setError('otp', { type: 'custom', message: otpError });
      } else if (subUser) {
        createSsoUser();
      } else {
        saveTps();
      }
    } catch (err) {
      errorHandler({ message: 'Invalid OTP' });
    }
  };

  const createSsoUser = async () => {
    try {
      const requestBody = {
        email: getValues('email'),
        userConsent: 'Y',
        role: getValues('role'),
        controlingPerson: getValues('controlingPerson'),
      };
      if (subUser) {
        requestBody.memberRegFlag = 'Y';
      }
      await ApiClient.post(serviceUrl.signUpApiPath, requestBody);
      dispatch(setLoader(false));
      if (subUser) {
        history.push(routePath.VERIFY_YOU);
      } else {
        dispatch(updateLeftPanelStatus(false));
        dispatch(updateAuthenticatedStatus(true));
        localStorage.removeItem('code');
        history.replace(routePath.TPS_MIDDLE);
      }
      localStorage.setItem('session', uuidv4());
    } catch (err) {
      errorHandler({ message: err.message });
    }
  };
  const saveTps = async () => {
    try {
      await ApiClient.post(
        serviceUrl.saveTpsProfileApiPath,
        {},
        {
          headers: {
            orgtaxid: taxId, // coming from auth token
            orignaltaxid: localStorage.getItem('EIN'), // dynamically genaretd
            tempTpsOrgId: localStorage.getItem('siteId'), // dynamically genaretd
          },
        },
      );
      createSsoUser();
    } catch (err) {
      errorHandler(err);
    }
  };
  const resendOtp = () => {
    resetField('otp');
    setErrorMsgs([{ message: resendCodeMsg, severity: 'success' }]);
    silienLogin({
      username: getValues('username'),
      password: getValues('password'),
    });
  };
  const obj = {
    heading: regTitle,
    subHeading: regSubTitle,
    continueBtnName: strings.signUp,
  };
  if (subUser) {
    setValue('isNotSubUser', false);
    obj.heading = welcomeSubUser(firstName);
    obj.subHeading = welcomeSubHeading;
    obj.continueBtnName = strings.continue;
  }
  const { heading, subHeading } = obj;
  const confirmPass = getValues('confirmPassword');
  const newPass = watch('password');
  useConfirmPasswordTrigger({ trigger, confirmPass, newPass });
  const continueEnable = subUser
    ? getValues('accept')
    : isValid && getValues('accept') && Object.keys(noneRoleError).length === 0;

  return (
    <>
      {!signUp ? (
        <form onSubmit={handleSubmit(createCognitoUser)} data-testid="form">
          <RightPanelLayout maxWidth="600px">
            <Notification errors={errorMsgs} />
            <SingleNotification error={noneRoleError} />
            <FormHead
              heading={heading}
              subHeading={subHeading}
              showSeparator={false}
            />
            <RegistrationForm
              control={control}
              errors={errors}
              getValues={getValues}
              subUser={subUser}
            />
            <Box>
              <Typography
                id="termsAndConds"
                variant="body2"
                className={internalClasses.termsTextAreaAlignment}
              >
                {strings.tNcData}
              </Typography>
              <Link
                href="/#"
                onClick={(e) => e.preventDefault()}
                className={classes.link}
              >
                {strings.viewnPrint}
              </Link>
            </Box>
            <Box marginBottom={2}>
              <CustomCheckbox
                name="accept"
                id="accept"
                defaultValue={false}
                control={control}
                label={strings.accept}
              />
            </Box>
          </RightPanelLayout>
          <Footer
            saveNexitBtn={false}
            continueEnable={continueEnable}
            backBtn={false}
            isRegistration
          />
        </form>
      ) : (
        <Box maxWidth="500px" mx="auto">
          <Notification errors={errorMsgs} />
          <Verification
            otp={otp}
            otpSubmit={otpSubmit}
            resendOtp={resendOtp}
            control={control}
            name="otp"
            inlineError={errors?.otp?.message}
          />
        </Box>
      )}
    </>
  );
};

export default Registration;
