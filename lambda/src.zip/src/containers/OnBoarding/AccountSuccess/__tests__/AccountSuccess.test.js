import { Provider } from 'react-redux';
import { render, screen, act, fireEvent } from '@testing-library/react';
import configureStore from 'redux-mock-store';
import AccountSuccess from '../AccountSuccess';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';

import theme from 'style/theme';
import { ThemeProvider, StyledEngineProvider } from '@mui/material/styles';
import { defaultFnPropTypes } from 'utils';

const initialState = {
  onBoarding: {
    payload: {
      PRAC_INFO: {
        orgName: 'My Company Name',
      },
    },
  },
};
const store = configureStore();
const memHistory = createMemoryHistory();

describe('rendering <AccountSuccess /> component', () => {
  beforeEach(() => {
    const props = {
      handleSave: jest.fn(),
      businessName: 'Family Practice',
      accountNumber: 'acctNumber1',
      errors: [],
    };
    render(
      <Provider store={store(initialState)}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <Router history={memHistory}>
              <AccountSuccess {...props} />
            </Router>
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
  });

  it('logo must have correct src & alt chello coffee cup', async () => {
    const chelloCoffeeLogo = screen.getByAltText('logo');
    expect(chelloCoffeeLogo).toHaveAttribute(
      'src',
      '/images/transition/Coffee.gif',
    );
    expect(chelloCoffeeLogo).toHaveAttribute('alt', 'logo');
  });

  it('should render title', () => {
    expect(
      screen.getByText(
        /Your account has been opened. Have a coffee break. We’ve got you covered./i,
      ),
    ).toBeInTheDocument();
  });

  it('should render sub title', () => {
    expect(screen.getByText(/Business Name/i)).toBeInTheDocument();
  });

  it('should have Back button ', () => {
    expect(
      screen.queryByRole('button', {
        name: /Back/i,
      }),
    ).toBeNull();
  });

  it('should have exit button', async () => {
    const exitBtn = screen.getByRole('button', { name: /exit/i });
    expect(exitBtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(exitBtn);
    });

    const saveBtn = screen.getByRole('button', { name: /save & exit/i });
    expect(saveBtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(saveBtn);
    });
  });
});
