import { Typography, Grid, Box, Button } from '@mui/material';
import { NavLink as RouterLink } from 'react-router-dom';
import PropTypes from 'prop-types';

import routePath from 'routes/routePath';
import { Notification } from 'components';
import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

import ExitDialog from '../components/ExitDialog';

const {
  chelloWelcomeHeading,
  businessName,
  accountNumber,
  chelloWelcomeButton,
} = strings;

const AccountSuccess = ({
  businessNameVal,
  accountNumberVal,
  errors,
  handleSave,
}) => (
  <Box className={classes.defaultLayoutOnbWrapper}>
    <Box className={classes.transitionImgCenter}>
      <img
        src={`${process.env.PUBLIC_URL}/images/transition/Coffee.gif`}
        alt="logo"
        className={classes.transitionImg}
      />
    </Box>
    <Box maxWidth="675px" mx="auto">
      <Typography variant="h1" align="center" mt="20px">
        {chelloWelcomeHeading}
      </Typography>
      <Grid container className={classes.businessInfo}>
        {errors && errors.length > 0 && (
          <Box mb={2.5}>
            <Notification errors={errors} />
          </Box>
        )}
        <Grid item xs={12} sm={5} className={classes.verticalDirection}>
          <Typography gutterBottom variant="p1">
            {businessName}
          </Typography>
          <Typography mb="10px" variant="p1SemiBold">
            {businessNameVal}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={7} className={classes.verticalDirection}>
          <Typography gutterBottom variant="p1">
            {accountNumber}
          </Typography>
          <Typography mb="10px" variant="p1SemiBold">
            {accountNumberVal}
          </Typography>
        </Grid>
      </Grid>
      <Box display="flex" flexDirection="row" className={classes.spacing}>
        <ExitDialog noBtn handleSave={handleSave} saveNexitBtn />
        <Button
          variant="contained"
          color="primary"
          component={RouterLink}
          to={routePath.FUNDING}
          fullWidth
        >
          {chelloWelcomeButton}
        </Button>
      </Box>
    </Box>
  </Box>
);

export default AccountSuccess;

AccountSuccess.propTypes = {
  businessNameVal: PropTypes.string,
  accountNumberVal: PropTypes.string,
  errors: PropTypes.instanceOf(Object),
  handleSave: PropTypes.func,
};

AccountSuccess.defaultProps = {
  businessNameVal: '',
  accountNumberVal: '',
  errors: [],
  handleSave: defaultFnPropTypes,
};
