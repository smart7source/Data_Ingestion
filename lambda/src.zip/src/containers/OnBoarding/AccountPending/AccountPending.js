import { Typography, Grid, Box } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import strings from 'localization/translation';

const { accountPendingHeading, listOfDocuments } = strings;
const AccountPending = ({ kyb, kyc }) => (
  <Box className={classes.defaultLayoutOnbWrapper}>
    <Box className={classes.transitionImgCenter}>
      <img
        src={`${process.env.PUBLIC_URL}/images/transition/Filing_cabinet.gif`}
        alt="logo"
        className={classes.transitionImg}
      />
    </Box>
    <Box maxWidth="675px" mx="auto">
      <Typography variant="h1" align="center" mt="20px">
        {accountPendingHeading}
      </Typography>
      <Grid container className={classes.businessInfo}>
        <Grid item xs={12} className={internalClasses.centerAlignment}>
          <Typography variant="p1" align="center">
            {listOfDocuments}
          </Typography>
        </Grid>
      </Grid>
      {kyb?.documents?.map(
        (ele, index) =>
          ele?.status !== 'Pass' && <Box key={index}>{ele.docType}</Box>,
      )}
      {kyc?.map(
        (ele, index) =>
          ele?.kycStatus !== 'Pass' && <Box key={index}>{ele.memberId}</Box>,
      )}
    </Box>
  </Box>
);

export default AccountPending;

AccountPending.propTypes = {
  kyb: PropTypes.instanceOf(Object),
  kyc: PropTypes.arrayOf(PropTypes.any),
};

AccountPending.defaultProps = {
  kyb: {},
  kyc: [],
};
