import { Provider } from 'react-redux';
import { render, screen } from '@testing-library/react';
import configureStore from 'redux-mock-store';
import AccountPending from '../AccountPending';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';

import theme from 'style/theme';
import { ThemeProvider, StyledEngineProvider } from '@mui/material/styles';
import { defaultFnPropTypes } from 'utils';

const initialState = {
  onBoarding: {
    payload: {
      practiceInfo: {
        organizationName: 'My Company Name',
      },
    },
  },
};
const store = configureStore();
const memHistory = createMemoryHistory();

describe('rendering <AccountPending /> component', () => {
  beforeEach(() => {
    const props = {
      kyb: {
        orgId: 'party1',

        kybStatus: 'Pending further Review',

        documents: [
          {
            docType: 'ArticlesofIncorporation',

            docId: '1118263',

            status: 'Pending further Review',

            instructions: 'NA',
          },

          {
            docType: 'ArticlesofIncorporation',

            docId: '1118260',

            status: 'Pass',

            instructions: 'NA',
          },
        ],
      },
      kyc: [
        {
          memberId: 'party1',

          kycStatus: 'Pending further Review',

          documents: [
            {
              docType: 'License',

              docId: '1118262',

              status: 'Pass',

              instructions: 'NA',
            },
          ],
        },

        {
          memberId: 'party2',

          kycStatus: 'Pass',

          documents: [
            {
              docType: 'License',

              docId: '1118261',

              status: 'Pass',

              instructions: 'NA',
            },
          ],
        },
      ],
    };
    render(
      <Provider store={store(initialState)}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <Router history={memHistory}>
              <AccountPending {...props} />
            </Router>
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
  });

  it('logo must have correct src & alt chello coffee cup', async () => {
    const chelloCoffeeLogo = screen.getByAltText('logo');
    expect(chelloCoffeeLogo).toHaveAttribute(
      'src',
      '/images/transition/Filing_cabinet.gif',
    );
    expect(chelloCoffeeLogo).toHaveAttribute('alt', 'logo');
  });

  it('should render title', () => {
    expect(
      screen.getByText(
        /Oops! Looks like we still need these docs from you.../i,
      ),
    ).toBeInTheDocument();
  });

  it('should render text', () => {
    expect(screen.getByText(/List of documents/i)).toBeInTheDocument();
    expect(screen.getByText(/ArticlesofIncorporation/i)).toBeInTheDocument();
    expect(screen.getByText(/party1/i)).toBeInTheDocument();
  });
});
