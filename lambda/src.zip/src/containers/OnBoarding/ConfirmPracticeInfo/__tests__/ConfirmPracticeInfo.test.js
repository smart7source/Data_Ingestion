import React from 'react';
import {
  render,
  act,
  screen,
  fireEvent,
  waitFor,
  cleanup,
} from '@testing-library/react';
import configureStore from 'store/configureStore';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import { rest } from 'msw';
import { createMemoryHistory } from 'history';

import { onBoardingStateMock, onBoardingStateEmptyMock } from 'testHelpers';
import strings from 'localization/translation';
import { routePath } from 'routes';
import serviceUrl from 'api/UrlHelper';
import server from 'apiMocks/server';

import ConfirmPracticeInfo from '../ConfirmPracticeInfo';

const {
  confirmPracticeInfoHeading,
  siteId,
  businessLegalName,
  businessPhone,
  businessAddress,
  businessEmail,
  cityStateZip,
  EIN,
  apiFailedError,
  verifyAddDlogHeading,
  continueBtnName,
} = strings;
const history = createMemoryHistory();

const renderExtBtn = () => {
  const exitBtn = screen.getByRole('button', { name: strings.exit });
  expect(exitBtn).toBeDefined();
  fireEvent.click(exitBtn);
};

describe('Render ConfirmPracticeInfo component with prefilled practice info data in redux for first time user', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    render(
      <Provider store={mockStore}>
        <Router history={history}>
          <ConfirmPracticeInfo />
        </Router>
      </Provider>,
    );
  });
  afterAll(cleanup);

  test('render component with inital data', () => {
    expect(screen.getByText(confirmPracticeInfoHeading)).toBeInTheDocument();
    expect(screen.getByText(siteId)).toBeInTheDocument();
    expect(screen.getByText(businessLegalName)).toBeInTheDocument();
    expect(screen.getByText(businessPhone)).toBeInTheDocument();
    expect(screen.getByText(businessAddress)).toBeInTheDocument();
    expect(screen.getByText(businessEmail)).toBeInTheDocument();
    expect(screen.getByText(new RegExp(cityStateZip, 'i'))).toBeInTheDocument();
    expect(screen.getByText(EIN)).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', { name: strings.continue });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).not.toBeDisabled();
  });
  test('should render exit button and click functionality', () => {
    renderExtBtn();
    expect(screen.getByTestId('onboarding-exit-dialog')).toBeInTheDocument();
    expect(screen.getByText(strings.exitDialogSaveAndExit)).toBeInTheDocument();
    expect(screen.getByText(strings.exitDialogMessage4)).toBeInTheDocument();

    const noGoBkBtn = screen.getByRole('button', {
      name: strings.exitDialogMessage5,
    });
    expect(noGoBkBtn).toBeInTheDocument();
    fireEvent.click(noGoBkBtn);
    expect(
      screen.queryByTestId('onboarding-exit-dialog'),
    ).not.toBeInTheDocument();
  });

  test('should render exit dialog and click on save n exit', async () => {
    renderExtBtn();
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    await act(async () => {
      fireEvent.click(exitDialogSaveAndExitBtn);
    });
    expect(history.location.pathname).toBe(routePath.LOGIN);
  });

  test('should render exit dialog and click on yes and cancel', async () => {
    renderExtBtn();
    const exitDialogMessage4Btn = screen.getByRole('button', {
      name: strings.exitDialogMessage4,
    });
    await act(async () => {
      fireEvent.click(exitDialogMessage4Btn);
    });
    expect(history.location.pathname).toBe(routePath.LOGIN);
  });

  test('should API fail on submit form', async () => {
    server.use(
      rest.post(serviceUrl.getPracinfoApiPath, (req, res, ctx) => {
        res.networkError('Failed to connect');
      }),
    );
    const continueBtn = screen.getByTestId('form');
    await act(async () => {
      fireEvent.submit(continueBtn);
    });
    await waitFor(() =>
      expect(screen.getByText(verifyAddDlogHeading)).toBeInTheDocument(),
    );

    const cntBtn = screen.getByRole('button', { name: continueBtnName });
    await act(async () => {
      fireEvent.click(cntBtn);
    });
    await waitFor(() => {
      expect(
        screen.getByText(new RegExp(apiFailedError, 'i')),
      ).toBeInTheDocument();
    });
  });
});

describe('Render ConfirmPracticeInfo component with prefilled practice info data in redux for first time user Address Testcases', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    render(
      <Provider store={mockStore}>
        <Router history={history}>
          <ConfirmPracticeInfo />
        </Router>
      </Provider>,
    );
  });
  afterAll(cleanup);

  test('should click on continue button and verify address dialog and submit with current address', async () => {
    const continueBtn = screen.getByTestId('form');
    await act(async () => {
      fireEvent.submit(continueBtn);
    });
    await waitFor(() =>
      expect(screen.getByText(verifyAddDlogHeading)).toBeInTheDocument(),
    );
    const cntBtn = screen.getByRole('button', { name: continueBtnName });
    await act(async () => {
      fireEvent.click(cntBtn);
    });

    await waitFor(async () => {
      expect(history.location.pathname).toBe(routePath.BIT_MORE_PRACTICE_INFO);
    });
  });

  test('should click on continue button and verify address dialog and submit with undelivered address', async () => {
    server.use(
      rest.post(serviceUrl.verifyAddress, (req, res, ctx) =>
        res(
          ctx.json({
            body: {
              address: {
                street: 'street1',
                city: 'city',
                state: 'state',
                zip: '12345',
              },
              deliverable: 'undeliverable',
            },
          }),
        ),
      ),
    );
    const continueBtn = screen.getByTestId('form');
    await act(async () => {
      fireEvent.submit(continueBtn);
    });
    await waitFor(() =>
      expect(screen.getByText(verifyAddDlogHeading)).toBeInTheDocument(),
    );
    const cntBtn = screen.getByRole('button', { name: continueBtnName });
    await act(async () => {
      fireEvent.click(cntBtn);
    });
    await waitFor(async () => {
      expect(history.location.pathname).toBe(routePath.BIT_MORE_PRACTICE_INFO);
    });
  });

  test('should click on continue button and verify address dialog and submit with suggested address', async () => {
    const continueBtn = screen.getByTestId('form');
    await act(async () => {
      fireEvent.submit(continueBtn);
    });
    await waitFor(() =>
      expect(screen.getByText(verifyAddDlogHeading)).toBeInTheDocument(),
    );
    const field = screen.getByLabelText(new RegExp('street', 'i'));
    expect(field).toBeInTheDocument();
    const event = { target: { value: 'S' } };
    await act(async () => {
      fireEvent.change(field, event);
    });
    const cntBtn = screen.getByRole('button', { name: continueBtnName });
    await act(async () => {
      fireEvent.click(cntBtn);
    });
    await waitFor(async () => {
      expect(history.location.pathname).toBe(routePath.BIT_MORE_PRACTICE_INFO);
    });
  });
});

describe('Render async ConfirmPracticeInfo component', () => {
  const mockStore = configureStore(onBoardingStateEmptyMock);
  beforeAll(() => {
    server.use(
      rest.get(serviceUrl.getPracinfoApiPath, (req, res, ctx) =>
        res(
          ctx.json({
            body: {
              orgId: 'D025',
              orgTaxId: '',
              orgName: '',
              orgAddressLine1: '',
              orgAddressLine2: '',
              orgCityName: '',
              orgStateCode: '',
              orgZipCode: '',
              orgPhoneNumber: '',
              orgEmail: '',
              action: 'add',
            },
          }),
        ),
      ),
    );
  });

  beforeEach(async () => {
    render(
      <Provider store={mockStore}>
        <Router history={history}>
          <ConfirmPracticeInfo />
        </Router>
      </Provider>,
    );
  });
  afterAll(cleanup);

  test('redirect to Edit Practice component with no tps data', async () => {
    await waitFor(() => {
      expect(history.location.pathname).toBe(routePath.EDIT_PRACTICE_INFO);
    });
  });
});
