import { Box, Grid } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { useCallback, useState, useEffect } from 'react';
import { Link, Redirect } from 'react-router-dom';

import {
  displayCity,
  displayStreet,
  completedAddress,
  displayPhoneTypeNumber,
  findNamebyVal,
} from 'utils';
import { useOnboarding, useRefData } from 'hooks';
import ApiClient from 'api/ApiClient';
import strings from 'localization/translation';
import serviceUrl from 'api/UrlHelper';
import routePath from 'routes/routePath';
import { setLoader } from 'store/actions';
import { confPracPgInfo } from 'helpers/URLConfiguration';
import {
  DisplayFormValue,
  Notification,
  VerifyAddressDialog,
} from 'components';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Edit } from 'assets/svg/edit.svg';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';

const {
  confirmPracticeInfoHeading,
  siteId,
  businessLegalName,
  businessPhone,
  businessAddress,
  businessEmail,
  cityStateZip,
  EIN,
  xx,
  xxx,
} = strings;
const { pageId, pageKey } = confPracPgInfo;
const { getPracinfoApiPath } = serviceUrl;
const ConfirmPracticeInfo = () => {
  const dispatch = useDispatch();
  const {
    payload: { PRAC_INFO = {}, curPageId },
  } = useSelector((state) => state.onBoarding);
  const refData = useSelector((state) => state.global.refData);
  const { PHONE_TYPE = [] } = refData;
  useRefData(['US_STATES', 'PHONE_TYPE']);
  const [errorMsgs, setErrorMsgs] = useState([]);
  const [open, setOpen] = useState(false);
  const [redirectToEditPracInfo, setRedirectToEditPracInfo] = useState(false);
  const [suggestedAddress, setSuggestedAddress] = useState({});
  const { saveDataInRedux, exitHandler } = useOnboarding({
    savedData: PRAC_INFO,
    url: getPracinfoApiPath,
    pageKey,
    pageId,
    curPageId,
  });
  const {
    orgAddressLine1,
    orgAddressLine2,
    orgCityName,
    orgStateCode,
    orgZipCode,
    orgTaxId,
    orgPhoneNumber,
    orgName,
    orgEmail,
    orgPhoneType = '3',
  } = PRAC_INFO;

  const onModalContinue = (prefAddress) => {
    setOpen(false);
    dispatch(setLoader(true));
    let clonedPracInfo = { orgPhoneType: '3', ...PRAC_INFO };
    if (prefAddress === 'S') {
      clonedPracInfo = { ...clonedPracInfo, ...suggestedAddress };
    }
    const { action } = clonedPracInfo;
    if (action === 'add') {
      ApiClient.post(serviceUrl.getPracinfoApiPath, clonedPracInfo)
        .then(() => navigateToNextPage(clonedPracInfo))
        .catch((err) => {
          setErrorMsgs([{ message: err.message }]);
        })
        .finally(() => {
          dispatch(setLoader(false));
        });
    } else {
      navigateToNextPage(clonedPracInfo);
    }
  };

  useEffect(() => {
    if (Object.keys(PRAC_INFO)?.length > 0) {
      const { orgAddressLine2: addressLine2, ...rest } = PRAC_INFO;
      const data = Object.values(rest);
      const tempInfo = data.some((ele) => ele === '' || ele === undefined);
      setRedirectToEditPracInfo(tempInfo);
    }
  }, [PRAC_INFO]);

  const navigateToNextPage = useCallback(
    (restPayload) => {
      setOpen(false);
      saveDataInRedux({
        formData: {
          [pageKey]: {
            ...restPayload,
            // action: 'edit'
          },
          curPageId: pageId,
        },
      });
    },
    [saveDataInRedux],
  );

  const handleSubmit = useCallback(
    () => async (event) => {
      event.preventDefault();
      dispatch(setLoader(true));
      try {
        const {
          body: {
            deliverable,
            address: {
              street = orgAddressLine1,
              street2 = orgAddressLine2,
              city = orgCityName,
              region = orgStateCode,
              postCode = orgZipCode,
            },
          },
        } = await ApiClient.post(serviceUrl.verifyAddress, {
          street: orgAddressLine1,
          street2: orgAddressLine2,
          city: orgCityName,
          region: orgStateCode,
          postCode: orgZipCode,
        });
        setSuggestedAddress({
          orgAddressLine1: street,
          orgAddressLine2: street2,
          orgCityName: city,
          orgStateCode: region,
          orgZipCode: postCode,
          addressStatus: deliverable,
        });
        setOpen(true);
      } catch (e) {
        // console.log(e);
      } finally {
        dispatch(setLoader(false));
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [dispatch, PRAC_INFO],
  );

  return (
    <>
      <form onSubmit={handleSubmit()} data-testid="form">
        <RightPanelLayout maxWidth="600px">
          <Notification errors={errorMsgs} />
          <FormHead heading={confirmPracticeInfoHeading} />

          <Box justifyContent="flex-end" display="flex">
            <Link
              to={routePath.EDIT_PRACTICE_INFO}
              data-testid="edit-practice-info-link"
              style={{ color: '#231F20' }}
              underline="hover"
              className={classes.editLinkPosition}
            >
              <CustomIcon
                component={Edit}
                inheritViewBox
                className={internalClasses.confirmPracticeIcon}
              />
            </Link>
          </Box>
          <Grid container className="practice-box" spacing={4}>
            <Grid item xs={12}>
              <DisplayFormValue
                name={siteId}
                value={localStorage.getItem('siteId') || PRAC_INFO?.orgId}
                showSeparator
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DisplayFormValue
                name={businessLegalName}
                value={orgName}
                showSeparator
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DisplayFormValue
                name={businessPhone}
                value={displayPhoneTypeNumber(
                  findNamebyVal(PHONE_TYPE, orgPhoneType),
                  orgPhoneNumber,
                )}
                showSeparator
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DisplayFormValue
                name={businessAddress}
                value={displayStreet(orgAddressLine1, orgAddressLine2)}
                showSeparator
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DisplayFormValue
                name={businessEmail}
                value={orgEmail}
                showSeparator
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DisplayFormValue
                name={cityStateZip}
                value={displayCity(orgCityName, orgStateCode, orgZipCode)}
                showSeparator
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DisplayFormValue
                name={EIN}
                value={
                  PRAC_INFO &&
                  PRAC_INFO.orgTaxId &&
                  `${xx}${xxx}${orgTaxId.slice(5, 9)}`
                }
                showSeparator
              />
            </Grid>
          </Grid>
        </RightPanelLayout>
        <Footer
          backBtn={false}
          saveHandler={() => exitHandler({ saveData: false })}
        />
      </form>
      {open && (
        <VerifyAddressDialog
          crntFullAdd={completedAddress(
            orgAddressLine1,
            orgAddressLine2,
            orgCityName,
            orgStateCode,
            orgZipCode,
          )}
          suggestedAdd={completedAddress(
            suggestedAddress?.orgAddressLine1,
            suggestedAddress?.orgAddressLine2,
            suggestedAddress?.orgCityName,
            suggestedAddress?.orgStateCode,
            suggestedAddress?.orgZipCode,
          )}
          addressStatus={suggestedAddress?.addressStatus}
          handleContinue={onModalContinue}
        />
      )}
      {redirectToEditPracInfo && <Redirect to={routePath.EDIT_PRACTICE_INFO} />}
    </>
  );
};

export default ConfirmPracticeInfo;
