import { render, screen, fireEvent, act } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import Boost from '../Boost';
import { cognitoCurrentSessionMock, cognitoUserMock } from 'testHelpers';
import { createMemoryHistory } from 'history';
import { Router } from 'react-router-dom';
import Auth from '@aws-amplify/auth';

const initialState = {
  onBoarding: {
    payload: {
      siteId: '',
      curPageId: '9',
    },
  },
};
const store = configureStore(initialState);

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);
const history = createMemoryHistory();

describe('Test Boost Page', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    // await act(async () =>
    render(
      <Provider store={store}>
        <Router history={history}>
          <Boost />
        </Router>
      </Provider>,
    );
    // );
  });

  it('should render Boost Text ', async () => {
    const boostMessage1 = screen.getByText(
      new RegExp(strings.boostMessage1, 'i'),
    );
    const boostMessage2 = screen.getByText(
      new RegExp(strings.boostMessage2, 'i'),
    );
    const boostMessage3 = screen.getByText(
      new RegExp(strings.boostMessage3, 'i'),
    );
    const boostMessage4 = screen.getByText(
      new RegExp(strings.boostMessage4, 'i'),
    );
    const boostMessage5 = screen.getByText(
      new RegExp(strings.boostMessage5, 'i'),
    );
    const boostMessage6 = screen.getByText(
      new RegExp(strings.boostMessage6, 'i'),
    );
    const boostMessage7 = screen.getByText(/Want to know if you might/i);

    const boostMessage8 = screen.getByText(
      /Use our auto-cover capabilities to reduce risk /i,
    );

    const boostMessage9 = screen.getByText(
      new RegExp(strings.boostMessage9, 'i'),
    );
    expect(boostMessage1).toBeInTheDocument();
    expect(boostMessage2).toBeInTheDocument();
    expect(boostMessage3).toBeInTheDocument();
    expect(boostMessage4).toBeInTheDocument();
    expect(boostMessage5).toBeInTheDocument();
    expect(boostMessage6).toBeInTheDocument();
    expect(boostMessage7).toBeInTheDocument();
    expect(boostMessage8).toBeInTheDocument();
    expect(boostMessage9).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', {
      name: strings.continue,
    });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).toBeEnabled();
    const form = screen.getByTestId('boostForm');
    await act(async () => {
      fireEvent.submit(form);
    });
    expect(history.location.pathname).toBe(routePath.ACCOUNT_TERMS);
  });

  test('should render exit dialog and click on save n exit', async () => {
    const exitBtn = screen.getByRole('button', { name: strings.exit });
    expect(exitBtn).toBeDefined();
    await act(async () => {
      fireEvent.click(exitBtn);
    });
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    await act(async () => {
      fireEvent.click(exitDialogSaveAndExitBtn);
    });
    expect(history.location.pathname).toBe(routePath.LOGIN);
  });
});
