import { Typography, Box } from '@mui/material';
import { useHistory } from 'react-router-dom';

import { getRouteInfo } from 'utils';
import { useOnboarding } from 'hooks';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Bulb } from 'assets/svg/bulb.svg';
import { ReactComponent as Bell } from 'assets/svg/bell.svg';
import { ReactComponent as Fire } from 'assets/svg/fire.svg';
import { ReactComponent as Activity } from 'assets/svg/activity.svg';
import internalClasses from 'style/onBoarding.module.scss';

import Footer from '../components/Footer';
import { boostPgInfo } from '../../../helpers/URLConfiguration';
import strings from '../../../localization/translation';
import RightPanelLayout from '../components/RightPanelLayout';

const {
  boostMessage1,
  boostMessage2,
  boostMessage3,
  boostMessage4,
  boostMessage5,
  boostMessage6,
  boostMessage7,
  boostMessage8,
  boostMessage9,
} = strings;
const { pageId } = boostPgInfo;
const Boost = () => {
  const { exitHandler } = useOnboarding({ pageId });
  const history = useHistory();

  const submitHandler = () => {
    const { nxtPgRoute } = getRouteInfo(pageId);
    history.push(nxtPgRoute);
  };

  return (
    <form onSubmit={submitHandler} data-testid="boostForm">
      <Box marginBottom={2}>
        <img
          src={`${process.env.PUBLIC_URL}/images/boost.png`}
          alt="boost"
          width="100%"
        />
      </Box>
      <RightPanelLayout maxWidth="600px">
        <Typography variant="h1">
          {boostMessage1}{' '}
          <Typography variant="h1" component="span" color="primary">
            {boostMessage2}
          </Typography>
          {boostMessage3}{' '}
          <Typography variant="h1" component="span" color="primary">
            {boostMessage4}
          </Typography>{' '}
          {boostMessage5}
        </Typography>
        <Box pt={5}>
          <Box
            alignItems="center"
            flexDirection="row"
            display="flex"
            marginBottom={3}
          >
            <Box>
              <CustomIcon
                component={Bulb}
                inheritViewBox
                className={internalClasses.boostIcon}
              />
            </Box>
            <Box marginLeft={3}>{boostMessage6}</Box>
          </Box>
          <Box
            alignItems="center"
            flexDirection="row"
            display="flex"
            marginBottom={3}
          >
            <Box>
              <CustomIcon
                component={Bell}
                inheritViewBox
                className={internalClasses.boostIcon}
              />
            </Box>
            <Box marginLeft={3}>{boostMessage7}</Box>
          </Box>
          <Box
            alignItems="center"
            flexDirection="row"
            display="flex"
            marginBottom={3}
          >
            <Box>
              <CustomIcon
                component={Fire}
                inheritViewBox
                className={internalClasses.boostIcon}
              />
            </Box>
            <Box marginLeft={3}>{boostMessage8}</Box>
          </Box>
          <Box
            alignItems="center"
            flexDirection="row"
            display="flex"
            marginBottom={3}
          >
            <Box>
              <CustomIcon
                component={Activity}
                inheritViewBox
                className={internalClasses.boostIcon}
              />
            </Box>
            <Box marginLeft={3}>{boostMessage9}</Box>
          </Box>
        </Box>
      </RightPanelLayout>
      <Footer saveHandler={() => exitHandler({ saveData: false })} />
    </form>
  );
};

export default Boost;
