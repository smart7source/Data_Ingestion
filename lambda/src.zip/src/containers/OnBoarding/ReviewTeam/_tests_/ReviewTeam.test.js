import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
  cleanup,
} from '@testing-library/react/pure';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';

import * as utilsFn from 'utils/authentication';
import Amplify from 'aws-amplify';
import awsConfigure from 'aws-exports';
import {
  buildTeamEmptyData,
  buildTeamData,
  onBoardingStateEmptyMock,
  onBoardingStateMock,
} from 'testHelpers';
import strings from 'localization/translation';
import ReviewTeam from '../ReviewTeam';
import { createMemoryHistory } from 'history';
import { Router } from 'react-router-dom';
import server from 'apiMocks/server';
import { rest } from 'msw';
import serviceUrl from 'api/UrlHelper';
import userEvent from '@testing-library/user-event';
import { routePath } from 'routes';

Amplify.configure(awsConfigure);

const { TEAM_LOADER } = routePath;

const history = createMemoryHistory();

const renderReviewTeamComponent = async (storeValue) => {
  await act(async () =>
    render(
      <Provider store={storeValue}>
        <Router history={history}>
          <ReviewTeam />
        </Router>
      </Provider>,
    ),
  );
};

const showAddressDialog = async () => {
  const continueBtn = screen.getByTestId('form');
  fireEvent.submit(continueBtn);

  await waitFor(() =>
    expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
  );
  await waitFor(() => expect(screen.queryByRole('dialog')).toBeInTheDocument());
};

const mockService = () => {
  server.use(
    rest.get(serviceUrl.getTeamInfoApi, (req, res, ctx) =>
      res(
        ctx.json({
          status: { code: '200', description: 'Record Edited' },
          body: [buildTeamData[0]],
        }),
      ),
    ),
  );
};

describe('Testing ReviewTeam component', () => {
  beforeAll(mockService);
  afterAll(cleanup);

  test('should render component with inital data', async () => {
    const mockStore = configureStore(onBoardingStateMock);
    await renderReviewTeamComponent(mockStore);

    expect(screen.getByText(strings.reviewTeamHeading)).toBeInTheDocument();
    expect(screen.getByText(strings.reviewTeamSubHeading1)).toBeInTheDocument();
    const continueBtn = screen.getByTestId('footer-nav-continue-btn');
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).not.toBeDisabled();
  });

  test('should show address dialog, to verify address', showAddressDialog);

  test('should show error notification when getTeamInfoApi is failed', async () => {
    server.use(
      rest.put(serviceUrl.getTeamInfoApi, (req, res, ctx) => {
        res.networkError('Failed to connect');
      }),
    );

    const continueBtnDialog = screen.getByTestId('continue_btn');
    expect(continueBtnDialog).toBeInTheDocument();
    userEvent.click(continueBtnDialog);

    await waitFor(() =>
      expect(
        screen.getByTestId('single-notification-alert'),
      ).toBeInTheDocument(),
    );
  });

  test('should display error message if residency status is selected as Non-Resident Alien', async () => {
    const resStatus = screen.getByTestId('resStatus_0');
    fireEvent.change(resStatus, { target: { value: '4' } });

    expect(await screen.findByText(strings.accountFailed)).toBeInTheDocument();

    fireEvent.change(resStatus, { target: { value: '1' } });
    await waitFor(() =>
      expect(screen.queryByText(strings.accountFailed)).not.toBeInTheDocument(),
    );
  });

  test(
    'should show address dialog, before verifying successfully',
    showAddressDialog,
  );

  test('when Continue button is click, user is prompted with Verify Team Address Dialog Box', async () => {
    server.use(
      rest.put(serviceUrl.getTeamInfoApi, (req, res, ctx) =>
        res(
          ctx.json({
            status: { code: '200', description: 'Record Edited' },
            body: {
              successResponseList: [
                {
                  responseCode: 200,
                  responseMessage: '200 OK',
                  customResponseMessage: 'Success',
                  value: {
                    memberId: '4hdG1sKzlLhm-V----9F-Bg-',
                    tpsMemberId: 'shams',
                    lastName: 'Majumder',
                    firstName: 'Sayantak',
                    phone: '3140890999',
                    phoneType: '1',
                    dob: '2002-01-01T00:00:00.000Z',
                    email: 'chello406072620@mailinator.com',
                    ssn: '451234561',
                    city: 'Roberto',
                    address: 'Robert Street',
                    address2: 'Robert Street Line Street2',
                    state: 'DC',
                    country: 'US',
                    zip: '45463',
                    resStatus: '2',
                    percentageOwnership: '',
                    role: '3',
                    primaryApplicant: 'N',
                    controlingPerson: false,
                    tpsMember: true,
                    beneficialOwnerRole: '2',
                    partyRelType: '3',
                    applicantRel: '10',
                  },
                },
              ],
            },
          }),
        ),
      ),
    );

    const continueBtnDialog = screen.getByTestId('continue_btn');
    expect(continueBtnDialog).toBeInTheDocument();
    userEvent.click(continueBtnDialog);
    await waitFor(() => expect(history.location.pathname).toBe(TEAM_LOADER));
  });
});

describe('Testing edit address', () => {
  beforeAll(mockService);
  afterAll(cleanup);

  test('should render component', async () => {
    const mockStore = configureStore(onBoardingStateMock);
    await renderReviewTeamComponent(mockStore);
    expect(screen.getByText(strings.reviewTeamHeading)).toBeInTheDocument();
  });

  test('should show address dialog', showAddressDialog);

  test('Should allow user to edit address when "edit all address" button is clicked', async () => {
    expect(screen.queryByRole('dialog')).toBeInTheDocument();
    const EditAllAddsBtn = screen.getByTestId('verify-team-edit-address');
    fireEvent.click(EditAllAddsBtn);
    await waitFor(() =>
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument(),
    );
  });
});

describe('Testing ReviewTeam component with empty data', () => {
  const emptyMock = configureStore(onBoardingStateEmptyMock);

  afterAll(cleanup);
  test('Should render component with empty data', async () => {
    server.use(
      rest.get(serviceUrl.getTeamInfoApi, (req, res, ctx) =>
        res(
          ctx.json({
            status: { code: '200', description: 'Record Edited' },
            body: buildTeamEmptyData,
          }),
        ),
      ),
    );
    await renderReviewTeamComponent(emptyMock);
    expect(screen.getByText(strings.reviewTeamHeading)).toBeInTheDocument();
  });

  test('Should render exit dialog when exit button clicked', async () => {
    const exitBtn = screen.getByTestId('footer-nav-exit-btn');
    expect(exitBtn).toBeDefined();
    userEvent.click(exitBtn);

    const exitDialog = await screen.findByTestId('onboarding-exit-dialog');

    expect(exitDialog).toBeInTheDocument();
  });

  test('Should save and exit when save and exit button is clicked', async () => {
    const mockFn = jest.spyOn(utilsFn, 'handleLogout');
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    userEvent.click(exitDialogSaveAndExitBtn);
    await waitFor(() => expect(mockFn).toHaveBeenCalled());
  });
});
