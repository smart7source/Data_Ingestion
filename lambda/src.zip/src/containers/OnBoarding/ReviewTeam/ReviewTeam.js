/* eslint-disable max-lines */
import {
  Box,
  Typography,
  Grid,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Alert,
} from '@mui/material';
import { useEffect, useState } from 'react';
import { useFieldArray, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch, useSelector } from 'react-redux';

import { useOnboarding, useRefData } from 'hooks';
import { isValidDateofBirth, isValidDate } from 'utils';
import routePath from 'routes/routePath';
import { rvwTeamPgInfo } from 'helpers/URLConfiguration';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import { editPersonalDetailsValidationSchema } from 'helpers/ValidationSchema';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { setLoader } from 'store/actions';
import { SingleNotification, Notification } from 'components';
import VerifyTeamAddressDialog from 'components/UIElements/VerifyTeamAddressDialog/VerifyTeamAddressDialog';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as AlertTriangle } from 'assets/svg/alert-triangle.svg';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';
import internalClasses from 'style/onBoarding.module.scss';

import Footer from '../components/Footer';
import EditPersonalDetails from '../EditPersonalDetails/EditPersonalDetails';
import FormHead from '../components/FormHead';
import ReviewTeamAccordian from '../components/ReviewTeamAccordian';
import {
  transformResponse,
  transformAPIPayload,
} from '../BuildTeam/components/TransformPayload';

const {
  reviewTeamHeading,
  reviewTeamSubHeading1,
  reviewTeamAlert1,
  accountFailed,
  dobFailed,
} = strings;
const { pageId, pageKey } = rvwTeamPgInfo;
const { getTeamInfoApi } = serviceUrl;
const ReviewTeam = () => {
  const [error, setError] = useState({});
  const [errMsgs, setErrMsgs] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [showDOBError, setShowDOBError] = useState(false);
  const [prefAdds, setPrefAdds] = useState({});
  const [sugAdds, setSugAdds] = useState([]);
  const [enable, setEnable] = useState(true);
  const payload = useSelector((state) => state.onBoarding.payload);
  const refData = useSelector((state) => state.global.refData);
  const [savedUsers, setSavedUsers] = useState([]);
  const {
    US_STATES = [],
    PHONE_TYPE = [],
    COUNTRY_CODE = [],
    CHELLO_RESIDENCY_STATUS = [],
    CHELLO_INDIVIDUAL_ROLE = [],
  } = refData;
  useRefData([
    'US_STATES',
    'PHONE_TYPE',
    'COUNTRY_CODE',
    'CHELLO_RESIDENCY_STATUS',
    'CHELLO_INDIVIDUAL_ROLE',
  ]);
  const { saveDataInRedux, exitHandler } = useOnboarding({
    pageId,
    url: getTeamInfoApi,
    pageKey,
    curPageId: payload.curPageId,
  });
  const dispatch = useDispatch();

  const [expanded, setExpanded] = useState('panel0');

  const {
    control,
    reset,
    handleSubmit,
    getValues,
    formState: { errors, isValid },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(editPersonalDetailsValidationSchema),
  });
  const { fields } = useFieldArray({
    control,
    name: 'additionalUsers',
  });

  const onModalContinue = async (allUsersData) => {
    const partialPayload = transformAPIPayload(
      allUsersData,
      savedUsers,
      false,
      [],
      true,
    );
    const { allUsers, ...rest } = partialPayload || {};
    try {
      dispatch(setLoader(true));
      const response = await ApiClient.put(getTeamInfoApi, rest);
      const { successResponseList } = response?.body;
      const parseSuccessArray = successResponseList.map((item) => item?.value);
      setSavedUsers(parseSuccessArray);
      const errorsArr = transformResponse(response?.body);
      setErrMsgs(errorsArr);
      const formData = {
        [pageKey]: allUsers,
        curPageId: pageId,
      };
      const moveToNext = !(errorsArr && errorsArr.length > 0);
      saveDataInRedux({
        formData,
        moveToNext,
        customPath: moveToNext ? routePath.TEAM_LOADER : '',
      });
    } catch (err) {
      setError({ message: err.message });
    } finally {
      dispatch(setLoader(false));
    }
  };

  const submitHandler = async (data) => {
    try {
      dispatch(setLoader(true));
      const { additionalUsers } = data;
      const p = [];
      additionalUsers.forEach((user, index) => {
        p[index] = ApiClient.post(serviceUrl.verifyAddress, {
          street: user.address,
          street2: user.address2,
          city: user.city,
          region: user.state,
          postCode: user.zip,
        });
      });
      const res = await Promise.all(p);
      let adds = [];
      let adrress = {};
      res.forEach((v) => {
        adrress = {
          ...v.body.address,
          state: v.body.address.region,
          addressStatus: v.body.deliverable,
        };
        adds = [...adds, adrress];
      });
      setSugAdds(adds);
      setOpenDialog(true);
    } catch (e) {
      // console.log(e);
    } finally {
      dispatch(setLoader(false));
    }
  };

  const getResidencyStatus = (data) =>
    data.some((ele) => ele.resStatus === '4');

  const getValidDOB = (data) => {
    const tempArr = [];
    data?.forEach((item) => {
      if (isValidDate(item.dob)) tempArr.push(isValidDateofBirth(item.dob));
    });
    return tempArr.some((ele) => !ele);
  };

  const checkValidResidencyStatus = (data) => {
    const resStatus = getResidencyStatus(data);
    if (resStatus) {
      setEnable(false);
    } else if (!resStatus) {
      setEnable(true);
    }
  };

  const checkValidDateofBirth = (data) => {
    const dateStatus = getValidDOB(data);
    if (dateStatus) {
      setShowDOBError(true);
    } else if (!dateStatus) {
      setShowDOBError(false);
    }
  };

  useEffect(() => {
    if (payload[pageKey]?.length > 0) {
      let cloneAddUsers = payload[pageKey].filter(
        (ele) => !(ele.role === '0' && !ele.controlingPerson),
      );
      cloneAddUsers = cloneAddUsers.map((obj) => ({
        ...obj,
        country: obj.country ? obj.country : 'US',
        phoneType: obj.phoneType ? obj.phoneType : '2',
      }));
      checkValidResidencyStatus(cloneAddUsers);
      checkValidDateofBirth(cloneAddUsers);
      reset({ additionalUsers: cloneAddUsers });
    }
  }, [payload, reset]);

  const checkError = (index) => {
    const values = getValues('additionalUsers')[index];
    const picked = (({
      firstName,
      lastName,
      email,
      phone,
      dob,
      ssn,
      address,
      city,
      state,
      zip,
      country,
      resStatus,
      phoneType,
    }) => ({
      firstName,
      lastName,
      email,
      phone,
      dob,
      ssn,
      address,
      city,
      state,
      zip,
      country,
      resStatus,
      phoneType,
    }))(values);
    const covertedArr = Object.values(picked);
    if (covertedArr.some((ele) => ele === '')) {
      return false;
    }
    if (
      errors &&
      errors.additionalUsers &&
      errors?.additionalUsers[index] &&
      Object.keys(errors?.additionalUsers?.[index]).length > 0
    ) {
      return false;
    }

    return true;
  };

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };

  const handleDateofBirthChange = (value) => {
    const dobStatus = getValidDOB(getValues('additionalUsers'));
    if (value) {
      const isValidDOB = isValidDateofBirth(value);
      if (!isValidDOB || dobStatus) {
        setShowDOBError(true);
      } else if (isValidDOB && !dobStatus) {
        setShowDOBError(false);
      }
    }
  };

  const handleResidencyChange = (value) => {
    const resStatus = getResidencyStatus(getValues('additionalUsers'));
    if (value === '4' || resStatus) {
      setEnable(false);
    } else if (value !== '4' && !resStatus) {
      setEnable(true);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit(submitHandler)} data-testid="form">
        <Box className="formBox">
          <Grid container>
            <Grid item xs={12} sm={12} md={10}>
              <SingleNotification error={error} severity="warning" />
              {errMsgs && errMsgs.length > 0 && (
                <Box mb={2.5}>
                  <Notification errors={errMsgs} />
                </Box>
              )}
              <FormHead
                heading={reviewTeamHeading}
                subHeading={reviewTeamSubHeading1}
                showSeparator={false}
              />
              {!isValid && (
                <Box marginBottom={1}>
                  <Alert
                    severity="warning"
                    icon={false}
                    classes={{
                      root: classes.alertRoot,
                      standardWarning: classes.alertStandardWarning,
                      message: classes.alertMsgAlignment,
                    }}
                  >
                    <Box className={internalClasses.reviewTeamAlert}>
                      <Typography variant="p2SemiBold">
                        {reviewTeamAlert1}
                      </Typography>
                      <CustomIcon
                        component={AlertTriangle}
                        inheritViewBox
                        className={internalClasses.reviewTeamAlertTriangleIcon}
                      />
                    </Box>
                  </Alert>
                </Box>
              )}
              {!enable && (
                <SingleNotification error={{ message: accountFailed }} />
              )}
              {showDOBError && (
                <SingleNotification error={{ message: dobFailed }} />
              )}
              <Box>
                {fields.map((item, index) => (
                  <Accordion
                    key={item.id}
                    data-testid={`accordian-${index}`}
                    expanded={expanded === `panel${index}`}
                    onChange={handleChange(`panel${index}`)}
                    className={internalClasses.reviewTeamAccordion}
                  >
                    <AccordionSummary
                      expandIcon={
                        <CustomIcon
                          component={ChevronDown}
                          inheritViewBox
                          className={internalClasses.reviewTeamAccordionIcon}
                        />
                      }
                      aria-controls={`panel_${index}`}
                      data-testid={`panel_${index}`}
                      id={`panel_${index}`}
                    >
                      <ReviewTeamAccordian
                        item={item}
                        roles={CHELLO_INDIVIDUAL_ROLE}
                        checkError={checkError}
                        index={index}
                      />
                    </AccordionSummary>
                    <AccordionDetails>
                      <EditPersonalDetails
                        item={item}
                        index={index}
                        control={control}
                        errors={errors}
                        states={US_STATES}
                        phoneTypes={PHONE_TYPE}
                        countries={COUNTRY_CODE}
                        residencyStatusList={CHELLO_RESIDENCY_STATUS}
                        handleResidencyChange={handleResidencyChange}
                        handleDateofBirthChange={handleDateofBirthChange}
                      />
                    </AccordionDetails>
                  </Accordion>
                ))}
              </Box>
            </Grid>
          </Grid>
        </Box>
        <Footer
          saveHandler={() =>
            exitHandler({
              payload: transformAPIPayload(
                getValues('additionalUsers'),
                savedUsers,
                true,
                [],
                true,
              ),
              endPoint: getTeamInfoApi,
              method: 'post',
            })
          }
          continueEnable={enable && isValid && !showDOBError}
        />
      </form>
      {openDialog && (
        <VerifyTeamAddressDialog
          open={openDialog}
          openAcc={handleChange}
          handleCLose={() => setOpenDialog(false)}
          users={getValues('additionalUsers')}
          prefAdds={prefAdds}
          setPrefAdds={setPrefAdds}
          sugAdds={sugAdds}
          onModalContinue={onModalContinue}
        />
      )}
    </>
  );
};

export default ReviewTeam;
