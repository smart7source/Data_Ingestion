import { Box, Typography } from '@mui/material';

import useTransition from 'hooks/useTransition';
import routePath from 'routes/routePath';
import strings from 'localization/translation';
import { useOnboarding } from 'hooks';
import serviceUrl from 'api/UrlHelper';
import { addDocPgInfo } from 'helpers/URLConfiguration';
import classes from 'style/globalStyle.module.scss';

const { teamLoaderMessage1, teamLoaderMessage2, teamLoaderMessage3 } = strings;
const { pageId, pageKey } = addDocPgInfo;
const TeamLoader = () => {
  useTransition({ redirectPath: routePath.ADD_DOCUMENTS });
  useOnboarding({ url: serviceUrl.getUploadDocs, pageId, pageKey });

  return (
    <Box className={classes.defaultLayoutOnbWrapper}>
      <Box className={classes.transitionImgCenter}>
        <img
          src={`${process.env.PUBLIC_URL}/images/transition/Desk.gif`}
          alt="logo"
          className={classes.transitionImg}
        />
      </Box>
      <Box maxWidth="500px" mx="auto">
        <Typography variant="h1" textAlign="center">
          {teamLoaderMessage1}
        </Typography>
        <Typography variant="h1" textAlign="center">
          {teamLoaderMessage2}
        </Typography>
        <Typography variant="h1" textAlign="center">
          {teamLoaderMessage3}
        </Typography>
      </Box>
    </Box>
  );
};

export default TeamLoader;
