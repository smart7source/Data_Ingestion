import { Provider } from 'react-redux';
import { render, screen, act } from '@testing-library/react';
import configureStore from 'store/configureStore';
import TeamLoader from '../TeamLoader';
import { onBoardingStateEmptyMock } from 'testHelpers';
import strings from 'localization/translation';

const mockStore = configureStore(onBoardingStateEmptyMock);

describe('Rendering Team Loader Page', () => {
  beforeEach(async () => {
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <TeamLoader />
        </Provider>,
      ),
    );
  });
  it('Must include image', () => {
    expect(screen.getByAltText('logo')).toBeInTheDocument();
  });

  it('Should include text', () => {
    expect(screen.getByText(strings.teamLoaderMessage1)).toBeInTheDocument();
    expect(screen.getByText(strings.teamLoaderMessage2)).toBeInTheDocument();
    expect(screen.getByText(strings.teamLoaderMessage3)).toBeInTheDocument();
  });
});
