import React from 'react';
import { render, screen, act } from '@testing-library/react';

import { routePath } from 'routes';
import { renderWithProviderAndRouter } from 'testHelpers';
import App from 'containers/App/App';

const { CANCEL_ONBOARDING } = routePath;

describe('Testing cancel onboarding page', () => {
  beforeEach(async () => {
    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: CANCEL_ONBOARDING,
        render,
      }),
    );
  });

  it('should render page successfully', () => {
    const formBox = screen.getByTestId('formBox');
    expect(formBox).toBeInTheDocument();
  });
});
