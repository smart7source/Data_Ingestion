import { Box } from '@mui/material';

import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

const { cancelOnboardingTpsMsg } = strings;
const CancelOnBoarding = () => (
  <>
    <Box className={classes.defaultLayoutMainWrapper} data-testid="formBox">
      {cancelOnboardingTpsMsg}
    </Box>
  </>
);

export default CancelOnBoarding;
