import { Provider } from 'react-redux';
import { render, screen, act, fireEvent } from '@testing-library/react';
import configureStore from 'redux-mock-store';
import AccountSubmitted from '../AccountSubmitted';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';

import { primaryColor } from '../../../../utils/constant';
import theme from 'style/theme';
import { ThemeProvider, StyledEngineProvider } from '@mui/material/styles';
import { defaultFnPropTypes } from 'utils';

const initialState = {
  onBoarding: {
    payload: {
      practiceInfo: {
        organizationName: 'My Company Name',
      },
    },
  },
};
const store = configureStore();
const memHistory = createMemoryHistory();

describe('rendering <AccountSubmitted /> component', () => {
  beforeEach(() => {
    const props = {
      history: {
        push: defaultFnPropTypes,
      },
      submitStatus: 'KYBKYC_FAILED',
    };
    render(
      <Provider store={store(initialState)}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <Router history={memHistory}>
              <AccountSubmitted {...props} />
            </Router>
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
  });

  it('logo must have correct src & alt chello coffee cup', async () => {
    const chelloCoffeeLogo = screen.getByAltText('logo');
    expect(chelloCoffeeLogo).toHaveAttribute(
      'src',
      '/images/transition/Paper_plane.gif',
    );
    expect(chelloCoffeeLogo).toHaveAttribute('alt', 'logo');
  });

  it('should render title', () => {
    expect(
      screen.getByText(
        /Thank you for submitting your application. A member of our team will reach out to you shortly./i,
      ),
    ).toBeInTheDocument();
  });
});
