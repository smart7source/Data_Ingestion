import { Typography, Box } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

const { accountSubmitted, accountSubmittedFail } = strings;
const AccountSubmitted = ({ submitStatus }) => (
  <Box className={classes.defaultLayoutOnbWrapper}>
    <Box className={classes.transitionImgCenter}>
      <img
        src={`${process.env.PUBLIC_URL}/images/transition/Paper_plane.gif`}
        alt="logo"
        className={classes.transitionImg}
      />
    </Box>
    <Box maxWidth="675px" mx="auto">
      <Typography variant="h1" gutterBottom align="center">
        {submitStatus === 'KYBKYC_FAILED'
          ? accountSubmittedFail
          : accountSubmitted}
      </Typography>
    </Box>
  </Box>
);

AccountSubmitted.propTypes = {
  submitStatus: PropTypes.string,
};

AccountSubmitted.defaultProps = {
  submitStatus: '',
};

export default AccountSubmitted;
