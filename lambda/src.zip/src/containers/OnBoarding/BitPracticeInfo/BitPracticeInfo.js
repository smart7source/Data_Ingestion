/* eslint-disable max-lines */
import { useCallback, useEffect, useState } from 'react';
import {
  Box,
  FormControlLabel,
  Radio,
  RadioGroup,
  FormControl,
  Alert,
  Typography,
} from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useSelector, useDispatch } from 'react-redux';
import clsx from 'clsx';

import { useOnboarding, useRefData, useClearNotification } from 'hooks';
import { minDate, bitPracticeInfoRefKeys } from 'utils';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import { bitMoreValidationScheme } from 'helpers/ValidationSchema';
import { addPracPgInfo } from 'helpers/URLConfiguration';
import ApiClient from 'api/ApiClient';
import { setLoader } from 'store/actions';
import serviceUrl from 'api/UrlHelper';
import strings from 'localization/translation';
import {
  CustomInput,
  CustomSelectBox,
  Notification,
  DatePicker,
} from 'components';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';

import TransformPayload from './TransformPayload';
import ActivitiesList from './ActivitiesList';

const { pageId, pageKey } = addPracPgInfo;
const { getAddPracinfoApiPath, getPracinfoApiPath } = serviceUrl;
const BitPracticeInfo = () => {
  const payload = useSelector((state) => state.onBoarding.payload);
  const refData = useSelector((state) => state.global.refData);
  const {
    BUSINESS_TYPE: businessTypeData,
    COUNTRY_CODE: countryOfOperationData,
    CHELLO_NAIC_CODE: naicCodeData,
    US_STATES: statesData,
    CHELLO_LEGAL_ENTITY: structureData,
  } = refData;
  const dispatch = useDispatch();
  useRefData(bitPracticeInfoRefKeys);
  const { saveDataInRedux, exitHandler } = useOnboarding({
    savedData: payload[pageKey],
    url: getAddPracinfoApiPath,
    pageKey,
    pageId,
    curPageId: payload.curPageId,
  });

  const [errorMsgs, setErrorMsgs] = useState([]);
  const {
    control,
    reset,
    watch,
    getValues,
    handleSubmit,
    trigger,
    formState: { errors, isValid },
  } = useForm({
    mode: 'all',
    defaultValues: {
      opnCountry: 'US',
    },
    resolver: yupResolver(bitMoreValidationScheme),
  });

  const operationStartDateValue = watch('opnStartDate');
  const establishedDateWatch = watch('establishedDate');

  useEffect(() => {
    if (operationStartDateValue) {
      trigger('opnStartDate');
    }
  }, [trigger, operationStartDateValue, establishedDateWatch]);

  const clearFn = useCallback(() => {
    setErrorMsgs([]);
  }, []);

  useClearNotification({
    watch,
    clear: errorMsgs.length,
    clearFn,
  });

  const handleSuccess = useCallback(
    (data) => {
      const formData = {
        [pageKey]: data,
        curPageId: pageId,
        PRAC_INFO: {
          ...payload?.PRAC_INFO,
          action: 'edit',
        },
      };
      saveDataInRedux({
        formData,
      });
      dispatch(setLoader(false));
    },
    [dispatch, payload?.PRAC_INFO, saveDataInRedux],
  );

  const apiCallHandler = useCallback(
    (url, methodParam, payloadParam) => {
      ApiClient[methodParam](url, payloadParam)
        .then(() => handleSuccess(payloadParam))
        .catch((err) => {
          setErrorMsgs([{ message: strings.systemError }]);
          dispatch(setLoader(false));
        });
    },
    [handleSuccess, dispatch],
  );

  useEffect(() => {
    if (!payload?.PRAC_INFO) {
      ApiClient.get(getPracinfoApiPath).then((data) => {
        const { body } = data;
        saveDataInRedux({
          formData: {
            PRAC_INFO: {
              ...body,
            },
            curPageId: pageId,
          },
          moveToNext: false,
        });
      });
    }
  }, []);

  useEffect(() => {
    let updatedPayload = {};
    if (payload?.[pageKey]) {
      updatedPayload = {
        ...payload[pageKey],
        opnCountry: 'US',
      };
      if (!payload?.[pageKey]?.businessType) {
        updatedPayload = {
          ...updatedPayload,
          businessType: '62',
        };
      }
      reset(updatedPayload);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payload]);

  const submitHandler = useCallback(
    (data) => {
      dispatch(setLoader(true));
      const { PRAC_INFO = {} } = payload;
      const { action } = PRAC_INFO;
      const modifiedPayload = TransformPayload(data, false);
      if (Object.keys(PRAC_INFO).length > 0) {
        const method = action === 'add' ? 'post' : 'put';
        const url =
          action === 'add' ? getPracinfoApiPath : getAddPracinfoApiPath;
        const { party_org: partyOrg, orgTaxId, ...rest } = modifiedPayload;
        apiCallHandler(url, method, rest);
      }
    },
    [apiCallHandler, dispatch, payload],
  );

  return (
    <form
      onSubmit={handleSubmit(submitHandler)}
      data-testid="bitPracticeInfoForm"
    >
      <RightPanelLayout maxWidth="600px">
        <Notification errors={errorMsgs} />
        <FormHead
          heading={strings.bitPracticeInfo}
          subHeading={strings.bitPracticeInfoSubHeading}
        />

        <Box>
          <CustomInput
            label={strings.doingBusiness}
            error={!!errors.doingBusiness}
            inputProps={{ maxLength: 50 }}
            id="dbaName"
            name="dbaName"
            control={control}
            optionalLabel={strings.optional}
            dataTestid="dbaName"
          />
        </Box>
        <Box>
          <CustomSelectBox
            dataTestid="businessLegalStructure"
            label={strings.businessLegalStructure}
            options={structureData}
            error={!!errors.legalStructure}
            errorText={errors.legalStructure && errors.legalStructure.message}
            name="legalStructure"
            id="legalStructure"
            control={control}
          />
        </Box>
        <Box>
          <DatePicker
            id="establishedDate"
            name="establishedDate"
            label={strings.dateBusinessEstablished}
            control={control}
            error={!!errors.establishedDate}
            errorText={errors.establishedDate && errors.establishedDate.message}
            // maxDateValue={businessEstablishedMaxDate}
            maxDateValue={new Date()}
            dataTestid="dateBusinessEstablished"
            returnDateFormat="yyyy-MM-DD"
            placeHolder={strings.selectDateFormat}
          />
        </Box>
        <Box>
          <DatePicker
            dataTestid="operationStartDate"
            id="opnStartDate"
            name="opnStartDate"
            label={strings.operationStartDate}
            control={control}
            error={!!errors.opnStartDate}
            errorText={errors.opnStartDate && errors.opnStartDate.message}
            // minDateValue={operationStartMinDate}
            maxDateValue={new Date()}
            returnDateFormat="yyyy-MM-DD"
            placeHolder={strings.selectDateFormat}
          />
        </Box>
        <Box>
          <CustomSelectBox
            dataTestid="countryOperation"
            label={strings.countryOperation}
            options={countryOfOperationData}
            error={!!errors.opnCountry}
            errorText={errors.opnCountry && errors.opnCountry.message}
            name="opnCountry"
            id="opnCountry"
            disabled
            control={control}
          />
        </Box>
        <Box>
          <CustomSelectBox
            dataTestid="stateLegalFormation"
            label={strings.stateLegalFormation}
            options={statesData}
            error={!!errors.stateLegalInfo}
            errorText={errors.stateLegalInfo && errors.stateLegalInfo.message}
            id="stateLegalInfo"
            name="stateLegalInfo"
            control={control}
          />
        </Box>
        <Box>
          <CustomSelectBox
            dataTestid="typeBusiness"
            label={strings.typeBusiness}
            options={businessTypeData}
            error={!!errors.businessType}
            errorText={errors.businessType && errors.businessType.message}
            name="businessType"
            id="businessType"
            control={control}
          />
        </Box>
        <Box>
          <CustomSelectBox
            dataTestid="NAICNumber"
            label={strings.NAICNumber}
            options={naicCodeData}
            error={!!errors.naicNumber}
            errorText={errors.naicNumber && errors.naicNumber.message}
            name="naicNumber"
            id="naicNumber"
            control={control}
          />
        </Box>
        <Box className={classes.bitPracticeInfoRadioBox}>
          <Controller
            defaultValue=""
            render={({ field }) => (
              <FormControl error={!!errors.certifyPracticeFlag}>
                <RadioGroup {...field} value={field.value}>
                  <FormControlLabel
                    htmlFor="checkbox-1"
                    value="Y"
                    control={<Radio color="primary" id="checkbox-1" />}
                    label={
                      <Typography variant="h3">
                        {strings.bitPracticeInfoFormLabel1}
                      </Typography>
                    }
                  />
                  <ActivitiesList />
                  <FormControlLabel
                    htmlFor="checkbox-2"
                    value="N"
                    control={<Radio color="primary" id="checkbox-2" />}
                    label={
                      <Typography variant="h3">
                        {strings.bitPracticeInfoFormLabel2}
                      </Typography>
                    }
                  />
                  {field.value === 'N' && (
                    <Alert
                      icon={false}
                      severity="error"
                      classes={{
                        root: clsx(
                          classes.alertRoot,
                          internalClasses.bitListError,
                        ),
                        standardError: classes.alertStandardError,
                      }}
                    >
                      {strings.listedActivity}
                    </Alert>
                  )}
                </RadioGroup>
              </FormControl>
            )}
            name="certifyPracticeFlag"
            control={control}
          />
        </Box>
      </RightPanelLayout>
      <Footer
        saveHandler={() =>
          exitHandler({
            payload: TransformPayload(getValues(), true),
            endPoint: getAddPracinfoApiPath,
            method: 'put',
          })
        }
        continueEnable={isValid && watch('certifyPracticeFlag') === 'Y'}
      />
    </form>
  );
};

export default BitPracticeInfo;
