import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import { rest } from 'msw';
import { Router, MemoryRouter, Route } from 'react-router-dom';

import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  onBoardingStateMock,
  onBoardingStateEmptyMock,
} from 'testHelpers';
import serviceUrl from 'api/UrlHelper';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import Auth from '@aws-amplify/auth';
import App from 'containers/App/App';
import server from 'apiMocks/server';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('Render async ConfirmPracticeInfo component', () => {
  let testHistory, testLocation;
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    await act(async () =>
      render(
        <MemoryRouter initialEntries={[routePath.BIT_MORE_PRACTICE_INFO]}>
          <Provider store={mockStore}>
            <App />
          </Provider>
          <Route
            path="*"
            render={({ history, location }) => {
              testHistory = history;
              testLocation = location;
              return null;
            }}
          />
        </MemoryRouter>,
      ),
    );
  });
  test('render component with inital data', async () => {
    await waitFor(async () => {
      expect(screen.getByText(strings.bitPracticeInfo)).toBeInTheDocument();
      expect(
        screen.getByText(strings.bitPracticeInfoSubHeading),
      ).toBeInTheDocument();
      expect(screen.getByTestId('dbaName')).toBeInTheDocument();
      expect(screen.getByTestId('businessLegalStructure')).toBeInTheDocument();
      expect(screen.getByTestId('dateBusinessEstablished')).toBeInTheDocument();
      expect(screen.getByTestId('operationStartDate')).toBeInTheDocument();
      expect(screen.getByTestId('countryOperation')).toBeInTheDocument();
      expect(screen.getByTestId('countryOperation')).toHaveValue('US');
      expect(screen.getByTestId('stateLegalFormation')).toBeInTheDocument();
      expect(screen.getByTestId('typeBusiness')).toBeInTheDocument();
      expect(screen.getByTestId('NAICNumber')).toBeInTheDocument();
    });
  });

  test('Back button functionality', async () => {
    const backBtn = screen.getByRole('button', { name: strings.back });
    expect(backBtn).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(backBtn);
    });
  });

  test('Select radio no option', async () => {
    const field = screen.getByLabelText(
      new RegExp(strings.bitPracticeInfoFormLabel2, 'i'),
    );
    expect(field).toBeInTheDocument();
    const event = { target: { value: 'N' } };

    await act(async () => {
      fireEvent.click(field, event);
    });
    expect(screen.getByText(strings.listedActivity)).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: strings.continueBtnName }),
    ).toBeDisabled();
  });

  test('Select radio Yes option', async () => {
    const field = screen.getByLabelText(
      new RegExp(strings.bitPracticeInfoFormLabel1, 'i'),
    );
    expect(field).toBeInTheDocument();
    const event = { target: { value: 'Y' } };

    await act(async () => {
      fireEvent.click(field, event);
    });
    // expect(screen.getByText(strings.listedActivity)).not.toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: strings.continueBtnName }),
    ).toBeEnabled();
  });

  test('Submit form successfully', async () => {
    server.use(
      rest.put(serviceUrl.getAddPracinfoApiPath, (req, res, ctx) => {
        return res(
          ctx.json({
            status: { code: '200', description: 'Record Edited' },
          }),
        );
      }),
    );
    const form = screen.getByTestId('bitPracticeInfoForm');
    await act(async () => {
      fireEvent.submit(form);
    });
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    expect(testHistory.location.pathname).toBe(routePath.BUILD_TEAM);
  });

  test('Api should fail on submit form', async () => {
    server.use(
      rest.put(serviceUrl.getAddPracinfoApiPath, (req, res, ctx) => {
        res.networkError('Failed to connect');
      }),
    );
    const form = screen.getByTestId('bitPracticeInfoForm');
    await act(async () => {
      fireEvent.submit(form);
    });
  });
});

describe('Render async ConfirmPracticeInfo component', () => {
  let testHistory, testLocation;
  const mockStore = configureStore(onBoardingStateEmptyMock);
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    await act(async () =>
      render(
        <MemoryRouter initialEntries={[routePath.BIT_MORE_PRACTICE_INFO]}>
          <Provider store={mockStore}>
            <App />
          </Provider>
          <Route
            path="*"
            render={({ history, location }) => {
              testHistory = history;
              testLocation = location;
              return null;
            }}
          />
        </MemoryRouter>,
      ),
    );
  });
  test('render component with inital data', async () => {
    server.use(
      rest.put(serviceUrl.getAddPracinfoApiPath, (req, res, ctx) => {
        return res(
          ctx.json({
            status: { code: '201', description: 'Record Edited' },
          }),
        );
      }),
    );
    await waitFor(async () => {
      const exitBtn = screen.getByRole('button', { name: strings.exit });
      expect(exitBtn).toBeDefined();
      await act(async () => {
        fireEvent.click(exitBtn);
      });
      const exitDialogSaveAndExitBtn = screen.getByRole('button', {
        name: strings.exitDialogSaveAndExit,
      });
      await act(async () => {
        fireEvent.click(exitDialogSaveAndExitBtn);
      });
    });
  });
});
