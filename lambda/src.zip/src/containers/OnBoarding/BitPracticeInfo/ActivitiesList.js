import { Typography } from '@mui/material';

import strings from 'localization/translation';
import internalClasses from 'style/onBoarding.module.scss';

const {
  activity1,
  activity2,
  activity3,
  activity4,
  activity5,
  activity6,
  activity7,
  activity9,
  activity10,
  activity11,
  activity12,
  activity13,
} = strings;

const ActivitiesList = () => (
  <Typography
    component="div"
    variant="p2"
    className={internalClasses.activityListTypo}
  >
    <ul className={internalClasses.leftUlBit}>
      <li data-testid="li1">{activity1}</li>
      <li data-testid="li2">{activity2}</li>
      <li data-testid="li3">{activity3}</li>
      <li data-testid="li4">{activity4}</li>
      <li data-testid="li5">{activity5}</li>
      <li data-testid="li13">{activity13}</li>
      <li data-testid="li6"> {activity6}</li>
      <li data-testid="li7">{activity7}</li>
      <li data-testid="li9">{activity9}</li>
      <li data-testid="li10"> {activity10}</li>
      <li data-testid="li11"> {activity11}</li>
      <li data-testid="li12">{activity12}</li>
    </ul>
  </Typography>
);

export default ActivitiesList;
