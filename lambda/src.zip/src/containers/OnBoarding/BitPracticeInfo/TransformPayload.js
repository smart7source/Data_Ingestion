import moment from 'moment';

const TransformPayload = (data, saveAndExit = false) => ({
  ...data,
  // orgTaxId: orgTaxId || '123456789',
  establishedDate: moment(data.establishedDate).format('yyyy-MM-DD'),
  // legalStructure: Number(data.legalStructure),
  // businessType: Number(data.businessType),
  opnStartDate: moment(data.opnStartDate).format('yyyy-MM-DD'),
  saveAndExit,
});

export default TransformPayload;
