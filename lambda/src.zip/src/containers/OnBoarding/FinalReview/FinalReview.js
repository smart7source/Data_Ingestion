/* eslint-disable max-lines */
import { Fragment, useEffect, useState } from 'react';
import { Typography, Box, Grid } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { useHistory } from 'react-router-dom';

import {
  displayPhoneTypeNumber,
  displayStreet,
  findNamebyVal,
  getRouteInfo,
  displaySSN,
} from 'utils';
import { useOnboarding, useRefData } from 'hooks';
import { DisplayFormValue, Notification } from 'components';
import classes from 'style/globalStyle.module.scss';
import routePath from 'routes/routePath';
import { rvwAllPgInfo } from 'helpers/URLConfiguration';
import strings from 'localization/translation';
import { loadOnboardingData } from 'store/actions';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import internalClasses from 'style/onBoarding.module.scss';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';

import DisplayPracInfo from './Components/DisplayPracInfo';
import EditHeading from './Components/EditHeading';

const {
  finalReviewHeading,
  practiceInformation,
  name,
  OwnershipInformation,
  nameOfOwner,
  controlingPerson,
  ownershipPercentage,
  teamInformation,
  email,
  phoneType,
  phone,
  address,
  documentInformation,
  cityStateZip,
  primaryRole,
} = strings;
const { pageId } = rvwAllPgInfo;
const FinalReview = () => {
  const [errorMsgs, setErrorMsgs] = useState([]);
  const payload = useSelector((state) => state.onBoarding.payload);
  const refData = useSelector((state) => state.global.refData);
  const {
    CHELLO_INDIVIDUAL_ROLE = [],
    PHONE_TYPE = [],
    CHELLO_RESIDENCY_STATUS = [],
    COUNTRY_CODE = [],
    CHELLO_LEGAL_ENTITY = [],
    US_STATES = [],
  } = refData;
  const dispatch = useDispatch();
  const { exitHandler } = useOnboarding({
    pageId,
    curPageId: payload.curPageId,
  });
  useRefData([
    'CHELLO_INDIVIDUAL_ROLE',
    'PHONE_TYPE',
    'CHELLO_RESIDENCY_STATUS',
    'COUNTRY_CODE',
    'CHELLO_LEGAL_ENTITY',
    'US_STATES',
  ]);
  const history = useHistory();
  const {
    PRAC_INFO = {},
    ADD_PRAC_INFO = {},
    BUILD_TEAM_INFO = [],
    ADD_DOC_INFO = [],
  } = payload || {};
  const additionalUsers = BUILD_TEAM_INFO?.filter(
    (ele) => !(ele.role === '0' && !ele.controlingPerson),
  );

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await ApiClient.post(serviceUrl.practieValidateApi, {});
      const { nxtPgRoute } = getRouteInfo(pageId);
      history.push(nxtPgRoute);
    } catch (err) {
      if (err?.response?.data?.body?.message) {
        const messageArr = err?.response?.data?.body?.message;
        const parseArray = messageArr.map((item) => ({ message: item[1] }));
        setErrorMsgs(parseArray);
      }
    }
  };

  useEffect(() => {
    dispatch(loadOnboardingData());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <form onSubmit={handleSubmit} data-testid="form">
      <RightPanelLayout maxWidth="600px">
        <Notification errors={errorMsgs} />
        <FormHead id="heading1" heading={finalReviewHeading} />
        <EditHeading
          heading={practiceInformation}
          redirectRoute={routePath.EDIT_PRACTICE_INFO}
        />
        <DisplayPracInfo
          practiceInfo={{ ...PRAC_INFO, ...ADD_PRAC_INFO }}
          CHELLO_LEGAL_ENTITY={CHELLO_LEGAL_ENTITY}
          US_STATES={US_STATES}
          PHONE_TYPE={PHONE_TYPE}
        />

        <EditHeading
          heading={OwnershipInformation}
          redirectRoute={routePath.BUILD_TEAM}
        />

        <Grid container spacing={4}>
          {additionalUsers.map((item, index) => (
            <Fragment key={index}>
              <Grid item xs={12} sm={6} className={internalClasses.flexItem}>
                <DisplayFormValue
                  name={nameOfOwner}
                  value={`${item.firstName} ${item.lastName} ${
                    item.primaryApplicant === 'Y' ? `(You)` : ``
                  }`}
                  showSeparator
                  showImage
                />
              </Grid>
              <Grid item xs={12} sm={6} className={internalClasses.flexItem}>
                <DisplayFormValue
                  name={primaryRole}
                  value={findNamebyVal(CHELLO_INDIVIDUAL_ROLE, item.role)}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={ownershipPercentage}
                  value={`${
                    item.percentageOwnership !== ''
                      ? item.percentageOwnership
                      : ''
                  } ${item.percentageOwnership !== '' ? '%' : ''}`}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={controlingPerson}
                  value={item.controlingPerson ? 'Yes' : 'No'}
                  showSeparator
                />
              </Grid>
            </Fragment>
          ))}
        </Grid>

        <EditHeading
          heading={teamInformation}
          redirectRoute={routePath.REVIEW_TEAM}
        />
        {additionalUsers.map((item, index) => {
          const phoneTypeValue = findNamebyVal(PHONE_TYPE, item.phoneType);

          const resStatusValue = findNamebyVal(
            CHELLO_RESIDENCY_STATUS,
            item.resStatus,
          );
          const countryValue = findNamebyVal(COUNTRY_CODE, item.country);

          return (
            <Grid
              container
              key={index}
              spacing={4}
              className={internalClasses.finalReviewGrid}
            >
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={name}
                  value={`${item.firstName} ${item.lastName}`}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={email}
                  value={item?.email}
                  showSeparator
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={phone}
                  value={displayPhoneTypeNumber(
                    findNamebyVal(PHONE_TYPE, item?.phoneType),
                    item?.phone,
                  )}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={address}
                  value={displayStreet(item?.address, item?.address2)}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={cityStateZip}
                  value={`${item.city}, ${item.state} ${item.zip}`}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={strings.birthDate}
                  value={moment(item.dob).format('MMMM D, YYYY')}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={strings.countryResidency}
                  value={countryValue}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={strings.ssn}
                  value={displaySSN(item?.ssn)}
                  showSeparator
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DisplayFormValue
                  name={strings.residencyStatus}
                  value={resStatusValue}
                  showSeparator
                />
              </Grid>
            </Grid>
          );
        })}
        <Box>
          <EditHeading
            heading={documentInformation}
            redirectRoute={routePath.ADD_DOCUMENTS}
          />
          {ADD_DOC_INFO.map((item, index) => (
            <Typography className={classes.boldText} key={index} gutterBottom>
              {item.docName}
            </Typography>
          ))}
        </Box>
      </RightPanelLayout>
      <Footer backBtn saveHandler={() => exitHandler({ saveData: false })} />
    </form>
  );
};

export default FinalReview;
