import { Provider } from 'react-redux';
import {
  render,
  screen,
  act,
  fireEvent,
  waitFor,
} from '@testing-library/react';
import configureStore from 'store/configureStore';

import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import routePath from '../../../../routes/routePath';
import strings from 'localization/translation';
import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  onBoardingStateMock,
  mockUseHistory,
} from 'testHelpers';
import App from 'containers/App/App';
import Auth from '@aws-amplify/auth';
import server from 'apiMocks/server';
import { rest } from 'msw';
import serviceUrl from 'api/UrlHelper';

import FinalReview from '../FinalReview';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);
const history = createMemoryHistory();

describe('rendering <FinalReview /> component', () => {
  const mockStore = configureStore(onBoardingStateMock);
  let testHistory, testLocation;
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    await act(async () =>
      render(
        // <MemoryRouter initialEntries={[routePath.FINAL_REVIEW]}>
        //   <Provider store={mockStore}>
        //     <App />
        //   </Provider>
        //   <Route
        //     path="*"
        //     render={({ history, location }) => {
        //       testHistory = history;
        //       testLocation = location;
        //       return null;
        //     }}
        //   />
        // </MemoryRouter>,
        <Provider store={mockStore}>
          <Router history={history}>
            <FinalReview />
          </Router>
        </Provider>,
      ),
    );
  });

  it('should render heading', async () => {
    await waitFor(async () => {
      expect(screen.getByText(strings.finalReviewHeading)).toBeInTheDocument();
      const cntBtn = screen.getByRole('button', { name: strings.continue });
      await act(async () => {
        fireEvent.click(cntBtn);
      });
    });
  });

  it('should submit form', async () => {
    await waitFor(async () => {
      const cntBtn = screen.getByTestId('form');
      await act(async () => {
        fireEvent.submit(cntBtn);
      });
    });
  });

  it('should submit form failed API', async () => {
    server.use(
      rest.post(serviceUrl.practieValidateApi, (req, res, ctx) =>
        res.networkError('Failed to connect'),
      ),
    );
    await waitFor(async () => {
      const cntBtn = screen.getByTestId('form');
      await act(async () => {
        fireEvent.submit(cntBtn);
      });
    });
  });

  test('should render exit dialog and click on save n exit', async () => {
    const exitBtn = screen.getByRole('button', { name: strings.exit });
    await act(async () => {
      fireEvent.click(exitBtn);
    });
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    await act(async () => {
      fireEvent.click(exitDialogSaveAndExitBtn);
    });

    expect(history.location.pathname).toBe(routePath.LOGIN);
  });
});
