import { Typography, Grid } from '@mui/material';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

import edit from 'assets/edit.svg';
import internalClasses from 'style/onBoarding.module.scss';

const EditHeading = ({ heading, redirectRoute }) => (
  <Grid container className={internalClasses.finalReviewHeadingGrid}>
    <Grid item xs={10}>
      <Typography variant="h2" data-testid="practiceInformation">
        {heading}
      </Typography>
    </Grid>
    <Grid item xs={2} container alignItems="end" justifyContent="end">
      <Link to={redirectRoute} data-testid="Link22" color="inherit">
        <img src={edit} alt="edit-practice" />
      </Link>
    </Grid>
  </Grid>
);

export default EditHeading;

EditHeading.propTypes = {
  heading: PropTypes.string,
  redirectRoute: PropTypes.string,
};
EditHeading.defaultProps = {
  heading: '',
  redirectRoute: '/',
};
