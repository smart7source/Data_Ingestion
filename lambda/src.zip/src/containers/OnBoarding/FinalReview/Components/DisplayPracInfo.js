import { Grid } from '@mui/material';
import moment from 'moment';
import PropTypes from 'prop-types';

import { DisplayFormValue } from 'components';
import strings from 'localization/translation';
import { displayPhoneTypeNumber, displayStreet, findNamebyVal } from 'utils';

const {
  finalReviewSiteId,
  businessLegalName,
  EIN,
  xx,
  xxx,
  businessAddress,
  dateEstablished,
  cityStateZip,
  businessPhone,
  legalStructure,
  businessEmail,
  stateFormation,
  operationStartDate,
} = strings;

const DisplayPracInfo = ({
  practiceInfo,
  CHELLO_LEGAL_ENTITY = [],
  US_STATES = [],
  PHONE_TYPE = [],
}) => {
  const {
    orgId,
    orgTaxId,
    orgName,
    orgAddressLine1,
    orgAddressLine2,
    orgCityName,
    orgStateCode,
    orgZipCode,
    orgPhoneNumber,
    orgEmail,
    establishedDate: dateEstablishedVal,
    opnStartDate,
    stateLegalInfo,
    legalStructure: legalStructureVal,
    orgPhoneType,
  } = practiceInfo;
  const busTypeValue = findNamebyVal(CHELLO_LEGAL_ENTITY, legalStructureVal);

  const stateValue = findNamebyVal(US_STATES, stateLegalInfo);

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <DisplayFormValue
          name={finalReviewSiteId}
          value={localStorage.getItem('siteId') || orgId}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={businessLegalName}
          value={orgName}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={EIN}
          value={
            practiceInfo && orgTaxId && `${xx}${xxx}${orgTaxId.slice(5, 9)}`
          }
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={businessAddress}
          value={displayStreet(orgAddressLine1, orgAddressLine2)}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={dateEstablished}
          value={moment(dateEstablishedVal).format('MMMM D, YYYY')}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={operationStartDate}
          value={moment(opnStartDate).format('MMMM D, YYYY')}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={cityStateZip}
          value={`${orgCityName},${orgStateCode},${orgZipCode}`}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={stateFormation}
          value={stateValue}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={businessPhone}
          value={displayPhoneTypeNumber(
            findNamebyVal(PHONE_TYPE, orgPhoneType),
            orgPhoneNumber,
          )}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue
          name={legalStructure}
          value={busTypeValue}
          showSeparator
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <DisplayFormValue name={businessEmail} value={orgEmail} showSeparator />
      </Grid>
    </Grid>
  );
};

export default DisplayPracInfo;

DisplayPracInfo.propTypes = {
  CHELLO_LEGAL_ENTITY: PropTypes.arrayOf(PropTypes.any),
  US_STATES: PropTypes.arrayOf(PropTypes.any),
  PHONE_TYPE: PropTypes.arrayOf(PropTypes.any),
  practiceInfo: PropTypes.shape({
    orgId: PropTypes.string,
    orgTaxId: PropTypes.string,
    orgName: PropTypes.string,
    orgAddressLine1: PropTypes.string,
    orgAddressLine2: PropTypes.string,
    orgCityName: PropTypes.string,
    orgStateCode: PropTypes.string,
    orgZipCode: PropTypes.string,
    orgPhoneNumber: PropTypes.string,
    orgEmail: PropTypes.string,
    establishedDate: PropTypes.string,
    opnStartDate: PropTypes.string,
    stateLegalInfo: PropTypes.string,
    legalStructure: PropTypes.string,
    orgPhoneType: PropTypes.string,
  }),
};
DisplayPracInfo.defaultProps = {
  practiceInfo: {},
  CHELLO_LEGAL_ENTITY: [],
  US_STATES: [],
  PHONE_TYPE: [],
};
