import {
  Link,
  Box,
  Button,
  FormControl,
  FormHelperText,
  Typography,
} from '@mui/material';
// import OtpInput from 'react-otp-input';
import PropTypes from 'prop-types';
import { Controller } from 'react-hook-form';

import { Notification, CustomOtp } from 'components';
import FormHead from 'containers/OnBoarding/components/FormHead';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';

const {
  verificationMessage1,
  verificationMessage2,
  verificationMessage3,
  verificationMessage5,
  continue: CONTINUE,
} = strings;
const Verification = ({
  otp,
  otpSubmit,
  resendOtp,
  inlineError,
  errorMsgs,
  control,
  name,
}) => {
  const resendCode = async (e) => {
    e.preventDefault();
    resendOtp();
  };

  return (
    <>
      <Box maxWidth="500px" mx="auto">
        <FormHead
          heading={verificationMessage1}
          subHeading={verificationMessage2}
          showSeparator={false}
        />
        <Box marginBottom="10px">
          <Typography variant="h3">{verificationMessage5}</Typography>
        </Box>
        {errorMsgs.length > 0 && (
          <Box className={classes.notificationWrapper}>
            <Notification errors={errorMsgs} />
          </Box>
        )}

        <form onSubmit={otpSubmit} data-testid="form">
          <Controller
            name={name}
            control={control}
            render={({ field }) => (
              <FormControl error={!!inlineError} fullWidth>
                <CustomOtp
                  {...field}
                  numInputs={6}
                  containerStyle={classes.otpContainer}
                  inputStyle={classes.otpInput}
                  focusStyle={classes.focusOtp}
                  shouldAutoFocus
                  isInputNum
                />
                <FormHelperText
                  data-testid="otp-error"
                  className={internalClasses.verificationHelper}
                >
                  {inlineError}
                  <span className={classes.loginLeftHelperNode}>
                    <Link
                      data-testid="resend-code"
                      href="/#"
                      onClick={resendCode}
                      role="button"
                      className={classes.link}
                    >
                      {verificationMessage3}
                    </Link>
                  </span>
                </FormHelperText>
              </FormControl>
            )}
          />

          <Box marginTop={3}>
            <Button
              variant="contained"
              color="primary"
              disabled={otp?.length !== 6}
              type="submit"
              fullWidth
            >
              {CONTINUE}
            </Button>
          </Box>
        </form>
      </Box>
    </>
  );
};

export default Verification;
Verification.propTypes = {
  otp: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  otpSubmit: PropTypes.func.isRequired,
  resendOtp: PropTypes.func.isRequired,
  inlineError: PropTypes.string,
  errorMsgs: PropTypes.instanceOf(Object),
  control: PropTypes.instanceOf(Object).isRequired,
  name: PropTypes.string.isRequired,
};
Verification.defaultProps = {
  otp: '',
  inlineError: '',
  errorMsgs: [],
};
