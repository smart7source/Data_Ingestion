import { Box, Typography } from '@mui/material';

import useTransition from 'hooks/useTransition';
import routePath from 'routes/routePath';
import strings from 'localization/translation';
import serviceUrl from 'api/UrlHelper';
import { confPracPgInfo } from 'helpers/URLConfiguration';
import { useOnboarding, useRefData } from 'hooks';
import classes from 'style/globalStyle.module.scss';

const { pageId, pageKey } = confPracPgInfo;
const { tpsMiddlewareMessage1 } = strings;
const { getPracinfoApiPath } = serviceUrl;
const TPSMiddleware = () => {
  useTransition({
    redirectPath: routePath.CONFIRM_PRACTICE_INFO,
  });
  useRefData(['PHONE_TYPE', 'US_STATES']);
  useOnboarding({ url: getPracinfoApiPath, pageKey, pageId });

  return (
    <Box className={classes.defaultLayoutOnbWrapper}>
      <Box className={classes.transitionImgCenter}>
        <img
          src={`${process.env.PUBLIC_URL}/images/transition/Timer.gif`}
          alt="logo"
          className={classes.transitionImg}
        />
      </Box>
      <Box maxWidth="500px" mx="auto">
        <Typography variant="h1" textAlign="center" color="grey.900">
          {tpsMiddlewareMessage1}
        </Typography>
      </Box>
    </Box>
  );
};

export default TPSMiddleware;
