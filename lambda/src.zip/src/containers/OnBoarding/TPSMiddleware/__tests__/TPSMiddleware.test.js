import { act, render, screen, waitFor } from '@testing-library/react';
import configureStore from 'store/configureStore';

import TPSMiddleware from '../TPSMiddleware';
import strings from '../../../../localization/translation';
import { Provider } from 'react-redux';
import { routePath } from 'routes';
import { onBoardingStateMock } from 'testHelpers';

const mockStore = configureStore(onBoardingStateMock);

const mockHistoryPush = jest.fn();
const mockUseHistory = {
  push: mockHistoryPush,
};

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => mockUseHistory,
}));
describe('Rendering Team Loader Page', () => {
  beforeEach(async () => {
    jest.useFakeTimers();
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <TPSMiddleware />
        </Provider>,
      ),
    );
  });

  afterEach(() => {
    jest.clearAllTimers();
  });

  it('Must include image', () => {
    expect(screen.getByAltText('logo')).toBeInTheDocument();
  });

  it('Should include text', async () => {
    await waitFor(async () => {
      expect(
        screen.getByText(strings.tpsMiddlewareMessage1),
      ).toBeInTheDocument();
    });
  });

  it('Should redirect to Confirm Practic Info page', async () => {
    jest.runOnlyPendingTimers();

    expect(mockHistoryPush).toHaveBeenCalledWith(
      routePath.CONFIRM_PRACTICE_INFO,
    );
  });
});
