import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';

const FormHead = ({ heading, subHeading, showSeparator }) => {
  let sx = {};
  if (showSeparator) {
    sx = {
      borderBottom: '1px solid',
      borderColor: 'grey.300',
      paddingBottom: 2.5,
    };
  }
  return (
    <Box mb={2.5} sx={sx}>
      {heading && <Typography variant="h1">{heading}</Typography>}
      {subHeading && (
        <Typography
          variant="p1"
          mt={2.5}
          dangerouslySetInnerHTML={{ __html: subHeading }}
        />
      )}
    </Box>
  );
};

export default FormHead;
FormHead.propTypes = {
  heading: PropTypes.string,
  subHeading: PropTypes.string,
  showSeparator: PropTypes.bool,
};
FormHead.defaultProps = {
  heading: '',
  subHeading: '',
  showSeparator: true,
};
