import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import { ReactComponent as AlertTriangle } from 'assets/svg/alert-triangle.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle.svg';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import strings from 'localization/translation';
import { findNamebyVal, defaultFnPropTypes } from 'utils';

const { controlingPerson, missingFieldRequired } = strings;

const ReviewTeamAccordian = (props) => {
  const { item, roles, checkError, index } = props;
  return (
    <Box width="100%" alignItems="center" className={classes.reviewTeamAcc}>
      <Box className={classes.userInfoContainer}>
        <Box className={classes.userIconContainer}>
          <img
            src={`${process.env.PUBLIC_URL}/svg/ReviewTeamUserIcon.svg`}
            alt="info"
            className={classes.userIcon}
            data-testid="info-icon"
          />
        </Box>
        <Box className={classes.userInfoDetails}>
          <Typography className={classes.boldText}>
            {item.firstName} {item.lastName}
            <Typography
              component="span"
              className={classes.ownershipName}
              variant="p1SemiBold"
            >
              {item.primaryApplicant === 'Y' && ' (You)'}
            </Typography>
          </Typography>

          {findNamebyVal(roles, item.role)}
          <Typography component="span">
            {item.controlingPerson && `, ${controlingPerson}`}
          </Typography>
        </Box>
      </Box>
      <Box className={classes.errAction}>
        {!checkError(index) ? (
          <>
            <CustomIcon
              component={AlertTriangle}
              inheritViewBox
              className={internalClasses.reviewTeamAccordionAlertTriangle}
            />{' '}
            {missingFieldRequired}
          </>
        ) : (
          <CustomIcon
            component={CheckmarkCircle}
            inheritViewBox
            className={internalClasses.reviewTeamAccordionSuccess}
          />
        )}
      </Box>
    </Box>
  );
};

export default ReviewTeamAccordian;

ReviewTeamAccordian.propTypes = {
  item: PropTypes.instanceOf(Object),
  roles: PropTypes.instanceOf(Array),
  checkError: PropTypes.instanceOf(Function),
  index: PropTypes.number,
};

ReviewTeamAccordian.defaultProps = {
  item: {},
  roles: [],
  checkError: defaultFnPropTypes,
  index: 0,
};
