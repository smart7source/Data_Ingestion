import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogContent,
  IconButton,
  Typography,
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { handleLogout, defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import { updateAuthenticatedStatus } from 'store/actions';
import internalClasses from 'style/onBoarding.module.scss';

const {
  exitDialogMessage1,
  exitDialogMessage2,
  exitDialogMessage3,
  exitDialogMessage4,
  exitDialogMessage5,
  exitDialogSaveAndExit,
  exit,
  savingPrgsBtn,
  regExitDialogHeading1,
  regExitDialogHeading2,
  regExitDialogSubHeading,
} = strings;
const ExitDialog = ({ handleSave, noBtn, saveNexitBtn, isRegistration }) => {
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const dispatch = useDispatch();

  const closeModal = (action) => {
    if (action === 'SaveNExit') {
      setLoading(true);
      handleSave();
    } else if (action === 'Exit') {
      setOpen(false);
      history.push(routePath.LOGIN);
    } else {
      handleLogout({
        history,
        route: routePath.LOGIN,
        onLogout: () => {
          dispatch(updateAuthenticatedStatus(false));
          dispatch({
            type: 'USER_LOGGED_OUT',
          });
        },
      });
    }
  };
  let loadingProps = {};
  if (loading) {
    loadingProps = {
      loadingPosition: 'start',
      startIcon: <CircularProgress color="primary" size={16} />,
    };
  }

  const SaveButton = !loading ? exitDialogSaveAndExit : savingPrgsBtn;

  const dialogView = () => (
    <Dialog
      aria-labelledby="customized-dialog-title"
      open={open}
      data-testid="onboarding-exit-dialog"
    >
      <Typography align="right">
        <IconButton
          data-testid="onboarding-exit-dialog-close-icon"
          aria-label="close"
          onClick={() => setOpen(false)}
          size="large"
          className={internalClasses.exitDialogCloseButton}
        >
          <CustomIcon
            component={Close}
            className={internalClasses.exitDialogCloseIcon}
            inheritViewBox
          />
        </IconButton>
      </Typography>
      <DialogContent>
        <Typography variant="h1" mb="24px">
          {isRegistration
            ? `${regExitDialogHeading1} ${regExitDialogHeading2}`
            : `${exitDialogMessage1} ${exitDialogMessage2}`}
        </Typography>
        <Typography variant="p1">
          {isRegistration ? regExitDialogSubHeading : exitDialogMessage3}
        </Typography>
        <Box
          justifyContent={isRegistration ? 'flex-end' : 'center'}
          display="flex"
          mt={4}
        >
          {isRegistration ? (
            <Button
              variant="contained"
              style={{ width: '130px' }}
              onClick={() => closeModal('Exit')}
              disableElevation
              data-testid="onboarding-exit-dialog-exit-btn"
            >
              {exit}
            </Button>
          ) : (
            <>
              <Button
                variant="contained"
                style={{ marginRight: '2rem' }}
                onClick={() => closeModal('YesClose')}
                disableElevation
                data-testid="onboarding-exit-dialog-yes-close-btn"
              >
                {exitDialogMessage4}
              </Button>
              {noBtn && (
                <Button
                  variant="contained"
                  style={{ marginRight: '2rem' }}
                  onClick={() => setOpen(false)}
                  disableElevation
                  data-testid="onboarding-exit-dialog-no-go-back-btn"
                >
                  {exitDialogMessage5}
                </Button>
              )}
              {saveNexitBtn && (
                <LoadingButton
                  loading={loading}
                  variant="contained"
                  color="primary"
                  onClick={() => closeModal('SaveNExit')}
                  disableElevation
                  data-testid="onboarding-exit-dialog-save-exit-btn"
                  {...loadingProps}
                >
                  {SaveButton}
                </LoadingButton>
              )}
            </>
          )}
        </Box>
      </DialogContent>
    </Dialog>
  );
  return (
    <>
      <Button
        variant="contained"
        onClick={() => setOpen(true)}
        disableElevation
        data-testid="footer-nav-exit-btn"
        size="OnbExitBtn"
        color="secondary"
      >
        {exit}
      </Button>
      {open && dialogView()}
    </>
  );
};

export default ExitDialog;
ExitDialog.propTypes = {
  handleSave: PropTypes.func,
  noBtn: PropTypes.bool,
  saveNexitBtn: PropTypes.oneOfType([PropTypes.func, PropTypes.bool]),
  isRegistration: PropTypes.bool,
};
ExitDialog.defaultProps = {
  noBtn: false,
  saveNexitBtn: false,
  handleSave: defaultFnPropTypes,
  isRegistration: false,
};
