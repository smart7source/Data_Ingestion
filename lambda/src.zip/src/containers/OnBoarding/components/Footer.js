import { Button, Box, AppBar, Toolbar } from '@mui/material';
import { useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';

import { defaultFnPropTypes, getRouteInfo } from 'utils';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';

import ExitDialog from './ExitDialog';

const { back } = strings;
const Footer = ({
  backBtn,
  noBtn,
  saveNexitBtn,
  backBtnDisable,
  saveHandler,
  continueEnable,
  continueBtnName,
  continueBtnType,
  handleSubmit,
  exitBtn,
  isRegistration,
}) => {
  const payload = useSelector((state) => state.onBoarding.payload);
  const history = useHistory();

  const handleBack = () => {
    const { bkPgRoute = '' } = getRouteInfo(payload.curPageId);
    if (bkPgRoute) {
      history.push(bkPgRoute);
    }
  };

  return (
    <AppBar
      position="fixed"
      className={classes.footerBar}
      component="div"
      color="grey"
    >
      <Toolbar className={classes.spacing} variant="onbFooter">
        {exitBtn && (
          <ExitDialog
            handleSave={saveHandler}
            noBtn={noBtn}
            saveNexitBtn={saveNexitBtn}
            isRegistration={isRegistration}
          />
        )}
        {backBtn && (
          <Button
            variant="contained"
            onClick={handleBack}
            disabled={backBtnDisable}
            disableElevation
            data-testid="footer-nav-back-btn"
            size="OnbExitBtn"
            color="secondary"
          >
            {back}
          </Button>
        )}
        <Box flexGrow="1" className={internalClasses.footerCntBox} />
        {continueBtnType === 'button' ? (
          <Button
            variant="contained"
            color="primary"
            type={continueBtnType}
            disabled={!continueEnable}
            onClick={handleSubmit}
            disableElevation
            data-testid="footer-nav-continue-btn"
            size="OnbCtnBtn"
            className={internalClasses.footerCntBtn}
          >
            {continueBtnName}
          </Button>
        ) : (
          <Button
            variant="contained"
            color="primary"
            type={continueBtnType}
            disabled={!continueEnable}
            disableElevation
            data-testid="footer-nav-continue-btn"
            size="OnbCtnBtn"
            className={internalClasses.footerCntBtn}
          >
            {continueBtnName}
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Footer;
Footer.propTypes = {
  exitBtn: PropTypes.bool,
  backBtn: PropTypes.bool,
  noBtn: PropTypes.bool,
  saveNexitBtn: PropTypes.bool,
  backBtnDisable: PropTypes.bool,
  saveHandler: PropTypes.func,
  continueEnable: PropTypes.bool,
  continueBtnName: PropTypes.string,
  continueBtnType: PropTypes.string,
  handleSubmit: PropTypes.func,
  isRegistration: PropTypes.bool,
};
Footer.defaultProps = {
  exitBtn: true,
  backBtn: true,
  noBtn: true,
  saveNexitBtn: true,
  backBtnDisable: false,
  continueEnable: true,
  continueBtnName: strings.continue,
  continueBtnType: 'submit',
  saveHandler: defaultFnPropTypes,
  handleSubmit: defaultFnPropTypes,
  isRegistration: false,
};
