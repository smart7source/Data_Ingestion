import { Box, Grid, InputLabel, Link, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import { CustomCheckbox } from 'components';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';

const TermsNPolicy = ({
  control,
  errors,
  textareaProps,
  checkboxProps,
  linkName,
}) => (
  <>
    <Box className="mb-1">
      <Box>
        <InputLabel>{textareaProps.tNcLable}</InputLabel>
        <Typography
          variant="body2"
          className={internalClasses.termsTextAreaAlignment}
        >
          {textareaProps.data}
        </Typography>
      </Box>

      <Grid container alignItems="center">
        <Grid item xs={6}>
          <CustomCheckbox
            name={checkboxProps.name}
            id={checkboxProps.id}
            control={control}
            label={checkboxProps.label}
            error={!!errors[`${checkboxProps.name}`]}
            errorText={
              errors[`${checkboxProps.name}`] &&
              errors[`${checkboxProps.name}`].message
            }
            margin="dense"
          />
        </Grid>
        <Grid container item xs={6} justifyContent="flex-end">
          <Link
            href="/#"
            onClick={(e) => e.preventDefault()}
            color="inherit"
            className={classes.link}
          >
            {linkName}
          </Link>
        </Grid>
      </Grid>
    </Box>
  </>
);

TermsNPolicy.defaultProps = {
  control: {},
  errors: {},
  linkName: 'link',
  textareaProps: {},
  checkboxProps: {},
};
TermsNPolicy.propTypes = {
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  textareaProps: PropTypes.instanceOf(Object),
  checkboxProps: PropTypes.instanceOf(Object),
  linkName: PropTypes.string,
};

export default TermsNPolicy;
