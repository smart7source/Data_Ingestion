import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import * as utilsFn from 'utils/authentication';
import strings from 'localization/translation';
import ExitDialog from '../ExitDialog';

const mockHandleSave = jest.fn();

const mockHistoryPush = jest.fn();
const store = configureStore();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}));

describe('Rendering ExitDialog Component', () => {
  test('renders ExitDialog correctly', async () => {
    render(
      <Provider store={store({})}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <ExitDialog
              handleSave={mockHandleSave}
              noBtn={false}
              saveNexitBtn={true}
            />
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
    const exitButton = screen.getByRole('button', { name: /Exit/ });
    expect(exitButton).toBeInTheDocument();

    userEvent.click(exitButton);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });
});

describe('buttons function correctly', () => {
  beforeEach(() => {
    render(
      <Provider store={store({})}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <ExitDialog
              handleSave={mockHandleSave}
              noBtn={true}
              saveNexitBtn={true}
            />
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
    userEvent.click(screen.getByRole('button', { name: /Exit/ }));
  });

  test('close icon button works correctly', async () => {
    const closeIconButton = screen.getByLabelText('close');
    expect(closeIconButton).toBeInTheDocument();
    userEvent.click(closeIconButton);
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });

  test('close button works correctly', async () => {
    const closeButton = screen.getByRole('button', { name: 'No, go back' });
    expect(closeButton).toBeInTheDocument();
    userEvent.click(closeButton);
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });

  test('save and exit button works correctly', () => {
    const saveNExitButton = screen.getByRole('button', { name: /Save & Exit/ });
    expect(saveNExitButton).toBeInTheDocument();
    userEvent.click(saveNExitButton);
    expect(mockHandleSave).toHaveBeenCalled();
  });
  test('cancel button works correctly with user logged in', async () => {
    jest.spyOn(window.localStorage.__proto__, 'getItem');
    window.localStorage.__proto__.getItem = jest.fn().mockReturnValue(true);

    const mockHandleLogout = jest.spyOn(utilsFn, 'handleLogout');

    const cancelButton = screen.getByRole('button', { name: 'Yes, cancel' });
    expect(cancelButton).toBeInTheDocument();
    userEvent.click(cancelButton);
    expect(mockHandleLogout).toHaveBeenCalled();
    mockHandleLogout.mockRestore();
  });
});

describe('edge cases', () => {
  test('handle save default', () => {
    render(
      <Provider store={store({})}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <ExitDialog noBtn={true} saveNexitBtn={true} />
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
    const exitButton = screen.getByRole('button', { name: /Exit/ });
    userEvent.click(exitButton);
    const saveNExitButton = screen.getByRole('button', { name: /Save & Exit/ });
    expect(saveNExitButton).toBeInTheDocument();
    userEvent.click(saveNExitButton);
  });
});

describe('SignUp Exit Dialog Test cases', () => {
  test('handle save default', async () => {
    render(
      <Provider store={store({})}>
        <StyledEngineProvider injectFirst>
          <ThemeProvider theme={theme}>
            <ExitDialog noBtn={false} saveNexitBtn={false} isRegistration />
          </ThemeProvider>
        </StyledEngineProvider>
      </Provider>,
    );
    userEvent.click(screen.getByRole('button', { name: /Exit/ }));
    expect(screen.getByRole('dialog')).toBeInTheDocument();
    const headingText = screen.getByText(strings.regExitDialogSubHeading);
    expect(headingText).toBeInTheDocument();
    const exitButton = screen.getByRole('button', { name: /Exit/ });
    userEvent.click(exitButton);
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });
});
