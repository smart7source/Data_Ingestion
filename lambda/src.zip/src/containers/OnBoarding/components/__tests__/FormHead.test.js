import { render, screen } from '@testing-library/react';
import FormHead from '../FormHead';

describe('Rendering FormHead Component', () => {
  test('FormHead Component renders correctly', () => {
    render(<FormHead heading="heading" subHeading="subheading" />);
    expect(screen.getByText('heading')).toBeInTheDocument();
    expect(screen.getByText('subheading')).toBeInTheDocument();
  });
});
