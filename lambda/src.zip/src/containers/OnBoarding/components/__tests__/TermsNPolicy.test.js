import { fireEvent, render, act, getByRole } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { ThemeProvider } from '@mui/material';
import { useForm } from 'react-hook-form';
import theme from 'style/theme';
import strings from 'localization/translation';
import TermsNPolicy from '../TermsNPolicy';

const initialState = {
  onBoarding: {
    payload: {
      siteId: '',
      curPageId: '',
    },
  },
};
const store = configureStore();
const defaultProps = {
  control: {},
  errors: {},
  linkName: 'link',
  textareaProps: {
    id: 'tnc',
    label: strings.tNcLable,
    name: 'tnc',
    data: strings.tNcData,
  },
  checkboxProps: {
    id: 'terms',
    name: 'terms',
    label: strings.chelloTermsOfUse,
  },
};

const SampleComponent = (props = defaultProps) => {
  const { control } = useForm();
  const currentProps = {
    ...props,
    control,
  };

  return <TermsNPolicy {...currentProps} />;
};

const RenderAsync = (props = defaultProps) => {
  return render(
    <Provider store={store(initialState)}>
      <SampleComponent {...props} />
    </Provider>,
  );
};

describe('Rendering TermsNPolicy Component', () => {
  test('TermsNPolicy Component renders correctly', () => {
    const screen = RenderAsync();
    expect(screen.getByText(strings.chelloTermsOfUse)).toBeInTheDocument();
    expect(screen.getByText(/link/i)).toBeInTheDocument();
  });

  it('should show error message if Terms checkbox is not checked', async () => {
    const props = {
      ...defaultProps,
      errors: {
        terms: { message: 'Accept Terms is required' },
      },
    };
    const screen = RenderAsync(props);
    const checkbox = screen.getByRole('checkbox', {
      name: /terms/i,
    });
    await act(async () => {
      fireEvent.click(checkbox);
    });
    expect(checkbox).toBeChecked();
    await act(async () => {
      fireEvent.click(checkbox);
    });
    expect(checkbox).not.toBeChecked();
    expect(screen.getByText(/Accept Terms is required/i)).toBeInTheDocument();
  });

  it('check terms and policy links functionality ', async () => {
    const mockfn = jest.fn();
    const screen = RenderAsync();
    const termsLink = screen.getByRole('link', {
      name: /link/i,
    });
    expect(termsLink).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(termsLink, {
        preventDefault: mockfn,
      });
    });
  });
});
