import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import RightPanelLayout from '../RightPanelLayout';

describe('Rendering RightPanelLayout Component', () => {
  test('renders RightPanelLayout correctly', () => {
    render(
      <RightPanelLayout>
        <h1>children</h1>
      </RightPanelLayout>,
    );

    expect(screen.getByText('children')).toBeInTheDocument();
  });
});
