import { render } from '@testing-library/react';

import strings from 'localization/translation';
import NotificationLink from '../NotificationLink';

describe('render NotificationLink component', () => {
  const defaultProps = {
    msg: '',
  };

  const RenderAsync = (props = defaultProps) => {
    return render(<NotificationLink {...props} />);
  };

  it('should render the component with the default props ', async () => {
    const { screen } = await RenderAsync();
    expect(screen).toMatchSnapshot();
  });

  it('should render the component with the defined props ', async () => {
    const definedProps = {
      msg: 'Account Failed',
    };
    const { getByText } = await RenderAsync(definedProps);
    expect(getByText(/Account Failed/i)).toBeInTheDocument();
    expect(getByText(strings.reviewTeamAlert2)).toBeInTheDocument();
  });
});
