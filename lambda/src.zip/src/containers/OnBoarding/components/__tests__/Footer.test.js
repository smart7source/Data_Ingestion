import { render, screen } from '@testing-library/react';
import Footer from '../Footer';

import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import userEvent from '@testing-library/user-event';
import { sectionFooterPrimaryContent } from 'aws-amplify';
const store = configureStore({});

const mockSaveHandler = jest.fn();
const mockHandleSubmit = jest.fn();

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}));

describe('Rendering Footer Component', () => {
  test('renders Footer component correctly with continueBtnType as button', () => {
    render(
      <Provider store={store}>
        <Footer
          backBtn={true}
          saveHandler={mockSaveHandler}
          noBtn={true}
          saveNexitBtn={true}
          backBtnDisable={false}
          continueEnable={true}
          continueBtnName="Continue"
          continueBtnType="button"
          handleSubmit={mockHandleSubmit}
        />
      </Provider>,
    );

    expect(screen.getByRole('button', { name: /Back/ })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Exit/ })).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /Continue/ }),
    ).toBeInTheDocument();
  });

  test('renders Footer component correctly with continueBtnType as submit', () => {
    render(
      <Provider store={store}>
        <Footer
          backBtn={true}
          saveHandler={mockSaveHandler}
          noBtn={true}
          saveNexitBtn={true}
          backBtnDisable={false}
          continueEnable={true}
          continueBtnName="Continue"
          continueBtnType="submit"
          handleSubmit={mockHandleSubmit}
        />
      </Provider>,
    );

    expect(screen.getByRole('button', { name: /Back/ })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Exit/ })).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /Continue/ }),
    ).toBeInTheDocument();
  });
});

describe('Renders correctly with default props', () => {
  test('renders correctly with saveHandle', () => {
    render(
      <Provider store={store}>
        <Footer />
      </Provider>,
    );
    Footer.defaultProps.saveHandler();
    Footer.defaultProps.handleSubmit();
    expect(screen.getByRole('button', { name: /Back/ })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Exit/ })).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /Continue/ }),
    ).toBeInTheDocument();
  });
});
