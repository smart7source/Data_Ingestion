import { Grid, Box } from '@mui/material';
import PropTypes from 'prop-types';

const RightPanelLayout = ({ children, maxWidth }) => {
  let sx = {};
  if (maxWidth !== '') {
    sx = { maxWidth: { lg: maxWidth } };
  }
  return (
    <Grid container>
      <Grid item xs={12} sm={12} md={12} lg={8}>
        <Box sx={sx}>{children}</Box>
      </Grid>
    </Grid>
  );
};

export default RightPanelLayout;
RightPanelLayout.propTypes = {
  maxWidth: PropTypes.string,
  children: PropTypes.node,
};
RightPanelLayout.defaultProps = {
  children: <></>,
  maxWidth: '',
};
