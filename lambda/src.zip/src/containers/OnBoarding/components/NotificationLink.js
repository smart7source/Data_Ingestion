import { Box, Alert, Link, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

const { reviewTeamAlert2 } = strings;

const NotificationLink = ({ msg }) => (
  <Box marginBottom={2}>
    <Alert
      icon={false}
      severity="error"
      classes={{
        root: classes.alertRoot,
        standardError: classes.alertStandardError,
      }}
    >
      <Typography component="span" variant="p2SemiBold">
        {msg}
      </Typography>
      <Link href="#" underline="hover">
        {' '}
        <strong>{reviewTeamAlert2}</strong>
      </Link>
      .
    </Alert>
  </Box>
);

export default NotificationLink;

NotificationLink.propTypes = {
  msg: PropTypes.string,
};
NotificationLink.defaultProps = {
  msg: '',
};
