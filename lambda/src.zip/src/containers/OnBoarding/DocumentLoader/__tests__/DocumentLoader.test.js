import React from 'react';
import { render, act } from '@testing-library/react';
import { Auth } from 'aws-amplify';

import { routePath } from 'routes';
import App from 'containers/App/App';

import { cognitoUserMock, renderWithProviderAndRouter } from 'testHelpers';

const mockHistoryPush = jest.fn();
const mockUseHistory = {
  push: mockHistoryPush,
};

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => mockUseHistory,
}));

const { DOCUMENT_LOADER, FINAL_REVIEW } = routePath;

const promiseResolve = Promise.resolve(cognitoUserMock);

describe('Testing Document Loader screen', () => {
  beforeEach(async () => {
    jest.useFakeTimers();
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolve;
    });
    await act(async () =>
      renderWithProviderAndRouter(<App />, { route: DOCUMENT_LOADER, render }),
    );
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.useRealTimers();
  });

  it('Should redirect to final review screen once document is uploaded successfully', async () => {
    jest.runOnlyPendingTimers();
    await act(() => promiseResolve);
    expect(mockHistoryPush).toHaveBeenCalledWith(FINAL_REVIEW);
  });
});
