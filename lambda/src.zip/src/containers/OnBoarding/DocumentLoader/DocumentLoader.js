import { Box, Typography } from '@mui/material';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import useTransition from 'hooks/useTransition';
import routePath from 'routes/routePath';
import strings from 'localization/translation';
import { loadOnboardingData } from 'store/actions';
import classes from 'style/globalStyle.module.scss';

const { documentLoaderMessage1, documentLoaderMessage2 } = strings;
const DocumentLoader = () => {
  const dispatch = useDispatch();
  useTransition({
    redirectPath: routePath.FINAL_REVIEW,
  });

  useEffect(() => {
    dispatch(loadOnboardingData());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Box className={classes.defaultLayoutOnbWrapper}>
      <Box className={classes.transitionImgCenter}>
        <img
          src={`${process.env.PUBLIC_URL}/images/transition/Lamp.gif`}
          alt="logo"
          className={classes.transitionImg}
        />
      </Box>
      <Box maxWidth="500px" mx="auto">
        <Typography variant="h1" textAlign="center">
          {documentLoaderMessage1}
        </Typography>
        <Typography variant="h1" textAlign="center">
          {documentLoaderMessage2}
        </Typography>
      </Box>
    </Box>
  );
};

export default DocumentLoader;
