import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';

import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  onBoardingStateEmptyMock,
  onBoardingStateMock,
} from 'testHelpers';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import Auth from '@aws-amplify/auth';
import { createMemoryHistory } from 'history';
import ChelloTerms from '../ChelloTerms';
import { Router } from 'react-router-dom';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);
const history = createMemoryHistory();

describe('Render Chello Terms component with empty data', () => {
  const mockStore = configureStore(onBoardingStateEmptyMock);
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });

    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <ChelloTerms />
          </Router>
        </Provider>,
      ),
    );
  });

  test('render component with inital data', () => {
    expect(screen.getByText(strings.genericDisclosure)).toBeInTheDocument();
    expect(
      screen.getByText(strings.genericDisclosureStatement1),
    ).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', {
      name: strings.continue,
    });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).toBeDisabled();
  });

  test('enable terms checkbox ', async () => {
    const termsCB = screen.getByRole('checkbox', {
      name: strings.chelloTermsOfUse,
    });

    await act(async () => {
      fireEvent.click(termsCB);
    });
    expect(termsCB).toBeChecked();
    const continueBtn = screen.getByRole('button', {
      name: strings.continue,
    });
    expect(continueBtn).toBeDisabled();
  });

  test('enable policy checkbox ', async () => {
    const checkbox = screen.getByRole('checkbox', {
      name: strings.chellopolicy,
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    const continueBtn = screen.getByRole('button', {
      name: strings.continue,
    });
    expect(continueBtn).toBeDisabled();
  });

  test('submit form', async () => {
    const continueBtn = screen.getByRole('button', {
      name: strings.continue,
    });
    const termsCB = screen.getByRole('checkbox', {
      name: strings.chelloTermsOfUse,
    });
    const policyCB = screen.getByRole('checkbox', {
      name: strings.chellopolicy,
    });
    await act(async () => {
      fireEvent.click(termsCB);
      fireEvent.click(policyCB);
    });
    await waitFor(() => {
      expect(termsCB).toBeChecked();
      expect(policyCB).toBeChecked();
      expect(continueBtn).toBeEnabled();
    });
    const form = screen.getByTestId('form');
    await act(async () => fireEvent.submit(form));
    await waitFor(() => {
      expect(history.location.pathname).toBe(routePath.BOOST);
    });
  });

  test('render print link and policy link', () => {
    const viewPrints = screen.getAllByRole('link', {
      name: strings.viewnPrint,
    });
    expect(viewPrints).toHaveLength(2);
    fireEvent.click(viewPrints[0]);
    fireEvent.click(viewPrints[1]);
  });

  test('should render exit dialog and click on save n exit', async () => {
    const exitBtn = screen.getByRole('button', { name: strings.exit });
    expect(exitBtn).toBeDefined();
    await act(async () => {
      fireEvent.click(exitBtn);
    });
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    await act(async () => {
      fireEvent.click(exitDialogSaveAndExitBtn);
    });
    expect(history.location.pathname).toBe(routePath.LOGIN);
  });
});
