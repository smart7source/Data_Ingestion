import { useEffect } from 'react';
import { Box, Grid, Link, Typography } from '@mui/material';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';

import { useOnboarding } from 'hooks';
import { chelloTermsSchema } from 'helpers/ValidationSchema';
import { CustomCheckbox } from 'components';
import { chelloTermsPgInfo } from 'helpers/URLConfiguration';
import strings from 'localization/translation';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { setLoader } from 'store/actions';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';

const {
  genericDisclosure,
  genericDisclosureStatement1,
  tNcData,
  chelloTermsOfUse,
  chellopolicy,
} = strings;
const { pageId, pageKey } = chelloTermsPgInfo;
const { consentChello } = serviceUrl;
const ChelloTerms = () => {
  const payload = useSelector((state) => state.onBoarding.payload);
  const dispatch = useDispatch();

  const { saveDataInRedux, exitHandler } = useOnboarding({
    pageKey,
    pageId,
    curPageId: payload.curPageId,
  });

  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(chelloTermsSchema),
  });

  const submitHandler = async (data) => {
    try {
      dispatch(setLoader(true));
      await ApiClient.post(consentChello, {
        ...data,
      });
      const formData = {
        [pageKey]: { ...data },
        curPageId: pageId,
      };
      saveDataInRedux({
        formData,
      });
    } catch (err) {
      // console.log(err)
    } finally {
      dispatch(setLoader(false));
    }
  };

  return (
    <form onSubmit={handleSubmit(submitHandler)} data-testid="form">
      <RightPanelLayout maxWidth="600px">
        <FormHead
          heading={genericDisclosure}
          subHeading={genericDisclosureStatement1}
        />
        <Box className="mb-1">
          <Box>
            {/* <InputLabel>{tNcLable}</InputLabel> */}
            <Typography
              variant="body2"
              className={internalClasses.termsTextAreaAlignment}
            >
              {tNcData}
            </Typography>
            <Link
              href="/#"
              color="inherit"
              onClick={(e) => e.preventDefault()}
              className={classes.link}
            >
              {strings.viewnPrint}
            </Link>
          </Box>
          <Grid container alignItems="center">
            <Grid item xs={6}>
              <CustomCheckbox
                name="chelloTncFlag"
                id="chelloTncFlag"
                control={control}
                label={chelloTermsOfUse}
                error={!!errors.chelloTncFlag}
                errorText={errors.chelloTncFlag && errors.chelloTncFlag.message}
                margin="normal"
              />
            </Grid>
          </Grid>
        </Box>
        <Box>
          <Box>
            {/* <InputLabel>{tNcLable}</InputLabel> */}
            <Typography
              variant="body2"
              className={internalClasses.termsTextAreaAlignment}
            >
              {tNcData}
            </Typography>
            <Link
              href="/#"
              color="inherit"
              onClick={(e) => e.preventDefault()}
              className={classes.link}
            >
              {strings.viewnPrint}
            </Link>
          </Box>
          <Grid container alignItems="center">
            <Grid item xs={6}>
              <CustomCheckbox
                name="chelloPvcyFlag"
                id="chelloPvcyFlag"
                control={control}
                label={chellopolicy}
                error={!!errors.chelloPvcyFlag}
                errorText={
                  errors.chelloPvcyFlag && errors.chelloPvcyFlag.message
                }
                margin="normal"
              />
            </Grid>
          </Grid>
        </Box>
      </RightPanelLayout>
      <Footer
        backBtn
        continueEnable={isValid}
        saveHandler={() => exitHandler({ saveData: false })}
      />
    </form>
  );
};

export default ChelloTerms;
