import { Grid } from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import internalClasses from 'style/onBoarding.module.scss';
import strings from 'localization/translation';
import {
  CustomInput,
  CustomSelectBox,
  MaskInput,
  DatePicker,
} from 'components';

const {
  firstName,
  lastName,
  email,
  phoneType,
  phone,
  address,
  businessAddressLine2,
  city,
  state,
  zipCode,
  birthDate,
  countryResidency,
  ssn,
  residencyStatus,
  optional,
} = strings;
const EditPersonalDetails = ({
  index,
  control,
  errors,
  states,
  phoneTypes,
  countries,
  residencyStatusList,
  handleResidencyChange,
  handleDateofBirthChange,
}) => (
  <Grid container>
    <Grid container spacing={3}>
      <Grid item xs={12} sm={6}>
        <CustomInput
          label={firstName}
          id={`additionalUsers.${index}.firstName`}
          inputProps={{ maxLength: 50 }}
          name={`additionalUsers.${index}.firstName`}
          control={control}
          error={!!errors.additionalUsers?.[index]?.firstName}
          errorText={errors.additionalUsers?.[index]?.firstName?.message}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <CustomInput
          label={lastName}
          inputProps={{ maxLength: 50 }}
          control={control}
          name={`additionalUsers.${index}.lastName`}
          id={`additionalUsers.${index}.lastName`}
          error={!!errors.additionalUsers?.[index]?.lastName}
          errorText={errors.additionalUsers?.[index]?.lastName?.message}
        />
      </Grid>
    </Grid>
    <Grid container spacing={3}>
      <Grid item xs={12} sm={6}>
        <CustomInput
          type="email"
          label={email}
          name={`additionalUsers.${index}.email`}
          id={`additionalUsers.${index}.email`}
          control={control}
          error={!!errors.additionalUsers?.[index]?.email}
          errorText={errors.additionalUsers?.[index]?.email?.message}
        />
      </Grid>
      <Grid item xs={12} sm={6} container spacing={2}>
        <Grid item xs={4}>
          <CustomSelectBox
            label={phoneType}
            options={phoneTypes}
            error={!!errors.additionalUsers?.[index]?.phoneType}
            errorText={errors.additionalUsers?.[index]?.phoneType?.message}
            name={`additionalUsers.${index}.phoneType`}
            id={`additionalUsers.${index}.phoneType`}
            control={control}
          />
        </Grid>
        <Grid item xs={8}>
          <MaskInput
            label={phone}
            name={`additionalUsers.${index}.phone`}
            id={`additionalUsers.${index}.phone`}
            control={control}
            mask="+1-999-999-9999"
            maskChar="_"
            alwaysShowMask
            error={!!errors.additionalUsers?.[index]?.phone}
            errorText={errors.additionalUsers?.[index]?.phone?.message}
            withoutCntryCode
          />
        </Grid>
      </Grid>
    </Grid>
    <Grid container>
      <CustomInput
        label={address}
        name={`additionalUsers.${index}.address`}
        id={`additionalUsers.${index}.address`}
        inputProps={{ maxLength: 100 }}
        control={control}
        error={!!errors.additionalUsers?.[index]?.address}
        errorText={errors.additionalUsers?.[index]?.address?.message}
      />
    </Grid>
    <Grid className={internalClasses.reviewTeamWidth}>
      <CustomInput
        label={businessAddressLine2}
        name={`additionalUsers.${index}.address2`}
        id={`additionalUsers.${index}.address2`}
        inputProps={{ maxLength: 100 }}
        control={control}
        optionalLabel={optional}
        error={!!errors.additionalUsers?.[index]?.address2}
        errorText={errors.additionalUsers?.[index]?.address2?.message}
      />
    </Grid>

    <Grid container spacing={3}>
      <Grid item xs={6} sm={6} md={6} lg={7}>
        <CustomInput
          label={city}
          name={`additionalUsers.${index}.city`}
          id={`additionalUsers.${index}.city`}
          inputProps={{ maxLength: 40 }}
          control={control}
          error={!!errors.additionalUsers?.[index]?.city}
          errorText={errors.additionalUsers?.[index]?.city?.message}
        />
      </Grid>
      <Grid item xs={6} sm={6} md={6} lg={3}>
        <CustomSelectBox
          label={state}
          options={states}
          name={`additionalUsers.${index}.state`}
          id={`additionalUsers.${index}.state`}
          control={control}
          error={!!errors.additionalUsers?.[index]?.state}
          errorText={errors.additionalUsers?.[index]?.state?.message}
        />
      </Grid>
      <Grid item xs={12} sm={6} md={6} lg={2}>
        <MaskInput
          label={zipCode}
          name={`additionalUsers.${index}.zip`}
          id={`additionalUsers.${index}.zip`}
          control={control}
          mask="99999-9999"
          maskChar={null}
          error={!!errors.additionalUsers?.[index]?.zip}
          errorText={errors.additionalUsers?.[index]?.zip?.message}
          isZipCode
          outputMasked
        />
      </Grid>
    </Grid>
    <Grid container spacing={3}>
      <Grid item xs={12} sm={12} md={6}>
        <DatePicker
          name={`additionalUsers.${index}.dob`}
          id={`additionalUsers.${index}.dob`}
          label={birthDate}
          control={control}
          error={!!errors.additionalUsers?.[index]?.dob}
          errorText={errors.additionalUsers?.[index]?.dob?.message}
          maxDateValue={new Date()}
          returnDateFormat="yyyy-MM-DD"
          callback={handleDateofBirthChange}
        />
      </Grid>
      <Grid item xs={12} sm={12} md={6}>
        <CustomSelectBox
          label={countryResidency}
          options={countries}
          name={`additionalUsers.${index}.country`}
          id={`additionalUsers.${index}.country`}
          control={control}
          error={!!errors.additionalUsers?.[index]?.country}
          errorText={errors.additionalUsers?.[index]?.country?.message}
        />
      </Grid>
    </Grid>
    <Grid container spacing={3}>
      <Grid item xs={12} sm={12} md={6}>
        <MaskInput
          label={ssn}
          name={`additionalUsers.${index}.ssn`}
          id={`additionalUsers.${index}.ssn`}
          control={control}
          mask="999-99-9999"
          error={!!errors.additionalUsers?.[index]?.ssn}
          errorText={errors.additionalUsers?.[index]?.ssn?.message}
          maskChar="_"
          alwaysShowMask
          withoutCntryCode={false}
        />
      </Grid>
      <Grid item xs={12} sm={12} md={6}>
        <CustomSelectBox
          label={residencyStatus}
          options={residencyStatusList}
          name={`additionalUsers.${index}.resStatus`}
          id={`additionalUsers.${index}.resStatus`}
          control={control}
          error={!!errors.additionalUsers?.[index]?.resStatus}
          errorText={errors.additionalUsers?.[index]?.resStatus?.message}
          dataTestid={`resStatus_${index}`}
          callback={handleResidencyChange}
        />
      </Grid>
    </Grid>
  </Grid>
);

export default EditPersonalDetails;

EditPersonalDetails.propTypes = {
  index: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  states: PropTypes.arrayOf(PropTypes.any),
  phoneTypes: PropTypes.arrayOf(PropTypes.any),
  countries: PropTypes.arrayOf(PropTypes.any),
  residencyStatusList: PropTypes.arrayOf(PropTypes.any),
  handleResidencyChange: PropTypes.func,
  handleDateofBirthChange: PropTypes.func,
};
EditPersonalDetails.defaultProps = {
  index: 0,
  control: {},
  errors: {},
  states: [],
  phoneTypes: [],
  countries: [],
  residencyStatusList: [],
  handleResidencyChange: defaultFnPropTypes,
  handleDateofBirthChange: defaultFnPropTypes,
};
