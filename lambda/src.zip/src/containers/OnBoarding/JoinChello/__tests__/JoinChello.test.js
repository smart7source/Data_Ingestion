import { render, screen, act, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { Provider } from 'react-redux';

import configureStore from 'store/configureStore';
import {
  onBoardingStateEmptyMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';

const { JOIN_CHELLO } = routePath;

describe('Testing JoinChello Page', () => {
  beforeEach(async () => {
    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: `${JOIN_CHELLO}?refToken=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzaXRlaWQiOiJEMDI1IiwidHBzdXNlcmlkIjoiRDAyNSIsInRheGlkIjoiMTIzNDU2Nzg5IiwiZW1haWxpZCI6InNhbXBsZXVzZXJAZGVtb3dlYnNpdGUuY29tIiwibmJmIjoxNjM5MDkwMjc2LCJleHAiOjE2NDE2ODIyNzYsImlhdCI6MTYzOTA5MDI3OCwiaXNzIjoiaHR0cDovL215c2l0ZS5jb20iLCJhdWQiOiJodHRwOi8vdG9rZW5BdWRpZW5jZS5jb20ifQ.IyjOFtUqQjUqIOXrxhQ6FKu4eDshRk88tas2I-JeIh19SDXWzzOMNqnPnKHV7AGlplyppVEgFD3-BVM85ZXv5Q`,
        render,
      }),
    );
  });

  it('Should render JoinChello Page successfully', () => {
    expect(screen.getByRole('heading', { level: 1 })).toBeInTheDocument();
  });

  it('Should have a lets go button', () => {
    const letsGoBtn = screen.getByRole('link', { name: /Let's Go/i });
    expect(letsGoBtn).toBeInTheDocument();
  });
});

describe('Testing JoinChello Page for edge cases', () => {
  const store = configureStore(onBoardingStateEmptyMock);
  beforeEach(async () => {
    await act(async () =>
      render(
        <MemoryRouter initialEntries={[`${routePath.JOIN_CHELLO}?code=fff`]}>
          <Provider store={store}>
            <App />
          </Provider>
        </MemoryRouter>,
      ),
    );
  });

  it('Should render JoinChello Page successfully without Ref token', async () => {
    await waitFor(async () =>
      expect(screen.getByRole('heading', { level: 1 })).toBeInTheDocument(),
    );
  });
});
