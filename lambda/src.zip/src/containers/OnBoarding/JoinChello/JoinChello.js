import { Box, Button, Container } from '@mui/material';
import { useEffect } from 'react';
import { useLocation, NavLink } from 'react-router-dom';
import Typography from '@mui/material/Typography';
import clsx from 'clsx';
import { useDispatch } from 'react-redux';

import routePath from 'routes/routePath';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import strings from 'localization/translation';
import { loadTpsInfo } from 'store/actions';

const {
  JoinChelloWelcome,
  joinChelloSubHeading1,
  joinChelloSubHeading2,
  joinChelloCriteria1,
  joinChelloCriteria2,
  letsGo,
} = strings;
const JoinChello = () => {
  const dispatch = useDispatch();
  const query = new URLSearchParams(useLocation().search);

  useEffect(() => {
    if (query.get('refToken') !== null) {
      localStorage.setItem('refToken', query.get('refToken'));
    }
    if (query.get('code') !== null) {
      localStorage.setItem('code', query.get('code'));
      dispatch(loadTpsInfo());
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Box
      display="flex"
      flexGrow="1"
      justifyContent="center"
      py={10}
      className={classes.joinChelloBg}
    >
      <Container maxWidth="lg">
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          gap="30px"
        >
          <Box component="h1" m={0} p={0}>
            <Box className={clsx(classes.chelloHeading)}>
              <Typography
                component="span"
                variant="h1"
                className={clsx(
                  classes.chelloHeading,
                  internalClasses.joinChelloLetterSpacing,
                )}
                color="primary"
              >
                Chello=
              </Typography>
              <Typography
                component="span"
                variant="h1"
                className={clsx(
                  classes.chelloHeading,
                  internalClasses.joinChelloAndAlign,
                )}
              >
                {' '}
                &
              </Typography>
            </Box>
            <Typography
              component="span"
              variant="h1"
              className={clsx(
                classes.chelloHeading,
                internalClasses.joinChelloWelcomeTxt,
              )}
            >
              {JoinChelloWelcome}
            </Typography>
          </Box>
          <Box display="flex" flexDirection="column" gap="30px">
            <Typography
              className={internalClasses.joinChelloSubHeading}
              variant="p1"
            >
              {joinChelloSubHeading1}
            </Typography>
            <Box
              justifyContent="center"
              alignItems="center"
              display="flex"
              flexDirection="column"
            >
              <Typography
                className={internalClasses.joinChelloSubHeadingTxt}
                variant="p1"
              >
                {joinChelloSubHeading2}
              </Typography>
              <ul className={classes.joinChelloList}>
                <li>
                  <Typography variant="p1">{joinChelloCriteria1}</Typography>
                </li>
                <li>
                  <Typography variant="p1">{joinChelloCriteria2}</Typography>
                </li>
              </ul>
            </Box>
          </Box>
          <Box display="flex" justifyContent="center">
            <Button
              variant="contained"
              color="primary"
              component={NavLink}
              to={routePath.REGISTRATION}
              size="large"
              className={internalClasses.joinChelloGoBtn}
            >
              {letsGo}
            </Button>
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default JoinChello;
