import { useEffect } from 'react';
import { Box, Grid, Link, Typography } from '@mui/material';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';

import { useOnboarding } from 'hooks';
import { accountTermsSchema } from 'helpers/ValidationSchema';
import { CustomCheckbox } from 'components';
import { accTermsPgInfo } from 'helpers/URLConfiguration';
import strings from 'localization/translation';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import { setLoader, updateLeftMenuStatus } from 'store/actions';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';

import Footer from '../components/Footer';
import FormHead from '../components/FormHead';
import RightPanelLayout from '../components/RightPanelLayout';

const {
  accountReleated,
  afterAccountReleatedTerms,
  tNcData,
  chelloTermsOfUse,
  chellopolicy,
  submit,
} = strings;
const { pageId, pageKey } = accTermsPgInfo;
const { consentAccount, submitApplicationApi } = serviceUrl;
const AccountTerms = () => {
  const payload = useSelector((state) => state.onBoarding.payload);
  const dispatch = useDispatch();
  const { saveDataInRedux, exitHandler } = useOnboarding({
    pageKey,
    pageId,
  });

  const {
    control,
    reset,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(accountTermsSchema),
  });

  useEffect(() => {
    dispatch(updateLeftMenuStatus(true));
  }, [dispatch]);

  const submitHandler = async (data) => {
    try {
      dispatch(setLoader(true));
      await ApiClient.post(consentAccount, {
        ...data,
      });
      await ApiClient.post(submitApplicationApi, {});

      const formData = {
        [pageKey]: { ...data },
        curPageId: pageId,
      };
      saveDataInRedux({
        formData,
      });
    } catch (err) {
      // console.log(err)
    } finally {
      dispatch(setLoader(false));
    }
  };

  useEffect(() => {
    if (payload?.[pageKey]) {
      reset(payload?.[pageKey]);
    }
  }, [payload]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <form onSubmit={handleSubmit(submitHandler)}>
      <RightPanelLayout maxWidth="600px">
        <FormHead
          heading={accountReleated}
          subHeading={afterAccountReleatedTerms}
        />
        <Box className="mb-1">
          <Box>
            {/* <InputLabel htmlFor="terms-and-cond-1">{tNcLable}</InputLabel> */}
            <Typography
              id="terms-and-cond-1"
              variant="body2"
              className={internalClasses.termsTextAreaAlignment}
            >
              {tNcData}
            </Typography>
            <Link
              href="/#"
              color="inherit"
              onClick={(e) => e.preventDefault()}
              className={classes.link}
            >
              {strings.viewnPrint}
            </Link>
          </Box>
          <Grid container alignItems="center">
            <Grid item xs={6}>
              <CustomCheckbox
                name="acctTncFlag"
                id="acctTncFlag"
                control={control}
                label={chelloTermsOfUse}
                error={!!errors.acctTncFlag}
                errorText={errors.acctTncFlag && errors.acctTncFlag.message}
                margin="normal"
              />
            </Grid>
          </Grid>
        </Box>
        <Box>
          <Box>
            {/* <InputLabel htmlFor="terms-and-cond-2">{tNcLable}</InputLabel> */}
            <Typography
              id="terms-and-cond-2"
              variant="body2"
              className={internalClasses.termsTextAreaAlignment}
            >
              {tNcData}
            </Typography>
            <Link
              href="/#"
              color="inherit"
              onClick={(e) => e.preventDefault()}
              className={classes.link}
            >
              {strings.viewnPrint}
            </Link>
          </Box>
          <Grid container alignItems="center">
            <Grid item xs={6}>
              <CustomCheckbox
                name="acctPvcyFlag"
                id="acctPvcyFlag"
                control={control}
                label={chellopolicy}
                error={!!errors.acctPvcyFlag}
                errorText={errors.acctPvcyFlag && errors.acctPvcyFlag.message}
                margin="normal"
              />
            </Grid>
          </Grid>
        </Box>
      </RightPanelLayout>
      <Footer
        continueEnable={isValid}
        continueBtnName={submit}
        saveHandler={() => exitHandler({ saveData: false })}
      />
    </form>
  );
};

export default AccountTerms;
