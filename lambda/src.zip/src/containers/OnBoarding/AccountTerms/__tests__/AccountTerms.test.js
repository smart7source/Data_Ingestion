import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';

import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  onBoardingStateEmptyMock,
  onBoardingStateMock,
} from 'testHelpers';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import Auth from '@aws-amplify/auth';
import { createMemoryHistory } from 'history';
import { Router } from 'react-router-dom';
import AccountTerms from '../AccountTerms';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);
const history = createMemoryHistory();

describe('Render Chello Terms component with empty data', () => {
  const mockStore = configureStore(onBoardingStateEmptyMock);
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });

    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <AccountTerms />
          </Router>
        </Provider>,
      ),
    );
  });

  test('render component with inital data', () => {
    expect(screen.getByText(strings.accountReleated)).toBeInTheDocument();
    expect(
      screen.getByText(strings.afterAccountReleatedTerms),
    ).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', {
      name: strings.submit,
    });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).toBeDisabled();
  });
  test('should render exit dialog and click on save n exit', async () => {
    const exitBtn = screen.getByRole('button', { name: strings.exit });
    expect(exitBtn).toBeDefined();
    await act(async () => {
      fireEvent.click(exitBtn);
    });
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    await act(async () => {
      fireEvent.click(exitDialogSaveAndExitBtn);
    });
    expect(history.location.pathname).toBe(routePath.LOGIN);
  });
});

describe('Render Chello Terms component with redux data', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });

    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <AccountTerms />
          </Router>
        </Provider>,
      ),
    );
  });

  test('render component with inital data', () => {
    expect(screen.getByText(strings.accountReleated)).toBeInTheDocument();
    expect(
      screen.getByText(strings.afterAccountReleatedTerms),
    ).toBeInTheDocument();
    const continueBtn = screen.getByRole('button', {
      name: strings.submit,
    });
    expect(continueBtn).toBeInTheDocument();
    expect(continueBtn).not.toBeDisabled();
  });

  test('enable checkbox and disable', async () => {
    const checkbox = screen.getByRole('checkbox', {
      name: strings.chelloTermsOfUse,
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    const continueBtn = screen.getByRole('button', {
      name: strings.submit,
    });
    expect(continueBtn).toBeDisabled();

    expect(
      screen.getByText(strings.acceptFieldRequiredMsg),
    ).toBeInTheDocument();
  });

  test('enable checkbox and disable policy', async () => {
    const checkbox = screen.getByRole('checkbox', {
      name: strings.chellopolicy,
    });

    await act(async () => {
      fireEvent.click(checkbox);
    });

    const continueBtn = screen.getByRole('button', {
      name: strings.submit,
    });
    expect(continueBtn).toBeDisabled();

    expect(
      screen.getByText(strings.policyFieldRequiredMsg),
    ).toBeInTheDocument();
  });

  test('submit form', async () => {
    const continueBtn = screen.getByRole('button', {
      name: strings.submit,
    });
    await act(async () => fireEvent.click(continueBtn));
    await waitFor(async () => {
      expect(history.location.pathname).toBe(routePath.ACCOUNT_STATUS);
    });
  });

  test('render print link and policy link', () => {
    const viewPrints = screen.getAllByRole('link', {
      name: strings.viewnPrint,
    });
    expect(viewPrints).toHaveLength(2);
    fireEvent.click(viewPrints[0]);
    fireEvent.click(viewPrints[1]);
  });
});
