import { Typography, Grid, Box, Button, Container } from '@mui/material';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Avatar from '@mui/material/Avatar';
import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';

import { routePath } from 'routes';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import strings from 'localization/translation';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { setLoader } from 'store/actions';
import { NotificationContext } from 'contexts';
import { Notification } from 'components';

const {
  chelloSetupHeading1,
  chelloSetupHeading2,
  chelloSetupContent,
  chelloSetupboxtitle1,
  chelloSetupboxtitle2,
  chelloSetupmessage,
  chelloseupButtonone,
  goToDashboard,
  joinChello,
  welcomePageExclamation,
  dot,
} = strings;
const { getRelationshipmanager, getAroImage } = serviceUrl;
const WelcomeChello = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [rmDetails, setRMDetails] = useState({});
  const [notification, setNotification] = useState([]);

  useEffect(() => {
    const fetchRelationshipManagerDetails = async () => {
      try {
        dispatch(setLoader(true));
        const response = await ApiClient.get(getRelationshipmanager, {
          params: {
            picture: true,
          },
        });
        const { body } = response;
        setRMDetails(body);
      } catch (err) {
        setNotification([{ severity: 'error', message: err?.message }]);
      } finally {
        dispatch(setLoader(false));
      }
    };
    fetchRelationshipManagerDetails();
  }, [dispatch]);

  return (
    <Box component="main">
      <Container
        maxWidth="sm"
        className={internalClasses.welcomeChelloContainer}
      >
        <NotificationContext.Provider value={{ notification, setNotification }}>
          {!!notification.length && (
            <Box mb={2.5}>
              <Notification errors={notification} needFocus />
            </Box>
          )}
          <Typography variant="h1" align="center">
            {chelloSetupHeading1}{' '}
            <Typography variant="h1" component="span" color="primary">
              {joinChello}
            </Typography>
            {welcomePageExclamation}
          </Typography>

          <Typography
            variant="h1"
            className={internalClasses.welcomeChelloSetupHeading}
          >
            {chelloSetupHeading2}
          </Typography>
          <Typography
            align="center"
            gutterBottom
            variant="p1"
            className={classes.transitionImgCenter}
          >
            {chelloSetupContent}
          </Typography>
          <Card style={{ marginTop: '30px', padding: '14px' }}>
            <CardContent>
              <Grid container direction="row">
                <Grid item xs={12} sm={2} container justifyContent="center">
                  <Avatar
                    alt={rmDetails?.displayName}
                    className={internalClasses.welcomeChelloAvatar}
                    src={`${getAroImage}${rmDetails?.id}.png`}
                  />
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={10}
                  className={internalClasses.welcomeChelloNameGrid}
                >
                  <Typography className={classes.welcomeChellottxt}>
                    {chelloSetupboxtitle1}
                    {rmDetails?.displayName}
                    {dot}
                  </Typography>
                  <Typography className={classes.welcomeChellottxt}>
                    {chelloSetupboxtitle2}
                    <Typography variant="h1" component="span" color="primary">
                      {joinChello}
                      {dot}
                    </Typography>
                  </Typography>
                  <Typography className={classes.aroSetuptext} variant="p1">
                    {chelloSetupmessage}
                  </Typography>
                  <CardActions
                    className={internalClasses.welcomeChelloCardAction}
                  >
                    <Button
                      variant="contained"
                      color="primary"
                      disableElevation
                    >
                      {chelloseupButtonone}
                    </Button>
                    <Button
                      variant="contained"
                      onClick={() => history.push(routePath.DASHBOARD)}
                      disableElevation
                    >
                      {goToDashboard}
                    </Button>
                  </CardActions>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </NotificationContext.Provider>
      </Container>
    </Box>
  );
};

export default WelcomeChello;
