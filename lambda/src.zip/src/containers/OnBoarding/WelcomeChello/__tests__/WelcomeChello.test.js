import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';

import strings from 'localization/translation';
import { createMemoryHistory } from 'history';
import { renderWithProviderAndRouter } from 'testHelpers';

import WelcomeChello from '../WelcomeChello';

const mockHistoryPush = jest.fn();
const mockUseHistory = {
  push: mockHistoryPush,
};
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => mockUseHistory,
}));

describe('Rendering WelcomeChello Page', () => {
  test('component renders correctly', async () => {
    renderWithProviderAndRouter(<WelcomeChello />, { render });
    await waitFor(() =>
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
    );
    await waitFor(() =>
      expect(screen.getByText(/Hemanth/i)).toBeInTheDocument(),
    );
    expect(screen.getByText(/Welcome to/)).toBeInTheDocument();
    expect(
      screen.getByText('Your account is up and running.'),
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        'We look forward to working with you and kicking off our relationship.We care about real and personal connections and want to make sure.you always have someone to turn to.',
      ),
    ).toBeInTheDocument();
    expect(
      screen.getByText(/I’ll be your point of contact for all things/),
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /I’ll be reaching out via email soon to introduce myself and learn more about your business./,
      ),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /Say Chello to your banker/ }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: strings.goToDashboard }),
    ).toBeInTheDocument();
  });

  test('buttons function correctly', async () => {
    renderWithProviderAndRouter(<WelcomeChello />, { render });
    await waitFor(() =>
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
    );
    await waitFor(() =>
      expect(screen.getByText(/Hemanth/i)).toBeInTheDocument(),
    );
    const dashBtn = screen.getByRole('button', { name: strings.goToDashboard });
    expect(dashBtn).toBeDefined();
    await act(async () => {
      fireEvent.click(dashBtn);
    });
    expect(mockHistoryPush).toHaveBeenCalledWith('/dashboard');
  });
});
