import { Box } from '@mui/material';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';

import { useOnboarding } from 'hooks';
import { accStatusPgInfo } from 'helpers/URLConfiguration';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import { setLoader } from 'store/actions';

import AccountPending from '../AccountPending/AccountPending';
import AccountSubmitted from '../AccountSubmitted/AccountSubmitted';
import AccountSuccess from '../AccountSuccess/AccountSuccess';

const { pageId, pageKey } = accStatusPgInfo;
const { onboardingStatusApi, addOneAccountApi } = serviceUrl;
const AccountStatus = () => {
  const dispatch = useDispatch();
  const [status, setStatus] = useState({});
  const [errMsgs, setErrMsgs] = useState([]);
  const [addAccountDetails, setAddAccountDetails] = useState({});
  const { exitHandler } = useOnboarding({
    pageKey,
    pageId,
  });

  const addOneAccount = async () => {
    try {
      dispatch(setLoader(true));
      const response = await ApiClient.post(addOneAccountApi);
      const { body } = response;
      setAddAccountDetails(body);
    } catch (e) {
      setErrMsgs([{ severity: 'error', message: e.message }]);
    } finally {
      dispatch(setLoader(false));
    }
  };

  const fetchOnboardingStatus = async () => {
    try {
      dispatch(setLoader(true));
      const response = await ApiClient.get(onboardingStatusApi);
      const { body } = response;
      if (
        body?.accountCreated === 'N' &&
        body?.kycKybResponseReceived === 'Y' &&
        body?.overallStatus === 'KYBKYC_COMPLETED'
      ) {
        addOneAccount();
      }
      setStatus(body);
    } catch (e) {
      // setErrMsgs([{ severity: 'error', message: e.message }]);
    } finally {
      dispatch(setLoader(false));
    }
  };
  useEffect(() => {
    fetchOnboardingStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const renderAccountStatus = () => {
    if (
      status?.accountCreated === 'N' &&
      status?.kycKybResponseReceived === 'Y' &&
      status?.overallStatus === 'KYBKYC_ADDLDOC'
    ) {
      return <AccountPending kyb={status?.kyb} kyc={status?.kyc} />;
    }
    if (
      (status?.accountCreated === 'Y' &&
        status?.kycKybResponseReceived === 'Y' &&
        status?.overallStatus === 'ACCOUNT_CREATED') ||
      Object.keys(addAccountDetails).length > 0
    ) {
      return (
        <AccountSuccess
          businessNameVal={
            addAccountDetails?.businessName || status?.businessName
          }
          accountNumberVal={
            addAccountDetails?.accountNumber || status?.accountNumber
          }
          errors={errMsgs}
          handleSave={() => exitHandler({ saveData: false })}
        />
      );
    }

    return <AccountSubmitted submitStatus={status?.overallStatus} />;
  };
  return <Box>{renderAccountStatus()}</Box>;
};

export default AccountStatus;
