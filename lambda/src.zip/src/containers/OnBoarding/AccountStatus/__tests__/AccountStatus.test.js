import { Provider } from 'react-redux';
import { render, screen, waitFor, act } from '@testing-library/react';
import configureStore from 'store/configureStore';
import AccountStatus from '../AccountStatus';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';

import {
  cognitoCurrentSessionMock,
  cognitoUserMock,
  onBoardingStateMock,
} from 'testHelpers';
import strings from 'localization/translation';
import Auth from '@aws-amplify/auth';
import server from 'apiMocks/server';
import { rest } from 'msw';
import serviceUrl from 'api/UrlHelper';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);
const history = createMemoryHistory();

describe('rendering <AccountStatus /> component when account is not created', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <AccountStatus />
          </Router>
        </Provider>,
      ),
    );
  });

  it('Application Submiitted Test', async () => {
    await waitFor(() => {
      const chelloCoffeeLogo = screen.getByAltText('logo');
      expect(chelloCoffeeLogo).toHaveAttribute('alt', 'logo');
      expect(
        screen.getByText(new RegExp(strings.accountSubmitted, 'i')),
      ).toBeInTheDocument();
    });
  });
});

describe('rendering <AccountStatus /> component when account is created', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    server.use(
      rest.get(serviceUrl.onboardingStatusApi, (req, res, ctx) =>
        res(
          ctx.json({
            status: { code: '200', description: 'Record Retrieved' },
            body: {
              overallStatus: 'ACCOUNT_CREATED',
              accountCreated: 'Y',
              businessName: 'Family Practice',
              accountNumber: 'acctNumber1',
              kycKybResponseReceived: 'Y',
              kyb: {
                orgId: 'party1',
                kybStatus: 'Pass',
                documents: [
                  {
                    docType: 'ArticlesofIncorporation',
                    docId: '1118263',
                    status: 'Pass',
                    instructions: 'NA',
                  },
                  {
                    docType: 'ArticlesofIncorporation',
                    docId: '1118260',
                    status: 'Pass',
                    instructions: 'NA',
                  },
                ],
              },
              kyc: [
                {
                  memberId: 'party1',
                  kycStatus: 'Pass',
                  documents: [
                    {
                      docType: 'License',
                      docId: '1118262',
                      status: 'Pass',
                      instructions: 'NA',
                    },
                  ],
                },
                {
                  memberId: 'party2',
                  kycStatus: 'Pass',
                  documents: [
                    {
                      docType: 'License',
                      docId: '1118261',
                      status: 'Pass',
                      instructions: 'NA',
                    },
                  ],
                },
              ],
            },
          }),
        ),
      ),
    );
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <AccountStatus />
          </Router>
        </Provider>,
      ),
    );
  });

  it('logo must have correct src & alt chello coffee cup', async () => {
    await waitFor(() => {
      const chelloCoffeeLogo = screen.getByAltText('logo');
      expect(chelloCoffeeLogo).toHaveAttribute('alt', 'logo');
      expect(
        screen.getByText(new RegExp(strings.chelloWelcomeHeading, 'i')),
      ).toBeInTheDocument();
    });
  });
});

describe('rendering <AccountStatus /> component when KYC is pending for Documents', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    server.use(
      rest.get(serviceUrl.onboardingStatusApi, (req, res, ctx) =>
        res(
          ctx.json({
            status: { code: '200', description: 'Record Retrieved' },
            body: {
              overallStatus: 'KYBKYC_ADDLDOC',
              accountCreated: 'N',
              kycKybResponseReceived: 'Y',
              kyb: {
                orgId: 'party1',
                kybStatus: 'Pass',
                documents: [
                  {
                    docType: 'ArticlesofIncorporation',
                    docId: '1118263',
                    status: 'Pass',
                    instructions: 'NA',
                  },

                  {
                    docType: 'ArticlesofIncorporation',
                    docId: '1118260',
                    status: 'Pass',
                    instructions: 'NA',
                  },
                ],
              },
              kyc: [
                {
                  memberId: 'party1',
                  kycStatus: 'Pass',
                  documents: [
                    {
                      docType: 'License',
                      docId: '1118262',
                      status: 'Pass',
                      instructions: 'NA',
                    },
                  ],
                },

                {
                  memberId: 'party2',
                  kycStatus: 'Pass',
                  documents: [
                    {
                      docType: 'License',
                      docId: '1118261',
                      status: 'Pass',
                      instructions: 'NA',
                    },
                  ],
                },
              ],
            },
          }),
        ),
      ),
    );
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <AccountStatus />
          </Router>
        </Provider>,
      ),
    );
  });

  it('Pending Docs test', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(new RegExp(strings.accountPendingHeading, 'i')),
      ).toBeInTheDocument();
    });
  });
});

describe('rendering <AccountStatus /> component when KYC is done and account is not created', () => {
  const mockStore = configureStore(onBoardingStateMock);
  beforeEach(async () => {
    server.use(
      rest.get(serviceUrl.onboardingStatusApi, (req, res, ctx) =>
        res(
          ctx.json({
            status: { code: '200', description: 'Record Retrieved' },
            body: {
              overallStatus: 'KYBKYC_COMPLETED',
              accountCreated: 'N',
              kycKybResponseReceived: 'Y',
              kyb: {
                orgId: 'party1',
                kybStatus: 'Pass',
                documents: [
                  {
                    docType: 'ArticlesofIncorporation',
                    docId: '1118263',
                    status: 'Pass',
                    instructions: 'NA',
                  },

                  {
                    docType: 'ArticlesofIncorporation',
                    docId: '1118260',
                    status: 'Pass',
                    instructions: 'NA',
                  },
                ],
              },
              kyc: [
                {
                  memberId: 'party1',
                  kycStatus: 'Pass',
                  documents: [
                    {
                      docType: 'License',
                      docId: '1118262',
                      status: 'Pass',
                      instructions: 'NA',
                    },
                  ],
                },

                {
                  memberId: 'party2',
                  kycStatus: 'Pass',
                  documents: [
                    {
                      docType: 'License',
                      docId: '1118261',
                      status: 'Pass',
                      instructions: 'NA',
                    },
                  ],
                },
              ],
            },
          }),
        ),
      ),
    );
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    jest.spyOn(Auth, 'signOut').mockImplementation(() => {
      return Promise.resolve(true);
    });
    await act(async () =>
      render(
        <Provider store={mockStore}>
          <Router history={history}>
            <AccountStatus />
          </Router>
        </Provider>,
      ),
    );
  });

  it('Successs Test Account Created', async () => {
    await waitFor(() => {
      expect(
        screen.getByText(new RegExp(strings.chelloWelcomeHeading, 'i')),
      ).toBeInTheDocument();
    });
  });
});
