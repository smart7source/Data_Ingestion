import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Box } from '@mui/material';
import clsx from 'clsx';

import ChatBotMain from '../Dashboard/HelpCenter/All/ChatBotMain';

const FloatingChatbot = () => {
  const {
    isAuthenticated,
    floatingChatbot: { enableFloatingChatbot, maximize },
  } = useSelector((state) => state.global);
  const [isExpanded, setIsExpanded] = useState(maximize);
  useEffect(() => setIsExpanded(maximize), [maximize]);

  if (!isAuthenticated || !enableFloatingChatbot) return null;
  return (
    <Box
      sx={{
        position: 'fixed',
        width: '445px',
        bottom: '0px',
        right: '30px',
        zIndex: 1101, // should be on top of all components
      }}
      className={clsx({
        floatingChatbotWrapper: isExpanded,
        minimizedFloatingChatbotWrapper: !isExpanded,
      })}
      data-testid="floating-chatbot"
    >
      <ChatBotMain
        headerProps={{
          isExpandCollapseDisabled: false,
          onExpandCollapseClick: () => setIsExpanded((status) => !status),
          isExpanded,
        }}
      />
    </Box>
  );
};

export default FloatingChatbot;
