import { useEffect } from 'react';
import { Switch } from 'react-router-dom';
import Amplify from 'aws-amplify';
import { useSelector, useDispatch } from 'react-redux';

import awsConfigure from 'aws-exports';
import { PrivateRoute, PublicRoute } from 'routes';
import { privateRoutes, publicRoutes } from 'routes/routes';
import { checkAuthState } from 'utils';
import { updateAuthenticatedStatus } from 'store/actions';
import SavanaTimerComponent from 'components/SavanaTimerComponent';

import PageNotFound from '../PageNotFound/PageNotFound';
import { Spinner, ErrorModal } from '../../components';

import FloatingChatbot from './FloatingChatbot';
import './App.scss';

Amplify.configure(awsConfigure);

function App() {
  const { loading, errorMessage } = useSelector((state) => state.global);
  const dispatch = useDispatch();
  useEffect(() => {
    const updateAuthStatus = async () => {
      const { isAuthenticated: isAuth } = await checkAuthState();
      dispatch(updateAuthenticatedStatus(isAuth));
    };
    updateAuthStatus();
  }, [dispatch]);

  return (
    <>
      <FloatingChatbot />
      <Spinner open={loading} errorMessage={errorMessage} />
      <ErrorModal />
      <SavanaTimerComponent />
      <Switch>
        {publicRoutes.map((route, index) => (
          <PublicRoute
            key={index}
            path={route.path}
            exact={route.exact}
            component={route.component}
            layout={route.layout}
            redirect={route.redirect || false}
          />
        ))}

        {privateRoutes.map((route, index) => (
          <PrivateRoute
            key={index}
            path={route.path}
            exact={route.exact}
            component={route.component}
            // render={getOnboardingRoute({ component: route.component })}
            layout={route.layout}
            redirect={route.redirect || false}
          />
        ))}

        <PublicRoute component={PageNotFound} />
      </Switch>
    </>
  );
}

export default App;
