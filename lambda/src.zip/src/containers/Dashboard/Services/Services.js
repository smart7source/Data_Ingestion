import strings from 'localization/translation';

const { servicesPage } = strings;
const Services = () => <h2>{servicesPage}</h2>;

export default Services;
