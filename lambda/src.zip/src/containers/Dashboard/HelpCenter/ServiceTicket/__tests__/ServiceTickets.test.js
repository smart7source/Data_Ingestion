import { render, screen, fireEvent, act } from '@testing-library/react/pure';
import { Provider } from 'react-redux';
import configureStore from 'store/configureStore';
import ServiceTickets from '../ServiceTickets';

const initialState = {};
const store = configureStore(initialState);
const currentProps = {};

describe('Service Tickets screen', () => {
  beforeAll(() => {
    render(
      <Provider store={store}>
        <ServiceTickets {...currentProps} />
      </Provider>,
    );
  });

  it('should render text', () => {
    const category = screen.getAllByText(/Category/i);
    expect(category[0]).toBeInTheDocument();
    const created = screen.getAllByText(/Created/i);
		expect(created[0]).toBeInTheDocument();
    const estimate = screen.getAllByText(/Estimate date/i);
		expect(estimate[0]).toBeInTheDocument();
  });
});
