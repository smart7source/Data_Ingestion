import { useDispatch } from 'react-redux';
import { Box, Typography, Grid, Paper, IconButton } from '@mui/material';

import CustomIcon from 'components/UIElements/CustomIcon';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as Archive } from 'assets/svg/archive.svg';
import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';
import { updateActiveHelpDeskTab } from 'store/actions';

const {
  processing,
  pending,
  completed,
  category,
  loremText,
  general,
  created,
  estimateDate,
  serviceTickets,
  viewAll,
} = strings;
const ServiceTickets = () => {
  const dispatch = useDispatch();
  return (
    <Grid container>
      <Grid item xs={12} sm={12} md={12} lg={12}>
        <Box className={HCClasses.serviceTicketsBox}>
          <Paper elevation={2}>
            <Box m={2}>
              <Box
                mt={2}
                style={{
                  paddingBottom: '0.5rem',
                  borderBottom: '1px solid #ccc',
                  marginTop: '0.5rem',
                }}
              >
                <Grid container justifyContent="space-between">
                  <Typography variant="h2" className={classes.modalTitle}>
                    {serviceTickets}
                  </Typography>
                  <Typography className={classes.boldText}>
                    <IconButton
                      data-testid="open-service-tickets"
                      aria-label="open"
                      onClick={() => dispatch(updateActiveHelpDeskTab(2))}
                    >
                      <CustomIcon
                        component={Archive}
                        color="primary"
                        inheritViewBox
                        className={classes.serviceTicketsIcon}
                      />
                    </IconButton>
                    {viewAll}
                  </Typography>
                </Grid>
              </Box>
              <Grid direction="row" container spacing={2}>
                <Grid container item sm={4}>
                  <Box
                    mt={3}
                    style={{
                      borderRight: '1px solid #ccc',
                    }}
                  >
                    <Grid item xs={12}>
                      <Box pr={1}>
                        <Grid container justifyContent="space-between">
                          <Typography
                            variant="csubtitle2"
                            className={classes.boldText}
                          >
                            #439309849
                          </Typography>
                          <Box
                            style={{
                              padding: '3px 12px',
                              backgroundColor: '#F2CEFF',
                              borderRadius: '12px',
                            }}
                          >
                            <Typography variant="body2">{pending}</Typography>
                          </Box>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Grid container justifyContent="flex-start">
                          <Typography pr={1} className={classes.boldText}>
                            {category}
                          </Typography>
                          <Typography> {general}</Typography>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Grid container justifyContent="flex-start">
                          <Typography variant="caption">{created}</Typography>
                          <Typography variant="caption">12/12/21 </Typography>
                          <Typography variant="caption">
                            {estimateDate}
                          </Typography>
                          <Typography variant="caption">12/25/21</Typography>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Typography variant="body2">{loremText}</Typography>
                      </Box>
                    </Grid>
                  </Box>
                </Grid>
                <Grid container item sm={4}>
                  <Box
                    mt={3}
                    style={{
                      borderRight: '1px solid #ccc',
                    }}
                  >
                    <Grid item xs={12}>
                      <Box pr={1}>
                        <Grid container justifyContent="space-between">
                          <Typography
                            variant="csubtitle2"
                            className={classes.boldText}
                          >
                            #439309644
                          </Typography>
                          <Box
                            style={{
                              padding: '3px 12px',
                              backgroundColor: '#F2CEFF',
                              borderRadius: '12px',
                            }}
                          >
                            <Typography variant="body2">
                              {processing}
                            </Typography>
                          </Box>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Grid container justifyContent="flex-start">
                          <Typography pr={1} className={classes.boldText}>
                            {category}
                          </Typography>
                          <Typography> {general}</Typography>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Grid container justifyContent="flex-start">
                          <Typography variant="caption">{created}</Typography>
                          <Typography variant="caption">12/12/21 </Typography>
                          <Typography variant="caption">
                            {estimateDate}
                          </Typography>
                          <Typography variant="caption">12/25/21</Typography>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Typography variant="body2">{loremText}</Typography>
                      </Box>
                    </Grid>
                  </Box>
                </Grid>
                <Grid container item sm={4}>
                  <Box mt={3}>
                    <Grid item xs={12}>
                      <Box>
                        <Grid container justifyContent="space-between">
                          <Typography
                            variant="csubtitle2"
                            className={classes.boldText}
                          >
                            #439309849
                          </Typography>
                          <Box
                            style={{
                              padding: '3px 12px',
                              backgroundColor: '#DCDCDC',
                              borderRadius: '12px',
                            }}
                          >
                            <Typography variant="body2">{completed}</Typography>
                          </Box>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Grid container justifyContent="flex-start">
                          <Typography pr={1} className={classes.boldText}>
                            {category}
                          </Typography>
                          <Typography> {general}</Typography>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Grid container justifyContent="flex-start">
                          <Typography variant="caption">{created}</Typography>
                          <Typography variant="caption">12/12/21 </Typography>
                          <Typography variant="caption">
                            {estimateDate}
                          </Typography>
                          <Typography variant="caption">12/25/21</Typography>
                        </Grid>
                      </Box>
                      <Box mt={2}>
                        <Typography variant="body2">{loremText}</Typography>
                      </Box>
                    </Grid>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Paper>
        </Box>
      </Grid>
    </Grid>
  );
};

export default ServiceTickets;
