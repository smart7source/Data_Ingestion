import { useState } from 'react';
import {
  Box,
  Grid,
  Paper,
  Button,
  Typography,
  IconButton,
  Link,
} from '@mui/material';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as calendar } from 'assets/svg/calendar.svg';
import { ReactComponent as fileText } from 'assets/svg/file-text.svg';
import { ReactComponent as messageCircle } from 'assets/svg/message-circle.svg';
import { bookAppointmentModal } from 'store/actions';
import classes from 'style/globalStyle.module.scss';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import strings from 'localization/translation';
import { defaultFnPropTypes } from 'utils';
import serviceUrl from 'api/UrlHelper';
import { ComponentSpinner } from 'components';

import CancelAppointment from './TalkToUs/CancelAppointment/CancelAppointment';
import ViewProfile from './TalkToUs/ViewProfile/ViewProfile';
import SendMessage from './TalkToUs/SendMessage/SendMessage';

const {
  relationshipManager2,
  viewProfile,
  sendMessage,
  bookAnAppointment,
  messageLog,
  yourAppointment,
  cancel,
  reschedule,
} = strings;

const TalkToUs = ({
  selectedData,
  setSelectedData,
  hendleLogSubmit,
  messageLogData,
  rmDetails,
}) => {
  const [openProfile, setOpenProfile] = useState(false);
  const [cancelModal, setCancelModal] = useState(false);
  const [messageModal, setMessageModal] = useState(false);

  const dispatch = useDispatch();

  const openViewProfile = (event) => {
    setOpenProfile(!openProfile);
  };

  const openCancelModal = (event) => {
    setCancelModal(!cancelModal);
  };

  const openSendMessage = (event) => {
    setMessageModal(!messageModal);
  };

  return (
    <>
      <Grid container>
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <Paper sx={{ position: 'relative' }} elevation={2}>
            <ComponentSpinner
              dataTestId="talkToUsSpinner"
              open={rmDetails.loading}
            />
            <Box m={1}>
              <Grid className={classes.gridPadding}>
                <Box mb={1}>
                  <Typography variant="h2" color="grey.1100">
                    {relationshipManager2}
                  </Typography>
                </Box>
                <Grid container>
                  <Grid item xs={3} md={4} lg={4}>
                    <img
                      src={`${serviceUrl.getAroImage}${rmDetails?.id}.png`}
                      alt="manager"
                      style={{
                        width: '69px',
                        height: '69px',
                        borderRadius: ' 50% ',
                      }}
                    />
                  </Grid>
                  <Grid item xs={8} md={6} lg={8}>
                    <Grid container direction="column">
                      <Typography variant="p1SemiBold" color="grey.1100">
                        {rmDetails?.displayName}
                      </Typography>
                      <Typography variant="p2" color="grey.700">
                        {strings.relationshipManager}
                      </Typography>
                    </Grid>
                    <Grid>
                      <Typography
                        variant="p2"
                        style={{
                          fontStyle: 'italic',
                        }}
                      >
                        <IconButton
                          aria-label="close"
                          style={{
                            paddingLeft: '0px',
                            paddingTop: '0px',
                          }}
                          onClick={openViewProfile}
                        >
                          <CustomIcon
                            data-testid="view-profile-icon"
                            component={fileText}
                            inheritViewBox
                            className={HCClasses.customIconTalkToUs}
                          />
                        </IconButton>
                        {viewProfile}
                      </Typography>
                    </Grid>
                  </Grid>
                </Grid>
                <Box mt={1}>
                  <Typography variant="p2" color="grey.700">
                    {strings.setUpTime(rmDetails?.displayName)}
                  </Typography>
                </Box>
                <Grid
                  container
                  mt={1}
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <Grid item xs="auto">
                    <Grid container direction="column">
                      <Typography variant="button" color="grey.800">
                        <IconButton
                          aria-label="open-send-message-modal"
                          data-testid="send-message-modal"
                          onClick={openSendMessage}
                        >
                          <CustomIcon
                            component={messageCircle}
                            inheritViewBox
                            className={HCClasses.customIconTalkToUs}
                          />
                        </IconButton>
                        {sendMessage}
                      </Typography>
                      {messageLogData?.isOpen && (
                        <Link underline="hover">
                          <Typography
                            variant="p1"
                            color="primary"
                            style={{
                              lineHeight: '14.95px',
                            }}
                          >
                            {messageLog} (1)
                          </Typography>
                        </Link>
                      )}
                    </Grid>
                  </Grid>
                  <Grid item xs="auto">
                    {!selectedData.isOpen && (
                      <Button
                        data-testid="book-appointment"
                        className={classes.buttonNew}
                        variant="contained"
                        color="primary"
                        onClick={() => dispatch(bookAppointmentModal(true))}
                      >
                        {bookAnAppointment}
                      </Button>
                    )}
                    {selectedData.isOpen && (
                      <Grid item xs="auto">
                        <Grid container direction="column">
                          <Typography
                            variant="p2"
                            style={{ fontSize: '11px', color: '#5F5F5F' }}
                          >
                            <IconButton>
                              <CustomIcon
                                component={calendar}
                                inheritViewBox
                                className={HCClasses.talkToUsIconFont}
                              />
                            </IconButton>
                            {yourAppointment}
                          </Typography>
                          <Typography
                            ml={4}
                            variant="p2SemiBold"
                            color="grey.1100"
                          >
                            {selectedData.isOpen &&
                              `${selectedData.date || ''} at ${
                                selectedData.time || ''
                              }`}
                          </Typography>
                        </Grid>
                        <Grid>
                          <Box ml={4}>
                            <Link underline="hover" onClick={openCancelModal}>
                              <Typography
                                variant="p1"
                                color="primary"
                                style={{
                                  fontSize: '12px',
                                  lineHeight: '13.8px',
                                  fontStyle: 'normal',
                                }}
                              >
                                {cancel}
                              </Typography>
                            </Link>{' '}
                            |{' '}
                            <Link
                              underline="hover"
                              onClick={() =>
                                dispatch(bookAppointmentModal(true))
                              }
                            >
                              <Typography
                                variant="p1"
                                color="primary"
                                style={{
                                  fontSize: '12px',
                                  lineHeight: '13.8px',
                                  fontStyle: 'normal',
                                }}
                              >
                                {reschedule}
                              </Typography>
                            </Link>
                          </Box>
                        </Grid>
                      </Grid>
                    )}
                  </Grid>
                </Grid>
              </Grid>
            </Box>
          </Paper>
        </Grid>
      </Grid>
      {openProfile && (
        <ViewProfile
          openViewProfile={openViewProfile}
          selectedData={selectedData}
          rmDetails={rmDetails}
        />
      )}
      {cancelModal && (
        <CancelAppointment
          openCancelModal={openCancelModal}
          selectedData={selectedData}
          setSelectedData={setSelectedData}
        />
      )}
      {messageModal && (
        <SendMessage
          openSendMessage={openSendMessage}
          hendleLogSubmit={hendleLogSubmit}
        />
      )}
    </>
  );
};

export default TalkToUs;

TalkToUs.propTypes = {
  selectedData: PropTypes.instanceOf(Object),
  setSelectedData: PropTypes.func,
  hendleLogSubmit: PropTypes.func,
  messageLogData: PropTypes.instanceOf(Object),
  rmDetails: PropTypes.any,
};

TalkToUs.defaultProps = {
  selectedData: { isOpen: false },
  setSelectedData: defaultFnPropTypes,
  hendleLogSubmit: defaultFnPropTypes,
  messageLogData: {},
  rmDetails: {},
};
