import {
  render,
  screen,
  fireEvent,
  act,
} from '@testing-library/react/pure';
import { Provider } from 'react-redux';
import SendMessage from '../SendMessage';
import configureStore from 'store/configureStore';

const initialState = {};
const store = configureStore(initialState);
const currentProps = {};

describe('Send Message modal', () => {
  beforeAll(() => {
    render(
      <Provider store={store}>
        <SendMessage {...currentProps} />
      </Provider>,
    );
  });

  it('should render modal', async () => {
    expect(screen.getByText(/Help desk/i)).toBeInTheDocument();
    expect(screen.getByText(/To:/i)).toBeInTheDocument();
    expect(screen.getByText(/Subject:/i)).toBeInTheDocument();
    expect(screen.getByText(/Message Body/i)).toBeInTheDocument();
    await act(async () => {
      const textField = screen.getByTestId('messageBody');
      fireEvent.change(textField, {
        target: { value: 'Test' },
      });
    });
    const frequency = screen.getByTestId('message-subject');
    await act(async () => {
      fireEvent.change(frequency, { target: { value: 'Some text' } });

    });
  });

  it('should render button Send ', async () => {
    const button = screen.getByRole('button', { name: 'Send' });
    expect(button).toBeInTheDocument();
    expect(button).toBeEnabled();
    await act(async () => {
      fireEvent.click(button);
    });
  });

  it('should render button Attach file ', async () => {
    const button = screen.getByRole('button', { name: 'Attach file' });
    expect(button).toBeInTheDocument();
    expect(button).toBeEnabled();
  });

  it('should render button `x`  ', async () => {
    const button = screen.getByLabelText('close');
    await act(async () => {
      fireEvent.click(button);
    });
  });

  it('should render button Cancel ', async () => {
    const button = screen.getByRole('button', { name: 'Cancel' });
    expect(button).toBeInTheDocument();
    expect(button).toBeEnabled();
    await act(async () => {
      fireEvent.click(button);
    });
  });
});

