import { render, screen, fireEvent, act } from '@testing-library/react/pure';
import { Provider } from 'react-redux';
import ConfirmedAppointment from '../ConfirmedAppointment';
import configureStore from 'store/configureStore';

const initialState = {};
const store = configureStore(initialState);
const currentProps = {
	selectedData: {
		date: 'Feb 10, 2022',
		time: '11:00 am',
		typeOfAppointment: 'Help',
    appointmentReason: 'Some text'
	}
};

describe('Confirmed Appointment screen', () => {
	beforeAll(() => {
		render(
			<Provider store={store}>
				<ConfirmedAppointment {...currentProps} />
			</Provider>
		);
	});

	it('should render text', () => {
		expect(screen.getByText(/Your appointment is on the calendar./i)).toBeInTheDocument();
		expect(screen.getByText(/Your Relationship Manager/i)).toBeInTheDocument();
		expect(screen.getByText(/Date & time/i)).toBeInTheDocument();
		expect(screen.getByText(/Type of appointment/i)).toBeInTheDocument();
		expect(screen.getByText(/Description/i)).toBeInTheDocument();
	});

	it('should render value from Props', () => {
		expect(screen.getByText(/Feb 10, 2022/i)).toBeInTheDocument();
		expect(screen.getByText(/11:00 am/i)).toBeInTheDocument();
		expect(screen.getByText(/Help/i)).toBeInTheDocument();
  	expect(screen.getByText(/Some text/i)).toBeInTheDocument();
	});

	it('should render buttons ', () => {
		const buttonOk = screen.getByRole('button', { name: 'Ok' });
		expect(buttonOk).toBeInTheDocument();
		expect(buttonOk).toBeEnabled();
	});

	it('button OK should close modal', async () => {
		const buttonOk = screen.getByRole('button', { name: /Ok/i });
		await act(async () => {
			fireEvent.click(buttonOk);
		});
	});

	it('button `x` should close modal ', async () => {
		const button = screen.getByLabelText('close')
		await act(async () => {
			fireEvent.click(button);
		});
	});
});
