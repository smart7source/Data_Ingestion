import { Box, Grid, Typography } from '@mui/material';
import moment from 'moment';
import PropTypes from 'prop-types';

import strings from 'localization/translation';

const { at, original, rescheduled } = strings;

const DisplayTime = ({
  selectedData,
  displayDay,
  selectedDay,
  displayTime,
  selectedTime,
}) => {
  const locateDate = moment(selectedDay).format('MMM DD, YYYY');
  let selected;

  if (selectedData.isOpen) {
    selected = (
      <>
        <Grid
          container
          direction="column"
          justifyContent="center"
          alignItems="flex-end"
        >
          <Grid item>
            <Typography variant="p2SemiBold" color="grey.500">
              {selectedData.isOpen &&
                `${original} ${selectedData.date} ${at} ${selectedData.time}`}
            </Typography>
          </Grid>
          <Grid item>
            <Typography variant="p2SemiBold" color="grey.800">
              {displayDay &&
                displayTime &&
                `${rescheduled} ${locateDate || ''} ${at} ${
                  selectedTime || ''
                }`}
            </Typography>
          </Grid>
        </Grid>
      </>
    );
  } else {
    selected = (
      <>
        <Typography variant="p1SemiBold" color="grey.1100">
          {displayDay &&
            displayTime &&
            `${locateDate || ''} at ${selectedTime?.toLowerCase() || ''}`}
        </Typography>
      </>
    );
  }

  return (
    <>
      <Box mr={1} mt={!selectedData.isOpen ? 1 : 0}>
        {selected}
      </Box>
    </>
  );
};

export default DisplayTime;

DisplayTime.propTypes = {
  selectedData: PropTypes.instanceOf(Object),
  displayDay: PropTypes.string,
  selectedDay: PropTypes.string,
  displayTime: PropTypes.string,
  selectedTime: PropTypes.string,
};
DisplayTime.defaultProps = {
  selectedData: {},
  displayDay: '',
  selectedDay: '',
  displayTime: '',
  selectedTime: '',
};
