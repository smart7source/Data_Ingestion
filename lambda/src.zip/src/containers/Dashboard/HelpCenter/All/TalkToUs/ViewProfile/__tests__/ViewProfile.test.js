import { render, screen, fireEvent, act } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import ViewProfile from '../ViewProfile';

const initialState = {};
const mockStore = configureStore();

const SampleComponent = () => {
  const currentProps = {
    openBookModal: jest.fn(),
  };
  return <ViewProfile {...currentProps} />;
};

function renderElement() {
  return render(
    <Provider store={mockStore(initialState)}>
      <SampleComponent />
    </Provider>,
  );
}

describe('Testing ViewProfile screen', () => {
  it('should render sub title', () => {
    renderElement();
    expect(screen.getByText(/Your Relationship Manager/i)).toBeInTheDocument();
  });

  it('should render mock text', () => {
    renderElement();
    expect(
      screen.getByText(
        /Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis molestie eros penatibus tortor aliquet viverra interdum./i,
      ),
    ).toBeInTheDocument();
  });

  it('should render Book an Appointment button ', async () => {
    renderElement();
    const button = screen.getByRole('button', { name: /Book Appointment/i });
    expect(button).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(button);
    });
  });

  it('button `x` should close modal ',  () => {
    renderElement();
    const button = screen.getByLabelText('close');
    expect(button).toBeInTheDocument();
  });
});
