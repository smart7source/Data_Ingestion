import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Grid,
  Button,
  IconButton,
} from '@mui/material';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';

import { ReactComponent as Close } from 'assets/svg/close.svg';
import { bookAppointmentModal } from 'store/actions';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';
import serviceUrl from 'api/UrlHelper';

const { relationshipManager, bookAppointment, sendMessage, lorem } = strings;
const ViewProfile = ({ openViewProfile, selectedData, rmDetails }) => {
  const dispatch = useDispatch();
  const openBookModal = () => {
    dispatch(bookAppointmentModal(true));
    openViewProfile(false);
  };

  return (
    <Dialog aria-labelledby="customized-dialog-title" open>
      <DialogTitle>
        <Grid container justifyContent="space-between">
          <Grid item xs={10}>
            <Grid container alignItems="center">
              <Grid mt={1} item xs={3}>
                <img
                  src={`${serviceUrl.getAroImage}${rmDetails?.id}.png`}
                  alt="manager"
                  style={{
                    width: '89.34px',
                    height: '89.34px',
                    borderRadius: ' 50% ',
                  }}
                />
              </Grid>
              <Grid mt={1} item xs={9}>
                <Typography variant="h1" color="grey.1100">
                  {rmDetails?.displayName}
                </Typography>
                <Typography
                  variant="p2"
                  color="grey.600"
                  style={{ fontWeight: '400' }}
                >
                  {relationshipManager}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={1}>
            <Typography>
              <IconButton
                aria-label="close"
                sx={{
                  position: 'absolute',
                  right: { xs: 10, sm: 17 },
                  top: { xs: 10, sm: 17 },
                }}
                onClick={openViewProfile}
              >
                <Close
                  fill="grey.800"
                  style={{
                    width: '10px',
                    height: '10px',
                  }}
                />
              </IconButton>
            </Typography>
          </Grid>
        </Grid>
      </DialogTitle>
      <DialogContent>
        <Grid container alignItems="center" spacing={1}>
          <Grid item>
            <IconButton>
              <img
                src={`${process.env.PUBLIC_URL}/svg/message-circle.svg`}
                alt="send message"
              />
            </IconButton>
          </Grid>
          <Grid item>
            <Typography variant="button" color="grey.800">
              {sendMessage}
            </Typography>
          </Grid>
        </Grid>
        <Grid mt={3}>
          <Typography variant="p1" color="grey.1100">
            {lorem}
          </Typography>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button
          className={classes.buttonNew}
          disabled={selectedData.isOpen}
          variant="contained"
          color="primary"
          onClick={openBookModal}
        >
          {bookAppointment}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
export default ViewProfile;

ViewProfile.propTypes = {
  openViewProfile: PropTypes.func,
  selectedData: PropTypes.instanceOf(Object),
  rmDetails: PropTypes.any,
};
ViewProfile.defaultProps = {
  openViewProfile: defaultFnPropTypes,
  selectedData: {},
  rmDetails: {},
};
