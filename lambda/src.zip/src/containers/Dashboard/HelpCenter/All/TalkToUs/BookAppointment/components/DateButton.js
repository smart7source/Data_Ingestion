import { Typography, Button, Grid } from '@mui/material';
import PropTypes from 'prop-types';
import moment from 'moment';

import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

const DateButton = ({ item, index, handleClick, selected }) => {
  let buttonDisabled = false;

  // disable if it Sunday or if array is empty
  if (
    moment(item.date).format('ddd').toUpperCase() === 'SUN' ||
    !item.timeSlot.length
  ) {
    buttonDisabled = true;
  }

  // the first day will be replaced by TODAY
  const isToday =
    moment(new Date()).format('YYYY-MM-DD') ===
    moment(item.date).format('YYYY-MM-DD')
      ? 'TODAY'
      : moment(item.date).format('ddd').toUpperCase();
  return (
    <>
      <Button
        data-testid="slider-button-day"
        variant="outlined"
        className={classes.appointmentData}
        style={{
          backgroundColor: selected ? '#f8e8fd' : '',
          border: selected ? '1px solid #a120d1' : '',
        }}
        onClick={handleClick}
        disabled={buttonDisabled}
      >
        <Grid direction="column" container>
          <Typography
            variant="h2"
            color={buttonDisabled ? 'grey.500' : 'grey.1100'}
          >
            {moment(item.date).format('DD')}
          </Typography>
          <Typography
            className={classes.daySlot}
            color={buttonDisabled ? 'grey.500' : 'grey.1100'}
          >
            {isToday}
          </Typography>
        </Grid>
      </Button>
    </>
  );
};

export default DateButton;

DateButton.propTypes = {
  item: PropTypes.instanceOf(Object),
  index: PropTypes.number,
  handleClick: PropTypes.func,
  selected: PropTypes.bool,
};
DateButton.defaultProps = {
  item: {},
  index: 0,
  handleClick: defaultFnPropTypes,
  selected: false,
};
