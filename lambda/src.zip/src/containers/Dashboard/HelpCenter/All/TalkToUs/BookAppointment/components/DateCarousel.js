import { useState } from 'react';
import { Box, Grid, IconButton, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import 'testHelpers/matchMedia';
import Slider from 'react-slick';
import moment from 'moment';

import CustomIcon from 'components/UIElements/CustomIcon';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as ChevronRight } from 'assets/svg/chevron-right.svg';
import { ReactComponent as ChevronLeft } from 'assets/svg/chevron-left.svg';
import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

import DateButton from './DateButton';

const DateCarousel = ({ handleChangeDay, dateTime }) => {
  const [background, setBackground] = useState();
  const [month, setMonth] = useState('');
  const [currentIndex, setCurrentIndex] = useState();

  const ArrowLeft = ({ className, onClick }) => (
    <Grid className={classes.slickPrev}>
      <IconButton
        onClick={onClick}
        disabled={className?.includes('slick-disabled')}
      >
        <CustomIcon
          component={ChevronLeft}
          inheritViewBox
          color="grey.800"
          className={HCClasses.dateCarouselIcon}
        />
      </IconButton>
    </Grid>
  );

  const ArrowRight = ({ className, onClick }) => (
    <Grid className={classes.slickNext}>
      <IconButton
        onClick={onClick}
        disabled={className?.includes('slick-disabled')}
      >
        <CustomIcon
          component={ChevronRight}
          inheritViewBox
          color="grey.800"
          className={HCClasses.dateCarouselIcon}
        />
      </IconButton>
    </Grid>
  );

  const settings = {
    dots: false,
    infinite: false,
    arrows: true,
    prevArrow: <ArrowLeft />,
    nextArrow: <ArrowRight />,
    speed: 300,
    slidesToShow: 7,
    slidesToScroll: 1,
    afterChange: (index) => {
      setCurrentIndex(index);
      const newArr = [];
      for (let x = 1; x <= 7; x += 1) {
        const dateVal = new Date(dateTime[index + x]?.date);
        const monthVal = moment(dateVal).format('MMM');
        newArr.push(
          // eslint-disable-next-line no-nested-ternary
          newArr.includes(monthVal)
            ? ''
            : monthVal === 'Invalid date'
            ? ''
            : monthVal,
        );
        setMonth(newArr);
      }
    },
  };

  const handleClick = (itemDate, index) => {
    setBackground(index);
    handleChangeDay(itemDate, index);
  };

  return (
    <>
      <Grid container spacing={3}>
        <Grid item style={{ minWidth: '120px' }}>
          <Typography
            variant="p2SemiBold"
            color="grey.600"
            style={{ lineHeight: '19.5px' }}
          >
            {moment(dateTime[currentIndex]?.date).format('MMM')}
          </Typography>
        </Grid>
        <Grid item style={{ minWidth: '90px' }}>
          <Typography
            variant="p2SemiBold"
            color="grey.600"
            style={{ lineHeight: '19.5px' }}
          >
            {month[1]}
          </Typography>
        </Grid>

        <Grid item style={{ minWidth: '90px' }}>
          <Typography
            variant="p2SemiBold"
            color="grey.600"
            style={{ lineHeight: '19.5px' }}
          >
            {month[2]}
          </Typography>
        </Grid>
        <Grid item style={{ minWidth: '90px' }}>
          <Typography
            variant="p2SemiBold"
            color="grey.600"
            style={{ lineHeight: '19.5px' }}
          >
            {month[3]}
          </Typography>
        </Grid>
        <Grid item style={{ minWidth: '90px' }}>
          <Typography
            variant="p2SemiBold"
            color="grey.600"
            style={{ lineHeight: '19.5px' }}
          >
            {month[4]}
          </Typography>
        </Grid>
        <Grid item style={{ minWidth: '90px' }}>
          <Typography
            variant="p2SemiBold"
            color="grey.600"
            style={{ lineHeight: '19.5px' }}
          >
            {month[5]}
          </Typography>
        </Grid>
        <Grid item style={{ minWidth: '92px' }}>
          <Typography
            variant="p2SemiBold"
            color="grey.600"
            style={{ lineHeight: '19.5px' }}
          >
            {month[6]}
          </Typography>
        </Grid>
      </Grid>
      <Box mt={2} mx={3} maxWidth>
        <Slider {...settings}>
          {dateTime?.map((item, index) => (
            <DateButton
              key={index}
              item={item}
              index={index}
              handleClick={() => {
                handleClick(item.date, index);
              }}
              selected={background === index}
            />
          ))}
        </Slider>
      </Box>
      {/* <Box> // TODO its mobile version of button it still not approved
        <Grid
          container
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <Grid item>
            <IconButton p={0}>
              <ArrowBackIosIcon className={classes.iconArrow} />
            </IconButton>
          </Grid>
          <Grid item>
            <ToggleButtonGroup
              color="primary"
              value={selectedDay}
              exclusive
              onChange={handleChangeDay}
              fullWidth
            >
              {dataButtons.map((item, index) => (
                <ToggleButton
                  key={index}
                  data-testid="toggle-button-day"
                  className={classes.appointmentData}
                  value={formatToDate(item.day, 'MMM DD, YYYY')}
                >
                  <Grid direction="column" container>
                    <Typography variant="h2" color="grey.1100">
                      {formatToDate(item.day, 'DD')}
                    </Typography>
                    <Typography className={classes.daySlot}>
                      {formatToDate(item.day, 'ddd').toUpperCase()}
                    </Typography>
                  </Grid>
                </ToggleButton>
              ))}
            </ToggleButtonGroup>
          </Grid>
          <Grid item>
            <IconButton p={0}>
              <ArrowForwardIosIcon className={classes.iconArrow} />
            </IconButton>
          </Grid>
        </Grid>
      </Box> */}
    </>
  );
};

export default DateCarousel;

DateCarousel.propTypes = {
  handleChangeDay: PropTypes.func,
  className: PropTypes.instanceOf(Object),
  onClick: PropTypes.func,
  dateTime: PropTypes.instanceOf(Array),
  // currentSlide: PropTypes.number,
};
DateCarousel.defaultProps = {
  handleChangeDay: defaultFnPropTypes,
  className: {},
  onClick: defaultFnPropTypes,
  dateTime: [],
  // currentSlide: 0,
};
