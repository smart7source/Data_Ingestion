import { render, screen, fireEvent, act } from '@testing-library/react/pure';
import { Provider } from 'react-redux';
import CancelAppointment from '../CancelAppointment';
import configureStore from 'store/configureStore';

const initialState = {};
const store = configureStore(initialState);
const currentProps = {
  selectedData: {
    date: 'Feb 10, 2022',
    time: '11:00 am',
    typeOfAppointment: 'Help',
    appointmentReason: 'Some text'
  },
};

describe('Confirmed Appointment screen', () => {
  beforeAll(() => {
    render(
      <Provider store={store}>
        <CancelAppointment {...currentProps} />
      </Provider>,
    );
  });

  it('should render text', () => {
    expect(
      screen.getByText(/Are you sure you want to cancel your appointment?/i),
    ).toBeInTheDocument();
    expect(screen.getByText(/Your Relationship Manager/i)).toBeInTheDocument();
    expect(screen.getByText(/Date & time/i)).toBeInTheDocument();
    expect(screen.getByText(/Type of appointment/i)).toBeInTheDocument();
    expect(screen.getByText(/Description/i)).toBeInTheDocument();
  });

  it('should render value from Props', () => {
  	expect(screen.getByText(/Feb 10, 2022/i)).toBeInTheDocument();
  	expect(screen.getByText(/11:00 am/i)).toBeInTheDocument();
  	expect(screen.getByText(/Help/i)).toBeInTheDocument();
  	expect(screen.getByText(/Some text/i)).toBeInTheDocument();
  });

  it('should render buttons ', () => {
    const buttonCancel = screen.getByRole('button', {
      name: /Cancel appointment/i,
    });
		const buttonGoBack = screen.getByRole('button', {
      name: /Go back/i,
    });
    expect(buttonCancel).toBeInTheDocument();
    expect(buttonCancel).toBeEnabled();
    expect(buttonGoBack).toBeInTheDocument();
    expect(buttonGoBack).toBeEnabled();
  });

  it('button Cancel appointment should close modal', async () => {
    const button = screen.getByRole('button', {
      name: /Cancel appointment/i,
    });
    await act(async () => {
      fireEvent.click(button);
    });
  });

  it('button Go back should close modal', async () => {
    const button = screen.getByRole('button', {
      name: /Go back/i,
    });
    await act(async () => {
      fireEvent.click(button);
    });
  });

  it('button `x` should close modal ', async () => {
    const button = screen.getByLabelText('close');
    await act(async () => {
      fireEvent.click(button);
    });
  });
});
