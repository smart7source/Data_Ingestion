import {
  Box,
  Grid,
  Button,
  Dialog,
  DialogContent,
  IconButton,
  Typography,
  DialogTitle,
  DialogActions,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

import CustomIcon from 'components/UIElements/CustomIcon';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { ReactComponent as Plus } from 'assets/svg/plus.svg';
import { sendMessageSchema } from 'helpers/ValidationSchema';
import image from 'assets/image.svg';
import classes from 'style/globalStyle.module.scss';
import { CustomInput, CustomSelectBox } from 'components';
import strings from 'localization/translation';
import { defaultFnPropTypes } from 'utils';
import { Subject } from 'containers/Settings/components/SettingsUserData';

const { to, subject, messageBody, attachFile, cancel, send, helpDesk } =
  strings;

const SendMessage = ({ openSendMessage, hendleLogSubmit }) => {
  const {
    control,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(sendMessageSchema),
  });

  const charactersLimit = 1000;
  const characters = watch('appointmentReason') || '';

  const submitHandler = (data) => {
    hendleLogSubmit(data);
    openSendMessage();
    reset();
    // setSelectedDay('');
  };

  return (
    <Dialog
      aria-labelledby="send-message-modal"
      data-testid="send-message-modal"
      open
      PaperProps={{
        sx: {
          minWidth: { sm: 773 },
        },
      }}
    >
      <form
        onSubmit={handleSubmit(submitHandler)}
        data-testid="send-message-form"
      >
        <DialogTitle>
          <Grid container justifyContent="space-between">
            <Grid item xs={11} mt={{ xs: 0, sm: 2 }}>
              <Typography variant="h1" color="grey.900">
                {helpDesk}
              </Typography>
            </Grid>
            <Grid item xs={1}>
              <Typography>
                <IconButton
                  aria-label="close"
                  data-testid="close-button"
                  className={HCClasses.sendMessageIcon}
                  onClick={openSendMessage}
                >
                  <Close
                    fill="grey.800"
                    style={{
                      width: '10px',
                      height: '10px',
                    }}
                  />
                </IconButton>
              </Typography>
            </Grid>
          </Grid>
        </DialogTitle>
        <DialogContent>
          <Box>
            <Grid container spacing={1}>
              <Grid item>
                <Typography variant="p1SemiBold" color="grey.900">
                  {to}:
                </Typography>
              </Grid>
              <Grid item>
                <Box
                  ml={{ xs: 1, sm: 4 }}
                  display="flex"
                  justifyContent="flex-end"
                >
                  <img
                    src={image}
                    alt="support manager"
                    style={{
                      borderRadius: '50%',
                      width: '24px',
                      height: '24px',
                    }}
                  />
                </Box>
              </Grid>
              <Grid item>
                <Typography variant="p1SemiBold" color="grey.900">
                  Alan B.
                </Typography>
              </Grid>
            </Grid>
          </Box>
          <Box mt={{ xs: 0, sm: 2 }}>
            <Grid container spacing={2} alignItems="center" display="flex">
              <Grid item xs={12} sm={1.5} pb={{ xs: 0, sm: 2 }}>
                <Typography variant="p1SemiBold" color="grey.900">
                  {subject}:
                </Typography>
              </Grid>
              <Grid item xs={12} sm={10.5}>
                <CustomSelectBox
                  dataTestid="message-subject"
                  options={Subject}
                  name="subject"
                  error={!!errors.subject}
                  errorText={errors.subject && errors.subject.message}
                  control={control}
                />
              </Grid>
            </Grid>
          </Box>
          <Box>
            <Grid container justifyContent="space-between" direction="row">
              <Typography variant="p1SemiBold" color="grey.900">
                {messageBody}
              </Typography>
              <Typography
                variant="p2"
                style={{
                  color: '#636363',
                  lineHeight: '135%',
                  fontStyle: 'normal',
                }}
              >
                {characters.length}/{charactersLimit}
              </Typography>
            </Grid>
          </Box>
          <Box>
            <CustomInput
              name="messageBody"
              id="messageBody"
              dataTestid="messageBody"
              control={control}
              multiline
              minRows={4}
              inputProps={{
                maxLength: charactersLimit,
              }}
              margin="none"
              error={!!errors.messageBody}
              errorText={errors.messageBody && errors.messageBody.message}
            />
          </Box>
          <Box mt={1}>
            <Grid item xs={12} sm={2.5}>
              <Button
                variant="outlined"
                fullWidth
                className={classes.attachFileBtn}

                // onClick={openSendMessage}
              >
                {attachFile}
                <CustomIcon
                  aria-label="add-file"
                  component={Plus}
                  color="grey.500"
                  inheritViewBox
                  className={HCClasses.sendMsgCustomIcon}
                />
              </Button>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item xs={4} sm={6}>
              <Button
                variant="contained"
                size="OnbCtnBtn"
                sx={{ minWidth: { xs: '80px', sm: '99px' } }}
                onClick={openSendMessage}
              >
                {cancel}
              </Button>
            </Grid>
            <Grid item xs={8} sm={6}>
              <Box display="flex" justifyContent="flex-end">
                <Button
                  variant="contained"
                  color="primary"
                  sx={{ minWidth: { xs: '80px', sm: '99px' } }}
                  type="submit"
                >
                  {send}
                </Button>
              </Box>
            </Grid>
          </Grid>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default SendMessage;

SendMessage.propTypes = {
  openSendMessage: PropTypes.func,
  hendleLogSubmit: PropTypes.func,
};
SendMessage.defaultProps = {
  openSendMessage: defaultFnPropTypes,
  hendleLogSubmit: defaultFnPropTypes,
};
