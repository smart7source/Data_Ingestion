import { Typography, Button } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

const TimeButton = ({
  item,
  handleClick,
  selected,
  selectedIndex,
  selectedTime,
}) => (
  <>
    <Button
      data-testid="slider-button-time"
      variant="outlined"
      disabled={selectedIndex === ''}
      className={classes.appointmentBtn}
      style={{
        backgroundColor: selected && selectedTime ? '#f8e8fd' : '',
        border: selected && selectedTime ? '1px solid #a120d1' : '',
      }}
      onClick={handleClick}
    >
      <Typography variant="p1SemiBold">{item.toLowerCase()}</Typography>
    </Button>
  </>
);

export default TimeButton;

TimeButton.propTypes = {
  selectedIndex: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  item: PropTypes.string,
  handleClick: PropTypes.func,
  selected: PropTypes.bool,
  selectedTime: PropTypes.string,
};
TimeButton.defaultProps = {
  selectedIndex: '',
  item: '',
  handleClick: defaultFnPropTypes,
  selected: false,
  selectedTime: '',
};
