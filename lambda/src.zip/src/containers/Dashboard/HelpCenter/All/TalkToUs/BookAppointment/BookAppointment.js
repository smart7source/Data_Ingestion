import { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Button,
  Dialog,
  DialogContent,
  IconButton,
  Typography,
  DialogTitle,
  DialogActions,
} from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { bookAppointmentSchema } from 'helpers/ValidationSchema';
import { bookAppointmentModal } from 'store/actions';
import classes from 'style/globalStyle.module.scss';
import { CustomInput, CustomSelectBox } from 'components';
import strings from 'localization/translation';
import { defaultFnPropTypes } from 'utils';
import { typeOfAppointment } from 'containers/Settings/components/SettingsUserData';

import DisplayTime from './components/DisplayTime';
import DateCarousel from './components/DateCarousel';
import TimeCarousel from './components/TimeCarousel';

const {
  bookAnAppointment,
  bookAppointmentSubtitle,
  selectTimeSlot,
  letUsKnow,
  cancel,
  book,
  RescheduleApp,
} = strings;

const BookAppointment = ({ hendleSubmit, selectedData }) => {
  const {
    control,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(bookAppointmentSchema),
  });
  const [dateTime, setDateTime] = useState([]);
  const [selectedDay, setSelectedDay] = useState('');
  const [selectedTime, setSelectTime] = useState('');
  const [selectedIndex, setSelectedIndex] = useState('');
  const settings = useSelector((state) => state.settings.bookAppointmentModal);
  const dispatch = useDispatch();
  const charactersLimit = 250;
  const characters = watch('appointmentReason') || '';
  const displayDay = selectedDay || '';
  const displayTime = selectedTime || '';

  const handleChangeDay = (itemDate, index) => {
    setSelectedDay(itemDate);
    setSelectedIndex(index);
    setSelectTime('');
  };

  const handleChangeTime = (newTime) => {
    setSelectTime(newTime);
  };

  const closeModal = () => {
    dispatch(bookAppointmentModal(false));
    setSelectedDay('');
    reset();
    setSelectedIndex('');
  };

  const submitHandler = (data) => {
    hendleSubmit(data, selectedDay, selectedTime);
    dispatch(bookAppointmentModal(false));
    reset();
    setSelectedDay('');
  };

  let buttonDisabled;
  if (!displayTime || !displayDay) {
    buttonDisabled = true;
  }

  useEffect(() => {
    const fetchDateTimeSlots = async () => {
      try {
        // getting a date from the backend, the method is POST.
        // Backend team still working on it. it should be the GET method.
        const response = await ApiClient.get(serviceUrl.getDateTimeSlots);
        setDateTime(response?.responseBody?.dates || []);
      } catch (err) {
        console.log('error', err);
      }
    };
    fetchDateTimeSlots();
  }, []);

  return (
    <Dialog
      aria-labelledby="customized-dialog-title"
      data-testid="customized-dialog-title"
      open={settings}
      PaperProps={{
        sx: {
          maxWidth: 730,
        },
      }}
    >
      <form onSubmit={handleSubmit(submitHandler)}>
        <DialogTitle>
          <Grid container justifyContent="space-between">
            <Grid item xs={11} mt={2}>
              <Typography variant="h1" color="grey.900">
                {selectedData.isOpen ? RescheduleApp : bookAnAppointment}
              </Typography>
            </Grid>
            <Grid item xs={1}>
              <Typography>
                <IconButton
                  aria-label="Close"
                  className={HCClasses.sendMessageIcon}
                  onClick={() => closeModal()}
                >
                  <Close
                    fill="grey.800"
                    style={{
                      width: '10px',
                      height: '10px',
                    }}
                  />
                </IconButton>
              </Typography>
            </Grid>
          </Grid>
        </DialogTitle>
        <DialogContent>
          <Typography variant="p1" color="grey.800">
            {bookAppointmentSubtitle}
          </Typography>
          <Box mt={2}>
            <Grid container>
              <Grid item xs={5}>
                <CustomSelectBox
                  label="Type of appointment"
                  options={typeOfAppointment}
                  name="typeOfAppointment"
                  error={!!errors.typeOfAppointment}
                  errorText={
                    errors.typeOfAppointment && errors.typeOfAppointment.message
                  }
                  control={control}
                />
              </Grid>
            </Grid>
          </Box>
          <Box>
            <Typography mb={1} variant="h3">
              {selectTimeSlot}
            </Typography>
          </Box>
          <DateCarousel handleChangeDay={handleChangeDay} dateTime={dateTime} />
          <Box mt={2} mx={3} maxWidth>
            <TimeCarousel
              handleChangeTime={handleChangeTime}
              selectedIndex={selectedIndex}
              selectedTime={selectedTime}
              dateTime={dateTime}
            />
          </Box>
          <Box mt={4} mb={1}>
            <Grid container justifyContent="space-between" direction="row">
              <Typography variant="h3" color="grey.800">
                {letUsKnow}
              </Typography>
              <Typography variant="p2SemiBold" style={{ color: '#888888' }}>
                {characters.length}/{charactersLimit}
              </Typography>
            </Grid>
          </Box>
          <Box>
            <CustomInput
              name="appointmentReason"
              id="appointmentReason"
              dataTestid="appointmentReason"
              control={control}
              multiline
              minRows={3}
              inputProps={{
                maxLength: charactersLimit,
              }}
              margin="none"
              error={!!errors.appointmentReason}
              errorText={
                errors.appointmentReason && errors.appointmentReason.message
              }
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Grid container spacing={2} justifyContent="space-between">
            <Grid item xs={3}>
              <Button
                variant="contained"
                size="OnbCtnBtn"
                onClick={() => closeModal()}
              >
                {cancel}
              </Button>
            </Grid>
            <Grid item xs={9}>
              <Grid container justifyContent="flex-end">
                <Grid item>
                  <DisplayTime
                    selectedData={selectedData}
                    displayDay={displayDay}
                    selectedDay={selectedDay}
                    displayTime={displayTime}
                    selectedTime={selectedTime}
                  />
                </Grid>
                <Grid item>
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    className={classes.saveButton}
                    disabled={buttonDisabled}
                  >
                    {book}
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default BookAppointment;

BookAppointment.propTypes = {
  hendleSubmit: PropTypes.func,
  selectedData: PropTypes.instanceOf(Object),
};
BookAppointment.defaultProps = {
  hendleSubmit: defaultFnPropTypes,
  selectedData: { isOpen: false },
};
