import { useState } from 'react';
import { Grid, IconButton } from '@mui/material';
import PropTypes from 'prop-types';
import 'testHelpers/matchMedia';
import Slider from 'react-slick';

import CustomIcon from 'components/UIElements/CustomIcon';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as ChevronRight } from 'assets/svg/chevron-right.svg';
import { ReactComponent as ChevronLeft } from 'assets/svg/chevron-left.svg';
import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

import TimeButton from './TimeButton';

const TimeCarousel = ({
  handleChangeTime,
  selectedIndex,
  selectedTime,
  dateTime,
}) => {
  const [background, setBackground] = useState('');

  const ArrowLeft = ({ className, onClick }) => (
    <Grid className={classes.slickPrev}>
      <IconButton
        onClick={onClick}
        disabled={className?.includes('slick-disabled')}
      >
        <CustomIcon
          component={ChevronLeft}
          inheritViewBox
          color="grey.800"
          className={HCClasses.timeCarouselIcon}
        />
      </IconButton>
    </Grid>
  );

  const ArrowRight = ({ className, onClick }) => (
    <Grid className={classes.slickNext}>
      <IconButton
        onClick={onClick}
        disabled={className?.includes('slick-disabled')}
      >
        <CustomIcon
          component={ChevronRight}
          inheritViewBox
          color="grey.800"
          className={HCClasses.timeCarouselIcon}
        />
      </IconButton>
    </Grid>
  );

  const settings = {
    dots: false,
    infinite: false,
    prevArrow: <ArrowLeft />,
    nextArrow: <ArrowRight />,
    speed: 300,
    slidesToShow: 6,
    slidesToScroll: 1,
    swipe: selectedIndex !== '',
    arrows: selectedIndex !== '',
  };

  const handleClick = (itemValue, index) => {
    setBackground(index);
    handleChangeTime(itemValue);
  };
  return (
    <>
      <Slider {...settings}>
        {dateTime[selectedIndex || 0]?.timeSlot.map((item, index) => (
          <TimeButton
            selectedIndex={selectedIndex}
            selectedTime={selectedTime}
            key={index}
            item={item}
            handleClick={() => {
              handleClick(item, index);
            }}
            selected={background === index}
          />
        ))}
      </Slider>
    </>
  );
};

export default TimeCarousel;

TimeCarousel.propTypes = {
  handleChangeTime: PropTypes.func,
  selectedIndex: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  className: PropTypes.instanceOf(Object),
  onClick: PropTypes.func,
  selectedTime: PropTypes.string,
  dateTime: PropTypes.instanceOf(Array),
};
TimeCarousel.defaultProps = {
  selectedIndex: '',
  handleChangeTime: defaultFnPropTypes,
  className: {},
  onClick: defaultFnPropTypes,
  selectedTime: '',
  dateTime: [],
};
