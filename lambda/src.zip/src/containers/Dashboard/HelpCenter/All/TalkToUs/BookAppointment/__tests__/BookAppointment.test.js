import {
  render,
  screen,
  act,
  fireEvent,
  waitFor,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Auth } from 'aws-amplify';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';
import ApiClient from 'api/ApiClient';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

jest.mock('api/ApiClient');

describe('Test Book Appointment modal', () => {
  beforeAll(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    ApiClient.post = jest.fn().mockResolvedValue();
  });

  afterAll(() => {
    ApiClient.get.mockClear();
  });

  it('should render Help Center page', async () => {
    renderWithProviderAndRouter(<App />, {
      route: routePath.HELP_CENTER,
      render,
    });
    await act(() => promiseResolveCurrentUser);
    expect(screen.getByText('Your relationship manager')).toBeInTheDocument();
  });

  it('should display Book an appointment button', () => {
    const button = screen.getByRole('button', { name: 'Book an appointment' });
    expect(button).toBeInTheDocument();
  });

  it('should render Book an Appointment modal ', async () => {
    const button = screen.getByTestId('book-appointment');
    userEvent.click(button);

    expect(
      screen.getByRole('heading', { name: 'Book an appointment' }),
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /All of our appointments are booked in 30-minute slots. But don't worry, we can take more or less time, depending on your situation./i,
      ),
    ).toBeInTheDocument();
    expect(screen.getByText(/Select available time slot/i)).toBeInTheDocument();
    expect(
      screen.getByText(/Let us know the reason for your appointment/i),
    ).toBeInTheDocument();
  });

  it('should render buttons Cancel & Book - Book an Appointment modal ', async () => {
    const button = screen.getByTestId('book-appointment');
    userEvent.click(button);

    const buttonCancel = screen.getByRole('button', { name: 'Cancel' });
    expect(buttonCancel).toBeInTheDocument();
    expect(buttonCancel).toBeEnabled();
    const buttonBook = screen.getByRole('button', { name: 'Book' });
    expect(buttonBook).toBeInTheDocument();
    expect(buttonBook).toBeDisabled();
  });

  it('should submit form - Book an Appointment modal', async () => {
    const button = screen.getByTestId('book-appointment');
    userEvent.click(button);
    //TODO do not remove
    const buttonDay = screen.queryAllByTestId('slider-button-day');
    // await act(async () => {
    //     fireEvent.click(buttonDay[0]);
    //   });
    // userEvent.click(buttonDay[0]);
    // expect(buttonDay[0]).toHaveValue('Feb 07, 2022'); // TODO used this after confection with API
    // const buttonTime = screen.getAllByTestId('slider-button-time');
    // userEvent.click(buttonTime[0]);
    // const sliderButton = screen.queryByText('9:30 am')
    // expect(sliderButton).toBeInTheDocument()
    await act(async () => {
      const textField = screen.getByTestId('appointmentReason');
      fireEvent.change(textField, {
        target: { value: 'Test' },
      });
    });
    const buttonBook = screen.getByRole('button', { name: 'Book' });
    expect(buttonBook).toBeInTheDocument();
    // expect(buttonBook).toBeEnabled();
    // await act(async () => {
    //   fireEvent.click(buttonBook);
    // });
  });

  it('button `x` should close modal - Book an Appointment modal', async () => {
    const button = screen.getByTestId('book-appointment');
    userEvent.click(button);

    const buttonClose = screen.getByLabelText('Close');
    expect(buttonClose).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(buttonClose);
    });
    waitFor(() =>
      expect(screen.getByText('Your relationship manager')).toBeInTheDocument(),
    );
  });

  it('button Cancel should close modal - Book an Appointment modal ', async () => {
    const button = screen.getByTestId('book-appointment');
    userEvent.click(button);

    const buttonClose = screen.getByRole('button', { name: 'Cancel' });
    await act(async () => {
      fireEvent.click(buttonClose);
    });
    waitFor(() =>
      expect(screen.getByText('Your relationship manager')).toBeInTheDocument(),
    );
  });
});
