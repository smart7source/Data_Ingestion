import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Grid,
  IconButton,
  Button,
  Box,
} from '@mui/material';
import PropTypes from 'prop-types';

import { ReactComponent as Close } from 'assets/svg/close.svg';
import strings from 'localization/translation';
import image from 'assets/image.svg';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

const {
  cancelYourAppointment,
  relationshipManager,
  dateTime,
  cancelAppointment: cancelApp,
  typeOfAppointment,
  description,
  goBack,
  typeOf,
  appointment,
} = strings;
const CancelAppointment = ({
  openCancelModal,
  selectedData,
  setSelectedData,
}) => {
  const cancelAppointment = () => {
    const newData = {
      appointmentReason: '',
      date: '',
      isOpen: false,
      time: '',
      typeOfAppointment: '',
    };
    setSelectedData(newData);
  };

  return (
    <Dialog
      aria-labelledby="cancel-appointment-modal"
      open
      PaperProps={{
        sx: {
          maxWidth: 650,
        },
      }}
    >
      <DialogTitle>
        <Grid item xs={10}>
          <Typography variant="h1">{cancelYourAppointment}</Typography>
        </Grid>
        <IconButton
          aria-label="close"
          sx={{
            position: 'absolute',
            right: { xs: 20, sm: 24 },
            top: { xs: 20, sm: 32 },
          }}
          onClick={openCancelModal}
        >
          <Close
            fill="grey.800"
            style={{
              width: '10px',
              height: '10px',
            }}
          />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Box className={classes.boxGray}>
          <Grid>
            <Grid container spacing={{ xs: 1, sm: 2 }} justifyContent="center">
              <Grid item xs={3} sm={4}>
                <Box
                  ml={{ xs: 4, ml: 0 }}
                  display="flex"
                  justifyContent="flex-end"
                >
                  <img
                    src={image}
                    alt="support manager"
                    style={{
                      borderRadius: '50%',
                    }}
                  />
                </Box>
              </Grid>
              <Grid item xs={9} sm={8}>
                <Box ml={{ xs: 2, sm: 0 }}>
                  <Grid>
                    <Typography variant="p1SemiBold" color="grey.1100">
                      Alan B.
                    </Typography>
                  </Grid>
                  <Grid>
                    <Typography variant="p2" color="darkGray.700">
                      {relationshipManager}
                    </Typography>
                  </Grid>
                </Box>
              </Grid>
            </Grid>
            <Grid container spacing={1} mt={2}>
              <Grid item xs={5} sm={4}>
                <Box mt={1} display="flex" justifyContent="flex-end">
                  <Typography variant="p1" color="grey.600" align="left">
                    {dateTime}
                  </Typography>
                </Box>
                <Box
                  mt={1}
                  justifyContent="flex-end"
                  display={{ xs: 'none', sm: 'flex' }}
                >
                  <Typography variant="p1" color="grey.600">
                    {typeOfAppointment}
                  </Typography>
                </Box>
                <Box
                  mt={1}
                  justifyContent="flex-end"
                  display={{ xs: 'flex', sm: 'none' }}
                  flexWrap="wrap"
                >
                  <Typography variant="p1" color="grey.600">
                    {typeOf}
                  </Typography>
                  <Typography variant="p1" color="grey.600">
                    {appointment}
                  </Typography>
                </Box>
                <Box mt={1} display="flex" justifyContent="flex-end">
                  <Typography variant="p1" color="grey.600">
                    {description}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={7} sm={8}>
                <Box mt={1} display="flex" justifyContent="flex-start">
                  <Typography variant="p1SemiBold" color="grey.900">
                    {selectedData.date} at {selectedData.time.toLowerCase()}
                  </Typography>
                </Box>
                <Box
                  mt={{ xs: 1, sm: 1 }}
                  display="flex"
                  justifyContent="flex-start"
                >
                  <Typography variant="p1SemiBold" color="grey.900">
                    {selectedData.typeOfAppointment}
                  </Typography>
                </Box>
                <Box
                  mt={{ xs: 3, sm: 1 }}
                  display="flex"
                  justifyContent="flex-start"
                >
                  <Typography variant="p1SemiBold" color="grey.900">
                    {selectedData.appointmentReason}
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions>
        <Grid container justifyContent="space-between">
          <Grid item xs={4} sm={6}>
            <Button
              variant="contained"
              sx={{ minWidth: '71px', display: { xs: 'block', sm: 'none' } }}
              onClick={openCancelModal}
            >
              {goBack}
            </Button>
          </Grid>
          <Grid item xs={8} sm={6}>
            <Box display="flex" justifyContent="flex-end">
              <Button
                type="submit"
                variant="contained"
                color="primary"
                sx={{ minWidth: '167px' }}
                onClick={() => {
                  cancelAppointment();
                  openCancelModal();
                }}
              >
                {cancelApp}
              </Button>
            </Box>
          </Grid>
        </Grid>
      </DialogActions>
    </Dialog>
  );
};

export default CancelAppointment;

CancelAppointment.propTypes = {
  openCancelModal: PropTypes.func,
  selectedData: PropTypes.instanceOf(Object),
  setSelectedData: PropTypes.func,
};
CancelAppointment.defaultProps = {
  openCancelModal: defaultFnPropTypes,
  selectedData: {},
  setSelectedData: defaultFnPropTypes,
};
