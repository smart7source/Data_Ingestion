import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Grid,
  IconButton,
  Button,
  Box,
} from '@mui/material';
import PropTypes from 'prop-types';

import { ReactComponent as Close } from 'assets/svg/close.svg';
import strings from 'localization/translation';
import image from 'assets/image.svg';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import classes from 'style/globalStyle.module.scss';
import { defaultFnPropTypes } from 'utils';

const {
  yourAppointmentScheduled,
  relationshipManager,
  ok,
  dateTime,
  typeOfAppointment,
  description,
  typeOf,
  appointment,
} = strings;
const ConfirmedAppointment = ({ openConfirmedModal, selectedData }) => (
  <Dialog
    aria-labelledby="success-appointment-modal"
    open
    PaperProps={{
      sx: {
        minWidth: { sm: 650 },
      },
    }}
  >
    <DialogTitle>
      <Grid container>
        <Grid item xs={11}>
          <Typography variant="h1">{yourAppointmentScheduled}</Typography>
        </Grid>
        <Grid item xs={1}>
          <IconButton
            aria-label="close"
            className={HCClasses.sendMessageIcon}
            onClick={openConfirmedModal}
          >
            <Close
              fill="grey.800"
              style={{
                width: '10px',
                height: '10px',
              }}
            />
          </IconButton>
        </Grid>
      </Grid>
    </DialogTitle>
    <DialogContent>
      <Box className={classes.boxGray}>
        <Grid>
          <Grid container spacing={{ xs: 1, sm: 2 }} justifyContent="center">
            <Grid item xs={3} sm={4}>
              <Box
                ml={{ xs: 4, ml: 0 }}
                display="flex"
                justifyContent="flex-end"
              >
                <img
                  src={image}
                  alt="support manager"
                  style={{
                    borderRadius: '50%',
                  }}
                />
              </Box>
            </Grid>
            <Grid item xs={9} sm={8}>
              <Box ml={{ xs: 2, sm: 0 }}>
                <Grid>
                  <Typography variant="p1SemiBold" color="grey.1100">
                    Alan B.
                  </Typography>
                </Grid>
                <Grid>
                  <Typography variant="p2" color="darkGray.700">
                    {relationshipManager}
                  </Typography>
                </Grid>
              </Box>
            </Grid>
          </Grid>
          <Grid container spacing={1} mt={2}>
            <Grid item xs={5} sm={4}>
              <Box mt={1} display="flex" justifyContent="flex-end">
                <Typography variant="p1" color="grey.600" align="left">
                  {dateTime}
                </Typography>
              </Box>
              <Box
                mt={1}
                justifyContent="flex-end"
                display={{ xs: 'none', sm: 'flex' }}
              >
                <Typography variant="p1" color="grey.600">
                  {typeOfAppointment}
                </Typography>
              </Box>
              <Box
                mt={1}
                justifyContent="flex-end"
                display={{ xs: 'flex', sm: 'none' }}
                flexWrap="wrap"
              >
                <Typography variant="p1" color="grey.600">
                  {typeOf}
                </Typography>
                <Typography variant="p1" color="grey.600">
                  {appointment}
                </Typography>
              </Box>
              <Box mt={1} display="flex" justifyContent="flex-end">
                <Typography variant="p1" color="grey.600">
                  {description}
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={7} sm={8}>
              <Box mt={1} display="flex" justifyContent="flex-start">
                <Typography variant="p1SemiBold" color="grey.900">
                  {selectedData.date} at {selectedData.time}
                  {/* {selectedData.date} at {selectedData.time.toLowerCase()} */}
                </Typography>
              </Box>
              <Box
                mt={{ xs: 1, sm: 1 }}
                display="flex"
                justifyContent="flex-start"
              >
                <Typography variant="p1SemiBold" color="grey.900">
                  {selectedData.typeOfAppointment}
                </Typography>
              </Box>
              <Box
                mt={{ xs: 3, sm: 1 }}
                display="flex"
                justifyContent="flex-start"
              >
                <Typography variant="p1SemiBold" color="grey.900">
                  {selectedData.appointmentReason}
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Box>
    </DialogContent>
    <DialogActions>
      <Grid container justifyContent="space-between">
        <Grid item xs={0} sm={6}>
          {/*
          // TODO 
          <Button
            variant="contained"
            sx={{ minWidth: '128px', display: { xs: 'block', sm: 'none' } }}
            onClick={openConfirmedModal}
          >
            Add to Calendar
          </Button> */}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Box display="flex" justifyContent={{ xs: 'center', sm: 'flex-end' }}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              sx={{ minWidth: { sm: '73px', xs: '238px' } }}
              onClick={openConfirmedModal}
            >
              {ok}
            </Button>
          </Box>
        </Grid>
      </Grid>
    </DialogActions>
  </Dialog>
);

export default ConfirmedAppointment;

ConfirmedAppointment.propTypes = {
  openConfirmedModal: PropTypes.func,
  selectedData: PropTypes.instanceOf(Object),
};
ConfirmedAppointment.defaultProps = {
  openConfirmedModal: defaultFnPropTypes,
  selectedData: {},
};
