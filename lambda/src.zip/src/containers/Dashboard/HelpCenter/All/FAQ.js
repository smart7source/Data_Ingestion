import { useCallback } from 'react';
import { Box, Typography, Grid, Paper } from '@mui/material';
import PropTypes from 'prop-types';
import Link from '@mui/material/Link';
import { useDispatch } from 'react-redux';

import classes from 'style/globalStyle.module.scss';
import { updateActiveHelpDeskTab, updateActiveFaqs } from 'store/actions';

import { categoryPropType } from '../Config';

const FAQ = ({ faqCategories }) => {
  const dispatch = useDispatch();
  const handleFaqLink = useCallback((category) => {
    dispatch(updateActiveHelpDeskTab(1));
    dispatch(updateActiveFaqs(category?.id));
  }, []);
  return (
    <>
      <Grid container>
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <Paper
            elevation={2}
            style={{ height: '578px', position: 'relative' }}
          >
            <Box m={1}>
              <Grid className={classes.gridPadding}>
                <Typography variant="h2" color="grey.1100">
                  FAQs
                </Typography>
                {faqCategories?.map((category) => (
                  <Box
                    key={category.id}
                    mt={3}
                    className={classes.faqPanelBox}
                    onClick={() => handleFaqLink(category)}
                  >
                    <Link underline="hover">
                      <Typography
                        className={classes.faqLink}
                        variant="h3"
                        color="grey.800"
                      >
                        {category.name}
                      </Typography>
                    </Link>
                  </Box>
                ))}
                <Box
                  mt={2}
                  color="primary"
                  onClick={() => handleFaqLink(faqCategories?.[0])}
                  style={{ cursor: 'pointer' }}
                >
                  <Typography variant="p2SemiBold">
                    <Link underline="hover">View all</Link>
                  </Typography>
                </Box>
              </Grid>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </>
  );
};

export default FAQ;

FAQ.propTypes = {
  faqCategories: PropTypes.arrayOf(PropTypes.shape(categoryPropType)),
};
FAQ.defaultProps = {
  faqCategories: [],
};
