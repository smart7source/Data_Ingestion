import { useEffect, useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Paper, Box } from '@mui/material';
import PropTypes from 'prop-types';

import { sendChatbotMessage, addUserMessage } from 'store/actions';

import ChatBot from './ChatBot/ChatBot';

const ChatBotMain = (props) => {
  const state = useSelector((store) => store.helpCenter.chatbot);
  const dispatch = useDispatch();
  const [timeoutId, setTimeoutId] = useState(null);
  const sendToLex = useCallback(
    async (message) => dispatch(sendChatbotMessage(message)),
    [dispatch],
  );

  useEffect(() => {
    if (!state.messages.length && !state.isLoading) {
      sendToLex('hi');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startTimer = useCallback(() => {
    const id = setTimeout(() => {
      sendToLex('stoplexrequest');
    }, 900000);
    setTimeoutId(id);
  }, [sendToLex]);

  const handleNewUserMessage = (newMessage, ownMessage) => {
    if (timeoutId) {
      clearTimeout(timeoutId);
      setTimeoutId(null);
    }
    const userMessage = {
      message: [{ content: newMessage.text, contentType: 'PlainText' }],
      isOwn: ownMessage,
      messageDate: new Date(),
    };
    dispatch(addUserMessage(userMessage));
    sendToLex(newMessage.value);
  };

  return (
    <>
      <Box mt={1}>
        <Paper elevation={2} className="chatbotWrapper">
          <ChatBot
            messages={state.messages}
            handleMessage={handleNewUserMessage}
            showSpinner={state.isLoading}
            startTimer={startTimer}
            {...props}
          />
        </Paper>
      </Box>
    </>
  );
};

export default ChatBotMain;

ChatBotMain.propTypes = {
  headerProps: PropTypes.shape({}),
};

ChatBotMain.defaultProps = {
  headerProps: {},
};
