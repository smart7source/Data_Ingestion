import moment from 'moment';
import { Box, Grid, IconButton, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import { ReactComponent as Close } from 'assets/svg/close.svg';
import { ReactComponent as DiagonalArrowRightUp } from 'assets/svg/diagonal-arrow-right-up.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import strings from 'localization/translation';

const { ello, virtualAssistant } = strings;

const ChatBotHeader = ({
  isExpandCollapseDisabled,
  onExpandCollapseClick,
  isExpanded,
}) => (
  <Grid
    className="chatbotHeaderWrapper"
    container
    justifyContent="space-between"
    alignItems="center"
  >
    <Grid item>
      <Box>
        <Typography variant="p1SemiBold">{ello}</Typography> |
        <Typography variant="p3" ml={1}>
          {virtualAssistant}
        </Typography>
      </Box>
    </Grid>
    <Grid item>
      <Grid container alignItems="center">
        <Grid item>
          <Box component="span" mr={1}>
            <Typography variant="p3">
              {moment().format('dddd, MMMM DD, YYYY')}
            </Typography>
          </Box>
          |
        </Grid>
        <Grid item>
          <IconButton
            aria-label="open-new"
            data-testid="open-new"
            size="small"
            disabled={!!isExpandCollapseDisabled}
            onClick={() => onExpandCollapseClick?.()}
            className="chatbotMaximizeScreenBtn"
          >
            {isExpanded ? (
              <CustomIcon
                component={Close}
                color="grey.800"
                inheritViewBox
                style={{ fontSize: '0.75em' }}
              />
            ) : (
              <CustomIcon
                component={DiagonalArrowRightUp}
                color="grey.800"
                inheritViewBox
                style={{ fontSize: '0.75em' }}
              />
            )}
          </IconButton>
        </Grid>
      </Grid>
    </Grid>
  </Grid>
);

export default ChatBotHeader;

ChatBotHeader.propTypes = {
  isExpandCollapseDisabled: PropTypes.bool,
  onExpandCollapseClick: PropTypes.func,
  isExpanded: PropTypes.bool,
};

ChatBotHeader.defaultProps = {
  isExpandCollapseDisabled: true,
  onExpandCollapseClick: () => null,
  isExpanded: false,
};
