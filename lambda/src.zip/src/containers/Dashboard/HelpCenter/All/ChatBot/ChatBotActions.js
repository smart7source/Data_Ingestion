import { useState } from 'react';
import {
  Box,
  Button,
  Grid,
  TextField,
  InputAdornment,
  IconButton,
  Typography,
  // Popover,
} from '@mui/material';
// import { Picker } from 'emoji-mart';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';

import { ReactComponent as Mic } from 'assets/svg/mic.svg';
import strings from 'localization/translation';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as GrinningFace } from 'assets/svg/grinning-face-emoji.svg';
import { ReactComponent as AttachFile } from 'assets/svg/attach-2.svg';
import { ReactComponent as AttachImage } from 'assets/svg/image.svg';

const ChatBotActions = ({ handleMessage, messages }) => {
  const [message, setMessage] = useState('');
  // const [anchorEl, setAnchorEl] = useState(null);

  const enableFloatingChatbot = useSelector(
    (state) => state.global.enableFloatingChatbot,
  );
  const handleChange = (e) => {
    if (e) {
      setMessage(e.target.value);
      localStorage.setItem('textContent', e.target.value);
    }
  };
  const handleSendMessage = () => {
    localStorage.removeItem('textContent');
    if (message !== '') {
      handleMessage({ text: message, value: message }, true);
      setMessage('');
    }
  };
  // TODO: fix this eslint disable comment
  // eslint-disable-next-line consistent-return
  const handleKeyDown = (event) => {
    if (event.keyCode === 13) {
      event.preventDefault();
      handleSendMessage();
    }
    return false;
  };

  //   const emojiHandleClick = (event) => {
  //     setAnchorEl(event.currentTarget);
  //   };

  //   const emojiHandleClose = () => {
  //     setAnchorEl(null);
  //   };

  //   const addEmoji = (e) => {
  //     const sym = e.unified.split('-');
  //     const codesArray = [];
  //     sym.forEach((el) => codesArray.push(`0x${el}`));
  //     const emoji = String.fromCodePoint(...codesArray);
  //     setMessage((msg) => msg + emoji);
  //     emojiHandleClose();
  //   };

  //  // const emojiOpen = Boolean(anchorEl);
  return (
    <Box className={HCClasses.chatBotActionBox}>
      <Grid
        container
        alignItems="center"
        className="chatBotActionsGridContainer"
      >
        <Grid item xs="auto" className={`chatBotActionsGridItem `}>
          <IconButton disabled aria-label="attach-image">
            <CustomIcon
              component={AttachImage}
              inheritViewBox
              color="grey.500"
              className={HCClasses.customIconfont}
            />
          </IconButton>
          <IconButton disabled aria-label="attach-file">
            <CustomIcon
              component={AttachFile}
              inheritViewBox
              color="grey.500"
              className={HCClasses.customIconfont}
            />
          </IconButton>
          <IconButton
            aria-label="attach-emoji"
            size="small"
            disabled
            // onClick={emojiHandleClick}
          >
            <CustomIcon
              component={GrinningFace}
              inheritViewBox
              color="grey.500"
              style={{ fontSize: '18px' }}
            />
          </IconButton>
          {/* <Popover
            open={!!anchorEl}
            anchorEl={anchorEl}
            disabled
            onClose={emojiHandleClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'left',
            }}
          >
            <Picker
              onSelect={addEmoji}
              title="Pick your emoji…"
              emoji="point_up"
            />
          </Popover> */}
        </Grid>
        {enableFloatingChatbot ? (
          <Grid
            item
            xs="auto"
            sm={7.6}
            className="chatBotActionsGridItem chatBotActionsFlex"
          >
            <TextField
              placeholder="How can we help?"
              size="small"
              fullWidth
              maxRows={1}
              id="messageText"
              name="messageText"
              value={message}
              onChange={handleChange}
              onKeyDown={handleKeyDown}
              InputProps={{
                className: 'chatBotMessageEditor',
                'data-testid': 'messageText',
              }}
            />
            <IconButton
              aria-label="mic"
              size="small"
              disabled
              className="chatbotMicIcon"
            >
              <CustomIcon component={Mic} color="grey.500" inheritViewBox />
            </IconButton>
          </Grid>
        ) : (
          <Grid item xs style={{ padding: '0px 10px 0px 10px' }}>
            <TextField
              variant="outlined"
              sx={{ py: 'unset' }}
              placeholder="How can we help?"
              fullWidth
              maxRows={1}
              size="small"
              id="messageText"
              name="messageText"
              value={message}
              onChange={handleChange}
              onKeyDown={handleKeyDown}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="mic"
                      size="small"
                      disabled
                      className="chatbotMicIcon"
                    >
                      <CustomIcon
                        component={Mic}
                        color="grey.500"
                        inheritViewBox
                      />
                    </IconButton>
                  </InputAdornment>
                ),
                className: 'chatBotMessageEditor',
                'data-testid': 'messageText',
              }}
            />
          </Grid>
        )}
        <Grid item xs="auto" className={`chatBotActionsGridItem `}>
          <Button
            variant="contained"
            color="secondary"
            onClick={handleSendMessage}
            className="chatBotSendActionButton"
            data-testid="chatbot-send-action"
          >
            <Typography component="span" variant="buttonSmall">
              {strings.send}
            </Typography>
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ChatBotActions;

ChatBotActions.propTypes = {
  messages: PropTypes.arrayOf(PropTypes.any),
  handleMessage: PropTypes.func.isRequired,
};

ChatBotActions.defaultProps = {
  messages: [],
};
