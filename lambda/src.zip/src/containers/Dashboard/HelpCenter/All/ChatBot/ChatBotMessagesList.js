import moment from 'moment';
import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import clsx from 'clsx';

import { defaultFnPropTypes } from 'utils';

import MessageFactory, { messageShape } from './MessageFactory';
import Spinner from './Spinner';

const ChatBotMessagesList = ({
  messages,
  handleMessage,
  showSpinner,
  startTimer,
}) => (
  <div id="messageList">
    <Box className="chatbotMessageList">
      <Box className="chatbotMessageGroupWrapper">
        <Box className="chatbotMessageGroup">
          {messages.map((messageData, index) => (
            <div key={index}>
              <div
                className={clsx({
                  chatbotOwnMessageContainer: messageData.isOwn,
                  chatbotBotMessageContainer: !messageData.isOwn,
                })}
              >
                <div>
                  <Typography
                    variant="p3"
                    mb={1}
                    className={clsx({
                      chatbotMessageDate: messageData.isOwn,
                      chatbotMessageDateBot: !messageData.isOwn,
                    })}
                  >
                    {moment(messageData.messageDate).format('LT')}
                  </Typography>

                  <div className="chatbotMessageWrapper">
                    {!messageData.isOwn && (
                      <div className="chatbotMessageBotAvatar">
                        <img
                          src={`${process.env.PUBLIC_URL}/images/Chat-logo.png`}
                          alt="chello chat logo"
                          height="35"
                        />
                      </div>
                    )}
                    <div
                      className={clsx({
                        bubbleOwnContainer: messageData.isOwn,
                        bubbleBotContainer: !messageData.isOwn,
                      })}
                    >
                      {messageData?.message?.map?.((msg, i) => (
                        <MessageFactory
                          key={i}
                          message={msg}
                          handleMessage={handleMessage}
                          isOwn={messageData.isOwn}
                          messageData={messageData.message}
                          sessionAttributes={messageData?.sessionAttributes}
                          messageDate={messageData.messageDate}
                          startTimer={startTimer}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {showSpinner && <Spinner key={messages.length} />}
        </Box>
      </Box>
    </Box>
  </div>
);

export default ChatBotMessagesList;

const messagePropType = PropTypes.shape({
  message: PropTypes.arrayOf(messageShape),
  messageDate: PropTypes.any,
  isOwn: PropTypes.bool,
});

ChatBotMessagesList.propTypes = {
  messages: PropTypes.arrayOf(messagePropType),
  handleMessage: PropTypes.func.isRequired,
  showSpinner: PropTypes.bool,
  startTimer: PropTypes.func,
};

ChatBotMessagesList.defaultProps = {
  messages: [],
  showSpinner: false,
  startTimer: defaultFnPropTypes,
};
