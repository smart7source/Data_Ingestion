import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';

import {
  updateActiveFaqs,
  updateFloatingChatbotVisibility,
  updateActiveHelpDeskTab,
  bookAppointmentModal,
} from 'store/actions';
import { defaultFnPropTypes } from 'utils';

import QuickReplies from './QuickReplies';
import PlainTextMessage from './PlainTextMessage';

const ImageResponseCardTypes = {
  WELCOME: 'WELCOME',
  FAQ: 'FAQ',
  FEEDBACK: 'FEEDBACK',
  FALLBACKACTIONS: 'FALLBACKACTIONS',
  CHATSURVEY: 'ChatSurvey',
};

const FallbackActions = {
  BOOK_AN_APPOINTMENT: 'Book an Appointment',
};

const SEPARATOR = '\u0003';
const MessageFactory = ({
  message,
  handleMessage,
  isOwn,
  messageData,
  sessionAttributes,
  messageDate,
  startTimer,
}) => {
  const dispatch = useDispatch();
  const onButtonSelectHandler = (msg, type, index) => {
    const {
      faqIDs = '',
      maincatIDs = '',
      subcatIDs = '',
    } = sessionAttributes || {};
    const [activeCat, activeSubCat, activeFaq] = [
      maincatIDs,
      subcatIDs,
      faqIDs,
    ].map((x) => x?.split('#')?.map((y) => parseInt(y, 10))?.[index]);
    switch (type) {
      case ImageResponseCardTypes.FAQ:
        handleMessage({ text: msg.text, value: 'Click on FAQ' }, true);
        dispatch(updateActiveFaqs(activeCat, activeSubCat, activeFaq));
        dispatch(updateFloatingChatbotVisibility(true, true));
        dispatch(updateActiveHelpDeskTab(1));
        break;
      case ImageResponseCardTypes.FALLBACKACTIONS:
        if (msg.text === FallbackActions.BOOK_AN_APPOINTMENT) {
          dispatch(bookAppointmentModal(true, 'chatbot'));
        } else {
          handleMessage({ text: msg.text, value: msg.value }, true);
        }
        break;
      case ImageResponseCardTypes.CHATSURVEY:
        handleMessage({ text: msg.text, value: msg.value }, true, true);
        break;
      case ImageResponseCardTypes.WELCOME:
      default:
        handleMessage({ text: msg.text, value: msg.value }, true);
    }
  };
  let type = message.contentType;
  let title;
  if (type === 'ImageResponseCard') {
    [title, type] = message.imageResponseCard.title.split(SEPARATOR);
  }

  switch (message.contentType) {
    case 'PlainText':
      return <PlainTextMessage message={message.content} isOwn={isOwn} />;
    case 'ImageResponseCard':
      return (
        <QuickReplies
          options={message.imageResponseCard.buttons}
          onSelect={onButtonSelectHandler}
          startTimer={startTimer}
          title={title}
          type={type}
        />
      );
    default:
      return <PlainTextMessage message={message.content} isOwn={isOwn} />;
  }
};
export default MessageFactory;

export const messageShape = PropTypes.shape({
  content: PropTypes.string,
  contentType: PropTypes.string,
  imageResponseCard: PropTypes.shape({
    title: PropTypes.string,
    buttons: PropTypes.arrayOf(PropTypes.any),
  }),
});

MessageFactory.propTypes = {
  message: messageShape,
  messageData: PropTypes.arrayOf(messageShape),
  handleMessage: PropTypes.func.isRequired,
  isOwn: PropTypes.bool,
  sessionAttributes: PropTypes.any,
  messageDate: PropTypes.any,
  startTimer: PropTypes.func,
};

MessageFactory.defaultProps = {
  message: {},
  isOwn: false,
  messageData: [],
  sessionAttributes: {},
  messageDate: '',
  startTimer: defaultFnPropTypes,
};
