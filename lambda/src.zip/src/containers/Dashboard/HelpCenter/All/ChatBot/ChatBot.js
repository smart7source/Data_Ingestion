import { useRef, useEffect, useCallback } from 'react';
import { Box, Grid } from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import HCClasses from 'style/HelpCenterStyle.module.scss';

import ChatBotHeader from './ChatBotHeader';
import ChatBotMessagesList from './ChatBotMessagesList';
import ChatBotActions from './ChatBotActions';

import './ChatBot.scss';

import 'emoji-mart/css/emoji-mart.css';

const ChatBot = ({
  messages,
  handleMessage,
  showSpinner,
  headerProps,
  startTimer,
}) => {
  const messagesRef = useRef(null);
  const handleScroll = useCallback((event) => {
    const { currentTarget } = event;
    currentTarget.scroll({
      top: currentTarget.scrollHeight,
      behavior: 'smooth',
    });
  }, []);
  useEffect(() => {
    if (messagesRef.current) {
      messagesRef?.current?.addEventListener?.('DOMNodeInserted', handleScroll);
    }
    return () =>
      // eslint-disable-next-line react-hooks/exhaustive-deps
      messagesRef.current?.removeEventListener?.(
        'DOMNodeInserted',
        handleScroll,
      );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messagesRef.current]);
  return (
    <>
      <Box className="chatbotHeader">
        <ChatBotHeader {...headerProps} />
      </Box>
      <Box className={HCClasses.chatBotBox}>
        <Grid
          container
          wrap="nowrap"
          direction="column"
          className={HCClasses.flex1}
        >
          <Grid
            item
            style={{
              padding: '0 0.5rem 0 0.5rem',
              overflowY: 'auto',
              flex: '1',
            }}
            className="chatbotMessagelistWrapper"
            ref={messagesRef}
          >
            <ChatBotMessagesList
              messages={messages}
              handleMessage={handleMessage}
              showSpinner={showSpinner}
              startTimer={startTimer}
            />
          </Grid>
          <Grid item className={HCClasses.flex0}>
            <ChatBotActions messages={messages} handleMessage={handleMessage} />
          </Grid>
        </Grid>
      </Box>
    </>
  );
};
export default ChatBot;

ChatBot.propTypes = {
  messages: PropTypes.arrayOf(PropTypes.any),
  handleMessage: PropTypes.func.isRequired,
  showSpinner: PropTypes.bool,
  headerProps: PropTypes.shape({}),
  startTimer: PropTypes.func,
};

ChatBot.defaultProps = {
  messages: [],
  showSpinner: false,
  headerProps: {},
  startTimer: defaultFnPropTypes,
};
