import { Typography } from '@mui/material';
import PropTypes from 'prop-types';
import clsx from 'clsx';

const PlainTextMessage = ({ message, isOwn }) => (
  <div
    className={clsx({
      bubbleBotStyle: isOwn,
      bubbleOwnStyle: !isOwn,
    })}
  >
    <Typography variant="p1" className="chatbotMessageText">
      {message}
    </Typography>
  </div>
);

export default PlainTextMessage;

PlainTextMessage.propTypes = {
  message: PropTypes.string.isRequired,
  isOwn: PropTypes.bool,
};

PlainTextMessage.defaultProps = {
  isOwn: false,
};
