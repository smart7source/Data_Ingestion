import { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Typography, Box } from '@mui/material';

import CustomIcon from 'components/UIElements/CustomIcon';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as unhappy } from 'assets/svg/unhappy.svg';
import { ReactComponent as neutral } from 'assets/svg/neutral.svg';
import { ReactComponent as happy } from 'assets/svg/happy.svg';
import { defaultFnPropTypes } from 'utils';

import { ImageResponseCardTypes } from '../../Config';

import PlainTextMessage from './PlainTextMessage';

const SurveyTypes = {
  UNHAPPY: 'Disappointed',
  NEUTRAL: 'Neutral',
  HAPPY: 'Very satisfied',
};

const SurveyIcons = {
  [SurveyTypes.UNHAPPY]: unhappy,
  [SurveyTypes.NEUTRAL]: neutral,
  [SurveyTypes.HAPPY]: happy,
};

const ChatSurvey = ({ options, onSelect, type, startTimer }) => {
  useEffect(() => {
    startTimer();
  }, []);
  return (
    <Box className={HCClasses.quickRepliesBox}>
      {options.map((option, i) => (
        <Box
          key={i}
          m={1}
          className={HCClasses.quickRepliesBox2}
          onClick={() => onSelect(option, type, i)}
          data-testid={`surveyoption-${option.text}`}
        >
          <CustomIcon
            component={SurveyIcons[option.text]}
            inheritViewBox
            color="grey.500"
            className={HCClasses.quickRepliesIcon}
          />
          <Typography mt={1} component="div" variant="p2">
            {option.text}
          </Typography>
        </Box>
      ))}
    </Box>
  );
};

ChatSurvey.propTypes = {
  options: PropTypes.arrayOf(PropTypes.any),
  onSelect: PropTypes.func.isRequired,
  type: PropTypes.string,
  startTimer: PropTypes.func,
};

ChatSurvey.defaultProps = {
  options: [],
  type: '',
  startTimer: defaultFnPropTypes,
};

const QuickReplies = ({ options, onSelect, title, type, startTimer }) => {
  if (type === ImageResponseCardTypes.CHATSURVEY) {
    return (
      <ChatSurvey
        options={options}
        onSelect={onSelect}
        type={type}
        startTimer={startTimer}
      />
    );
  }

  return (
    <>
      {title !== '' && <PlainTextMessage message={title} />}
      <div className="quickReplies" role="listbox">
        {options.map((option, i) => (
          <Button
            aria-label={`${option.text}`}
            key={i}
            onClick={() => onSelect(option, type, i)}
            data-testid={option.text}
            variant="filled"
          >
            <Typography component="span" variant="button">
              {option.text}
            </Typography>
          </Button>
        ))}
      </div>
    </>
  );
};

export default QuickReplies;

QuickReplies.propTypes = {
  options: PropTypes.arrayOf(PropTypes.any),
  onSelect: PropTypes.func.isRequired,
  title: PropTypes.string,
  type: PropTypes.string,
  startTimer: PropTypes.func,
};

QuickReplies.defaultProps = {
  options: [],
  title: '',
  type: '',
  startTimer: defaultFnPropTypes,
};
