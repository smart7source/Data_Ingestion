import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import { Auth } from 'aws-amplify';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';

// import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import { rest } from 'msw';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';
import ChatBotMain from '../../ChatBotMain';
import configureStore from 'store/configureStore';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  mockMatchMediaToDesktop,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { surveyResponse } from 'testHelpers/mocks/helpCenterMocks';

const initialState = {
  helpCenter: {
    chatbot: {
      messages: [],
      isLoading: false,
    },
    faqs: {
      activeCategoryId: null,
      activeSubCategoryId: null,
      activeFaqId: null,
    },
    activeTab: 0,
  },
};
function renderElement() {
  const store = configureStore(initialState);
  return render(
    <Provider store={store}>
      <StyledEngineProvider injectFirst>
        <ThemeProvider theme={theme}>
          <ChatBotMain />
        </ThemeProvider>
      </StyledEngineProvider>
    </Provider>,
  );
}

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('Testing chatbot', () => {
  beforeAll(() => mockMatchMediaToDesktop());
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
  });
  it('should render chatbot content correctly', async () => {
    await act(async () => renderElement());
    expect(screen.getByLabelText(/open-new/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/attach-image/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/attach-file/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/attach-emoji/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Send' })).toBeInTheDocument();
    expect(screen.getByTestId(/messageText/i)).toBeInTheDocument();
    await waitFor(() =>
      expect(
        screen.queryByText('Hi im bot available 24/7'),
      ).toBeInTheDocument(),
    );
  });

  it('should send user message to bot', async () => {
    await act(async () => renderElement());
    const messageEditorInput = screen
      .getByTestId('messageText')
      .querySelector('input');
    const sendButton = screen.getByRole('button', { name: 'Send' });
    await act(async () => {
      fireEvent.change(messageEditorInput, {
        target: { value: 'account number' },
      });
    });
    expect(messageEditorInput.value).toBe('account number');
    await act(async () => fireEvent.click(sendButton));
    expect(messageEditorInput.value).toBe('');
    await waitFor(() =>
      expect(screen.queryByText('account number')).toBeInTheDocument(),
    );
    const Spinner = await screen.queryByTestId('message-spinner');
    await waitFor(() => expect(Spinner).not.toBeInTheDocument());
    await waitFor(() =>
      expect(screen.queryAllByText('Hi im bot available 24/7')).toHaveLength(2),
    );
  });
  it('should send user message on Enter key press', async () => {
    await act(async () => renderElement());
    const messageEditorInput = screen
      .getByTestId('messageText')
      .querySelector('input');
    const sendButton = screen.getByRole('button', { name: 'Send' });
    await act(async () => {
      fireEvent.change(messageEditorInput, {
        target: { value: 'account number' },
      });
    });
    expect(messageEditorInput.value).toBe('account number');
    await act(async () =>
      fireEvent.keyDown(screen.getByTestId('messageText'), {
        key: 'Enter',
        code: 13,
        charCode: '13',
        keyCode: 13,
      }),
    );
    expect(messageEditorInput.value).toBe('');
    await waitFor(() =>
      expect(screen.queryByText('account number')).toBeInTheDocument(),
    );
    await waitFor(() =>
      expect(screen.queryAllByText('Hi im bot available 24/7')).toHaveLength(2),
    );
  });
  it('should not show bot welcome message', async () => {
    server.use(
      rest.post(serviceUrl.lexbotApi, (req, res, ctx) => res(ctx.status(500))),
    );
    await act(async () => renderElement());
    expect(screen.getByLabelText(/open-new/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/attach-image/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/attach-file/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/attach-emoji/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Send' })).toBeInTheDocument();
    expect(screen.getByTestId(/messageText/i)).toBeInTheDocument();
    const Spinner = await screen.queryByTestId('message-spinner');
    await waitFor(() => expect(Spinner).not.toBeInTheDocument());
    await waitFor(() =>
      expect(
        screen.queryByText('Hi im bot available 24/7'),
      ).not.toBeInTheDocument(),
    );
  });
  it('should show quick reply butons to the user', async () => {
    await act(async () => renderElement());
    const Spinner = await screen.queryByTestId('message-spinner');
    await waitFor(() => expect(Spinner).not.toBeInTheDocument());
    await waitFor(() =>
      expect(
        screen.queryByText('Hi im bot available 24/7'),
      ).toBeInTheDocument(),
    );
    const quickReplyButton = screen.getByRole('button', {
      name: 'How do I change my password?',
    });
    await waitFor(() => expect(quickReplyButton).toBeInTheDocument());
    await act(async () => fireEvent.click(quickReplyButton));
    await waitFor(() =>
      expect(
        screen.queryAllByText('How do I change my password?'),
      ).toHaveLength(3),
    );
  });
  it('should show survey options', async ()=>{
    server.use(
      rest.post(serviceUrl.lexbotApi, (req, res, ctx) => res(ctx.json(surveyResponse))),
    );
    await act(async () => renderElement());
    const Spinner = await screen.queryByTestId('message-spinner');
    await waitFor(() => expect(Spinner).not.toBeInTheDocument());
    expect(screen.getByText('Glad we could help.')).toBeInTheDocument();
    const surveyOption = screen.queryByTestId('surveyoption-Happy');
    expect(surveyOption).toBeInTheDocument();
    await act(async () => fireEvent.click(surveyOption));
  });
});
