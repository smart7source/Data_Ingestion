import { useState, useEffect } from 'react';
import { Grid, Typography, Box } from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import { Notification } from 'components';
import strings from 'localization/translation';

import TalkToUs from './All/TalkToUs';
import ServiceTickets from './ServiceTicket/ServiceTickets';
import ChatBotMain from './All/ChatBotMain';
import FAQ from './All/FAQ';
import { categoryPropType } from './Config';

const { msgHasBeenSent } = strings;

const HelpCenter = ({
  faqCategories,
  setSelectedData,
  selectedData,
  rmDetails,
}) => {
  const [messageLogData, setMessageLogData] = useState();
  const [errorMsgs, setErrorMsgs] = useState([]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setErrorMsgs([]);
    }, 3000);
    return () => clearTimeout(timer);
  }, [messageLogData]);

  const hendleLogSubmit = (data) => {
    const newData = {
      ...data,
      isOpen: true,
    };
    setMessageLogData(newData);
    setErrorMsgs([
      {
        severity: 'success',
        message: (
          <Typography variant="p1SemiBold" color="grey.650">
            {msgHasBeenSent} Alan B.
          </Typography>
        ),
      },
    ]);
  };

  return (
    <>
      <Box>
        <Notification errors={errorMsgs} />
      </Box>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} lg={7}>
          <Grid direction="column" container spacing={2}>
            <Grid item xs={12} sm={12} lg={12}>
              <ChatBotMain />
            </Grid>
            <Grid item xs={12} sm={12} lg={12}>
              <ServiceTickets />
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12} sm={12} lg={5}>
          <Grid direction="column" container spacing={1}>
            <Grid item xs={12} md={12} sm={12} lg={12}>
              <TalkToUs
                selectedData={selectedData}
                setSelectedData={setSelectedData}
                hendleLogSubmit={hendleLogSubmit}
                messageLogData={messageLogData}
                rmDetails={rmDetails}
              />
            </Grid>
            <Grid item xs={12} sm={12} md={12} lg={12}>
              <FAQ faqCategories={faqCategories} />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};
export default HelpCenter;

HelpCenter.propTypes = {
  faqCategories: PropTypes.arrayOf(PropTypes.shape(categoryPropType)),
  setSelectedData: PropTypes.func,
  selectedData: PropTypes.any,
  rmDetails: PropTypes.any,
};
HelpCenter.defaultProps = {
  faqCategories: [],
  setSelectedData: defaultFnPropTypes,
  selectedData: {},
  rmDetails: {},
};
