import PropTypes from 'prop-types';
import moment from 'moment';

import { ReactComponent as infoIcon } from 'assets/svg/info.svg';
import { ReactComponent as person } from 'assets/svg/person.svg';
import { ReactComponent as arrowRight } from 'assets/svg/arrowhead-right.svg';
import { ReactComponent as layers } from 'assets/svg/layers.svg';
import { ReactComponent as home } from 'assets/svg/home.svg';
import { ReactComponent as book } from 'assets/svg/book.svg';
import { ReactComponent as keypad } from 'assets/svg/keypad.svg';
import { ReactComponent as questionmark } from 'assets/svg/question-mark-circle.svg';
import classes from 'style/globalStyle.module.scss';

export const faqPropType = {
  id: PropTypes.number,
  question: PropTypes.string,
  answer: PropTypes.string,
  categoryId: PropTypes.number,
  subCategoryId: PropTypes.number,
  subCategoryName: PropTypes.string,
};

export const categoryPropType = {
  id: PropTypes.number,
  name: PropTypes.string,
  slug: PropTypes.string,
};

export const subCategoryPropType = {
  categoryId: PropTypes.number,
  id: PropTypes.number,
  name: PropTypes.string,
  slug: PropTypes.string,
};

export const getBookAnAppointmentMessage = (date, time, ticketId) => {
  const message = `Great! Your relationship manager will reach out to you on ${moment(
    date,
  ).format(
    'dddd, MMMM Do YYYY',
  )} at ${time} (EST). You can reschedule or cancel on the top right panel. I've also created a service ticket for you ${ticketId}.`;
  return {
    message: [
      {
        contentType: 'PlainText',
        content: message,
      },
    ],
    isOwn: false,
    messageDate: new Date(),
    sessionAttributes: {},
  };
};

export const faqsSliderSettings = {
  dots: true,
  dotsClass: classes.buttonBar,
  infinite: false,
  arrows: false,
  speed: 500,
  slidesToShow: 7,
  slidesToScroll: 1,
  className: classes.sliderCustomDiv,
  focusOnSelect: true,
  responsive: [
    {
      breakpoint: 2200,
      settings: {
        slidesToShow: 8,
      },
    },
    {
      breakpoint: 1186,
      settings: {
        slidesToShow: 7,
      },
    },
    {
      breakpoint: 1080,
      settings: {
        slidesToShow: 6,
      },
    },
    {
      breakpoint: 975,
      settings: {
        slidesToShow: 5,
      },
    },
    {
      breakpoint: 655,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 540,
      settings: {
        slidesToShow: 3,
      },
    },
    {
      breakpoint: 425,
      settings: {
        slidesToShow: 2,
      },
    },
  ],
};

export const categoriesToShow = [
  'about_chello',
  'setting',
  'move-money',
  'boost_by_chello',
  'home_screen',
  'chello-one-account',
  'transaction-reconciliation-categorization',
  'others',
];

export const categoryIdToIconMapping = {
  about_chello: infoIcon,
  setting: person,
  'move-money': arrowRight,
  home_screen: home,
  boost_by_chello: layers,
  'transaction-reconciliation-categorization': keypad,
  others: questionmark,
  'chello-one-account': book,
};

export const categoryKeysMapping = {
  MaincategoryId: 'id',
  MaincategoryName: 'name',
  MaincategorySlug: 'slug',
};

export const subCategoryKeysMapping = {
  subCategoryId: 'id',
  subCategoryName: 'name',
  subCategorySlug: 'slug',
  maincategoryId: 'categoryId',
};

export const faqKeysMapping = {
  faq_id: 'id',
  ques: 'question',
  ans: 'answer',
  maincategory_id: 'categoryId',
  sub_category_id: 'subCategoryId',
  sub_category_name: 'subCategoryName',
};

export const ImageResponseCardTypes = {
  WELCOME: 'WELCOME',
  FAQ: 'FAQ',
  FEEDBACK: 'FEEDBACK',
  FALLBACKACTIONS: 'FALLBACKACTIONS',
  CHATSURVEY: 'ChatSurvey',
};
