import {
  Box,
  Typography,
  Dialog,
  Button,
  IconButton,
  DialogTitle,
  DialogActions,
  DialogContent,
} from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import { defaultFnPropTypes } from 'utils';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { CustomIcon } from 'components';
import Classes from 'containers/OneAccount/OneAccount.module.scss';

import classes from './ViewTicketDetails.module.scss';

const {
  ticketId: TICKET_ID,
  ok: OK,
  status: STATUS,
  categoryText: CATEGORY,
  createDate: CREATE_DATE,
  estimatedDate: ESTIMATED_DATE,
  description: DESCRIPTION,
} = strings;

const ViewTicketDetails = (props) => {
  const { open, handleClose, ticketDetails } = props;
  const { ticketId, status, category, createDate, estimatedDate, description } =
    ticketDetails;

  return (
    <Dialog open={open} aria-labelledby="ticketDetailModal">
      <IconButton
        aria-label="close"
        size="small"
        data-testid="ticket-detail-close-btn"
        onClick={handleClose}
        className={Classes.closeIcon}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={HCClasses.viewTicketIcon}
        />
      </IconButton>
      <DialogTitle>
        <Typography component="span" variant="h1" id="ticketDetailModal">
          {TICKET_ID}: {ticketId}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box className={classes.ticketInfoWrapper}>
          <Box className={classes.ticketInfoGrid}>
            <Typography
              variant="p1"
              component="p"
              className={classes.ticketInfoLabel}
            >
              {STATUS}
            </Typography>
            <Typography variant="p1SemiBold" className={classes.ticketInfo}>
              {status}
            </Typography>
            <Typography
              variant="p1"
              component="p"
              className={classes.ticketInfoLabel}
            >
              {CATEGORY}
            </Typography>
            <Typography variant="p1SemiBold" className={classes.ticketInfo}>
              {category}
            </Typography>
            <Typography
              variant="p1"
              component="p"
              className={classes.ticketInfoLabel}
            >
              {CREATE_DATE}
            </Typography>
            <Typography variant="p1SemiBold" className={classes.ticketInfo}>
              {createDate}
            </Typography>
            <Typography
              variant="p1"
              component="p"
              className={classes.ticketInfoLabel}
            >
              {ESTIMATED_DATE}
            </Typography>
            <Typography variant="p1SemiBold" className={classes.ticketInfo}>
              {estimatedDate}
            </Typography>
            <Typography
              variant="p1"
              component="p"
              className={classes.ticketInfoLabel}
            >
              {DESCRIPTION}
            </Typography>
            <Typography variant="p1SemiBold" className={classes.ticketInfo}>
              {description}
            </Typography>
          </Box>
        </Box>
      </DialogContent>

      <DialogActions>
        <Box>
          <Button variant="contained" color="primary" onClick={handleClose}>
            <Typography variant="buttonMedium">{OK}</Typography>
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default ViewTicketDetails;

ViewTicketDetails.propTypes = {
  open: PropTypes.bool,
  handleClose: PropTypes.func,
  ticketDetails: PropTypes.instanceOf(Object),
};

ViewTicketDetails.defaultProps = {
  open: false,
  handleClose: defaultFnPropTypes,
  ticketDetails: {},
};
