import ViewTicketDetails from './ViewTicketDetails';

export default ViewTicketDetails;
