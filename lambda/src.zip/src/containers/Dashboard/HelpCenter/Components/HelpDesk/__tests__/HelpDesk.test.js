import {
  render,
  screen,
  act,
  fireEvent,
} from '@testing-library/react/pure';
import { Auth } from 'aws-amplify';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';
import ApiClient from 'api/ApiClient';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

jest.mock('api/ApiClient');

describe('Test Help desk tabs', () => {
  beforeAll(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    ApiClient.post = jest.fn().mockResolvedValue({});
  });

  afterAll(() => {
    ApiClient.get.mockClear();
  });

  it('should render Help Center page', async () => {
    renderWithProviderAndRouter(<App />, {
      route: routePath.HELP_CENTER,
      render,
    });
    await act(() => promiseResolveCurrentUser);
    expect(screen.getByText('Your relationship manager')).toBeInTheDocument();
  });

  it('navigate to different tab on selection', async () => {
    const tabs = screen.getAllByRole('tab');
    expect(tabs).toHaveLength(4);
    await act(async () => {
      fireEvent.click(tabs[0]);
    });
    expect(screen.getAllByText('All')).toHaveLength(1);
    // TODO API throws an error
    // await act(async () => {
    //   fireEvent.click(tabs[1]);
    // });
    // expect(screen.getAllByText('FAQs')).toHaveLength(1);
    await act(async () => {
      fireEvent.click(tabs[2]);
    });
    expect(screen.getAllByText('Service tickets')).toHaveLength(1);
    await act(async () => {
      fireEvent.click(tabs[3]);
    });
    expect(screen.getAllByText('Chat history')).toHaveLength(1);
  });
});
