import { useState, useEffect, useMemo } from 'react';
import { Typography, Box, Tab, Tabs, Paper } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import moment from 'moment';

import { convertTime12to24, convertTime24to12 } from 'utils';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { renameObjectKeys } from 'utils/utility';
import {
  addBotMessage,
  setLoader,
  updateActiveHelpDeskTab,
} from 'store/actions';

import HelpCenter from '../../HelpCenter';
import TabPanel from '../../../components/TabPanel';
import FAQs from '../../FAQs/FAQ';
import ChatHistory from '../../ChatHistory/ChatHistory';
import ViewServiceTickets from '../../ViewServiceTickets';
import BookAppointment from '../../All/TalkToUs/BookAppointment/BookAppointment';
import ConfirmedAppointment from '../../All/TalkToUs/ConfirmedAppointment/ConfirmedAppointment';
import {
  categoryKeysMapping,
  faqKeysMapping,
  getBookAnAppointmentMessage,
  subCategoryKeysMapping,
  categoriesToShow,
} from '../../Config';

const { all, fAQs, serviceTickets, chatHistory, helpDesk } = strings;
export const tabs = {
  all: 0,
  faqs: 1,
  serviceTickets: 2,
  chatHistory: 3,
};

const HelpDesk = () => {
  const { activeTab } = useSelector((state) => state.helpCenter);
  const bookAppointmentModalSource = useSelector(
    (state) => state.settings.bookAppointmentModalSource,
  );
  const [helpDeskTab, setHelpDeskTab] = useState(tabs.all);
  const [FAQData, setFAQData] = useState(null);
  const [rmDetails, setRMDetails] = useState({});
  const dispatch = useDispatch();
  const faqs = useMemo(
    () => FAQData?.faqs?.map?.((faq) => renameObjectKeys(faq, faqKeysMapping)),
    [FAQData?.faqs],
  );
  const mostAskedFAQS = useMemo(
    () =>
      FAQData?.most_asked_questions?.map?.((faq) =>
        renameObjectKeys(faq, faqKeysMapping),
      ),
    [FAQData?.faqs],
  );
  const faqCategories = useMemo(
    () =>
      FAQData?.maincategories
        ?.map?.((category) => renameObjectKeys(category, categoryKeysMapping))
        .filter(
          (category) =>
            category?.id && categoriesToShow.includes(category.slug),
        )
        .sort(
          (a, b) =>
            categoriesToShow.indexOf(a.slug) - categoriesToShow.indexOf(b.slug),
        ),
    [FAQData?.maincategories],
  );
  const faqSubCategories = useMemo(
    () =>
      FAQData?.subcategories?.map?.((subCategory) =>
        renameObjectKeys(subCategory, subCategoryKeysMapping),
      ),
    [FAQData?.subcategories],
  );
  const [confirmedModal, setConfirmedModal] = useState(false);
  const [selectedData, setSelectedData] = useState();

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    const getFAQData = async (props) => {
      try {
        ApiClient.get(serviceUrl.helpcenterFaq)
          .then((response) => {
            setFAQData(response);
          })
          .catch((error) => console.log('FAQs failed', error));
      } catch (err) {
        console.log('Error fetching Faqs', err);
      }
    };
    const fetchRMDetails = async () => {
      try {
        setRMDetails({ loading: true });
        const response = await ApiClient.get(
          serviceUrl.getRelationshipmanager,
          {
            params: {
              picture: true,
            },
          },
        );
        const { body } = response;
        setRMDetails(body);
      } catch (err) {
        setRMDetails({ loading: false });
        console.log('Error fetching RM Details', err);
      }
    };
    fetchRMDetails();
    getFAQData();
  }, []);
  useEffect(() => setHelpDeskTab(activeTab), [activeTab]);
  useEffect(() => () => dispatch(updateActiveHelpDeskTab(tabs.all)), []);

  const tabHandleChange = (e, newTab) => {
    dispatch(updateActiveHelpDeskTab(newTab));
  };

  const openConfirmedModal = (event) => {
    setConfirmedModal(!confirmedModal);
  };

  const hendleSubmit = async (bookedData, day, time) => {
    const newData = {
      ...bookedData,
      date: day,
      time: convertTime12to24(time),
      isOpen: true,
    };
    try {
      const {
        typeOfAppointment,
        appointmentReason,
        date,
        time: convertedTime,
      } = newData;
      dispatch(setLoader(true));
      const response = await ApiClient.post(
        serviceUrl.postBookingAppointment,
        {},
        {
          params: {
            typeOfAppointment,
            appointmentReason,
            date,
            time: convertedTime,
          },
        },
      );
      setSelectedData({
        ...newData,
        time: convertTime24to12(response?.responseBody?.time || ''),
        date: moment(response?.responseBody?.date || '').format('MMM DD, YYYY'),
      });
      setConfirmedModal(!confirmedModal);
      if (bookAppointmentModalSource === 'chatbot') {
        dispatch(
          addBotMessage(
            getBookAnAppointmentMessage(
              day,
              time,
              response?.responseBody?.ticketId,
            ),
          ),
        );
      }
    } catch (err) {
      console.log('error', err);
    } finally {
      dispatch(setLoader(false));
    }
  };

  return (
    <>
      <Box>
        <Paper className={classes.pageHeader} elevation={1}>
          <Typography variant="h1">{helpDesk}</Typography>
          <Tabs
            value={activeTab}
            onChange={tabHandleChange}
            textColor="inherit"
            indicatorColor="primary"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab label={all} className={classes.tabHeading} />
            <Tab label={fAQs} className={classes.tabHeading} />
            <Tab label={serviceTickets} className={classes.tabHeading} />
            <Tab label={chatHistory} className={classes.tabHeading} />
          </Tabs>
        </Paper>
        <TabPanel value={helpDeskTab} index={0}>
          <HelpCenter
            faqCategories={faqCategories}
            selectedData={selectedData}
            setSelectedData={setSelectedData}
            rmDetails={rmDetails}
          />
        </TabPanel>
        <TabPanel value={helpDeskTab} index={1}>
          <FAQs
            faqs={faqs}
            categories={faqCategories}
            subCategories={faqSubCategories}
            mostAskedFAQS={mostAskedFAQS}
          />
        </TabPanel>
        <TabPanel value={helpDeskTab} index={2}>
          <ViewServiceTickets />
        </TabPanel>
        <TabPanel value={helpDeskTab} index={3}>
          <ChatHistory />
        </TabPanel>
        <BookAppointment
          hendleSubmit={hendleSubmit}
          selectedData={selectedData}
        />
        {confirmedModal && (
          <ConfirmedAppointment
            openConfirmedModal={openConfirmedModal}
            selectedData={selectedData}
          />
        )}
      </Box>
    </>
  );
};

export default HelpDesk;
