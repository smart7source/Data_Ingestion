import {
  render,
  screen,
  waitFor,
  fireEvent,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';

import ViewServiceTickets from '../index';

const initialState = {
    helpCenter: {
        serviceTickets:[ {
            ticketId: '#139309849',
            status: 'Completed',
            category: 'General',
            createDate: 'Dec 12,2021',
            estimatedDate: 'Dec 12,2021',
            description: 'Lorum ipsum lurup upslum lurup upslum lorem...',
          },
          {
            ticketId: '#239309849',
            status: 'Completed',
            category: 'General',
            createDate: 'Dec 12,2021',
            estimatedDate: 'Dec 12,2021',
            description: 'Lorum ipsum lurup upslum lurup upslum lorem...',
          },
        ]
    }
  }




describe('Testing service ticket component', () => {
  beforeAll(() => {
   
    renderWithProviderAndRouter(<ViewServiceTickets />, {
      render,
      wrapperProps: {
        initialState,
      },
    });
  });
  it('should render ticket details',()=>
  {
      expect(screen.getByText('#139309849')).toBeInTheDocument();
  })
  it('should show ticket details on open', async () => {
    userEvent.click(screen.getByTestId('ticket-0'));
    expect(await screen.findByText('#139309849')).toBeInTheDocument();
  });
});
