import {
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Box,
} from '@mui/material';
import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import strings from 'localization/translation';
import { fetchServiceTickets } from 'store/actions/HelpCenterActions';
import HCClasses from 'style/HelpCenterStyle.module.scss';

import EachTicketRow from '../EachTicketRow';

import Classes from './ViewTickets.module.scss';

const {
  ticketId: TICKET_ID,
  status: STATUS,
  categoryText: CATEGORY,
  createDate: CREATE_DATE,
  estimatedDate: ESTIMATED_DATE,
  description: DESCRIPTION,
  nosearchTickets: NO_TICKETS,
} = strings;

const ViewServiceTickets = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchServiceTickets());
  }, [dispatch]);

  const serviceTickets = useSelector(
    (state) => state.helpCenter?.serviceTickets,
  );

  return (
    <Paper className={HCClasses.viewSTPaper}>
      {serviceTickets.length > 0 ? (
        <Box className={HCClasses.viewSTBox}>
          <Table className={Classes.viewTicketsTable}>
            <TableHead>
              <TableRow>
                <TableCell className={HCClasses.stTableCell1}>
                  <Typography
                    variant="p1SemiBold"
                    component="p"
                    color="grey.1100"
                  >
                    {TICKET_ID}
                  </Typography>
                </TableCell>
                <TableCell className={HCClasses.stTableCell2}>
                  <Typography
                    variant="p1SemiBold"
                    component="p"
                    color="grey.1100"
                  >
                    {STATUS}
                  </Typography>
                </TableCell>
                <TableCell className={HCClasses.stTableCell3}>
                  <Typography
                    variant="p1SemiBold"
                    component="p"
                    color="grey.1100"
                  >
                    {CATEGORY}
                  </Typography>
                </TableCell>
                <TableCell className={HCClasses.stTableCell4}>
                  <Typography
                    variant="p1SemiBold"
                    component="p"
                    color="grey.1100"
                  >
                    {CREATE_DATE}
                  </Typography>
                </TableCell>
                <TableCell className={HCClasses.stTableCell5}>
                  <Typography
                    variant="p1SemiBold"
                    component="p"
                    color="grey.1100"
                  >
                    {ESTIMATED_DATE}
                  </Typography>
                </TableCell>
                <TableCell className={HCClasses.stTableCell6}>
                  <Typography
                    variant="p1SemiBold"
                    component="p"
                    color="grey.1100"
                  >
                    {DESCRIPTION}
                  </Typography>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {serviceTickets.map((eachTicket, index) => (
                <EachTicketRow
                  key={index}
                  ticketDetails={eachTicket}
                  dataTestId={`ticket-${index}`}
                />
              ))}
            </TableBody>
          </Table>
        </Box>
      ) : (
        <>
          <Box
            display="flex"
            flexDirection="column"
            alignContent="center"
            gap={2.5}
          >
            <Box>
              <img
                width="179"
                height="50"
                src={`${process.env.PUBLIC_URL}/images/no-linked-accts.png`}
                alt="no linked accounts"
                style={{ width: '100%', height: 'auto' }}
              />
            </Box>
            <Typography variant="p1SemiBold" component="p" color="grey.1100">
              {NO_TICKETS}
            </Typography>
          </Box>
        </>
      )}
    </Paper>
  );
};

export default ViewServiceTickets;
