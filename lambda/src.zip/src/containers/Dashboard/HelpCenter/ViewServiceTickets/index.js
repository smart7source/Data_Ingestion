import ViewServiceTickets from './ViewServiceTickets';

export default ViewServiceTickets;
