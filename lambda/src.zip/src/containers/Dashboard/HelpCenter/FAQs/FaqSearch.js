import { useState } from 'react';
import {
  Typography,
  Box,
  IconButton,
  TextField,
  InputAdornment,
  MenuItem,
  Popper,
  ClickAwayListener,
} from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import { ReactComponent as Search } from 'assets/svg/search.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import classes from 'style/globalStyle.module.scss';
import { debounce } from 'utils/utility';

import helpDeskStyles from '../HelpDesk.module.scss';

const FaqSearch = ({ searchResults, onSearch, setSearchedFaq }) => {
  const [anchorElement, setAnchorElement] = useState(null);
  const [open, setOpen] = useState(false);
  const handleChange = (e) => {
    if (!e.target.value) {
      setAnchorElement(null);
      setOpen(false);
    } else {
      setAnchorElement(e.target);
      setOpen(true);
    }
    onSearch(e.target.value);
  };

  const handleClose = () => {
    setOpen(false);
    setAnchorElement(null);
  };
  const handleFaqClick = (faq) => {
    setOpen(false);
    handleClose();
    setSearchedFaq(faq.id);
  };
  const opendropDown = (e) => {
    setAnchorElement(e.target);
    setOpen(true);
  };
  return (
    <Box className={classes.searchCategory}>
      <TextField
        fullWidth
        placeholder="Search..."
        id="faq-search"
        name="faq-search"
        onChange={debounce(handleChange, 500)}
        onFocus={opendropDown}
        InputProps={{
          endAdornment: (
            <InputAdornment position="start">
              <IconButton>
                <CustomIcon
                  component={Search}
                  inheritViewBox
                  className={HCClasses.faqSearchIcon}
                />
              </IconButton>
            </InputAdornment>
          ),
          'data-testid': 'faqSearch',
        }}
      />
      <ClickAwayListener onClickAway={handleClose}>
        <Popper
          anchorEl={anchorElement}
          open={open}
          onClose={handleClose}
          placement="bottom-start"
          className={HCClasses.popperFaq}
        >
          <Box
            data-testid="faq-search-results"
            className={helpDeskStyles.faqSearchResultsWrapper}
          >
            {searchResults.map((faq, i) => (
              <MenuItem
                data-testid={`faq-search-result${i + 1}`}
                p={2}
                key={i}
                onClick={() => handleFaqClick(faq)}
              >
                <Typography key={i} variant="p2" color="grey.900">
                  {faq.question}
                </Typography>
              </MenuItem>
            ))}
          </Box>
        </Popper>
      </ClickAwayListener>
    </Box>
  );
};

export default FaqSearch;

FaqSearch.propTypes = {
  searchResults: PropTypes.arrayOf(PropTypes.any),
  onSearch: PropTypes.func,
  setSearchedFaq: PropTypes.func,
};

FaqSearch.defaultProps = {
  searchResults: [],
  onSearch: defaultFnPropTypes,
  setSearchedFaq: defaultFnPropTypes,
};
