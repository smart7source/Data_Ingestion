import { Typography } from '@mui/material';
import PropTypes from 'prop-types';

const FaqSubCategory = ({
  subCategory,
  onClick,
  children,
  selectedSubCategory,
  id,
}) => (
  <Typography
    variant="p2SemiBold"
    style={{ cursor: 'pointer', color: 'primary' }}
    color="primary"
    onClick={onClick}
  >
    {subCategory}
  </Typography>
);

export default FaqSubCategory;

FaqSubCategory.propTypes = {
  children: PropTypes.node,
  subCategory: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
  selectedSubCategory: PropTypes.number,
  id: PropTypes.number.isRequired,
};

FaqSubCategory.defaultProps = {
  children: <></>,
  selectedSubCategory: null,
};
