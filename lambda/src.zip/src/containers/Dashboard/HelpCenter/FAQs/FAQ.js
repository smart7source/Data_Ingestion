import { Typography, Grid, Paper, Box } from '@mui/material';
import { useState, useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import 'testHelpers/matchMedia';
import Slider from 'react-slick';

import { ReactComponent as questionmark } from 'assets/svg/question-mark-circle.svg';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import {
  updateActiveFaqs,
  updateFloatingChatbotVisibility,
} from 'store/actions';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { renameObjectKeys } from 'utils/utility';

import {
  categoryIdToIconMapping,
  categoryPropType,
  faqKeysMapping,
  faqPropType,
  faqsSliderSettings,
  subCategoryPropType,
} from '../Config';

import FaqCategory from './FaqCatogery';
import FaqSubCategory from './FaqSubCategory';
import FaqQuestions from './FaqQuestions';
import FaqSearch from './FaqSearch';

const { fAQs, howCanWeHelpYou, chooseACategory } = strings;

const FAQs = ({ faqs, categories, subCategories, mostAskedFAQS }) => {
  const { activeCategoryId, activeSubCategoryId, activeFaqId } = useSelector(
    (state) => state.helpCenter.faqs,
  );
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchedFaq, setSearchedFaq] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(() =>
    categories.find((category) => category.id === activeCategoryId),
  );
  const [selectedSubCategory, setSelectedSubCategory] = useState(
    () => activeSubCategoryId,
  );
  const faqsHeading = useMemo(() => {
    if (searchText) {
      return `Searching "${searchText}"`;
    }
    return !selectedCategory
      ? strings.mostAskedQuestions
      : selectedCategory?.name?.replace('&amp;', '&');
  }, [searchText, selectedCategory]);
  const dispatch = useDispatch();
  useEffect(() => {
    setSelectedCategory(
      (prevValue) =>
        categories.find((category) => category.id === activeCategoryId) ||
        prevValue,
    );
    setSelectedSubCategory(activeSubCategoryId);
  }, [activeFaqId]);
  useEffect(
    () => () => {
      dispatch(updateActiveFaqs(null, null, null));
      dispatch(updateFloatingChatbotVisibility(false));
    },
    [],
  );
  const handleClick = (itemIndex, category) => {
    setSelectedCategory(category);
  };

  const onSearch = (search) => {
    setSearchText(search);
    if (!search) {
      setSearchResults([]);
      return;
    }
    ApiClient.get(`${serviceUrl.helpcenterFaq}?limit=10&&search=${search}`)
      .then((response) => {
        setSearchResults(
          response?.faqs.map?.((faq) =>
            renameObjectKeys(faq, faqKeysMapping),
          ) || [],
        );
      })
      .catch((error) => console.log('FAQs failed', error));
  };

  return (
    <Paper elevation={2}>
      <Box p={3}>
        <Grid container alignItems="center" mb={2} className="formSettings">
          <Grid item>
            <Typography variant="h2" color="grey.1100">
              {fAQs}
            </Typography>
          </Grid>
        </Grid>
        <Grid textAlign="center">
          <Typography variant="h2">
            <span style={{ color: '#A120D1' }}>Che||o</span>
            <span fontWeight="bold">{howCanWeHelpYou}</span>
          </Typography>
          <Box justifyContent="center" display="flex">
            <FaqSearch
              onSearch={onSearch}
              searchResults={searchResults}
              setSearchedFaq={setSearchedFaq}
            />
          </Box>
          <Typography variant="p3" color="grey.800">
            {chooseACategory}
          </Typography>
        </Grid>

        <Slider {...faqsSliderSettings} className={classes.slider}>
          {categories.map((category, index) => (
            <FaqCategory
              key={index}
              dataTestid={`faqCategory${category.id}`}
              handleClick={() => handleClick(index, category)}
              category={category.name?.replace('&amp;', '&')}
              Icon={categoryIdToIconMapping[category.slug] || questionmark}
              selected={!searchText && selectedCategory?.id === category?.id}
            />
          ))}
        </Slider>
        <Grid mb={2} container alignItems="center" className="formSettings">
          <Grid item>
            <Typography mt={4} variant="h3" color="grey.900">
              {faqsHeading}
            </Typography>
          </Grid>
        </Grid>

        {!searchText &&
          subCategories
            .filter(
              (subCategory) => subCategory.categoryId === selectedCategory?.id,
            )
            .map((subcategory, i) => (
              <Box mb={2} key={i}>
                <FaqSubCategory
                  key={i}
                  subCategory={subcategory.name}
                  id={subcategory.id}
                  selectedSubCategory={selectedSubCategory}
                  onClick={() =>
                    setSelectedSubCategory((prevSubCat) =>
                      prevSubCat === subcategory.id ? null : subcategory.id,
                    )
                  }
                />
                {selectedSubCategory === subcategory.id && (
                  <FaqQuestions
                    faq={faqs.filter(
                      (faq) => faq.subCategoryId === subcategory.id,
                    )}
                    selectedFaq={activeFaqId}
                    loading={loading}
                  />
                )}
              </Box>
            ))}
        {searchText && (
          <FaqQuestions
            faq={searchResults}
            selectedFaq={searchedFaq}
            loading={loading}
          />
        )}
        {!selectedCategory && !searchText && (
          <FaqQuestions
            faq={mostAskedFAQS}
            selectedFaq={searchedFaq}
            loading={loading}
          />
        )}
      </Box>
    </Paper>
  );
};

export default FAQs;

FAQs.propTypes = {
  faqs: PropTypes.arrayOf(PropTypes.shape(faqPropType)),
  categories: PropTypes.arrayOf(PropTypes.shape(categoryPropType)),
  subCategories: PropTypes.arrayOf(PropTypes.shape(subCategoryPropType)),
  mostAskedFAQS: PropTypes.arrayOf(PropTypes.shape(faqPropType)),
};

FAQs.defaultProps = {
  faqs: [],
  categories: [],
  subCategories: [],
  mostAskedFAQS: [],
};
