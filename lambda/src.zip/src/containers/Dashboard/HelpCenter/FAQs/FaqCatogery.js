import { Box, Typography, Grid } from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';
import CustomIcon from 'components/UIElements/CustomIcon';

const FaqCategory = ({ category, Icon, handleClick, selected, dataTestid }) => (
  <Grid item style={{ borderRadius: '6.06px' }} onClick={handleClick}>
    <Box
      className={classes.faqCategory}
      style={{
        background: selected ? '#f8e8fd' : '',
        border: selected ? '0.61px solid #A120D1' : '',
      }}
    >
      <CustomIcon component={Icon} color="grey.800" />
      <Typography
        data-testid={dataTestid}
        variant="h3"
        className={classes.faqBoxTypo}
        color="grey.900"
      >
        {category}
      </Typography>
    </Box>
  </Grid>
);

export default FaqCategory;

FaqCategory.propTypes = {
  category: PropTypes.string,
  handleClick: PropTypes.func,
  selected: PropTypes.bool,
  Icon: PropTypes.instanceOf(Object),
  dataTestid: PropTypes.string,
};
FaqCategory.defaultProps = {
  category: '',
  handleClick: defaultFnPropTypes,
  selected: false,
  Icon: {},
  dataTestid: '',
};
