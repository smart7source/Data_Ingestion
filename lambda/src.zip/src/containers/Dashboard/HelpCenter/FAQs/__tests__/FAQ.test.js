import {
  render,
  screen,
  act,
  fireEvent,
  waitFor,
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Auth } from 'aws-amplify';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';
import strings from 'localization/translation';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const initialState = {
  helpCenter: {
    chatbot: {
      messages: [],
      isLoading: false,
    },
    faqs: {
      activeCategoryId: null,
      activeSubCategoryId: null,
      activeFaqId: null,
    },
    activeTab: 0,
  },
};

describe('Test FAQs Tab', () => {
  beforeAll(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
  });

  beforeEach(async () => {
    jest.useFakeTimers();
    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: routePath.HELP_CENTER,
        render,
        wrapperProps: { initialState },
      }),
    );
    await act(() => promiseResolveCurrentUser);
    await waitFor(
      () =>
        expect(
          screen.queryByRole('heading', { level: 1, name: strings.helpDesk }),
        ).toBeInTheDocument,
    );
    const tab = screen.queryByRole('tab', { name: strings.fAQs });
    fireEvent.click(tab);
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.useRealTimers();
  });

  it('should render FAQs correctly', () => {
    const heading = screen.getByRole('heading', {
      name: strings.fAQs,
      level: 2,
    });
    expect(heading).toBeInTheDocument();
    const chelloCategory = screen.queryByRole('heading', { name: 'About Chello', level: 3 });
    expect(
      chelloCategory,
    ).toBeInTheDocument();
    expect(
      screen.queryAllByRole('heading', { name: strings.mostAskedQuestions, level: 3 }),
    ).toHaveLength(1);
    const category = screen.queryByTestId('faqCategory26');
    act(() => {
      fireEvent.click(category);
    });
    const subCategory = screen.queryByText('Platform / Software Integration');
    expect(subCategory).toBeInTheDocument();
    act(() => {
      fireEvent.click(subCategory);
    });
    const question = screen.queryByText(
      'What are the platforms that I can integrate with my Chello account?',
    );
    expect(question).toBeInTheDocument();
    act(() => {
      fireEvent.click(question);
    });
    const answer = screen.queryByText('some answer');
    expect(answer).toBeInTheDocument();
  });
  it('should render search results correctly', async () => {
    const searchBar = screen.getByTestId(/faqSearch/i).querySelector('input');
    expect(searchBar).toBeInTheDocument();
    expect(screen.queryByTestId(/faq-search-results/i)).not.toBeInTheDocument();
    await act(async () => {
      await fireEvent.change(searchBar, { target: { value: 'chello' } });
    });
    await act(async () => {
      jest.runAllTimers();
    });
    expect(searchBar).toHaveValue('chello');
    await waitFor(() =>
      expect(screen.queryByTestId(/faq-search-results/i)).toBeInTheDocument(),
    );
    const faqSearchResult = screen.queryByTestId('faq-search-result1');
    expect(faqSearchResult).toBeInTheDocument();
    expect(screen.queryAllByText('What are the platforms that I can integrate with my Chello account?')).toHaveLength(2);
    act(() => {
      fireEvent.click(faqSearchResult);
    });
    expect(screen.queryByTestId(/faq-search-results/i)).not.toBeInTheDocument();
    expect(screen.queryAllByText('What are the platforms that I can integrate with my Chello account?')).toHaveLength(1);
  });
});
