import {
  Typography,
  Grid,
  IconButton,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Box,
} from '@mui/material';
import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Plus } from 'assets/svg/plus.svg';
import { ReactComponent as Minus } from 'assets/svg/minus.svg';
import HCClasses from 'style/HelpCenterStyle.module.scss';

import Spinner from '../All/ChatBot/Spinner';

const FaqQuestions = ({ faq, loading, selectedFaq }) => {
  const [clicked, setClicked] = useState([selectedFaq]);
  useEffect(() => {
    setClicked((prevState) => [...prevState, selectedFaq]);
  }, [selectedFaq]);
  const handleIconClick = (event, index) => {
    event.preventDefault();
    setClicked((open) => {
      if (open.includes(index)) {
        return open.filter((x) => x !== index);
      }
      return [...open, index];
    });
  };

  return (
    <>
      {loading ? (
        <Spinner />
      ) : (
        faq.map((qns, index) => {
          const { question = '', answer = '', id } = qns;
          return (
            <Grid key={index.toString()} display="flex" flexWrap="nowrap">
              <Accordion elevation={0} expanded={clicked.includes(id)}>
                <AccordionSummary
                  onClick={(e) => handleIconClick(e, id)}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                  style={{
                    padding: '0px',
                    margin: '0px',
                    alignItems: 'flex-end',
                  }}
                >
                  <Box display="flex">
                    <Box>
                      <IconButton
                        aria-label="close"
                        style={{
                          padding: '0px',
                        }}
                      >
                        <CustomIcon
                          component={!clicked.includes(id) ? Plus : Minus}
                          color="primary"
                          className={HCClasses.faqQns}
                          inheritViewBox
                        />
                      </IconButton>
                    </Box>
                    <Box>
                      <Typography variant="p1SemiBold" color="grey.900">
                        {question}
                      </Typography>
                    </Box>
                  </Box>
                </AccordionSummary>
                <Grid item>
                  <AccordionDetails style={{ padding: '0px 0px 0px 23px' }}>
                    <Typography
                      dangerouslySetInnerHTML={{ __html: answer }}
                      variant="p2"
                      color="grey.800"
                    />
                  </AccordionDetails>
                </Grid>
              </Accordion>
            </Grid>
          );
        })
      )}
    </>
  );
};

export default FaqQuestions;

FaqQuestions.propTypes = {
  faq: PropTypes.arrayOf(PropTypes.any),
  loading: PropTypes.bool,
  selectedFaq: PropTypes.number,
};
FaqQuestions.defaultProps = {
  faq: [],
  loading: false,
  selectedFaq: null,
};
