import {
  render,
  screen,
  act,
  fireEvent,
  waitFor,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Auth } from 'aws-amplify';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';
import ApiClient from 'api/ApiClient';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

jest.mock('../All/ChatBotMain', () => () => 'ChatBotMain');
jest.mock('api/ApiClient');

describe('Test Help Center page', () => {
  beforeAll(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
    ApiClient.post = jest.fn().mockResolvedValue();
  });

  afterAll(() => {
    ApiClient.get.mockClear();
  });

  it('should render Help Center page', async () => {
    renderWithProviderAndRouter(<App />, {
      route: routePath.HELP_CENTER,
      render,
    });
    await act(() => promiseResolveCurrentUser);
    await waitFor(() =>
      expect(screen.queryByTestId(/talkToUsSpinner/i)).not.toBeInTheDocument(),
    );
    expect(screen.getByText('Your relationship manager')).toBeInTheDocument();
  });

  it('should render Your relationship manager', async () => {
    expect(screen.getByText('Your relationship manager')).toBeInTheDocument();
    expect(screen.getByText('Your Relationship Manager')).toBeInTheDocument();
    expect(screen.getByText(/View Profile/i)).toBeInTheDocument();
    expect(screen.getByText(/Send message/i)).toBeInTheDocument();
    expect(
      screen.getByText(
        /Set up time with Hemanth Palaka to get guidance on everyday financial matters and to find out how you can make the most of your money./i,
      ),
    ).toBeInTheDocument();
  });

  it('should render Book appointment modal', async () => {
    const button = screen.getByTestId('book-appointment');
    userEvent.click(button);
    const dialog = await screen.findByTestId('customized-dialog-title');
    expect(dialog).toBeInTheDocument();
  });

  // it('should render Confirmed Appointment modal', async () => {
  //   const button = screen.getByTestId('book-appointment');
  //   userEvent.click(button);
  //   const dialog = await screen.findByTestId('customized-dialog-title');
  //   const buttonDay = screen.getAllByTestId('slider-button-day');
  //   userEvent.click(buttonDay[0]);
  //   const buttonTime = screen.getAllByTestId('slider-button-time');
  //   userEvent.click(buttonTime[0]);
  //   await act(async () => {
  //     const textField = screen.getByTestId('appointmentReason');
  //     fireEvent.change(textField, {
  //       target: { value: 'tt' },
  //     });
  //   });
  //   const buttonBook = screen.getByRole('button', { name: 'Book' });
  //   await act(async () => {
  //     fireEvent.click(buttonBook);
  //   });
  //   expect(screen.getByRole('dialog')).toBeInTheDocument();
  // }, 10000);

  it('should render View Profile dialog ', () => {
    const button = screen.getByTestId('view-profile-icon');
    expect(button).toBeInTheDocument();
    userEvent.click(button);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('should render Service ticket tab ', async () => {
    const button = screen.getByTestId('open-service-tickets');
    expect(button).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(button);
    });
    waitFor(() =>
      expect(screen.getByText('Service Tickets.')).toBeInTheDocument(),
    );
  });
});
