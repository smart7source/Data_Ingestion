import {
  render,
  screen,
  act,
  fireEvent,
  waitFor,
} from '@testing-library/react/pure';
import { Auth } from 'aws-amplify';
import { rest } from 'msw';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';
import strings from 'localization/translation';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const initialState = {
  helpCenter: {
    chatbot: {
      messages: [],
      isLoading: false,
    },
    faqs: {
      activeCategoryId: null,
      activeSubCategoryId: null,
      activeFaqId: null,
    },
    activeTab: 0,
  },
};

const faqsResponseMock = {
  httpStatusCode: 200,
  responseCode: 0,
  responseBody: {
    messages: [
      {
        contentType: 'ImageResponseCard',
        imageResponseCard: {
          title: "Let's see if any of these articles help\u0003FAQ",
          buttons: [
            {
              text: 'Platform / Software Integration',
              value: 'Platform / Software Integration',
            },
            {
              text: 'Platform / Software Integration1',
              value: 'Platform / Software Integration',
            },
            {
              text: 'Platform / Software Integration2',
              value: 'Platform / Software Integration',
            },
          ],
        },
      },
    ],
    sessionState: {
      sessionAttributes: {
        name: 'fallbackintent',
        faqIDs: '464#462#460',
        maincatIDs: '26#26#26',
        subcatIDs: '41#41#41',
        searchText: 'chello',
        counter: 0,
        postcount: 80,
      },
    },
    requestAttributes: {},
  },
  headers: {},
};
jest.mock('../All/ChatBotMain', () => () => 'ChatBotMain');
jest.mock('../FAQs/FAQ', () => () => 'FAQ');

describe('Test floating chatbot', () => {
  beforeAll(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
  });

  beforeEach(() => {
    server.use(
      rest.post(serviceUrl.lexbotApi, (req, res, ctx) =>
        res(ctx.json(faqsResponseMock)),
      ),
    );
  });

  it('should render Help Center page', async () => {
    renderWithProviderAndRouter(<App />, {
      route: routePath.HELP_CENTER,
      render,
      wrapperProps: { initialState },
    });
    await act(() => promiseResolveCurrentUser);
    expect(screen.getAllByText(strings.helpDesk).length).toBe(2);
    expect(screen.queryByTestId(/floating-chatbot/i)).toBeNull();
  });
  it('should goto FAQs tab and show floating chatbot correctly', async () => {
    server.use(
      rest.post(serviceUrl.lexbotApi, (req, res, ctx) =>
        res(ctx.json(faqsResponseMock)),
      ),
    );
    // const faqButton = screen.queryByText('Platform / Software Integration');
    const Spinner = await screen.queryByTestId('message-spinner');
    await waitFor(() => expect(Spinner).not.toBeInTheDocument());
    const faqButton = screen.queryByText('Platform / Software Integration');
    await act(async () => fireEvent.click(faqButton));
    expect(
      screen.getByRole('heading', { name: /FAQs/i, level: 2 }),
    ).toBeInTheDocument();
    const floatingChatBot = screen.queryByTestId(/floating-chatbot/i);
    expect(floatingChatBot).toHaveClass('floatingChatbotWrapper');
    // expect(screen.getByLabelText(/open-new/i)).toBeInTheDocument();
    // const minimizeMaximizeButton = screen.getByLabelText(/open-new/i);
    // await act(async () => fireEvent.click(minimizeMaximizeButton));
    // expect(floatingChatBot).toHaveClass('minimizedFloatingChatbotWrapper');
  });
});
