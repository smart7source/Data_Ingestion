import { render, screen, fireEvent } from '@testing-library/react/pure';
import { Provider } from 'react-redux';
import moment from 'moment';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import theme from 'style/theme';
import { Auth } from 'aws-amplify';
import { cognitoUserMock, cognitoCurrentSessionMock } from 'testHelpers';
import configureStore from 'redux-mock-store';
import ChatHistory from '../ChatHistory';

const initialState = {
  helpCenter: {
    chatHistory: {
      availableHistoryDates: [
        {
          date: '02-15-2022',
        },
        {
          date: '03-15-2022',
        },
      ],
      availableChatHistory: {
        '03-15-2022': [
          {
            message: [
              {
                contentType: 'PlainText',
                content:
                  "Hi There! I'm Chello, your assistant. I'm not an human, so i'm available 24/7 . Ask me a questions, or try one of these:",
              },
            ],
            isOwn: false,
            messageDate: '2022-03-15T02:59:40.459Z',
          },
          {
            message: [
              {
                contentType: 'PlainText',
                content: 'How do I change my password?',
              },
            ],
            isOwn: true,
            messageDate: '2022-03-15T02:59:50.459Z',
          },
        ],
        '02-15-2022': [
          {
            message: [
              {
                contentType: 'PlainText',
                content: 'Hi',
              },
            ],
            isOwn: true,
            messageDate: '2022-02-15T02:59:30.459Z',
          },
          {
            message: [
              {
                contentType: 'PlainText',
                content:
                  "Hi There! I'm Chello, your assistant. I'm not an human, so i'm available 24/7 . Ask me a questions, or try one of these:",
              },
              {
                contentType: 'ImageResponseCard',
                imageResponseCard: {
                  title: 'FAQ Response Card',
                  buttons: [
                    {
                      text: 'How do I change my password?',
                      value: 'How to Change my Password?',
                    },
                  ],
                },
              },
            ],
            isOwn: false,
            messageDate: '2022-02-15T02:59:40.459Z',
          },
        ],
      },
    },
  },
};

const mockStore = configureStore(initialState);

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

jest.mock('../../All/ChatBotMain', () => () => 'ChatBotMain');

describe('Test Chat History component', () => {
  beforeAll(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });
  });

  beforeEach(() => {
    render(
      <StyledEngineProvider injectFirst>
        <ThemeProvider theme={theme}>
          <Provider store={mockStore(initialState)}>
            <ChatHistory />
          </Provider>
        </ThemeProvider>
      </StyledEngineProvider>,
    );
  });

  it('should render chathistory tab', () => {
    expect(screen.getByTestId(/chatHistorySearch/i)).toBeInTheDocument();
    expect(screen.queryAllByTestId(/chatHistoryDate/i)).toHaveLength(2);
    const dateButton = screen.getByText(
      moment('02-15-2022', ['MM-DD-YYYY']).format('dddd, MMMM DD, YYYY'),
    );
    expect(dateButton).toBeInTheDocument();
    fireEvent.click(dateButton);
    expect(dateButton).toHaveStyle('font-weight:600');
    expect(screen.getByText('Hi')).toBeInTheDocument();
  });
});
