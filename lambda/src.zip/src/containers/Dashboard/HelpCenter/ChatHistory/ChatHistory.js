import { useState, useMemo } from 'react';
import {
  Paper,
  Box,
  Grid,
  TextField,
  InputAdornment,
  IconButton,
  Accordion,
  AccordionSummary,
  Typography,
} from '@mui/material';
import moment from 'moment';
import { useSelector, useDispatch } from 'react-redux';

import { ReactComponent as ChevronRight } from 'assets/svg/chevron-right.svg';
import HCClasses from 'style/HelpCenterStyle.module.scss';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Search } from 'assets/svg/search.svg';
import strings from 'localization/translation';
import { getChatHistory } from 'store/actions';

import ChatBotMessagesList from '../All/ChatBot/ChatBotMessagesList';

const noop = () => {};

const ChatHistory = () => {
  const { availableHistoryDates, availableChatHistory } = useSelector(
    (state) => state.helpCenter.chatHistory,
  );

  const dispatch = useDispatch();
  dispatch(getChatHistory());

  const sortedHistoryDates = availableHistoryDates?.sort(
    (date1, date2) => new Date(date1.date) - new Date(date2.date),
  );

  const [selectedDate, setSelectedDate] = useState('02-15-2022');
  const selectedHistory = useMemo(
    () => availableChatHistory?.[selectedDate] || [],
    [selectedDate, availableChatHistory],
  );

  return (
    <>
      <Paper elevation={2} className={HCClasses.chatHistoryPaper}>
        <Box p={3} className={HCClasses.chatHistoryBox}>
          <Box marginBottom={2}>
            <TextField
              fullWidth
              placeholder="Search..."
              id="chat-history-search"
              name="chat-history-search"
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <IconButton>
                      <CustomIcon
                        component={Search}
                        inheritViewBox
                        className={HCClasses.chatHistoryIcon}
                      />
                    </IconButton>
                  </InputAdornment>
                ),
                'data-testid': 'chatHistorySearch',
              }}
            />
          </Box>
          {sortedHistoryDates?.length && (
            <Box pb={2} className={HCClasses.chatHistoryBox2}>
              <Grid container className={HCClasses.chatHistoryGrid}>
                <Grid item pr={1} xs={12} lg={4}>
                  {sortedHistoryDates?.map((historyDate, i) => (
                    <Accordion
                      expanded={false}
                      key={i}
                      data-testid="chatHistoryDate"
                      onClick={() => setSelectedDate(historyDate.date)}
                    >
                      <AccordionSummary
                        expandIcon={
                          <CustomIcon
                            component={ChevronRight}
                            inheritViewBox
                            color="grey.800"
                            className={HCClasses.chatHistoryIcon2}
                          />
                        }
                      >
                        <Typography
                          variant={
                            historyDate.date === selectedDate
                              ? 'p1SemiBold'
                              : 'p1'
                          }
                        >
                          {moment(historyDate.date, ['MM-DD-YYYY']).format(
                            'dddd, MMMM DD, YYYY',
                          )}
                        </Typography>
                      </AccordionSummary>
                    </Accordion>
                  ))}
                </Grid>
                <Grid
                  item
                  xs={12}
                  lg={8}
                  height="100%"
                  sx={{ overflowY: 'auto', borderLeft: '1px solid #d7d7d7' }}
                  className="chatbotHistoryMessagesContainer chatbotMessagelistWrapper"
                >
                  <ChatBotMessagesList
                    messages={selectedHistory}
                    handleMessage={noop}
                    showSpinner={false}
                  />
                </Grid>
              </Grid>
            </Box>
          )}
          {!sortedHistoryDates?.length && (
            <Box
              display="flex"
              justifyContent="center"
              width="100%"
              flexDirection="column"
            >
              <img
                height="50px"
                src="/svg/no-chat-history.svg"
                alt="emoji-picker"
              />
              <Typography align="center" sx={{ fontWeight: 'bold' }}>
                {strings.noChatHistory}
              </Typography>
            </Box>
          )}
        </Box>
      </Paper>
    </>
  );
};

export default ChatHistory;
