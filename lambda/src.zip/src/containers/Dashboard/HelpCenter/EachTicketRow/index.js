import EachTicketRow from './EachTicketRow';

export default EachTicketRow;
