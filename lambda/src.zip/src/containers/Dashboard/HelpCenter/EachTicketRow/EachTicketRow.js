import { TableCell, TableRow, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { useState } from 'react';
import { useDispatch } from 'react-redux';

import { showDetailsDialog } from 'store/actions/OneAccountActions';

import ViewTicketDetails from '../ViewTicketDetails';

const EachTicketRow = ({ ticketDetails, dataTestId }) => {
  const [showTicketDetails, setShowTicketDetails] = useState(false);
  const dispatch = useDispatch();

  const viewFullDetails = () => {
    dispatch(showDetailsDialog(true));
    setShowTicketDetails(true);
  };

  const handleClose = () => {
    setShowTicketDetails(false);
  };

  const { ticketId, status, category, createDate, estimatedDate, description } =
    ticketDetails;
  return (
    <>
      <ViewTicketDetails
        open={showTicketDetails}
        handleClose={handleClose}
        ticketDetails={ticketDetails}
      />
      <TableRow onClick={viewFullDetails} tabIndex="0" data-testid={dataTestId}>
        <TableCell>
          <Typography variant="p1" color="grey.700">
            {ticketId}
          </Typography>
        </TableCell>
        <TableCell>
          <Typography variant="p1" color="grey.700">
            {status}
          </Typography>
        </TableCell>
        <TableCell>
          <Typography variant="p1" color="grey.700">
            {category}
          </Typography>
        </TableCell>
        <TableCell>
          <Typography variant="p1" color="grey.700">
            {createDate}
          </Typography>
        </TableCell>
        <TableCell>
          <Typography variant="p1" color="grey.700">
            {estimatedDate}
          </Typography>
        </TableCell>
        <TableCell>
          <Typography variant="p1" color="grey.700">
            {description}
          </Typography>
        </TableCell>
      </TableRow>
    </>
  );
};

export default EachTicketRow;

EachTicketRow.propTypes = {
  ticketDetails: PropTypes.instanceOf(Object).isRequired,
  dataTestId: PropTypes.string,
};
EachTicketRow.defaultProps = {
  dataTestId: '',
};
