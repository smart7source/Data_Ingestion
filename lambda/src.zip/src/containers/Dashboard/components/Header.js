import { AppBar, Badge, Box, Button, IconButton } from '@mui/material';
import PropTypes from 'prop-types';
import {
  Link,
  NavLink as RouterLink,
  useHistory,
  useLocation,
} from 'react-router-dom';
import { useDispatch } from 'react-redux';
import clsx from 'clsx';
import Toolbar from '@mui/material/Toolbar';

import { routePath } from 'routes';
import { primaryColor, whiteToBlackColor } from 'style/variables';
import { handleLogout } from 'utils';
import classes from 'style/DashboardStyle.module.scss';
import globalClasses from 'style/globalStyle.module.scss';
import strings from 'localization/translation';
import { updateAuthenticatedStatus } from 'store/actions';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Settings } from 'assets/svg/settings-2.svg';
import { ReactComponent as Notifications } from 'assets/svg/bell-fill.svg';
import { ReactComponent as Menu } from 'assets/svg/menu.svg';

const { logoutButtonText } = strings;
const Header = ({ open, openDrawer }) => {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();

  const onLogoClick = () => {
    if (location?.pathname === routePath.LOGIN) {
      history.go(0);
    } else history.push(routePath.LOGIN);
  };
  return (
    <AppBar
      position="sticky"
      elevation={0}
      // className={clsx(classes.appBar, {
      //   [classes.appBarShift]: open,
      // })}
    >
      <Toolbar variant="regular" sx={{ bgcolor: 'grey.100' }}>
        <Box className={globalClasses.sectionMobile}>
          <IconButton
            edge="start"
            color="inherit"
            aria-label="open drawer"
            onClick={openDrawer}
            // className={clsx(classes.menuButton, {
            //   [classes.hide]: open,
            // })}
            data-testid="header-toggle-drawer-menu"
            size="large"
          >
            <CustomIcon
              component={Menu}
              inheritViewBox
              sx={{ fontSize: 20, color: whiteToBlackColor[1100] }}
            />
          </IconButton>
        </Box>
        <Box border={1} flexGrow="1">
          <Link onClick={onLogoClick} to="#" style={{ display: 'flex' }}>
            <img
              src={`${process.env.PUBLIC_URL}/images/Chello-logo.png`}
              alt="logo"
            />
          </Link>
        </Box>
        <Box className={clsx(classes.sectionDesktop, classes.spacing)}>
          <IconButton
            aria-label="show 17 new notifications"
            color="inherit"
            size="large"
          >
            <Badge badgeContent={17} color="warning">
              <CustomIcon
                component={Notifications}
                inheritViewBox
                sx={{ fontSize: 20, color: primaryColor }}
              />
            </Badge>
          </IconButton>
          <IconButton
            aria-label="show 17 new notifications"
            color="inherit"
            component={RouterLink}
            to={routePath.SETTINGS}
            size="large"
          >
            <CustomIcon
              component={Settings}
              inheritViewBox
              sx={{ fontSize: 20, color: primaryColor }}
            />
          </IconButton>

          <Button
            variant="contained"
            color="primary"
            size="small"
            onClick={() =>
              handleLogout({
                history,
                onLogout: () => {
                  dispatch(updateAuthenticatedStatus(false));
                  dispatch({
                    type: 'USER_LOGGED_OUT',
                  });
                },
              })
            }
            disableElevation
          >
            {logoutButtonText}
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;

Header.propTypes = {
  open: PropTypes.bool,
  openDrawer: PropTypes.func.isRequired,
};

Header.defaultProps = {
  open: false,
};
