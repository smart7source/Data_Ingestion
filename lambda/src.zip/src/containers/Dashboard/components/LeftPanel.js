import {
  Box,
  Divider,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Tooltip,
  Typography,
  Collapse,
  Toolbar,
  Paper,
  Button,
  useMediaQuery,
} from '@mui/material';
import {
  NavLink as RouterLink,
  useHistory,
  useLocation,
} from 'react-router-dom';
import clsx from 'clsx';
import ListItemIcon from '@mui/material/ListItemIcon';
import { useState, useCallback, memo } from 'react';
import PropTypes from 'prop-types';

import { ReactComponent as ChevronUp } from 'assets/svg/chevron-up.svg';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';
import { ReactComponent as ChevronRight } from 'assets/svg/chevron-right.svg';
import { ReactComponent as ChevronLeft } from 'assets/svg/chevron-left.svg';
import { ReactComponent as Person } from 'assets/svg/person.svg';
import { topItems, defaultFnPropTypes } from 'utils';
import classes from 'style/DashboardStyle.module.scss';
import CustomIcon from 'components/UIElements/CustomIcon';

function a11yProps(isSubMenu, isExpanded) {
  return isSubMenu
    ? {
        'aria-expanded': isExpanded,
        'aria-haspopup': 'true',
      }
    : {};
}

const MainMenuItem = memo(({ menu, open, handleDrawerStatus }) => {
  const { icon: Icon } = menu;
  const [openSubMenu, setSubMenuOpen] = useState(false);
  const history = useHistory();
  const location = useLocation();
  const belowLg = useMediaQuery((theme) => theme.breakpoints.down('md'));

  const isSubMenu =
    (menu.subMenu || []).findIndex(
      (item) => item.href === location.pathname,
    ) !== -1;

  const handleMenuClick = useCallback(
    (event) => {
      event.preventDefault();
      event.stopPropagation();
      setSubMenuOpen((prevOpenSubMenu) => !prevOpenSubMenu);
      if (!menu.hasSubMenu) {
        history.push(menu.href);
        if (belowLg) handleDrawerStatus();
      }
    },
    [history, menu, belowLg, handleDrawerStatus],
  );

  const handleSubMenuClick = useCallback(
    (subMenu) => (event) => {
      event.preventDefault();
      history.push(subMenu.href);
      if (belowLg) handleDrawerStatus();
    },
    [history, belowLg, handleDrawerStatus],
  );
  const isExpanded = openSubMenu || isSubMenu;
  const ExpandSymbol = isExpanded ? (
    <CustomIcon
      component={ChevronUp}
      inheritViewBox
      color="grey.800"
      sx={{ fontSize: 11 }}
    />
  ) : (
    <CustomIcon
      component={ChevronDown}
      inheritViewBox
      color="grey.800"
      sx={{ fontSize: 11 }}
    />
  );
  const icon = (
    <ListItemIcon aria-label={menu.title}>
      <Icon />
    </ListItemIcon>
  );

  return (
    <Box>
      <ListItem
        {...a11yProps(menu.hasSubMenu, isExpanded)}
        className={classes.listItem}
      >
        <RouterLink
          to={menu.href}
          className={clsx(classes.primaryNavLink, classes.listItemText)}
          activeClassName="active"
          onClick={handleMenuClick}
        >
          {!open ? (
            <Tooltip
              title={menu.title}
              aria-label={menu.title}
              arrow
              placement="right"
              disableInteractive
            >
              {icon}
            </Tooltip>
          ) : (
            icon
          )}

          <ListItemText
            primary={
              <Typography variant="h3" component="h3" color="grey.900">
                {menu.title}
              </Typography>
            }
          />
          {menu.hasSubMenu && ExpandSymbol}
        </RouterLink>
      </ListItem>
      <Divider variant="middle" />
      {menu.hasSubMenu && (openSubMenu || isSubMenu) && (
        <Collapse
          component="li"
          in={openSubMenu || isSubMenu}
          timeout="auto"
          unmountOnExit
        >
          <List disablePadding>
            {menu.subMenu.map((subMenu, subMenuIndex) => (
              <ListItem key={subMenuIndex} className={classes.subMenuBtn}>
                <RouterLink
                  to={subMenu.href}
                  className={clsx(classes.primaryNavLink)}
                  onClick={handleSubMenuClick(subMenu)}
                >
                  <ListItemIcon>
                    <Icon />
                  </ListItemIcon>
                  <ListItemText primary={subMenu.title} />
                </RouterLink>
              </ListItem>
            ))}
          </List>
        </Collapse>
      )}
    </Box>
  );
});

const LeftPanel = ({ open, handleDrawerStatus }) => (
  <Drawer
    variant="permanent"
    className={clsx(classes.drawer, {
      [classes.drawerOpen]: open,
      [classes.drawerClose]: !open,
    })}
    classes={{
      paper: clsx(classes.drawerPaper, {
        [classes.drawerOpen]: open,
        [classes.drawerClose]: !open,
      }),
    }}
  >
    <Toolbar
      style={{ background: '#fff', marginBottom: '32px', paddingRight: 0 }}
    >
      {open && (
        <Box display="flex" gap="10px">
          <Box alignSelf="flex-start">
            <CustomIcon
              component={Person}
              color="grey.500"
              inheritViewBox
              sx={{ width: '20px', height: '20px' }}
            />
          </Box>
          <Box>
            <Typography
              variant="h3"
              component="h3"
              color="grey.900"
              gutterBottom
            >
              Lakewood Clinic
            </Typography>
            <Typography variant="p2" component="p" color="grey.600">
              Site ID: 12345679
            </Typography>
          </Box>
        </Box>
      )}
    </Toolbar>

    <nav aria-label="Primary">
      <List>
        {topItems.map((menu, index) => (
          <MainMenuItem
            key={index}
            menu={menu}
            open={open}
            handleDrawerStatus={handleDrawerStatus}
          />
        ))}
      </List>
    </nav>

    <Box flexGrow={1} />

    <Box sx={{ display: 'flex', justifyContent: 'end' }} mb={10}>
      <Paper
        elevation={3}
        component={Button}
        className={classes.drawerActbtn}
        onClick={handleDrawerStatus}
        data-testid="left-panel-toggle-drawer-button"
      >
        {!open ? (
          <CustomIcon
            component={ChevronRight}
            inheritViewBox
            color="grey.800"
            sx={{ fontSize: 11 }}
          />
        ) : (
          <CustomIcon
            component={ChevronLeft}
            inheritViewBox
            color="grey.800"
            sx={{ fontSize: 11 }}
          />
        )}
      </Paper>
    </Box>
  </Drawer>
);

export default LeftPanel;

MainMenuItem.propTypes = {
  menu: PropTypes.instanceOf(Object),
  open: PropTypes.bool,
  handleDrawerStatus: PropTypes.func,
};
MainMenuItem.defaultProps = {
  menu: {},
  open: false,
  handleDrawerStatus: defaultFnPropTypes,
};

LeftPanel.propTypes = {
  open: PropTypes.bool,
  handleDrawerStatus: PropTypes.func,
};
LeftPanel.defaultProps = {
  open: PropTypes.bool,
  handleDrawerStatus: PropTypes.func,
};
