import {
  Typography,
  Dialog,
  DialogContent,
  DialogTitle,
  DialogActions,
  Grid,
  Button,
  Box,
  IconButton,
} from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';

import classes from 'style/globalStyle.module.scss';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as checkMarkCircle } from 'assets/svg/checkmark-circle.svg';
import { ReactComponent as Close } from 'assets/svg/close.svg';

import strings from '../../../localization/translation';
import { openSuccessModal } from '../../../store/actions';

const { passwordChanged, passwordReset, ok } = strings;
const SuccessModal = () => {
  const dispatch = useDispatch();
  const isOpen = useSelector((state) => state.global.isOpen);

  const closeHandler = () => {
    dispatch(openSuccessModal(false));
  };

  return (
    <Dialog open={isOpen} maxWidth="sm" fullWidth data-testid="dialog">
      <DialogTitle>
        <Grid container>
          <Grid item xs={10}>
            <Typography component="span" variant="h1" color="grey.800">
              {passwordChanged}
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <Box display={{ xs: 'none', md: 'block' }}>
              <Typography align="right" gutterBottom>
                <IconButton
                  aria-label="close"
                  onClick={closeHandler}
                  size="large"
                  className={classes.closeIcon}
                >
                  <CustomIcon
                    component={Close}
                    color="grey.800"
                    inheritViewBox
                    sx={{ width: '14px', height: '14px' }}
                  />
                </IconButton>
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </DialogTitle>
      <DialogContent>
        <Grid container className={classes.circleIconGrid}>
          <Grid item xs={1}>
            <Typography variant="h1">
              <CustomIcon
                component={checkMarkCircle}
                inheritViewBox
                sx={{ fontSize: 20, color: '#30bc76' }}
              />
            </Typography>
          </Grid>
          <Grid item xs={11}>
            <Typography variant="p1" color="grey.650">
              {passwordReset}
            </Typography>
          </Grid>
        </Grid>
        <img
          className={classes.imgChangePass}
          src={`${process.env.PUBLIC_URL}/images/Chello_forgot_password_success.svg`}
          alt="Reset password success"
        />
      </DialogContent>
      <DialogActions>
        <Button
          color="primary"
          variant="contained"
          className={classes.saveButton}
          onClick={closeHandler}
        >
          {ok}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default SuccessModal;
