import { Grid, Tab, Tabs, Paper, Typography, Button, Box } from '@mui/material';
import PropTypes from 'prop-types';

import { a11yProps, defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import FHDClasses from 'style/FHDStyle.module.scss';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as ShareIcon } from 'assets/svg/share.svg';
import { primaryColor } from 'style/variables';

const {
  financialDashboard: FINANCIAL_DASHBOARD,
  summary: SUMMARY,
  cashFlow: CASH_FLOW,
  financials: FINANCIALS,
  yourPractice: YOUR_PRACTICE,
  didYouKnow: DID_YOU_KNOW,
  fsdHeaderSubtitle: HEADER_SUBTITLE,
  share: SHARE,
  fsdWelcome: WELCOME,
  drAustin: NAME,
} = strings;

const Head = (props) => {
  const { tabIndex, handleChange } = props;
  return (
    <Paper variant="dashboardHead">
      <Grid container>
        <Grid
          item
          sm={12}
          md={8}
          lg={6}
          p={2.5}
          pt={4}
          pb={0}
          container
          flexDirection="column"
          gap={{ sm: 0, md: '10px' }}
        >
          <Box
            display="flex"
            flexDirection={{ sm: 'row', md: 'column' }}
            gap={{ xs: '10px', md: 0 }}
          >
            <Typography
              component={Box}
              variant="h1"
              color="grey.900"
              sx={{ fontSize: '40px' }}
            >
              {WELCOME}
            </Typography>
            <Typography
              component={Box}
              variant="h1"
              color="grey.900"
              sx={{ fontSize: '40px' }}
            >
              {NAME}
            </Typography>
          </Box>
          <Box>
            <Tabs
              aria-label={FINANCIAL_DASHBOARD}
              indicatorColor="primary"
              value={tabIndex}
              onChange={handleChange}
              textColor="inherit"
              variant="scrollable"
              scrollButtons={false}
              sx={{ alignItems: 'flex-end' }}
            >
              <Tab
                label={SUMMARY}
                {...a11yProps(0)}
                className={classes.tabHeading}
                data-testid="one-account-all-tab"
              />
              <Tab
                label={CASH_FLOW}
                {...a11yProps(1)}
                className={classes.tabHeading}
                data-testid="one-account-chello-tab"
              />
              <Tab
                label={FINANCIALS}
                {...a11yProps(2)}
                className={classes.tabHeading}
                data-testid="one-account-linked-tab"
              />
              <Tab
                label={YOUR_PRACTICE}
                {...a11yProps(3)}
                className={classes.tabHeading}
                data-testid="one-account-linked-tab"
                wrapped
              />
            </Tabs>
          </Box>
        </Grid>
        <Grid
          item
          sm={12}
          md={4}
          lg={6}
          className={FHDClasses.rightHomePart}
          px={2.5}
          py="10px"
          container
        >
          <Box
            display="flex"
            flexDirection="column"
            gap="10px"
            flexWrap="wrap"
            alignSelf={{ sm: 'auto', md: 'flex-end' }}
            maxWidth={{ md: '100%', lg: '50%' }}
          >
            <Typography component={Box} variant="p1SemiBold" color="grey.900">
              {DID_YOU_KNOW}
            </Typography>
            <Box
              display="flex"
              flexDirection={{ sm: 'row', md: 'column' }}
              gap="20px"
              justifyContent="space-between"
            >
              <Typography component={Box} variant="p3" color="grey.900">
                {HEADER_SUBTITLE}
              </Typography>
              <Button
                color="regular"
                size="small"
                className={FHDClasses.shareButton}
                startIcon={
                  <CustomIcon
                    component={ShareIcon}
                    inheritViewBox
                    sx={{ fontSize: 20, color: primaryColor, pl: 0 }}
                  />
                }
              >
                {SHARE}
              </Button>
            </Box>
            <Box className={FHDClasses.promotionalImgBlk}>
              <img
                src={`${process.env.PUBLIC_URL}/images/fhd-1-md.png`}
                alt="info"
                data-testid="info-icon"
              />
            </Box>
            <Box className={FHDClasses.promotionalImgBlkLg}>
              <img
                src={`${process.env.PUBLIC_URL}/images/fhd-1.png`}
                alt="info"
                data-testid="info-icon"
              />
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Paper>
  );
};

Head.propTypes = {
  tabIndex: PropTypes.number,
  handleChange: PropTypes.func,
};

Head.defaultProps = {
  tabIndex: 0,
  handleChange: defaultFnPropTypes,
};
export default Head;
