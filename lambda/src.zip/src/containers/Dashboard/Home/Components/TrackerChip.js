import PropTypes from 'prop-types';
import { Chip } from '@mui/material';

import { ReactComponent as TrendingUp } from 'assets/svg/trending-up.svg';
import { ReactComponent as TrendingDown } from 'assets/svg/trending-down.svg';
import CustomIcon from 'components/UIElements/CustomIcon';

const TrackerChip = (props) => {
  const { trendingUp, label, ...rest } = props;
  return (
    <Chip
      sx={
        trendingUp
          ? { bgcolor: '#DBFFD8', color: '#15894F', px: '2px', py: '5px' }
          : { bgcolor: '#FFD8DF', color: '#FF0000', px: '2px', py: '5px' }
      }
      icon={
        <CustomIcon
          component={trendingUp ? TrendingUp : TrendingDown}
          inheritViewBox
          sx={{
            height: '10px',
            color: trendingUp ? '#15894F' : '#FF0000',
          }}
        />
      }
      label={label}
      size="medium"
      {...rest}
    />
  );
};

TrackerChip.propTypes = {
  trendingUp: PropTypes.bool,
  label: PropTypes.node,
};
TrackerChip.defaultProps = {
  trendingUp: false,
  label: '',
};

export default TrackerChip;
