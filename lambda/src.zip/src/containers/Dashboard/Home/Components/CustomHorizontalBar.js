import PropTypes from 'prop-types';
import { Typography, Box } from '@mui/material';

import { HorizontalBarWithLabel } from 'components';

const CustomHorizontalBar = ({ title, series }) => (
  <>
    {title && (
      <Typography variant="p2SemiBold" component="p" color="grey.900" mb={1}>
        {title}
      </Typography>
    )}
    <Box display="flex" flexDirection="column" gap={1} position="relative">
      {series.map((ele, index) => (
        <HorizontalBarWithLabel value={72} {...ele} key={index} />
      ))}
    </Box>
  </>
);

CustomHorizontalBar.propTypes = {
  title: PropTypes.string,
  series: PropTypes.array,
};

CustomHorizontalBar.defaultProps = {
  title: '',
  series: [],
};

export default CustomHorizontalBar;
