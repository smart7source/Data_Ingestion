import { Typography, Box } from '@mui/material';

const CustomLegends = () => (
  <Box
    mt="auto"
    display="flex"
    borderTop="3px solid"
    borderColor="grey.300"
    pt={2}
    flexWrap="wrap"
    gap="20px"
  >
    <Box display="flex">
      <Typography
        component={Box}
        width="30px"
        height="15px"
        borderRadius="10px"
        sx={{ backgroundColor: 'primary.main' }}
        color="grey.100"
        mr={1}
      >
        .
      </Typography>
      <Typography variant="p3" component="span" color="grey.800">
        Your business
      </Typography>
    </Box>
    <Box display="flex">
      <Typography
        component={Box}
        width="30px"
        height="15px"
        borderRadius="10px"
        sx={{ backgroundColor: 'secondary.main' }}
        color="grey.100"
        mr={1}
      >
        .
      </Typography>
      <Typography variant="p3" component="span" color="grey.800">
        Industry standard
      </Typography>
    </Box>
  </Box>
);

export default CustomLegends;
