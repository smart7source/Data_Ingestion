import PropTypes from 'prop-types';
import { Box, Grid, Typography } from '@mui/material';

import classes from 'style/DashboardStyle.module.scss';
import strings from 'localization/translation';
import { howDoingDetail } from 'utils/Charts/Summary';

const {
  howDoingHeading: HOW_I_AM_DOING,
  rockyWaters: ROCKY_WATERS,
  smoothSailing: SMOOTH_SAILING,
  outOfThisWorld: OUT_OF_THIS_WORLD,
} = strings;

const getSliderClass = (variant) => {
  if (variant === 'top') {
    return classes.howDoingSliderTop;
  }
  if (variant === 'average') {
    return classes.howDoingSliderAvg;
  }
  return classes.howDoingSliderBottom;
};

const HowIamDoing = (props) => {
  const { variant } = props;
  const { image, heading, subHeading } = howDoingDetail[variant];
  const sliderClass = getSliderClass(variant);

  return (
    <Box className={classes.howDoingContainer} pt={{ xs: 2, md: 0 }}>
      <Typography variant="h3" color="grey.900">
        {HOW_I_AM_DOING}
      </Typography>
      <Grid
        item
        xs
        container
        spacing={3}
        justifyContent="center"
        flexDirection="column"
      >
        <Grid item xs="auto" container justifyContent="center">
          <img
            src={`${process.env.PUBLIC_URL}/images/${image}`}
            alt="how-i-am-doing"
          />
        </Grid>
        <Grid item xs="auto">
          <Typography
            component="h2"
            variant="h2"
            color="grey.800"
            textAlign="center"
          >
            {heading}
          </Typography>
        </Grid>
        <Grid item xs="auto">
          {' '}
          <Typography
            component="p"
            variant="p3"
            color="grey.800"
            textAlign="center"
          >
            {subHeading}
          </Typography>
        </Grid>
        <Grid item xs="auto" className={sliderClass}>
          <Box className={classes.slider}>
            <Box className={classes.sliderBar} />
          </Box>
          <Box className={classes.pointer} />
        </Grid>
        <Grid
          item
          xs="auto"
          container
          justifyContent="space-between"
          sx={{ pt: 0 }}
        >
          <Grid item xs={3}>
            <Typography variant="p3" color="grey.800" textAlign="center">
              {ROCKY_WATERS}
            </Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography variant="p3" color="grey.800" textAlign="center">
              {SMOOTH_SAILING}
            </Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography variant="p3" color="grey.800" textAlign="center">
              {OUT_OF_THIS_WORLD}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
};

HowIamDoing.propTypes = {
  variant: PropTypes.string.isRequired,
};

export default HowIamDoing;
