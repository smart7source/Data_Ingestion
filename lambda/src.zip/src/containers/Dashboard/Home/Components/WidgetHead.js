import { Typography, Grid, Button, Box } from '@mui/material';
import PropTypes from 'prop-types';
import React from 'react';
import { Link as RouterLink } from 'react-router-dom';

import { ReactComponent as ArrowRight } from 'assets/svg/arrow-right-1.svg';
import { whiteToBlackColor, h3Headline } from 'style/variables';
import ShowInfo from 'containers/OneAccount/ShowInfo';
import { CustomIcon, KebabMenu } from 'components';
import { defaultFnPropTypes } from 'utils';
import { kebabMenuOptions } from 'utils/Charts';
import { ReactComponent as Info } from 'assets/svg/info.svg';

const WidgetHead = ({
  heading,
  headingAction,
  subHeading,
  callToAction,
  infoIcon,
  filter,
  handleMenuClick,
}) => {
  const subHeadingEle = React.isValidElement(subHeading);
  return (
    <Box display="flex">
      <Grid container mb={2} gap={{ xs: '10px', md: 0 }}>
        {heading && (
          <Grid
            item
            xs={12}
            md={filter ? 6 : 12}
            container
            alignItems="center"
            gap={1}
          >
            {headingAction ? (
              <>
                <Button
                  variant="text"
                  component={RouterLink}
                  to={headingAction}
                  sx={{ ...h3Headline, color: whiteToBlackColor[900], pl: 0 }}
                  endIcon={
                    <CustomIcon
                      component={ArrowRight}
                      color="primary.main"
                      inheritViewBox
                      sx={{ fontSize: '16px' }}
                    />
                  }
                >
                  {heading}
                </Button>
                {infoIcon && (
                  <CustomIcon
                    component={Info}
                    inheritViewBox
                    data-testid="info-icon"
                    sx={{ fontSize: '20px' }}
                  />
                )}
              </>
            ) : (
              <Box display="flex" alignItems="center" flexBasis="100%" gap={1}>
                <Typography variant="h3" component="span" color="grey.900">
                  {heading}
                </Typography>
                {infoIcon && (
                  <CustomIcon
                    component={Info}
                    inheritViewBox
                    data-testid="info-icon"
                    sx={{ fontSize: '20px' }}
                  />
                )}
              </Box>
            )}
            <Box display="flex" flexBasis="100%">
              {subHeading && !subHeadingEle && (
                <Typography
                  variant="p3"
                  component="p"
                  color="grey.900"
                  mt={0}
                  dangerouslySetInnerHTML={{ __html: subHeading }}
                />
              )}
              {subHeading && subHeadingEle && subHeading}
            </Box>
          </Grid>
        )}
        {filter && (
          <Grid
            item
            xs={12}
            md={6}
            container
            justifyContent={{ xs: 'flex-start', md: 'flex-end' }}
          >
            {filter}
          </Grid>
        )}
      </Grid>
      {callToAction && (
        <Box>
          <KebabMenu
            options={kebabMenuOptions}
            onMenuOptionClick={handleMenuClick}
          />
        </Box>
      )}
    </Box>
  );
};

export default WidgetHead;

WidgetHead.propTypes = {
  heading: PropTypes.string,
  callToAction: PropTypes.bool,
  filter: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  subHeading: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  headingAction: PropTypes.string,
  infoIcon: PropTypes.bool,
  handleMenuClick: PropTypes.func,
};

WidgetHead.defaultProps = {
  heading: '',
  callToAction: true,
  filter: '',
  subHeading: '',
  headingAction: '',
  infoIcon: false,
  handleMenuClick: defaultFnPropTypes,
};
