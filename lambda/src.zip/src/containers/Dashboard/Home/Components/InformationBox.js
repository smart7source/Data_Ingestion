import { Typography, Box, Paper } from '@mui/material';
import PropTypes from 'prop-types';
import { styled } from '@mui/styles';
import NumberFormat from 'react-number-format';

const Item = styled(Paper)(({ theme }) => ({
  border: '2px solid',
  padding: theme.spacing(2),
  textAlign: 'left',
  borderColor: theme.palette.grey[400],
  borderRadius: '10px',
}));

const InformationBox = ({ text, value }) => (
  <Item variant="outlined">
    <Box display="flex" rowGap={1} flexDirection="column">
      {text && (
        <Box>
          <Typography variant="p3SemiBold" component="p" color="grey.900">
            {text}
          </Typography>
        </Box>
      )}
      {value && (
        <Box>
          <Typography variant="h2" component="p" color="grey.900">
            <NumberFormat
              value={value}
              displayType="text"
              thousandSeparator
              prefix="$"
            />
          </Typography>
        </Box>
      )}
    </Box>
  </Item>
);

export default InformationBox;

InformationBox.propTypes = {
  text: PropTypes.string,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

InformationBox.defaultProps = {
  text: '',
  value: '',
};
