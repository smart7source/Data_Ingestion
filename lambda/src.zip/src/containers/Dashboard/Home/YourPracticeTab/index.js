import { Grid, Paper, Box, Typography } from '@mui/material';
import NumberFormat from 'react-number-format';

import Tracker510 from 'containers/Dashboard/Home/Trackers/Tracker510';
import Tracker511 from 'containers/Dashboard/Home/Trackers/Tracker511';
import {
  transactInsuranceData,
  totalClaimsData,
  rejectionsData,
  proceduresData,
  diagnosesData,
} from 'utils/Charts/YourPractice';

import {
  Diagnoses,
  Procedures,
  Rejection,
  TotalClaims,
  TransactInsurance,
  YourPractice,
} from '../Trackers';
import TrackerChip from '../Components/TrackerChip';

const YourPracticeTab = () => (
  <Grid container spacing={2}>
    <Grid item xs={12}>
      <YourPractice />
    </Grid>
    <Grid item container xs={12} spacing={1}>
      <Grid item xs={6} sm={4} md={2}>
        <Paper variant="dashboard" sx={{ paddingY: 4, height: '100%' }}>
          <Box display="flex" rowGap={1} flexDirection="column">
            <Box>
              <Typography variant="p2SemiBold" component="p" color="grey.900">
                Total outstanding claims
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" flexWrap="wrap">
              <Typography variant="h2" component="span" color="grey.900" mr={1}>
                <NumberFormat value="46" displayType="text" thousandSeparator />
              </Typography>
              <TrackerChip label="4 (8.6%)" trendingUp />
            </Box>
            <Box>
              <Typography variant="p3SemiBold" component="p">
                *older than 3 weeks
              </Typography>
            </Box>
          </Box>
        </Paper>
      </Grid>
      <Grid item xs={6} sm={4} md={2}>
        <Paper variant="dashboard" sx={{ paddingY: 4, height: '100%' }}>
          <Box display="flex" rowGap={1} flexDirection="column">
            <Box>
              <Typography variant="p2SemiBold" component="p" color="grey.900">
                Claims submitted
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" flexWrap="wrap">
              <Typography variant="h2" component="span" mr={1}>
                345.45K
              </Typography>
              <TrackerChip label="14k (4%)" trendingUp={false} />
            </Box>
          </Box>
        </Paper>
      </Grid>
      <Grid item xs={6} sm={4} md={2}>
        <Paper variant="dashboard" sx={{ paddingY: 4, height: '100%' }}>
          <Box display="flex" rowGap={1} flexDirection="column">
            <Box>
              <Typography variant="p2SemiBold" component="p" color="grey.900">
                Total charges
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" flexWrap="wrap">
              <Typography variant="h2" component="span" mr={1}>
                <NumberFormat
                  value="42.31"
                  displayType="text"
                  prefix="$"
                  suffix="M"
                />
              </Typography>
              <TrackerChip label="5k (10%)" trendingUp />
            </Box>
          </Box>
        </Paper>
      </Grid>
      <Grid item xs={6} sm={4} md={2}>
        <Paper variant="dashboard" sx={{ paddingY: 4, height: '100%' }}>
          <Box display="flex" rowGap={1} flexDirection="column">
            <Box>
              <Typography variant="p2SemiBold" component="p" color="grey.900">
                Clean claim rate
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" flexWrap="wrap">
              <Typography variant="h2" component="span" mr={1}>
                <NumberFormat value="97.47" displayType="text" suffix="%" />
              </Typography>
              <TrackerChip label="3.5%" trendingUp />
            </Box>
          </Box>
        </Paper>
      </Grid>
      <Grid item xs={6} sm={4} md={2}>
        <Paper variant="dashboard" sx={{ paddingY: 4, height: '100%' }}>
          <Box display="flex" rowGap={1} flexDirection="column">
            <Box>
              <Typography variant="p2SemiBold" component="p" color="grey.900">
                TPS rejection
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" flexWrap="wrap">
              <Typography variant="h2" component="span" mr={1}>
                <NumberFormat value="0.07" displayType="text" suffix="%" />
              </Typography>
              <TrackerChip label="0.02%" trendingUp={false} />
            </Box>
          </Box>
        </Paper>
      </Grid>
      <Grid item xs={6} sm={4} md={2}>
        <Paper variant="dashboard" sx={{ paddingY: 4, height: '100%' }}>
          <Box display="flex" rowGap={1} flexDirection="column">
            <Box>
              <Typography variant="p2SemiBold" component="p" color="grey.900">
                Payer rejection
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" flexWrap="wrap">
              <Typography variant="h2" component="span" mr={1}>
                <NumberFormat value="0.46" displayType="text" suffix="%" />
              </Typography>
              <TrackerChip label="0.4%" trendingUp />
            </Box>
          </Box>
        </Paper>
      </Grid>
    </Grid>

    <Grid item xs={12} sm={12} md={6}>
      <TransactInsurance data={transactInsuranceData} />
    </Grid>
    <Grid item xs={12} sm={12} md={6}>
      <TotalClaims data={totalClaimsData} />
    </Grid>
    <Grid item xs={12} sm={6} md={6}>
      <Tracker510 />
    </Grid>
    <Grid item xs={12} sm={6} md={6}>
      <Tracker511 />
    </Grid>
    <Grid item xs={12} sm={12} md={4}>
      <Rejection data={rejectionsData} />
    </Grid>
    <Grid item xs={12} sm={12} md={4}>
      <Procedures data={proceduresData} />
    </Grid>
    <Grid item xs={12} sm={12} md={4}>
      <Diagnoses data={diagnosesData} />
    </Grid>
  </Grid>
);

export default YourPracticeTab;
