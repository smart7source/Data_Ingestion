/* eslint-disable react/no-this-in-sfc */
import { Grid, Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { useRef } from 'react';
import PropTypes from 'prop-types';

import { MuiSelectBox } from 'components';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import { errorColor, whiteToBlackColor } from 'style/variables';
import { pieSettings } from 'utils/Charts/Templates/PieSettings';
import { monthDropDownOptions } from 'utils/Charts/Summary';

const defaultSettings = pieSettings();

const TotalClaims = (props) => {
  const { data } = props;
  const chart = useRef(null);
  const options = {
    ...pieSettings(
      {
        legend: {
          enabled: true,
        },

        tooltip: {
          ...defaultSettings.tooltip,
          padding: 10,
          useHTML: true,
          formatter() {
            return `<p class=${classes.tooltipHeader}>${this.key}</p><p class=${
              classes.tooltipBody
            }>${Math.round(this.percentage)}% of all transactions</p>`;
          },
        },
        colors: [whiteToBlackColor[500], errorColor],
        series: [
          {
            name: 'Plaid',

            data: data.claims,
          },
        ],
      },
      data.total,
      'Total claims',
    ),
  };

  const handleMenuClick = (option) => {
    if (option.value === 'jpeg') {
      chart.current.chart.exportChart({
        type: 'image/jpeg',
      });
    } else if (option.value === 'pdf') {
      chart.current.chart.exportChart({
        type: 'application/pdf',
      });
    } else if (option.value === 'xls') {
      chart.current.chart.downloadXLS();
    }
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={strings.tracker512Heading}
        filter={
          <>
            <Grid item width="165px">
              <MuiSelectBox
                options={monthDropDownOptions}
                name="filter"
                id="filter"
                value="4"
                margin="none"
                callback={(e) => {
                  e.preventDefault();
                }}
              />
            </Grid>
          </>
        }
        callToAction
        handleMenuClick={handleMenuClick}
      />
      {options &&
        options.series &&
        options.series.length > 0 &&
        options.series[0].data &&
        options.series[0].data.length > 0 && (
          <HighchartsReact
            highcharts={Highcharts}
            options={options}
            ref={chart}
          />
        )}
    </Paper>
  );
};

export default TotalClaims;

TotalClaims.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};
