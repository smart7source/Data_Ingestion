import { Grid, Paper, Box } from '@mui/material';

import { routePath } from 'routes';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { tracker205Options, monthDropDownOptions } from 'utils/Charts/Summary';
import strings from 'localization/translation';
import { MuiSelectBox } from 'components';

import CustomHorizontalBar from '../../Components/CustomHorizontalBar';
import CustomLegends from '../../Components/CustomLegends';

const { tracker205Heading: YOUR_PRACTICE } = strings;

const Tracker205 = () => (
  <Paper
    variant="dashboard"
    component={Box}
    display="flex"
    flexDirection="column"
    height="100%"
  >
    <WidgetHead
      heading={YOUR_PRACTICE}
      headingAction={routePath.ACCOUNT_OVERVIEW}
      filter={
        <>
          <Grid item width="165px">
            <MuiSelectBox
              options={monthDropDownOptions}
              name="filter"
              id="filter"
              value="4"
              margin="none"
              callback={(e) => {
                console.log(e.target.value);
              }}
            />
          </Grid>
        </>
      }
      callToAction
    />
    <Box display="flex" flexDirection="column" gap="20px" flexGrow="1">
      <Grid container rowSpacing={3}>
        {tracker205Options.map((ele, index) => (
          <Grid item xs={12} key={index}>
            <CustomHorizontalBar {...ele} />
          </Grid>
        ))}
      </Grid>
      <CustomLegends />
    </Box>
  </Paper>
);

export default Tracker205;
