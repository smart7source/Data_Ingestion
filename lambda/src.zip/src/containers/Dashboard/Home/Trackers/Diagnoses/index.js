/* eslint-disable react/no-this-in-sfc */
import { Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import PropTypes from 'prop-types';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import classes from 'style/DashboardStyle.module.scss';
import { brandColors, whiteToBlackColor } from 'style/variables';
import strings from 'localization/translation';
import { pieSettings } from 'utils/Charts/Templates/PieSettings';

const defaultSettings = pieSettings();

const Diagnoses = (props) => {
  const { data } = props;

  const options = {
    ...pieSettings(
      {
        legend: {
          itemMarginBottom: 5,
        },
        tooltip: {
          ...defaultSettings.tooltip,
          padding: 10,
          useHTML: true,
          formatter() {
            return `<p class=${classes.tooltipHeader}>${this.key}</p><p class=${
              classes.tooltipBody
            }>${Math.round(this.percentage)}% of all diagnosis codes</p>`;
          },
        },
        colors: [
          brandColors[600],
          brandColors[500],
          whiteToBlackColor[500],
          brandColors[200],
          whiteToBlackColor[400],
        ],
        series: [
          {
            name: 'Plaid',

            data: data.diagnoses,
          },
        ],
      },
      '',
      'Diagnosis<br />codes',
    ),
  };
  return (
    <Paper variant="dashboard">
      <WidgetHead heading={strings.tracker515Heading} />
      {options &&
        options.series &&
        options.series.length > 0 &&
        options.series[0].data &&
        options.series[0].data.length > 0 && (
          <HighchartsReact highcharts={Highcharts} options={options} />
        )}
    </Paper>
  );
};

export default Diagnoses;

Diagnoses.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};
