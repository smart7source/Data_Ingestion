import { Grid, Paper, Typography, Box } from '@mui/material';
import NumberFormat from 'react-number-format';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import FHDClasses from 'style/FHDStyle.module.scss';

import TrackerChip from '../../Components/TrackerChip';

export const defaultOptions = [
  { name: 'Monthly', value: '1' },
  { name: 'Quarterly', value: '2' },
  { name: 'Yearly', value: '3' },
];

const Receiveables = () => (
  <Paper variant="dashboard">
    <WidgetHead
      heading={strings.tracker403Heading}
      subHeading={strings.tracker403SubHeading}
      infoIcon
    />
    <Grid container>
      <Grid
        item
        xs={12}
        py={1.2}
        borderBottom="1px solid"
        borderColor="grey.400"
        container
        gap="15px"
        flexDirection="row"
      >
        <Box>
          <Typography variant="h2" component="p" color="grey.900">
            <NumberFormat
              value="70000"
              displayType="text"
              thousandSeparator
              prefix="$"
            />
          </Typography>
        </Box>
        <Box>
          <TrackerChip trendingUp label="Up 10% since last week" />
        </Box>
      </Grid>
      <Grid item xs={12} paddingY={1.2}>
        <Typography
          variant="p2SemiBold"
          component="p"
          color="grey.900"
          mb={1.5}
        >
          Upcoming payments due:
        </Typography>
        <Grid container rowGap={2}>
          <Grid item container xs={12} alignItems="baseline">
            <Grid item xs={2} sm={3} md={2}>
              <Box className={FHDClasses.dateBox} px={2} py={1}>
                <Typography variant="p2SemiBold" component="p" color="grey.900">
                  4
                </Typography>
                <Typography
                  variant="p2SemiBold"
                  component="p"
                  color="grey.900"
                  whiteSpace="nowrap"
                  overflow="hidden"
                  textOverflow="ellipsis"
                >
                  APRIL
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={5} sm={4} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                Insurance 1
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Insurance companies
              </Typography>
            </Grid>
            <Grid item xs={5} sm={5} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="#197F4C">
                <NumberFormat
                  value="23000"
                  displayType="text"
                  thousandSeparator
                  prefix="$"
                />
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Deposit to Chase Business *1111
              </Typography>
            </Grid>
          </Grid>
          <Grid item container xs={12} alignItems="baseline">
            <Grid item xs={2} sm={3} md={2}>
              <Box className={FHDClasses.dateBox} px={2} py={1}>
                <Typography variant="p2SemiBold" component="p" color="grey.800">
                  17
                </Typography>
                <Typography
                  variant="p2SemiBold"
                  component="p"
                  color="grey.800"
                  whiteSpace="nowrap"
                  overflow="hidden"
                  textOverflow="ellipsis"
                >
                  APRIL
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={5} sm={4} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                Example medical
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Medical Company
              </Typography>
            </Grid>
            <Grid item xs={5} sm={5} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="#197F4C">
                <NumberFormat
                  value="2983"
                  displayType="text"
                  thousandSeparator
                  prefix="$"
                />
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Deposit to Chase Business *1111
              </Typography>
            </Grid>
          </Grid>
          <Grid item container xs={12} alignItems="baseline">
            <Grid item xs={2} sm={3} md={2}>
              <Box className={FHDClasses.dateBox} px={2} py={1}>
                <Typography variant="p2SemiBold" component="p" color="grey.800">
                  22
                </Typography>
                <Typography
                  variant="p2SemiBold"
                  component="p"
                  color="grey.800"
                  whiteSpace="nowrap"
                  overflow="hidden"
                  textOverflow="ellipsis"
                >
                  APRIL
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={5} sm={4} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                Insurance 2
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Insurance companies
              </Typography>
            </Grid>
            <Grid item xs={5} sm={5} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="#197F4C">
                <NumberFormat
                  value="3293"
                  displayType="text"
                  thousandSeparator
                  prefix="$"
                />
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Deposit to Chase Business *1111
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  </Paper>
);

export default Receiveables;
