import { Grid, Paper, Box } from '@mui/material';
import { useForm } from 'react-hook-form';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import InformationBox from 'containers/Dashboard/Home/Components/InformationBox';
import { tracker404Options } from 'utils/Charts/Financials';
import { DatePicker } from 'components';
import globalClasses from 'style/globalStyle.module.scss';
import { minDate } from 'utils';

import CustomHorizontalBar from '../../Components/CustomHorizontalBar';
import CustomLegends from '../../Components/CustomLegends';

const Tracker404 = () => {
  const { control, watch } = useForm();

  const toMinDate = watch('profitLossFromDate')
    ? new Date(watch('profitLossFromDate'))
    : new Date(minDate);

  const fromMaxDate = watch('profitLossToDate')
    ? new Date(watch('profitLossToDate'))
    : undefined;
  return (
    <Paper
      variant="dashboard"
      component={Box}
      display="flex"
      flexDirection="column"
      height="100%"
    >
      <WidgetHead
        heading={strings.tracker404Heading}
        callToAction
        filter={
          <Box display="flex" gap={1}>
            <DatePicker
              id="profitLossFromDate"
              name="profitLossFromDate"
              control={control}
              dataTestid="profit-loss-from-date"
              maxDateValue={fromMaxDate}
              returnDateFormat="yyyy-MM-DD"
              placeHolder="From"
              margin="none"
              classes={globalClasses.dashboardDatePicker}
            />

            <DatePicker
              id="profitLossToDate"
              name="profitLossToDate"
              control={control}
              dataTestid="profit-loss-to-date"
              minDateValue={toMinDate}
              returnDateFormat="yyyy-MM-DD"
              placeHolder="To"
              margin="none"
              classes={globalClasses.dashboardDatePicker}
            />
          </Box>
        }
      />
      <Box gap="16px" flexDirection="column" display="flex">
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <InformationBox text="Profit and Loss" value="135961" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InformationBox text="Operating profit" value="135961" />
          </Grid>
        </Grid>
        <Grid container rowSpacing={3} mb={2}>
          {tracker404Options.map((ele, index) => (
            <Grid item xs={12} key={index}>
              <CustomHorizontalBar {...ele} />
            </Grid>
          ))}
        </Grid>
      </Box>
      <CustomLegends />
    </Paper>
  );
};

export default Tracker404;
