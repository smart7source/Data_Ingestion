import { Grid, Paper, Typography, Box } from '@mui/material';
import NumberFormat from 'react-number-format';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import FHDClasses from 'style/FHDStyle.module.scss';

import TrackerChip from '../../Components/TrackerChip';

export const defaultOptions = [
  { name: 'Monthly', value: '1' },
  { name: 'Quarterly', value: '2' },
  { name: 'Yearly', value: '3' },
];

const Payables = () => (
  <Paper variant="dashboard">
    <WidgetHead
      heading={strings.tracker402Heading}
      subHeading={strings.tracker402SubHeading}
      infoIcon
    />
    <Grid container>
      <Grid
        item
        xs={12}
        py={1.2}
        borderBottom="1px solid"
        borderColor="grey.400"
        container
        gap="15px"
        flexDirection="row"
      >
        <Box>
          <Typography variant="h2" component="p" color="grey.900">
            <NumberFormat
              value="52783"
              displayType="text"
              thousandSeparator
              prefix="$"
            />
          </Typography>
        </Box>
        <Box>
          <TrackerChip trendingUp label="Up 10% since last week" />
        </Box>
      </Grid>
      <Grid item xs={12} paddingY={1.2}>
        <Typography
          variant="p2SemiBold"
          color="grey.900"
          component="p"
          mb={1.5}
        >
          Upcoming payments due:
        </Typography>
        <Grid container rowGap={2}>
          <Grid item container xs={12} alignItems="baseline">
            <Grid item xs={2} sm={3} md={2}>
              <Box className={FHDClasses.dateBox} px={2} py={1}>
                <Typography variant="p2SemiBold" color="grey.800" component="p">
                  1
                </Typography>
                <Typography
                  variant="p2SemiBold"
                  component="p"
                  color="grey.800"
                  whiteSpace="nowrap"
                  overflow="hidden"
                  textOverflow="ellipsis"
                >
                  APRIL
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={5} sm={4} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                Rent
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Overhead / Rent
              </Typography>
            </Grid>
            <Grid item xs={5} sm={5} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                <NumberFormat
                  value="36848"
                  displayType="text"
                  thousandSeparator
                  prefix="$"
                />
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Chase Business *1111
              </Typography>
            </Grid>
          </Grid>
          <Grid item container xs={12} alignItems="baseline">
            <Grid item xs={2} sm={3} md={2}>
              <Box className={FHDClasses.dateBox} px={2} py={1}>
                <Typography variant="p2SemiBold" component="p" color="grey.800">
                  15
                </Typography>
                <Typography
                  variant="p2SemiBold"
                  component="p"
                  color="grey.800"
                  whiteSpace="nowrap"
                  overflow="hidden"
                  textOverflow="ellipsis"
                >
                  APRIL
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={5} sm={4} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                Verizon
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Tech subscriptions
              </Typography>
            </Grid>
            <Grid item xs={5} sm={5} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                <NumberFormat
                  value="57.98"
                  displayType="text"
                  thousandSeparator
                  prefix="$"
                />
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Autopay on Chase Business *1111
              </Typography>
            </Grid>
          </Grid>
          <Grid item container xs={12} alignItems="baseline">
            <Grid item xs={2} sm={3} md={2}>
              <Box className={FHDClasses.dateBox} px={2} py={1}>
                <Typography variant="p2SemiBold" component="p" color="grey.800">
                  30
                </Typography>
                <Typography
                  variant="p2SemiBold"
                  component="p"
                  color="grey.800"
                  whiteSpace="nowrap"
                  overflow="hidden"
                  textOverflow="ellipsis"
                >
                  APRIL
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={5} sm={4} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                Cleaning Service
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Other
              </Typography>
            </Grid>
            <Grid item xs={5} sm={5} md={5} px={2}>
              <Typography variant="p1SemiBold" component="p" color="grey.900">
                <NumberFormat
                  value="305"
                  displayType="text"
                  thousandSeparator
                  prefix="$"
                />
              </Typography>
              <Typography variant="p3" component="p" color="grey.700">
                Autopay on Chase Business *1111
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  </Paper>
);

export default Payables;
