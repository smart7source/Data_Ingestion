/* eslint-disable react/no-this-in-sfc */
import { Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import PropTypes from 'prop-types';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { HCNumberFormat } from 'utils/Charts';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import { brandColors, whiteToBlackColor } from 'style/variables';
import { pieSettings } from 'utils/Charts/Templates/PieSettings';

const defaultSettings = pieSettings();

const TransactInsurance = (props) => {
  const { data } = props;
  const options = {
    ...pieSettings(
      {
        tooltip: {
          ...defaultSettings.tooltip,
          useHTML: true,
          formatter() {
            return `<p class=${classes.tooltipHeader}>${
              this.key
            } | ${HCNumberFormat({
              value: this.y,
            })}</p><p class=${classes.tooltipBody}>${
              Math.round(this.percentage * 10) / 10
            }% of all transactions</p>`;
          },
        },
        colors: [
          brandColors[500],
          whiteToBlackColor[400],
          whiteToBlackColor[500],
          whiteToBlackColor[400],
          whiteToBlackColor[300],
        ],
        series: [
          {
            name: 'Plaid',

            data: data.claims,
          },
        ],
      },
      data.total,
      'Total',
    ),
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead heading={strings.tracker59Heading} />
      {options &&
        options.series &&
        options.series.length > 0 &&
        options.series[0].data &&
        options.series[0].data.length > 0 && (
          <HighchartsReact highcharts={Highcharts} options={options} />
        )}
    </Paper>
  );
};

export default TransactInsurance;

TransactInsurance.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};
