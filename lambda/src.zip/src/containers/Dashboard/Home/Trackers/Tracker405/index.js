import { useForm } from 'react-hook-form';
import { Grid, Paper, Box } from '@mui/material';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import InformationBox from 'containers/Dashboard/Home/Components/InformationBox';
import { tracker405Options } from 'utils/Charts/Financials';
import { DatePicker } from 'components';
import globalClasses from 'style/globalStyle.module.scss';
import { minDate } from 'utils';

import CustomHorizontalBar from '../../Components/CustomHorizontalBar';
import CustomLegends from '../../Components/CustomLegends';

const Tracker405 = () => {
  const { control, watch } = useForm();

  const toMinDate = watch('balanceSheetFromDate')
    ? new Date(watch('balanceSheetFromDate'))
    : new Date(minDate);

  const fromMaxDate = watch('balanceSheetToDate')
    ? new Date(watch('balanceSheetToDate'))
    : undefined;
  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={strings.tracker405Heading}
        callToAction
        filter={
          <Box display="flex" gap={1}>
            <DatePicker
              id="balanceSheetFromDate"
              name="balanceSheetFromDate"
              control={control}
              dataTestid="balance-sheet-from-date"
              maxDateValue={fromMaxDate}
              returnDateFormat="yyyy-MM-DD"
              placeHolder="From"
              margin="none"
              classes={globalClasses.dashboardDatePicker}
            />

            <DatePicker
              id="balanceSheetToDate"
              name="balanceSheetToDate"
              control={control}
              dataTestid="balance-sheet-to-date"
              minDateValue={toMinDate}
              returnDateFormat="yyyy-MM-DD"
              placeHolder="To"
              margin="none"
              classes={globalClasses.dashboardDatePicker}
            />
          </Box>
        }
      />
      <Box gap="16px" flexDirection="column" display="flex">
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <InformationBox text="Net assets" value="2028574" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InformationBox text="Equity" value="2028574" />
          </Grid>
        </Grid>
        <Grid container rowSpacing={3} mb={2}>
          {tracker405Options.map((ele, index) => (
            <Grid item xs={12} key={index}>
              <CustomHorizontalBar {...ele} />
            </Grid>
          ))}
        </Grid>
      </Box>
      <CustomLegends />
    </Paper>
  );
};

export default Tracker405;
