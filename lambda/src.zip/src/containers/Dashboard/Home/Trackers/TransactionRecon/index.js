import {
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';

import classes from 'style/DashboardStyle.module.scss';
import strings from 'localization/translation';
import { primaryColor } from 'style/variables';
import { ReactComponent as InfoIcon } from 'assets/svg/info.svg';
import CustomIcon from 'components/UIElements/CustomIcon';

const {
  transReconHeading: TRANSACTION_RECONCILIATION,
  tableHeading1: CLAIM_ID,
  tableHeading2: SERVICE_DATE,
  tableHeading3: CO_PAY,
  tableHeading4: BALANCE,
  tableHeading5: INSURANCE,
  tableHeading6: STATUS,
} = strings;
const TransactionRecon = (props) => {
  const { data } = props;
  return (
    <Paper variant="dashboard">
      <Typography variant="h2" color="grey.900">
        {`${TRANSACTION_RECONCILIATION} (${data.length})`}
        <IconButton>
          <CustomIcon
            component={InfoIcon}
            color="grey.900"
            inheritViewBox
            sx={{ fontSize: 16 }}
          />
        </IconButton>
      </Typography>
      <Paper
        elevation={0}
        sx={{
          '&::-webkit-scrollbar': {
            height: '10px',
          },
          '&::-webkit-scrollbar-track': {
            backgroundColor: '#EAEAEA',
          },
          '&::-webkit-scrollbar-thumb': {
            backgroundColor: primaryColor,
            borderRadius: 2,
          },
        }}
        className={classes.transReconTableContainer}
      >
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>
                <Typography
                  variant="p1SemiBold"
                  component="p"
                  color="grey.1100"
                >
                  {CLAIM_ID}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography
                  variant="p1SemiBold"
                  component="p"
                  color="grey.1100"
                >
                  {SERVICE_DATE}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography
                  variant="p1SemiBold"
                  component="p"
                  color="grey.1100"
                >
                  {CO_PAY}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography
                  variant="p1SemiBold"
                  component="p"
                  color="grey.1100"
                >
                  {BALANCE}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography
                  variant="p1SemiBold"
                  component="p"
                  color="grey.1100"
                >
                  {INSURANCE}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography
                  variant="p2Paragraph"
                  component="p"
                  color="grey.800"
                >
                  {STATUS}
                </Typography>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data?.length &&
              data.map((claim, index) => {
                const {
                  claimID = 'Claim 000',
                  date = '',
                  copay = 0,
                  balance = 0,
                  insurance = '',
                  status = '',
                } = claim;
                const key = `${claimID}${index}`;

                return (
                  <TableRow key={key}>
                    <TableCell>
                      <Typography variant="p2" color="grey.800" component="p">
                        {claimID}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="p2" color="grey.800" component="p">
                        {date}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="p2" color="grey.800" component="p">
                        <NumberFormat
                          value={copay}
                          displayType="text"
                          // thousandSeparator
                          prefix="$ "
                          decimalScale="2"
                          fixedDecimalScale
                        />
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="p2" color="grey.800" component="p">
                        <NumberFormat
                          value={balance}
                          displayType="text"
                          // thousandSeparator
                          prefix="$ "
                          decimalScale="2"
                          fixedDecimalScale
                        />
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <img
                        src={`${process.env.PUBLIC_URL}/svg/insurance-${insurance}.svg`}
                        alt="insurance"
                      />
                    </TableCell>
                    <TableCell>
                      <Typography
                        variant="p2SemiBold"
                        color="grey.800"
                        component="p"
                      >
                        {status}
                      </Typography>
                    </TableCell>
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </Paper>
    </Paper>
  );
};

TransactionRecon.propTypes = {
  data: PropTypes.instanceOf(Array),
};

TransactionRecon.defaultProps = {
  data: [],
};

export default TransactionRecon;
