/* eslint-disable react/no-this-in-sfc */
/* eslint-disable no-useless-concat */
import { Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import PropTypes from 'prop-types';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import { brandColors, whiteToBlackColor } from 'style/variables';
import { pieSettings } from 'utils/Charts/Templates/PieSettings';
import { HCNumberFormat } from 'utils/Charts';

const defaultSettings = pieSettings();

const Rejection = (props) => {
  const { data } = props;

  const options = {
    ...pieSettings(
      {
        legend: {
          itemMarginBottom: 5,
          labelFormatter() {
            return `${this.name} <br /> ${HCNumberFormat({
              prefix: '',
              value: this.y,
              suffix: '%',
            })}`;
          },
        },
        tooltip: {
          ...defaultSettings.tooltip,
          padding: 10,
          useHTML: true,
          formatter() {
            return `<p class=${classes.tooltipHeader}>${this.key}</p><p class=${
              classes.tooltipBody
            }>${Math.round(this.percentage)}% of all rejections</p>`;
          },
        },
        colors: [
          brandColors[600],
          brandColors[500],
          whiteToBlackColor[500],
          brandColors[200],
          whiteToBlackColor[400],
        ],
        series: [
          {
            name: 'Plaid',

            data: data.rejections,
          },
        ],
      },
      '',
      'Total rejections',
    ),
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead heading={strings.tracker513Heading} callToAction />
      {options &&
        options.series &&
        options.series.length > 0 &&
        options.series[0].data &&
        options.series[0].data.length > 0 && (
          <HighchartsReact highcharts={Highcharts} options={options} />
        )}
    </Paper>
  );
};

export default Rejection;

Rejection.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};
