import { Grid, Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import strings from 'localization/translation';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import Bar from 'utils/Charts/Templates/Bar';
import {
  trnsFrmResTracker304,
  revenueAndExpenseFrequency,
} from 'utils/Charts/Cashflow';
import { MuiSelectBox } from 'components';

const { revenueAndExpheading: MONTHLY_REVENUE_AND_EXPENSE } = strings;

const options = Bar(trnsFrmResTracker304());

const RevenueAndExpense = () => (
  <Paper variant="dashboard">
    <WidgetHead
      heading={MONTHLY_REVENUE_AND_EXPENSE}
      subHeading="MON FEB 28 - FRI MAR 28"
      filter={
        <Grid item sx={{ maxWidth: '165px' }}>
          <MuiSelectBox
            options={revenueAndExpenseFrequency}
            name="filter"
            id="filter"
            value="thisYear"
            margin="none"
            callback={(e) => {
              e.preventDefault();
            }}
          />
        </Grid>
      }
      callToAction
    />
    <HighchartsReact highcharts={Highcharts} options={options} />
  </Paper>
);

export default RevenueAndExpense;
