import { Box, Grid, Paper, Typography } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { useForm } from 'react-hook-form';
import NumberFormat from 'react-number-format';
import PropTypes from 'prop-types';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { DatePicker } from 'components';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import { ReactComponent as TrendingUp } from 'assets/svg/trending-up.svg';
import { ReactComponent as TrendingDown } from 'assets/svg/trending-down.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { defaultPieSettings } from 'utils/Charts/Templates/PieSettings';
import { MoneyInOutLegendSettings } from 'utils/Charts/Cashflow';

const {
  moneyIn: MONEY_IN,
  thisWeek: THIS_WEEK,
  thisMonth: THIS_MONTH,
} = strings;

const defaultSettings = defaultPieSettings();

const MoneyIn = (props) => {
  const { data } = props;
  const { control } = useForm();
  const pieSettings = {
    ...defaultPieSettings({
      chart: {
        height: '60%',
        type: 'pie',
      },
      colors: ['#A120D1', '#828282', '#DCDCDC'],
      yAxis: {
        labels: {
          reserveSpace: false,
        },
      },
      xAxis: {
        labels: {
          reserveSpace: false,
        },
      },
      subtitle: {
        ...defaultSettings.subtitle,
        text: `<div class=${classes.pieSubtitle}><h1>$ ${data.total}</h1><h3>Money in</h3></div>`,
        x: -55,
        y: undefined,
        align: 'center',
        verticalAlign: 'middle',
      },
      legend: MoneyInOutLegendSettings(),
      tooltip: {
        distance: 0,
        // outside: true,
        useHTML: true,
        borderRadius: 8,
        backgroundColor: '#fff',
        borderColor: '#F5F5F5',
        headerFormat: '',
        pointFormat: `<b>{point.percentage:.1f}%</b><br/>{point.name}`,
      },
      series: [
        {
          name: 'Money in',
          size: '100%',
          innerSize: '75%',
          data: data.series,
        },
      ],
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 325,
            },
            chartOptions: {
              chart: {
                height: '100%',
              },
              subtitle: {
                x: 0,
                y: -40,
              },
              legend: {
                enabled: true,
                align: 'center',
                verticalAlign: 'bottom',
                layout: 'horizontal',
              },
            },
          },
        ],
      },
    }),
  };
  return (
    <Paper variant="dashboard">
      <WidgetHead heading={MONEY_IN} infoIcon callToAction />
      <Grid container>
        <Grid item xs={12} sm={4}>
          <Typography component="p" variant="p3" color="grey.900" mb={2}>
            {THIS_WEEK}
          </Typography>

          <Typography variant="h1" color="grey.900" mb={1}>
            <NumberFormat
              value={data.weekAmount}
              displayType="text"
              thousandSeparator
              prefix="$"
            />
          </Typography>

          <Box
            className={
              data.trendingUp ? classes.positiveTrend : classes.negativeTrend
            }
          >
            <Box>
              <CustomIcon
                component={data.trendingUp ? TrendingUp : TrendingDown}
                inheritViewBox
                color={data.trendingUp ? 'success' : 'error'}
                sx={{ height: '14px', pt: '4px' }}
              />
            </Box>
            <Box pl={1}>
              <Typography variant="p3" color="grey.900">
                {data.trendingUp
                  ? `Up ${data.weekPercentage}% since last week`
                  : `Down ${data.weekPercentage}% since last week`}
              </Typography>
            </Box>
          </Box>
        </Grid>
        <Grid item xs={12} sm={8} className={classes.cashFlowSummSep}>
          <Typography component="p" variant="p3" ml={1}>
            {THIS_MONTH}
          </Typography>
          <HighchartsReact highcharts={Highcharts} options={pieSettings} />
        </Grid>
      </Grid>
    </Paper>
  );
};

MoneyIn.propTypes = {
  data: PropTypes.object,
};

MoneyIn.defaultProps = {
  data: {},
};

export default MoneyIn;
