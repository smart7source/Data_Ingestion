/* eslint-disable react/no-this-in-sfc */
/* eslint-disable camelcase */
import { Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import HC_exporting from 'highcharts/modules/exporting';
import HC_export_data from 'highcharts/modules/export-data';
import borderRadius from 'highcharts-border-radius';
import PropTypes from 'prop-types';
import { useRef } from 'react';

import { routePath } from 'routes';
import { pieSettings } from 'utils/Charts/Templates/PieSettings';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { HCNumberFormat } from 'utils/Charts';
import strings from 'localization/translation';
import { transformAccountOverData } from 'utils/Charts/Summary';

// init the module
HC_exporting(Highcharts);
HC_export_data(Highcharts);
borderRadius(Highcharts);
Highcharts.setOptions({
  lang: {
    thousandsSep: ',',
  },
});
const defaultSettings = pieSettings();

const AccountOverview = ({ data }) => {
  const chart = useRef(null);
  const options = {
    ...pieSettings(
      {
        tooltip: {
          ...defaultSettings.tooltip,
          useHTML: true,
          formatter() {
            return `<div style='display: flex; min-width: 100px;'><div>${
              this.point.custom.extraInformation
            }</div><div style='padding-left: 10px'><div>${
              this.key
            }</div><div><b>${HCNumberFormat({
              value: this.y,
            })}</b></div></div></div>`;
          },
        },
        series: [{ name: 'Plaid', data: transformAccountOverData(data.banks) }],
      },
      data.total,
      'Total cash',
    ),
  };

  const handleMenuClick = (option) => {
    if (option.value === 'jpeg') {
      chart.current.chart.exportChart({
        type: 'image/jpeg',
      });
    } else if (option.value === 'pdf') {
      chart.current.chart.exportChart({
        type: 'application/pdf',
      });
    } else if (option.value === 'xls') {
      chart.current.chart.downloadXLS();
    }
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={strings.linKedAccOverVHeading}
        headingAction={routePath.ACCOUNT_OVERVIEW}
        callToAction
        handleMenuClick={handleMenuClick}
      />
      {options &&
        options.series &&
        options.series.length > 0 &&
        options.series[0].data &&
        options.series[0].data.length > 0 && (
          <HighchartsReact
            highcharts={Highcharts}
            options={options}
            ref={chart}
          />
        )}
    </Paper>
  );
};

export default AccountOverview;

AccountOverview.propTypes = {
  data: PropTypes.object,
};

AccountOverview.defaultProps = {
  data: {},
};
