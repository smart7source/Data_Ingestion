import {
  Paper,
  Grid,
  Card,
  Box,
  CardHeader,
  Avatar,
  Typography,
} from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsSankey from 'highcharts/modules/sankey';
import HighchartsReact from 'highcharts-react-official';
import { useRef } from 'react';

import classes from 'style/globalStyle.module.scss';
import { CustomIcon, MuiSelectBox } from 'components';
import { ReactComponent as Bulb } from 'assets/svg/bulb.svg';
import { infoColor } from 'utils';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import Sankey from 'utils/Charts/Templates/Sankey';
import {
  OOFiniancialFrequency,
  trnsFrmResTracker401,
} from 'utils/Charts/Financials';

const {
  tracker41Heading: OVERVIEW_OF_FINANCES,
  financeInsight: FINANCE_INSIGHT,
} = strings;
HighchartsSankey(Highcharts);

const sankySettings = Sankey(trnsFrmResTracker401());

const OverviewOfFinances = () => {
  const chart = useRef(null);

  const handleMenuClick = (option) => {
    if (option.value === 'jpeg') {
      chart.current.chart.exportChart({
        type: 'image/jpeg',
      });
    } else if (option.value === 'pdf') {
      chart.current.chart.exportChart({
        type: 'application/pdf',
      });
    } else if (option.value === 'xls') {
      chart.current.chart.downloadXLS();
    }
  };
  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={OVERVIEW_OF_FINANCES}
        filter={
          <>
            <Grid item width="165px">
              <MuiSelectBox
                options={OOFiniancialFrequency}
                name="filter"
                id="filter"
                value="thisMonth"
                margin="none"
                callback={(e) => {
                  console.log(e.target.value);
                }}
              />
            </Grid>
          </>
        }
        callToAction
        handleMenuClick={handleMenuClick}
      />

      <HighchartsReact
        highcharts={Highcharts}
        options={sankySettings}
        ref={chart}
      />
      <Box>
        <Card elevation={0}>
          <CardHeader
            classes={{ avatar: classes.boostHeader }}
            disableTypography
            avatar={
              <Avatar sx={{ bgcolor: infoColor }} aria-label="boost">
                <CustomIcon
                  component={Bulb}
                  color="#fff"
                  inheritViewBox
                  sx={{ fontSize: 24 }}
                />
              </Avatar>
            }
            title={
              <Typography variant="p3SemiBold">{FINANCE_INSIGHT}</Typography>
            }
            subheader={
              <Typography component="p" variant="p2">
                We notice that your administrative costs are higher this month
                compared to last month. Do you want us to investigate this for
                you? There might be some saving tips we can help you with,{' '}
                <Typography component="span" color="primary" variant="p2">
                  <>schedule an appointment</>
                </Typography>{' '}
                with your relationship manager to talk it out.
              </Typography>
            }
          />
        </Card>
      </Box>
    </Paper>
  );
};

export default OverviewOfFinances;
