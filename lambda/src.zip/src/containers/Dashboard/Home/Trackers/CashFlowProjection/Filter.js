import {
  Box,
  IconButton,
  OutlinedInput,
  InputAdornment,
  InputLabel,
} from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import PropTypes from 'prop-types';
import { useState } from 'react';

import { defaultFnPropTypes } from 'utils';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { ReactComponent as Checkmark } from 'assets/svg/checkmark.svg';
import CustomIcon from 'components/UIElements/CustomIcon';

const Filter = ({ getBaseline, baseLine, resetBaseline }) => {
  const [customBaseValue, setCustomBaseValue] = useState('');

  return (
    <Box display="flex" gap="10px" alignItems="center">
      <InputLabel component={Box}>
        Set Baseline:
        <IconButton aria-label="info" size="small">
          <InfoOutlinedIcon fontSize="inherit" />
        </IconButton>
      </InputLabel>
      <OutlinedInput
        autoComplete="off"
        sx={{ maxWidth: '200px' }}
        placeholder="$0 (default)"
        onChange={(e) => setCustomBaseValue(e.target.value)}
        endAdornment={
          <InputAdornment position="end" disableTypography>
            <IconButton
              aria-label="toggle visibility"
              size="medium"
              onClick={(e) => {
                if (customBaseValue !== '') {
                  getBaseline({ target: { value: customBaseValue } });
                } else {
                  resetBaseline();
                }
              }}
            >
              {customBaseValue ? (
                <CustomIcon
                  component={Checkmark}
                  inheritViewBox
                  color="grey.800"
                  sx={{ fontSize: '12px' }}
                />
              ) : (
                <CustomIcon
                  component={Close}
                  inheritViewBox
                  color="grey.800"
                  sx={{ fontSize: '12px' }}
                />
              )}
            </IconButton>
          </InputAdornment>
        }
      />
    </Box>
  );
};

export default Filter;

Filter.propTypes = {
  getBaseline: PropTypes.func,
  resetBaseline: PropTypes.func,
  baseLine: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
Filter.defaultProps = {
  getBaseline: defaultFnPropTypes,
  resetBaseline: defaultFnPropTypes,
  baseLine: '',
};
