import { useRef, useState } from 'react';
import {
  Paper,
  Grid,
  Typography,
  Box,
  Card,
  CardHeader,
  Avatar,
  Button,
} from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import NumberFormat from 'react-number-format';

import { ReactComponent as Boost } from 'assets/svg/boost.svg';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { primaryColor } from 'utils';
import { CustomIcon, MuiSelectBox } from 'components';
import classes from 'style/globalStyle.module.scss';
import { routePath } from 'routes';
import { cashFlowSummarySettings, howDoingOptions } from 'utils/Charts/Summary';
import strings from 'localization/translation';
import FHDclasses from 'style/DashboardStyle.module.scss';
import { whiteToBlackColor, brandColors } from 'style/variables';

import HowIamDoing from '../../Components/HowIamDoing';

import Filter from './Filter';

// const options = cashFlowSummarySettings();

const {
  cashFlowProjHeading: YOUR_CAH_FLOW_OVERVIEW,
  today: TODAY,
  cfBoostNow: BOOST_NOW,
} = strings;

// (function bar(H) {
//   H.wrap(H.Tooltip.prototype, 'hide', function foo(defaultCallback) {
//     if (this.chart.series[0].name !== 'Cash flow') {
//       defaultCallback.apply(this);
//     }
//   });
// })(Highcharts);

const CashFlowProjection = () => {
  const [options, setOptions] = useState(cashFlowSummarySettings());
  const [baseLine, setBaseLine] = useState(0);

  const [howDoingState, setHowDoingState] = useState('average');
  const chart = useRef(null);
  const getBaseline = (e) => {
    const { value } = e.target;
    if (value !== 'custom') {
      const updatedSeries = cashFlowSummarySettings().series.map((ele) => {
        if (ele.name === 'Cash flow Fake') {
          return { ...ele, threshold: value };
        }
        return ele;
      });
      const updatedPlotLine = {
        yAxis: {
          ...cashFlowSummarySettings().yAxis,
          plotLines: [
            {
              color: brandColors[800],
              zIndex: 10,
              width: 3,
              value,
            },
          ],
        },
        series: updatedSeries,
      };
      setOptions(cashFlowSummarySettings(updatedPlotLine));
    }
    setBaseLine(value);
  };

  const resetBaseline = () => {
    const { plotLines = [] } = options.yAxis;
    const value = plotLines.length === 0 ? 0 : options.yAxis.plotLines[0].value;
    setBaseLine(value);
    getBaseline({ target: { value: null } });
  };
  const handleMenuClick = (option) => {
    if (option.value === 'jpeg') {
      chart.current.chart.exportChart({
        type: 'image/jpeg',
      });
    } else if (option.value === 'pdf') {
      chart.current.chart.exportChart({
        type: 'application/pdf',
      });
    } else if (option.value === 'xls') {
      chart.current.chart.downloadXLS();
    }
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={YOUR_CAH_FLOW_OVERVIEW}
        headingAction={routePath.ACCOUNT_OVERVIEW}
        filter={
          <Box display="flex" gap="10px" alignItems="center">
            <Box display="flex" gap="10px">
              <Filter
                getBaseline={getBaseline}
                baseLine={baseLine}
                resetBaseline={resetBaseline}
                hideDateRange
              />
            </Box>
            <Box display="flex" gap="10px">
              <MuiSelectBox
                fullWidth={false}
                options={howDoingOptions}
                value={howDoingState}
                classes={FHDclasses.howDoingDropDown}
                callback={(e) => {
                  e.preventDefault();
                  setHowDoingState(e.target.value);
                }}
              />
            </Box>
          </Box>
        }
      />
      <Grid container>
        <Grid
          item
          xs={12}
          sm={12}
          md={8.5}
          pr={{ xs: 0, md: 3 }}
          borderBottom={{ xs: `1px solid ${whiteToBlackColor[500]}`, md: 0 }}
        >
          <Typography variant="p3" color="grey.900">
            {TODAY}
          </Typography>
          <Typography variant="h1" color="grey.900">
            <NumberFormat
              value={5200}
              displayType="text"
              thousandSeparator
              prefix="$"
            />{' '}
          </Typography>
          <HighchartsReact
            highcharts={Highcharts}
            options={options}
            ref={chart}
          />
          <Box>
            <Card elevation={0}>
              <CardHeader
                classes={{ avatar: classes.boostHeader }}
                disableTypography
                avatar={
                  <Avatar
                    sx={{
                      bgcolor: primaryColor,
                      width: '24px',
                      height: '24px',
                    }}
                    aria-label="boost"
                  >
                    <CustomIcon
                      component={Boost}
                      color="#fff"
                      inheritViewBox
                      sx={{ fontSize: '15px' }}
                    />
                  </Avatar>
                }
                action={
                  <Button variant="contained" color="primary" disableElevation>
                    {BOOST_NOW}
                  </Button>
                }
                title={
                  <Typography component="p" variant="p3" color="grey.900">
                    Cash flow insight! You’ve got a larger expense of{' '}
                    <Typography component="span" variant="p3">
                      <NumberFormat
                        value={15988}
                        displayType="text"
                        thousandSeparator
                        prefix="$"
                        suffix=" "
                      />
                    </Typography>
                    coming up. Access your future revenue, today... with Boost
                    by Chello!
                  </Typography>
                }
              />
            </Card>
          </Box>
        </Grid>
        <Grid
          item
          container
          xs={12}
          sm={12}
          md={3.5}
          pl={{ xs: 0, md: 3 }}
          className={classes.cashFlowSummSep}
        >
          <HowIamDoing variant={howDoingState} />
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CashFlowProjection;
