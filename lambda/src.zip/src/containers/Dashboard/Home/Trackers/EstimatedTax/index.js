import { Grid, Paper, Typography, Button, Box } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { useRef } from 'react';
import FileDownloadSharpIcon from '@mui/icons-material/FileDownloadSharp';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { MuiSelectBox } from 'components';
import strings from 'localization/translation';
import { whiteToBlackColor } from 'style/variables';
import InformationBox from 'containers/Dashboard/Home/Components/InformationBox';
import Bar from 'utils/Charts/Templates/Bar';
import { trnsFrmResTracker407 } from 'utils/Charts/Financials';

const defaultSettings = Bar(trnsFrmResTracker407());
export const defaultOptions = [
  { name: 'Monthly', value: '1' },
  { name: 'Quarterly', value: '2' },
  { name: 'Yearly', value: '3' },
];

const EstimatedTax = () => {
  const chart = useRef(null);

  const handleMenuClick = () => {
    chart.current.chart.downloadCSV();
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={strings.esitimatedTaxHeading}
        filter={
          <MuiSelectBox
            options={defaultOptions}
            name="filter"
            id="filter"
            value="1"
            margin="none"
            sx={{ maxWidth: '145px' }}
            callback={(e) => {
              e.preventDefault();
            }}
          />
        }
        callToAction
        handleMenuClick={handleMenuClick}
      />
      <Grid container gap={{ xs: 2, md: 0 }}>
        <Grid
          item
          xs={12}
          md={3}
          paddingRight={{ xs: 0, md: 3 }}
          borderRight={{ xs: 0, md: `3px solid ${whiteToBlackColor[400]}` }}
        >
          <Box display="flex" flexDirection="column" gap="10px">
            <Typography variant="p1SemiBold" color="grey.900" component={Box}>
              Upcoming taxes owed
            </Typography>
            <Box
              display="flex"
              flexDirection={{ xs: 'row', md: 'column' }}
              gap="10px"
              flexWrap="wrap"
            >
              <Box flexGrow="1">
                <InformationBox text="This month:" value="12000" />
              </Box>
              <Box flexGrow="1">
                <InformationBox text="This year:" value="70000" />
              </Box>
              <Box textAlign="left" alignSelf="flex-end" mr="auto">
                <Button
                  variant="text"
                  sx={{ color: whiteToBlackColor[900], fontSize: 16 }}
                  startIcon={<FileDownloadSharpIcon color="primary" />}
                  onClick={handleMenuClick}
                >
                  Export tax report
                </Button>
              </Box>
            </Box>
          </Box>
        </Grid>
        <Grid item xs={12} md={9} pl={{ xs: 0, md: 3 }}>
          <Typography variant="p1SemiBold" color="grey.900" component={Box}>
            Tax deductions by category
          </Typography>
          <HighchartsReact
            highcharts={Highcharts}
            options={defaultSettings}
            ref={chart}
            containerProps={{ style: { width: '100%', height: '100%' } }}
          />
        </Grid>
      </Grid>
    </Paper>
  );
};

export default EstimatedTax;
