import PropTypes from 'prop-types';
import { Chip } from '@mui/material';

import { ReactComponent as TrendingUp } from 'assets/svg/trending-up.svg';
import { ReactComponent as TrendingDown } from 'assets/svg/trending-down.svg';
import CustomIcon from 'components/UIElements/CustomIcon';

const TrackerChip = (props) => {
  const { trendingUp, value, percentage } = props;
  return (
    <Chip
      sx={
        trendingUp
          ? { bgcolor: '#DBFFD8', color: '#15894F' }
          : { bgcolor: '#FFD8DF', color: '#FF0000' }
      }
      icon={
        <CustomIcon
          component={trendingUp ? TrendingUp : TrendingDown}
          inheritViewBox
          sx={{
            height: '10px',
            color: trendingUp ? '#15894F' : '#FF0000',
          }}
        />
      }
      label={`${value} (${percentage}%)`}
    />
  );
};

TrackerChip.propTypes = {
  trendingUp: PropTypes.bool,
  value: PropTypes.string,
  percentage: PropTypes.string,
};
TrackerChip.defaultProps = {
  trendingUp: false,
  value: '',
  percentage: '',
};

export default TrackerChip;
