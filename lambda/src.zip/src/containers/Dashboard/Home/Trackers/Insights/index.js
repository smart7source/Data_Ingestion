import { useState } from 'react';
import {
  Alert,
  Box,
  Collapse,
  Divider,
  IconButton,
  Paper,
  Tab,
  Tabs,
  Typography,
} from '@mui/material';
import PropTypes from 'prop-types';

import { routePath } from 'routes';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { KebabMenu } from 'components';
import classes from 'style/DashboardStyle.module.scss';
import strings from 'localization/translation';
import TabPanel from 'containers/Dashboard/components/TabPanel';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as CloseIcon } from 'assets/svg/close.svg';
import { whiteToBlackColor, primaryColor } from 'style/variables';

const {
  insightsHeading: INSIGHTS_AND_ALERTS,
  insightsTabHeading1: CASH_FLOW,
  insightsTabHeading2: FINANCIALS,
  insightsTabHeading3: YOUR_PRACTICE,
} = strings;
function a11yProps(index) {
  return {
    id: `insights-tab-${index}`,
    'aria-controls': `insigihts-tabpanel-${index}`,
  };
}

const Insights = (props) => {
  const { data } = props;
  const { cashFlow, financials, yourPractice } = data;
  const [tabIndex, setTabIndex] = useState(0);
  //   const [open, setOpen] = useState(true);

  const handleTabIndexChange = (event, newValue) => {
    setTabIndex(newValue);
  };
  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={INSIGHTS_AND_ALERTS}
        headingAction={routePath.DASHBOARD}
        callToAction
      />
      <Tabs
        aria-label="insights-and-alert-tabs"
        indicatorColor="primary"
        value={tabIndex}
        onChange={handleTabIndexChange}
        textColor="inherit"
        variant="scrollable"
        scrollButtons="auto"
      >
        <Tab {...a11yProps(0)} label={CASH_FLOW} />
        <Tab {...a11yProps(1)} label={FINANCIALS} />
        <Tab {...a11yProps(2)} label={YOUR_PRACTICE} />
      </Tabs>
      <Divider />
      <TabPanel value={tabIndex} index={0}>
        <Paper
          elevation={0}
          className={classes.insightsBody}
          sx={{
            height: 380,
            overflow: 'auto',
            '&::-webkit-scrollbar': {
              width: 7,
            },
            '&::-webkit-scrollbar-track': {
              backgroundColor: '#EAEAEA',
            },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: primaryColor,
              borderRadius: 2,
            },
          }}
        >
          {cashFlow?.map((insight) => (
            <Collapse in key={insight.id} sx={{ my: 2 }}>
              <Alert
                className={classes.insightsToaster}
                icon={false}
                action={
                  <IconButton
                    aria-label="close"
                    color="inherit"
                    size="small"
                    //   onClick={() => {
                    //     setOpen(false);
                    //   }}
                  >
                    <CustomIcon
                      component={CloseIcon}
                      inheritViewBox
                      sx={{
                        fontSize: 10,
                        color: whiteToBlackColor[1100],
                        pl: 0,
                      }}
                    />
                  </IconButton>
                }
              >
                <Typography component="p" variant="p3" sx={{ mb: 2 }}>
                  <Box component="span" className={classes.dateSymbol} />
                  {insight.date}
                </Typography>
                <Typography variant="h3" color="grey.800">
                  {insight.text}
                </Typography>
              </Alert>
            </Collapse>
          ))}
        </Paper>
      </TabPanel>
      <TabPanel value={tabIndex} index={1}>
        <Paper
          elevation={0}
          className={classes.insightsBody}
          sx={{
            height: 380,
            overflow: 'auto',
            '&::-webkit-scrollbar': {
              width: 7,
            },
            '&::-webkit-scrollbar-track': {
              backgroundColor: '#EAEAEA',
            },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: primaryColor,
              borderRadius: 2,
            },
          }}
        >
          {financials?.map((insight) => (
            <Collapse in key={insight.id} sx={{ my: 2 }}>
              <Alert
                className={classes.insightsToaster}
                icon={false}
                action={
                  <IconButton
                    aria-label="close"
                    color="inherit"
                    size="small"
                    //   onClick={() => {
                    //     setOpen(false);
                    //   }}
                  >
                    <CustomIcon
                      component={CloseIcon}
                      inheritViewBox
                      sx={{
                        fontSize: 10,
                        color: whiteToBlackColor[1100],
                        pl: 0,
                      }}
                    />
                  </IconButton>
                }
              >
                <Typography component="p" variant="p3" sx={{ mb: 2 }}>
                  <Box component="span" className={classes.dateSymbol} />
                  {insight.date}
                </Typography>
                <Typography variant="h3" color="grey.800">
                  {insight.text}
                </Typography>
              </Alert>
            </Collapse>
          ))}
        </Paper>
      </TabPanel>
      <TabPanel value={tabIndex} index={2}>
        <Paper
          elevation={0}
          className={classes.insightsBody}
          sx={{
            height: 380,
            overflow: 'auto',
            '&::-webkit-scrollbar': {
              width: 7,
            },
            '&::-webkit-scrollbar-track': {
              backgroundColor: '#EAEAEA',
            },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: primaryColor,
              borderRadius: 2,
            },
          }}
        >
          {yourPractice?.map((insight) => (
            <Collapse in key={insight.id} sx={{ my: 2 }}>
              <Alert
                className={classes.insightsToaster}
                icon={false}
                action={
                  <IconButton
                    aria-label="close"
                    color="inherit"
                    size="small"
                    //   onClick={() => {
                    //     setOpen(false);
                    //   }}
                  >
                    <CustomIcon
                      component={CloseIcon}
                      inheritViewBox
                      sx={{
                        fontSize: 10,
                        color: whiteToBlackColor[1100],
                        pl: 0,
                      }}
                    />
                  </IconButton>
                }
              >
                <Typography component="p" variant="p3" sx={{ mb: 2 }}>
                  <Box component="span" className={classes.dateSymbol} />
                  {insight.date}
                </Typography>
                <Typography variant="h3" color="grey.800">
                  {insight.text}
                </Typography>
              </Alert>
            </Collapse>
          ))}
        </Paper>
      </TabPanel>
    </Paper>
  );
};

Insights.propTypes = {
  data: PropTypes.instanceOf(Object),
};
Insights.defaultProps = {
  data: {},
};
export default Insights;
