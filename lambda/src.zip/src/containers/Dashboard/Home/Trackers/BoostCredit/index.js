/* eslint-disable react/no-this-in-sfc */
import { useRef } from 'react';
import { Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import PropTypes from 'prop-types';

import { routePath } from 'routes';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { KebabMenu } from 'components';
import strings from 'localization/translation';
import { halfPieSettings } from 'utils/Charts/Templates/PieSettings';
import { transformBoostCreditResponse } from 'utils/Charts/Summary';

const BoostCredit = ({ data }) => {
  const chart = useRef(null);
  const optionsClone = halfPieSettings(
    { series: [{ data: transformBoostCreditResponse(data) }] },
    data.availableToSpend,
    'Outstanding claim amount',
  );

  const handleMenuClick = (option) => {
    if (option.value === 'jpeg') {
      chart.current.chart.exportChart({
        type: 'image/jpeg',
      });
    } else if (option.value === 'pdf') {
      chart.current.chart.exportChart({
        type: 'application/pdf',
      });
    } else if (option.value === 'xls') {
      chart.current.chart.downloadXLS();
    }
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={strings.boostCreditHeading}
        headingAction={routePath.ACCOUNT_OVERVIEW}
        callToAction
        handleMenuClick={handleMenuClick}
        infoIcon
      />
      {optionsClone &&
        optionsClone.series &&
        optionsClone.series.length > 0 &&
        optionsClone.series[0].data &&
        optionsClone.series[0].data.length > 0 && (
          <HighchartsReact
            highcharts={Highcharts}
            options={optionsClone}
            ref={chart}
          />
        )}
    </Paper>
  );
};

export default BoostCredit;

BoostCredit.propTypes = {
  data: PropTypes.object,
};

BoostCredit.defaultProps = {
  data: {},
};
