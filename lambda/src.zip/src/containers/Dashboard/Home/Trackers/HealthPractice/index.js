import {
  Typography,
  Grid,
  Paper,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Box,
} from '@mui/material';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';

const HealthPractice = () => (
  <Paper variant="dashboard">
    <WidgetHead heading="Health of a Practice Review" />
    <FormControl margin="normal">
      <FormLabel id="demo-radio-buttons-group-label">Daily CheckIn</FormLabel>
      <RadioGroup
        aria-labelledby="demo-radio-buttons-group-label"
        defaultValue="female"
        name="radio-buttons-group"
      >
        <FormControlLabel
          value="female"
          control={<Radio />}
          label="Cash Flow"
        />
        <FormControlLabel value="male" control={<Radio />} label="Option 2" />
        <FormControlLabel value="other" control={<Radio />} label="Option 3" />
      </RadioGroup>
    </FormControl>
    <Grid container sx={{ marginTop: '16px' }}>
      <Grid item xs={6}>
        <Typography variant="body2">Some text will come</Typography>
      </Grid>
      <Grid item xs={6} container justifyContent="flex-end">
        <Typography variant="p1SemiBold"> $3,500</Typography>
      </Grid>
    </Grid>
    <Grid container sx={{ marginTop: '16px' }}>
      <Grid item xs={6}>
        <Typography variant="body2">Some text will come</Typography>
      </Grid>
      <Grid item xs={6} container justifyContent="flex-end">
        <Typography variant="p1SemiBold"> $1000</Typography>
      </Grid>
    </Grid>
    <Box marginTop={2}>
      <Typography variant="body2">Some text will come</Typography>
      <Box
        padding={0.5}
        sx={{
          backgroundColor: 'grey.300',
        }}
        display="flex"
        alignItems="center"
      >
        <Typography
          sx={{ fontSize: '32px', fontWeight: 'bold' }}
          component="span"
        >
          15
        </Typography>
        <Typography component="span" sx={{ marginLeft: '8px' }}>
          Some text
        </Typography>
      </Box>
    </Box>
    <Grid
      container
      sx={{ marginTop: '8px' }}
      rowSpacing={1}
      columnSpacing={{ xs: 1, sm: 2, md: 2 }}
    >
      <Grid item xs={12} sm={6}>
        <Box
          padding={0.5}
          sx={{
            backgroundColor: 'grey.300',
          }}
        >
          <Typography component="span">5 Some text</Typography>
        </Box>
      </Grid>
      <Grid item xs={12} sm={6}>
        <Box
          padding={0.5}
          sx={{
            backgroundColor: 'grey.300',
          }}
        >
          <Typography component="span">5 Some text</Typography>
        </Box>
      </Grid>
    </Grid>
  </Paper>
);

export default HealthPractice;
