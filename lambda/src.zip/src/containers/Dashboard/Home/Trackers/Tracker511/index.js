import { Paper } from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import Bar from 'utils/Charts/Templates/Bar';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import { trnsFrmResTracker511 } from 'utils/Charts/YourPractice';

const defaultSettings = Bar({
  ...trnsFrmResTracker511(),
  yAxis: {
    gridLineWidth: 0,
    visible: false,
    title: {
      text: '',
    },
  },
});

const Tracker511 = () => (
  <Paper variant="dashboard">
    <WidgetHead heading={strings.tracker511Heading} />
    <HighchartsReact
      highcharts={Highcharts}
      options={defaultSettings}
      containerProps={{ style: { width: '100%', height: '100%' } }}
    />
  </Paper>
);

export default Tracker511;
