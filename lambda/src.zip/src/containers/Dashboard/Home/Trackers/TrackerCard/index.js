import PropTypes from 'prop-types';
import { Button, Paper, Box, Grid, Divider, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

import { ReactComponent as ArrowRight } from 'assets/svg/arrow-right-1.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { whiteToBlackColor } from 'style/variables';
import classes from 'style/DashboardStyle.module.scss';
import { KebabMenu } from 'components';
import CustomSelectBox from 'components/FormElements/CustomSelectBox/CustomSelectBox';

const TrackerCard = (props) => {
  const {
    children,
    control,
    title,
    dropDownOptions,
    defaultDropDownValue,
    kebabOptions,
    headingAction,
    legendMargin,
  } = props;
  return (
    <Paper variant="dashboard">
      <Grid container justifyContent="space-between" alignItems="center" mb={2}>
        <Grid item>
          <Button
            variant="text"
            component={RouterLink}
            to={headingAction}
            sx={{ color: whiteToBlackColor[900], fontSize: 16 }}
            endIcon={
              <CustomIcon
                component={ArrowRight}
                color="primary.main"
                inheritViewBox
                sx={{ fontSize: 16 }}
              />
            }
          >
            {title}
          </Button>
        </Grid>
        <Grid item container xs="auto" alignItems="center">
          <Grid item>
            <CustomSelectBox
              name="month"
              options={dropDownOptions}
              control={control}
              size="small"
              margin="none"
            />
          </Grid>
          <Grid item>
            <KebabMenu
              options={kebabOptions}
              ariaLabel="options"
              id="options"
              // onMenuOptionClick={onMenuOptionClick}
            />
          </Grid>
        </Grid>
      </Grid>

      {children}

      <Divider sx={{ mt: legendMargin }} />
      <Grid mt={2} container justifyContent="space-between">
        <Grid item container direction="row" columnSpacing={2} xs="auto">
          <Grid item container alignItems="center" xs="auto" columnSpacing={1}>
            <Grid item>
              <Box className={classes.healthCheckLegend1} />
            </Grid>
            <Grid item>
              <Typography variant="p3" component="p" color="grey.800">
                Your Business
              </Typography>
            </Grid>
          </Grid>
          <Grid item container alignItems="center" xs="auto" columnSpacing={1}>
            <Grid item>
              <Box className={classes.healthCheckLegend2} />
            </Grid>
            <Grid item>
              <Typography variant="p3" component="p" color="grey.800">
                industry Standard
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Paper>
  );
};

TrackerCard.propTypes = {
  children: PropTypes.node,
  control: PropTypes.instanceOf(Object).isRequired,
  title: PropTypes.string,
  dropDownOptions: PropTypes.instanceOf(Array),
  defaultDropDownValue: PropTypes.number,
  kebabOptions: PropTypes.instanceOf(Array),
  headingAction: PropTypes.string,
  legendMargin: PropTypes.number,
};

TrackerCard.defaultProps = {
  children: <></>,
  title: '',
  dropDownOptions: [],
  defaultDropDownValue: 0,
  kebabOptions: [],
  headingAction: '',
  legendMargin: 0,
};

export default TrackerCard;
