import { Box, IconButton, Paper } from '@mui/material';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import Bar from 'utils/Charts/Templates/Bar';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import { trnsFrmResTracker510 } from 'utils/Charts/YourPractice';

const defaultSettings = Bar(trnsFrmResTracker510());

const Tracker510 = () => (
  <Paper variant="dashboard" component={Box} position="relative">
    <WidgetHead heading={strings.tracker510Heading} />

    <HighchartsReact
      highcharts={Highcharts}
      options={defaultSettings}
      containerProps={{ style: { width: '100%', height: '100%' } }}
    />
    <Box
      display="flex"
      justifyContent="space-between"
      width="100%"
      position="absolute"
      bottom="45px"
      paddingLeft={{ xs: '28px', sm: '24px', xl: '94px' }}
      paddingRight={{ xs: '28px', sm: '24px', xl: '94px' }}
    >
      <IconButton aria-label="left">
        <ArrowBackIosNewIcon />
      </IconButton>
      <IconButton aria-label="right">
        <ArrowForwardIosIcon />
      </IconButton>
    </Box>
  </Paper>
);

export default Tracker510;
