import { Box, Chip, Grid, Typography } from '@mui/material';
import NumberFormat from 'react-number-format';
import PropTypes from 'prop-types';

import { ReactComponent as TrendingUp } from 'assets/svg/trending-up.svg';
import { ReactComponent as TrendingDown } from 'assets/svg/trending-down.svg';
import CustomIcon from 'components/UIElements/CustomIcon';

const MoneyWeekElement = (props) => {
  const { amount, trendingUp, percentage } = props;
  const label = trendingUp
    ? `Up ${percentage}% since last week`
    : `Down ${percentage}% since last week`;
  return (
    <Grid item container>
      <Grid item xs={12}>
        <Typography component="p" variant="h1">
          <NumberFormat
            value={amount}
            displayType="text"
            thousandSeparator
            prefix="$"
          />
        </Typography>
      </Grid>
      <Grid item xs={12}>
        <Grid
          container
          columnSpacing={1}
          sx={
            trendingUp
              ? {
                  bgcolor: '#DBFFD8',
                  color: '#15894F',
                  borderRadius: 2,
                  maxWidth: '125px',
                }
              : {
                  bgcolor: '#FFD8DF',
                  color: '#FF0000',
                  borderRadius: '15px',
                  maxWidth: '125px',
                }
          }
        >
          <Grid item xs="auto">
            <CustomIcon
              component={trendingUp ? TrendingUp : TrendingDown}
              inheritViewBox
              sx={{
                height: '12px',
                color: trendingUp ? '#15894F' : '#FF0000',
              }}
            />
          </Grid>
          <Grid item xs>
            <Typography variant="p3" component="span">
              {label}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

MoneyWeekElement.propTypes = {
  amount: PropTypes.string,
  percentage: PropTypes.string,
  trendingUp: PropTypes.bool,
};

MoneyWeekElement.defaultProps = {
  amount: '',
  percentage: '',
  trendingUp: false,
};

export default MoneyWeekElement;
