import {
  Box,
  IconButton,
  OutlinedInput,
  InputAdornment,
  InputLabel,
} from '@mui/material';
import { useForm } from 'react-hook-form';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import PropTypes from 'prop-types';
import { useState } from 'react';

import { DatePicker } from 'components';
import { minDate, defaultFnPropTypes } from 'utils';
import globalClasses from 'style/globalStyle.module.scss';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { ReactComponent as Checkmark } from 'assets/svg/checkmark.svg';
import CustomIcon from 'components/UIElements/CustomIcon';

const Filter = ({ getBaseline, baseLine, resetBaseline }) => {
  const { control, watch } = useForm();
  const [customBaseValue, setCustomBaseValue] = useState('');

  const toMinDate = watch('cashFlowFromDate')
    ? new Date(watch('cashFlowFromDate'))
    : new Date(minDate);

  const fromMaxDate = watch('cashFlowToDate')
    ? new Date(watch('cashFlowToDate'))
    : undefined;
  return (
    <Box
      display="flex"
      gap={3}
      alignItems="center"
      flexDirection={{ xs: 'column', sm: 'row' }}
      flexGrow={1}
      justifyContent={{ xs: 'flex-start', md: 'flex-end' }}
    >
      <Box display="flex" gap="10px" alignItems="center">
        <InputLabel component={Box}>
          Set Baseline:
          <IconButton aria-label="info" size="small">
            <InfoOutlinedIcon fontSize="inherit" />
          </IconButton>
        </InputLabel>
        <OutlinedInput
          autoComplete="off"
          sx={{ maxWidth: '200px' }}
          placeholder="$0 (default)"
          onChange={(e) => setCustomBaseValue(e.target.value)}
          endAdornment={
            <InputAdornment position="end" disableTypography>
              <IconButton
                aria-label="toggle visibility"
                size="medium"
                onClick={(e) => {
                  if (customBaseValue !== '') {
                    getBaseline({ target: { value: customBaseValue } });
                  } else {
                    resetBaseline();
                  }
                }}
              >
                {customBaseValue ? (
                  <CustomIcon
                    component={Checkmark}
                    inheritViewBox
                    color="grey.800"
                    sx={{ fontSize: '12px' }}
                  />
                ) : (
                  <CustomIcon
                    component={Close}
                    inheritViewBox
                    color="grey.800"
                    sx={{ fontSize: '12px' }}
                  />
                )}
              </IconButton>
            </InputAdornment>
          }
        />
      </Box>
      <Box display="flex" gap={1}>
        <DatePicker
          id="cashFlowFromDate"
          name="cashFlowFromDate"
          control={control}
          dataTestid="cash-flow-from-date"
          maxDateValue={fromMaxDate}
          returnDateFormat="yyyy-MM-DD"
          placeHolder="From"
          margin="none"
          classes={globalClasses.dashboardDatePicker}
        />

        <DatePicker
          id="cashFlowToDate"
          name="cashFlowToDate"
          control={control}
          dataTestid="cash-flow-to-date"
          minDateValue={toMinDate}
          returnDateFormat="yyyy-MM-DD"
          placeHolder="To"
          margin="none"
          classes={globalClasses.dashboardDatePicker}
        />
      </Box>
    </Box>
  );
};

export default Filter;

Filter.propTypes = {
  getBaseline: PropTypes.func,
  resetBaseline: PropTypes.func,
  baseLine: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
Filter.defaultProps = {
  getBaseline: defaultFnPropTypes,
  resetBaseline: defaultFnPropTypes,
  baseLine: '',
};
