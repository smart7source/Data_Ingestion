import { useState } from 'react';
import {
  Grid,
  IconButton,
  Paper,
  Typography,
  Box,
  Divider,
  Button,
  Card,
  CardHeader,
  Avatar,
} from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import NumberFormat from 'react-number-format';

import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { CustomIcon } from 'components';
import { cashFlowDetailSettings, sources } from 'utils/Charts/Cashflow';
import { ReactComponent as InfoIcon } from 'assets/svg/info.svg';
import strings from 'localization/translation';
import { primaryColor } from 'utils';
import classes from 'style/globalStyle.module.scss';
import { ReactComponent as Boost } from 'assets/svg/boost.svg';
import { brandColors } from 'style/variables';

import InformationBox from '../../Components/InformationBox';

import Filter from './Filter';

const {
  tracker301Heading: CASH_FLOW_PROJECTION,
  sources: SOURCES,
  cfDate: DATE,
  revenue: REVENUE,
  expenses: EXPENSES,
  cashflow: CASH_FLOW,
  disclaimer: DISCLAIMER,
} = strings;

const CashFlowDetail = () => {
  const [options, setOptions] = useState(cashFlowDetailSettings());
  const [baseLine, setBaseLine] = useState(0);
  const getBaseline = (e) => {
    const { value } = e.target;
    if (value !== 'custom') {
      const updatedSeries = cashFlowDetailSettings().series.map((ele) => {
        if (ele.name === 'Cash flow Fake') {
          return { ...ele, threshold: value };
        }
        return ele;
      });
      const updatedPlotLine = {
        yAxis: {
          ...cashFlowDetailSettings().yAxis,
          plotLines: [
            {
              color: brandColors[800],
              zIndex: 10,
              width: 3,
              value,
            },
          ],
        },
        series: updatedSeries,
      };
      setOptions(cashFlowDetailSettings(updatedPlotLine));
    }
    setBaseLine(value);
  };

  const resetBaseline = () => {
    const { plotLines = [] } = options.yAxis;
    const value = plotLines.length === 0 ? 0 : options.yAxis.plotLines[0].value;
    setBaseLine(value);
    getBaseline({ target: { value: null } });
  };

  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading={CASH_FLOW_PROJECTION}
        filter={
          <Filter
            getBaseline={getBaseline}
            baseLine={baseLine}
            resetBaseline={resetBaseline}
          />
        }
      />
      <Box display="flex" flexWrap="wrap">
        <Box>
          <Typography variant="p3" color="grey.900">
            {SOURCES}
          </Typography>
          <IconButton>
            <CustomIcon
              component={InfoIcon}
              inheritViewBox
              color="grey.900"
              sx={{ fontSize: 11, ml: '5px' }}
            />
          </IconButton>
        </Box>

        <Box display="flex" gap="10px">
          {sources.map(({ id, name, logo }) => (
            <Box display="flex" gap="10px" alignItems="center" key={id}>
              <img
                src={`${process.env.PUBLIC_URL}/images/${logo}`}
                alt={`${name} logo`}
              />
              <Typography variant="p3" color="grey.900">
                {name}
              </Typography>
            </Box>
          ))}
        </Box>
      </Box>

      <Box display="flex" flexDirection="column" gap="10px">
        <HighchartsReact highcharts={Highcharts} options={options} />
        <Box
          display="flex"
          flexDirection="row"
          flexWrap="wrap"
          justifyContent="space-between"
          gap={{ xs: '10px', lg: 0 }}
        >
          <Box
            flexBasis={{ xs: '100%', lg: '46%' }}
            display="flex"
            flexDirection="column"
            gap="20px"
          >
            <Box display="flex" gap="10px">
              <Typography component={Box} variant="p1SemiBold" color="grey.900">
                {DATE}
              </Typography>
              <Typography component={Box} variant="p1" color="grey.900">
                20 Feb
              </Typography>
            </Box>
            <Box display="flex" gap="10px" flexWrap="wrap">
              <Box flexGrow="1">
                <InformationBox text={REVENUE} value={16061.85} />
              </Box>
              <Box flexGrow="1">
                <InformationBox text={EXPENSES} value={15653} />
              </Box>
              <Box flexGrow="1">
                <InformationBox text={CASH_FLOW} value={400} />
              </Box>
            </Box>
            <Box>
              <Typography variant="p3" color="grey.900">
                {DISCLAIMER}
              </Typography>
            </Box>
          </Box>
          <Box display={{ xs: 'none', lg: 'flex' }}>
            <Divider orientation="vertical" variant="middle" flexItem />
          </Box>
          <Box display={{ xs: 'flex', lg: 'none' }} flexBasis="100%">
            <Divider component={Box} flexBasis="100%" />
          </Box>
          <Box flexBasis={{ xs: '100%', lg: '46%' }}>
            <Card elevation={0} sx={{ padding: { sm: 0 } }}>
              <CardHeader
                classes={{
                  avatar: classes.boostHeader,
                  root: classes.rootHeader,
                }}
                disableTypography
                avatar={
                  <Avatar sx={{ bgcolor: primaryColor }} aria-label="boost">
                    <CustomIcon
                      component={Boost}
                      color="#fff"
                      inheritViewBox
                      sx={{ fontSize: 24 }}
                    />
                  </Avatar>
                }
                title={
                  <Typography
                    component="p"
                    variant="p3SemiBold"
                    color="grey.900"
                  >
                    Cash flow insight
                  </Typography>
                }
                subheader={
                  <>
                    <Typography component="p" variant="p2" color="grey.900">
                      This is an insight about your cash flow. Maybe we can let
                      you know about a larger expense of{' '}
                      <Typography component="span" color="primary">
                        <NumberFormat
                          value="500"
                          displayType="text"
                          thousandSeparator
                          prefix="$"
                        />
                      </Typography>{' '}
                      that’s coming up.
                    </Typography>
                    <Button
                      sx={{ mt: 2 }}
                      variant="contained"
                      color="primary"
                      disableElevation
                    >
                      Boost now
                    </Button>
                  </>
                }
              />
            </Card>
          </Box>
        </Box>
      </Box>
    </Paper>
  );
};

export default CashFlowDetail;
