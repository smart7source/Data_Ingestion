/* eslint-disable no-param-reassign */
/* eslint-disable func-names */
import {
  Paper,
  Card,
  Box,
  CardHeader,
  Avatar,
  Typography,
} from '@mui/material';
import Highcharts from 'highcharts';
import HighchartsSankey from 'highcharts/modules/sankey';
import HighchartsReact from 'highcharts-react-official';

import classes from 'style/globalStyle.module.scss';
import { CustomIcon } from 'components';
import { ReactComponent as Bulb } from 'assets/svg/bulb.svg';
import { infoColor } from 'utils';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import strings from 'localization/translation';
import Sankey from 'utils/Charts/Templates/Sankey';
import { trnsFrmResTracker501 } from 'utils/Charts/YourPractice';

HighchartsSankey(Highcharts);

(function (H) {
  H.seriesTypes.sankey.prototype.pointAttribs = function (point, state) {
    let opacity = this.options.linkOpacity;
    let { color } = point;

    if (state) {
      opacity = this.options.states[state].linkOpacity || opacity;
      color = this.options.states[state].color || point.color;
    }

    return {
      fill: point.isNode
        ? color
        : {
            linearGradient: {
              x1: 0,
              x2: 1,
              y1: 0,
              y2: 0,
            },
            stops: [
              [0, H.color(color).setOpacity(opacity).get()],
              [1, H.color(color).setOpacity(0.1).get()],
            ],
          },
    };
  };
})(Highcharts);

const sankySettings = Sankey(trnsFrmResTracker501());

const YourPractice = () => (
  <Paper variant="dashboard">
    <WidgetHead
      heading={strings.tracker51Heading}
      subHeading="MARCH 1 - MARCH 31"
    />

    <HighchartsReact
      highcharts={Highcharts}
      options={sankySettings}
      containerProps={{ style: { width: '100%', height: '100%' } }}
    />
    <Box>
      <Card elevation={0}>
        <CardHeader
          classes={{ avatar: classes.boostHeader }}
          disableTypography
          avatar={
            <Avatar sx={{ bgcolor: infoColor }} aria-label="boost">
              <CustomIcon
                component={Bulb}
                color="#fff"
                inheritViewBox
                sx={{ fontSize: 24 }}
              />
            </Avatar>
          }
          title={
            <Typography variant="p3SemiBold" color="grey.900">
              Practice insight
            </Typography>
          }
          subheader={
            <Typography component="p" variant="p2" color="grey.900">
              We notice that your rejected claims all have something in common.
              Lorem ipsum dolor sit consedeaur. <br />
              if we identify a problem, we also need to give you an action to
              solve it, so maybe you can{' '}
              <Typography component="span" color="primary" variant="p2">
                <> fix it in Trizetto</>
              </Typography>{' '}
            </Typography>
          }
        />
      </Card>
    </Box>
  </Paper>
);

export default YourPractice;
