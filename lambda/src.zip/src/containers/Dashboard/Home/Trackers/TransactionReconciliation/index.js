import { Paper } from '@mui/material';
import { useEffect, useState, useRef } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import { routePath } from 'routes';
import WidgetHead from 'containers/Dashboard/Home/Components/WidgetHead';
import { KebabMenu } from 'components';
import { halfPieSettings } from 'utils/Charts/Templates/PieSettings';
import {
  sampleTransReconili,
  transformTransReconiliResponse,
} from 'utils/Charts/Summary';

const sampleResponse = transformTransReconiliResponse(sampleTransReconili);
const defaultSettings = halfPieSettings(
  {},
  sampleResponse.total,
  'Outstanding claim amount',
);

const TransactionReconciliation = () => {
  const chart = useRef(null);
  const [pieData, setPieData] = useState(defaultSettings);
  const handleMenuClick = (option) => {
    if (option.value === 'jpeg') {
      chart.current.chart.exportChart({
        type: 'image/jpeg',
      });
    } else if (option.value === 'pdf') {
      chart.current.chart.exportChart({
        type: 'application/pdf',
      });
    } else if (option.value === 'xls') {
      chart.current.chart.downloadXLS();
    }
  };
  useEffect(() => {
    const clonedSettings = { ...defaultSettings };
    clonedSettings.series = [{ data: sampleResponse.data }];
    setPieData(clonedSettings);
  }, []);
  return (
    <Paper variant="dashboard">
      <WidgetHead
        heading="Transaction reconciliation"
        headingAction={routePath.ACCOUNT_OVERVIEW}
        callToAction
        handleMenuClick={handleMenuClick}
        infoIcon
      />
      {pieData &&
        pieData.series &&
        pieData.series.length > 0 &&
        pieData.series[0].data &&
        pieData.series[0].data.length > 0 && (
          <HighchartsReact
            highcharts={Highcharts}
            options={pieData}
            ref={chart}
          />
        )}
    </Paper>
  );
};

export default TransactionReconciliation;
