import PropTypes from 'prop-types';
import { Grid, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import LinearProgress, {
  linearProgressClasses,
} from '@mui/material/LinearProgress';

import TrackerChip from '../TrackerChip';

const TrackerDataElement = (props) => {
  const ProgressBar = styled(LinearProgress)(({ theme }) => ({
    [`&.${linearProgressClasses.root}`]: {
      height: '20px',
      borderRadius: '25px',
    },
    [`&.${linearProgressClasses.colorPrimary}`]: {
      backgroundColor: 'unset',
    },
    [`&.${linearProgressClasses.colorSecondary}`]: {
      backgroundColor: 'unset',
      height: '16px',
    },
    [`& .${linearProgressClasses.bar}`]: {
      borderRadius: '25px',
    },
  }));
  const {
    title,
    value,
    indValue,
    percentage,
    indPercentage,
    showChip,
    trendingUp,
    chipValue,
    chipPercentage,
  } = props;
  return (
    <>
      <Grid container rowSpacing={1}>
        <Grid item xs={12}>
          <Typography variant="p2SemiBold" component="p" color="#11827">
            {title}
          </Typography>
        </Grid>

        <Grid
          item
          container
          xs={12}
          justifyContent="space-between"
          alignItems="center"
        >
          <Grid item xs="auto" container alignItems="center" columnSpacing={2}>
            <Grid item xs="auto">
              <Typography
                variant="h1"
                component="p"
                color="#11827"
                sx={{ fontSize: '36px' }}
              >
                {value}
              </Typography>
            </Grid>
            {showChip && (
              <Grid item xs="auto">
                <TrackerChip
                  trendingUp={trendingUp}
                  value={chipValue}
                  percentage={chipPercentage}
                />
              </Grid>
            )}
          </Grid>
          <Grid item xs="auto">
            <Typography variant="h3" color="grey.600">
              {indValue}
            </Typography>
          </Grid>
        </Grid>

        <Grid item container xs={12} rowSpacing={1}>
          <Grid item xs={12}>
            <ProgressBar
              variant="determinate"
              color="primary"
              value={percentage}
            />
          </Grid>
          <Grid item xs={12}>
            <ProgressBar
              variant="determinate"
              color="secondary"
              value={indPercentage}
            />
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

TrackerDataElement.propTypes = {
  value: PropTypes.string,
  trendingUp: PropTypes.bool,
  chipValue: PropTypes.string,
  chipPercentage: PropTypes.string,
  title: PropTypes.string,
  percentage: PropTypes.number,
  indPercentage: PropTypes.number,
  indValue: PropTypes.string,
  showChip: PropTypes.bool,
};

TrackerDataElement.defaultProps = {
  value: '',
  trendingUp: false,
  chipValue: '',
  chipPercentage: '',
  title: '',
  percentage: 0,
  indPercentage: 0,
  indValue: '',
  showChip: false,
};

export default TrackerDataElement;
