import { Grid } from '@mui/material';

import { moneyInData, moneyOutData } from 'utils/Charts/Cashflow';

import { CashFlowDetail, MoneyIn, MoneyOut } from '../Trackers';
import RevenueAndExpense from '../Trackers/RevenueAndExpense';

const CashFlowTab = () => (
  <Grid container spacing={2}>
    <Grid item xs={12}>
      <CashFlowDetail />
    </Grid>
    <Grid item xs={12} sm={6}>
      <MoneyIn data={moneyInData} />
    </Grid>
    <Grid item xs={12} sm={6}>
      <MoneyOut data={moneyOutData} />
    </Grid>
    <Grid item xs={12}>
      <RevenueAndExpense />
    </Grid>
  </Grid>
);

export default CashFlowTab;
