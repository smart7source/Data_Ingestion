import { Grid } from '@mui/material';

import {
  boostCreditData,
  acountOverviewData,
  insightsData,
} from 'utils/Charts/Summary';

import {
  AccountOverview,
  BoostCredit,
  CashFlowProjection,
  Financials,
  Insights,
  Tracker205,
  TransactionReconciliation,
} from '../Trackers';

const SummaryTab = () => (
  <Grid container spacing={2}>
    <Grid item xs={12}>
      <CashFlowProjection />
    </Grid>
    <Grid item xs={12} sm={6} md={6} lg={4}>
      <BoostCredit data={boostCreditData} />
    </Grid>
    <Grid item xs={12} sm={6} md={6} lg={4}>
      <AccountOverview data={acountOverviewData} />
    </Grid>
    <Grid item xs={12} sm={6} md={6} lg={4}>
      <TransactionReconciliation />
    </Grid>
    <Grid item xs={12} sm={6} md={6} lg={4}>
      <Tracker205 />
    </Grid>
    <Grid item xs={12} sm={6} md={6} lg={4}>
      <Financials />
    </Grid>
    <Grid item xs={12} sm={6} md={6} lg={4}>
      <Insights data={insightsData} />
    </Grid>
  </Grid>
);

export default SummaryTab;
