import { useState } from 'react';
import { Box } from '@mui/material';

import classes from 'style/DashboardStyle.module.scss';
import TabPanel from 'containers/Dashboard/components/TabPanel';

import SummaryTab from './SummaryTab';
import CashFlowTab from './CashFlowTab';
import FinancialsTab from './FinancialsTab';
import YourPracticeTab from './YourPracticeTab';
import Head from './Components/Head';

const Home = () => {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <>
      <Box component="main" className={classes.mainContainer}>
        <Head tabIndex={value} handleChange={handleChange} />
        <TabPanel value={value} index={0}>
          <SummaryTab />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <CashFlowTab />
        </TabPanel>
        <TabPanel value={value} index={2}>
          <FinancialsTab />
        </TabPanel>
        <TabPanel value={value} index={3}>
          <YourPracticeTab />
        </TabPanel>
      </Box>
    </>
  );
};

export default Home;
