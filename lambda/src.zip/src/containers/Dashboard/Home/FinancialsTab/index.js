import { Grid } from '@mui/material';

import {
  EstimatedTax,
  OverviewOfFinances,
  Payables,
  Receiveables,
  Tracker404,
  Tracker405,
} from '../Trackers';

const FinancialsTab = () => (
  <Grid container spacing={2}>
    <Grid item xs={12}>
      <OverviewOfFinances />
    </Grid>
    <Grid item xs={12} sm={6}>
      <Payables />
    </Grid>
    <Grid item xs={12} sm={6}>
      <Receiveables />
    </Grid>
    <Grid item xs={12} sm={6}>
      <Tracker404 />
    </Grid>
    <Grid item xs={12} sm={6}>
      <Tracker405 />
    </Grid>
    <Grid item xs={12}>
      <EstimatedTax />
    </Grid>
  </Grid>
);

export default FinancialsTab;
