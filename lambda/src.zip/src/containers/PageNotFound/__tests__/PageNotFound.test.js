import { render, act, screen } from '@testing-library/react';

import { renderWithProviderAndRouter } from 'testHelpers';
import App from 'containers/App/App';
import strings from 'localization/translation';

describe('Rendering PageNotFound Component', () => {
  beforeEach(async () => {
    await act(async () =>
      renderWithProviderAndRouter(<App />, { route: 'abc', render }),
    );
  });
  test('PageNotFound Component renders correctly', async () => {
    expect(
      screen.getByText(new RegExp('bit of snag', 'i')),
    ).toBeInTheDocument();
  });
});
