import { Box } from '@mui/material';

import strings from 'localization/translation';

import { NavBar } from '../../components';

const { pageNotFoundMessage } = strings;
const PageNotFound = () => (
  <>
    <NavBar />
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      height="100vh"
    >
      {pageNotFoundMessage}
    </Box>
  </>
);

export default PageNotFound;
