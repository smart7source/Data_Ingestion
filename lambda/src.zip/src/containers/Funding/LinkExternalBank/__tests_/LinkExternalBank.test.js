import React from 'react';
import {
  act,
  render,
  screen,
  waitFor,
  fireEvent,
} from '@testing-library/react';
import { usePlaidLink } from 'react-plaid-link';
import userEvent from '@testing-library/user-event';
import { rest } from 'msw';
import { createMemoryHistory } from 'history';

import { routePath } from 'routes';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import strings from 'localization/translation';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';

import LinkExternalBank from '../LinkExternalBank';

jest.mock('react-plaid-link', () => ({
  ...jest.requireActual('react-plaid-link'),
  usePlaidLink: jest.fn(),
}));

const plaidMock = (config) => ({
  ready: true,
  open: () => {
    config.onSuccess('xxx', {
      account: {},
    });
  },
});

const { FUNDING, LINK_SOFTWARE } = routePath;
const history = createMemoryHistory();
const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('Testing LinkExternalBank page', () => {
  const mockOpen = jest.fn();
  beforeEach(async () => {
    server.use(
      rest.post(serviceUrl.setToken, (req, res, ctx) => res(ctx.status(200))),
    );
    usePlaidLink.mockImplementation(() => ({ ready: false, open: jest.fn() }));
    renderWithProviderAndRouter(<LinkExternalBank />, { render });
  });

  afterEach(() => {
    usePlaidLink.mockClear();
  });

  it('Should render funding account page successfully', async () => {
    await waitFor(() =>
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
    );
    await waitFor(() => {
      expect(screen.getByText(strings.noLinkAccHeading)).toBeInTheDocument();
      expect(screen.getByText(strings.noLinkAccSubHeading)).toBeInTheDocument();
      const continueBtn = screen.getByRole('button', {
        name: strings.continue,
      });
      expect(continueBtn).toBeInTheDocument();
      expect(continueBtn).toBeDisabled();
    });
  });

  it(`Should render plaid portal when "link a bank account" link is clicked and
    enable continue button when atleast one external bank is added`, async () => {
    usePlaidLink.mockImplementation(() => ({ ready: true, open: mockOpen }));
    await waitFor(() =>
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
    );
    await act(async () =>
      fireEvent.click(screen.getByTestId('funding-link-bank-account-link')),
    );
    await waitFor(() => {
      expect(mockOpen).toHaveBeenCalled();
    });
  });

  it('should show success notification on adding account successfully', async () => {
    await waitFor(() =>
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
    );
    usePlaidLink.mockImplementation(plaidMock);
    await act(async () =>
      userEvent.click(await screen.findByText('Link a bank account')),
    );
  });

  it('should show failure notification when adding account fails', async () => {
    await waitFor(() =>
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument(),
    );
    usePlaidLink.mockImplementation(plaidMock);
    server.use(
      rest.post(serviceUrl.setToken, (req, res, ctx) => res(ctx.status(400))),
    );
    await act(async () =>
      userEvent.click(await screen.findByText('Link a bank account')),
    );
  });
});
