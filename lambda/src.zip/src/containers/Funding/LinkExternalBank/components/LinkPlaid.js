import {
  List,
  ListItem,
  Avatar,
  ListItemText,
  ListItemButton,
  ListItemIcon,
} from '@mui/material';
import { useDispatch } from 'react-redux';
import {
  useEffect,
  useCallback,
  Children,
  isValidElement,
  cloneElement,
  useState,
} from 'react';
import { usePlaidLink } from 'react-plaid-link';
import PropTypes from 'prop-types';

import { ReactComponent as PlusCircle } from 'assets/svg/plus-circle.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import strings from 'localization/translation';
import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import { setLoader } from 'store/actions';

const { linkABankAcc } = strings;

const Link = (props) => {
  const config = {
    ...props,
  };

  const { open, ready } = usePlaidLink(config);

  useEffect(() => {
    if (ready) {
      open();
    }
  }, [ready, open]);

  return <></>;
};

const LinkPlaid = ({ registeAccount, onLinkedAcc, onError, children }) => {
  const dispatch = useDispatch();

  const [linkToken, setLinkToken] = useState(null);

  const getLinkToken = useCallback(async () => {
    try {
      dispatch(setLoader(true));
      const response = await ApiClient.post(serviceUrl.getPlaidToken, {
        language: 'en',
        redirect_uri: `${process.env.REACT_APP_URL}move-money`,
        client_name: 'Chello',
        country_codes: ['US'],
        products: ['auth'],
      });
      const { body } = response;
      const { token } = body || {};
      setLinkToken(token);
    } catch (e) {
      onError(e);
    } finally {
      dispatch(setLoader(false));
    }
  }, [dispatch, onError]);

  const onSuccess = (publicToken, accountInfo) => {
    const setToken = async () => {
      if (registeAccount) {
        try {
          dispatch(setLoader(true));
          await ApiClient.post(serviceUrl.setToken, {
            token: publicToken,
            account_id: accountInfo.account_id,
            data: JSON.stringify(accountInfo),
          });
          onLinkedAcc(accountInfo);
        } catch (e) {
          onError(e);
        } finally {
          dispatch(setLoader(false));
        }
      } else {
        onLinkedAcc(accountInfo);
      }
    };
    setToken();
    setLinkToken(null);
  };

  const onExit = async (error, metadata) => {
    setLinkToken(null);
    // TODO
    // log and save error and metadata
    // handle invalid link token
    if (error != null && error.error_code === 'INVALID_LINK_TOKEN') {
      // generate new link token
    }
    try {
      await ApiClient.post(serviceUrl.setToken, {
        error: { error },
      });
    } catch (e) {
      onError(e);
    }
    // TODO
    // handle other error codes, see https://plaid.com/docs/errors/
  };

  const onEvent = (eventName, metadata) => {
    // TODO
    // log eventName and metadata
    // console.log('eventName: ', eventName);
    // console.log('metadata: ', metadata);
  };

  const openPlaid = (e) => {
    e.preventDefault();
    if (!linkToken) {
      getLinkToken();
    }
  };

  const renderView = () => {
    if (children) {
      const childrenWithProps = Children.map(children, (child) => {
        if (isValidElement(child)) {
          return cloneElement(child, { onClick: openPlaid });
        }
        return child;
      });
      return <>{childrenWithProps}</>;
    }
    return (
      <List>
        <ListItem disablePadding>
          <ListItemButton
            onClick={openPlaid}
            data-testid="funding-link-bank-account-link"
          >
            <ListItemIcon>
              <Avatar className={classes.chelloAvatar}>
                <CustomIcon
                  component={PlusCircle}
                  className={internalClasses.plaidIcon}
                  inheritViewBox
                />
              </Avatar>
            </ListItemIcon>
            <ListItemText primary={linkABankAcc} />
          </ListItemButton>
        </ListItem>
      </List>
    );
  };
  return (
    <>
      {linkToken != null && (
        <Link
          token={linkToken}
          onSuccess={onSuccess}
          onExit={onExit}
          onEvent={onEvent}
        />
      )}
      {renderView()}
    </>
  );
};

export default LinkPlaid;

LinkPlaid.propTypes = {
  registeAccount: PropTypes.bool,
  onLinkedAcc: PropTypes.func,
  onError: PropTypes.func,
  children: PropTypes.node,
};
LinkPlaid.defaultProps = {
  registeAccount: true,
  onLinkedAcc: defaultFnPropTypes,
  onError: defaultFnPropTypes,
  children: null,
};
