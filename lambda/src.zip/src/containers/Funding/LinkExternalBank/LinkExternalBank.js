import { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemAvatar,
  Avatar,
  ListItemText,
  ListItemSecondaryAction,
} from '@mui/material';
import { useDispatch } from 'react-redux';
import { AccountBalance } from '@mui/icons-material';
import { useHistory } from 'react-router-dom';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Checkmark } from 'assets/svg/checkmark.svg';
import classes from 'style/globalStyle.module.scss';
import internalClasses from 'style/onBoarding.module.scss';
import strings from 'localization/translation';
import RightPanelLayout from 'containers/OnBoarding/components/RightPanelLayout';
import FormHead from 'containers/OnBoarding/components/FormHead';
import { linkExtBankAccPgInfo } from 'helpers/URLConfiguration';
import serviceUrl from 'api/UrlHelper';
import { useOnboarding } from 'hooks';
import ApiClient from 'api/ApiClient';
import { setLoader } from 'store/actions';
import Footer from 'containers/OnBoarding/components/Footer';
import { routePath } from 'routes';
import { SingleNotification } from 'components';

import LinkPlaid from './components/LinkPlaid';

const { pageId } = linkExtBankAccPgInfo;
const { getExternalBankAccounts } = serviceUrl;
const {
  existLinkAccHeading,
  existLinkAccSubHeading,
  noLinkAccHeading,
  noLinkAccSubHeading,
  bankAccount,
} = strings;
const LinkExternalBank = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [enable, setEnable] = useState(false);
  const [error, setError] = useState({});
  const [hasAccount, setHasAccount] = useState([]);
  const { exitHandler } = useOnboarding({ pageId });

  useEffect(() => {
    dispatch(setLoader(true));
    ApiClient.get(getExternalBankAccounts)
      .then((response) => {
        setHasAccount(response.body);
        setEnable(true);
      })
      .finally(() => dispatch(setLoader(false)));
  }, [dispatch]);

  const onLinkedAcc = (accountInfo) => {
    const {
      account: { name: acctTitle, mask: acctNbr },
    } = accountInfo;
    const clonedAccount = [...hasAccount, { acctTitle, acctNbr }];
    setHasAccount(clonedAccount);
    setEnable(true);
  };

  const handleError = (errorObj) => {
    setError(errorObj);
  };

  const { length } = hasAccount;
  return (
    <>
      <Box className="formBox">
        <SingleNotification error={error} />
        <RightPanelLayout>
          <FormHead
            heading={length ? existLinkAccHeading : noLinkAccHeading}
            subHeading={length ? existLinkAccSubHeading : noLinkAccSubHeading}
          />

          {length > 0 && <Typography>{bankAccount}</Typography>}
          <List>
            {length > 0 &&
              hasAccount.map((item, index) => (
                <ListItem key={index}>
                  <ListItemAvatar>
                    <Avatar className={classes.chelloAvatar}>
                      <AccountBalance htmlColor="#000" />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={`${item.acctTitle} **${item.acctNbr.slice(-4)}`}
                  />
                  <ListItemSecondaryAction>
                    <CustomIcon
                      component={Checkmark}
                      className={internalClasses.linkExternalBankIcon}
                      inheritViewBox
                    />
                  </ListItemSecondaryAction>
                </ListItem>
              ))}

            <LinkPlaid onLinkedAcc={onLinkedAcc} onError={handleError} />
          </List>
        </RightPanelLayout>
      </Box>
      <Footer
        saveHandler={() => exitHandler({ saveData: false })}
        backBtn={false}
        continueBtnType="button"
        continueEnable={enable}
        handleSubmit={() => history.push(routePath.LINK_SOFTWARE)}
      />
    </>
  );
};

export default LinkExternalBank;
