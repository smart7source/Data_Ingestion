import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';

import configureStore from 'store/configureStore';
import strings from 'localization/translation';
import routePath from 'routes/routePath';
import { onBoardingStateEmptyMock } from 'testHelpers';

import LinkAccountSoft from '../LinkAccountSoft';

const store = configureStore(onBoardingStateEmptyMock);

const history = createMemoryHistory();

describe('Render LinkAccountSoft component', () => {
  beforeEach(async () => {
    await act(async () =>
      render(
        <Provider store={store}>
          <Router history={history}>
            <LinkAccountSoft />
          </Router>
        </Provider>,
      ),
    );
  });

  it('should render heading', async () => {
    await waitFor(() => {
      expect(screen.getByText(strings.linkSoftHeading)).toBeInTheDocument();
    });
  });
  it('should render boxes with images in it', async () => {
    await waitFor(() => {
      expect(screen.getAllByRole('img')).toHaveLength(1);
      expect(
        screen.getByText("My software isn't listed here"),
      ).toBeInTheDocument();
    });
  });
  it('should navigate to next page on continue', async () => {
    expect(
      screen.getByRole('button', { name: strings.continue }),
    ).toBeEnabled();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: strings.continue }));
    });
    expect(history.location.pathname).toBe(routePath.WELCOME_CHELLO);
  });
});

describe(' LinkAccountSoft component Exit Button Testing', () => {
  beforeEach(async () => {
    await act(async () =>
      render(
        <Provider store={store}>
          <Router history={history}>
            <LinkAccountSoft />
          </Router>
        </Provider>,
      ),
    );
  });

  test('should render exit dialog and click on save n exit ', async () => {
    const exitBtn = screen.getByRole('button', { name: strings.exit });
    expect(exitBtn).toBeDefined();
    await act(async () => {
      fireEvent.click(exitBtn);
    });
    const exitDialogSaveAndExitBtn = screen.getByRole('button', {
      name: strings.exitDialogSaveAndExit,
    });
    await act(async () => {
      fireEvent.click(exitDialogSaveAndExitBtn);
    });
    expect(history.location.pathname).toBe(routePath.LOGIN);
  });
});
