import { useState } from 'react';
import { Box } from '@mui/material';
import { useHistory } from 'react-router-dom';

import { routePath } from 'routes';
import FormHead from 'containers/OnBoarding/components/FormHead';
import strings from 'localization/translation';
import RightPanelLayout from 'containers/OnBoarding/components/RightPanelLayout';
import { linkAccSoftPgInfo } from 'helpers/URLConfiguration';
import { useOnboarding } from 'hooks';
import { LinkCodatSoftware, SingleNotification } from 'components';

import Footer from '../../OnBoarding/components/Footer';

const { pageId } = linkAccSoftPgInfo;
const { linkSoftHeading, linkSoftSubHeading } = strings;
const LinkAccountSoft = () => {
  const history = useHistory();
  const [error, setError] = useState({});
  const { exitHandler } = useOnboarding({ pageId });

  const handleError = (errorObj) => {
    setError(errorObj);
  };

  return (
    <>
      <Box className="formBox">
        <RightPanelLayout>
          <SingleNotification error={error} />
          <FormHead heading={linkSoftHeading} subHeading={linkSoftSubHeading} />
          <LinkCodatSoftware onError={handleError} />
        </RightPanelLayout>
      </Box>
      <Footer
        saveHandler={() => exitHandler({ saveData: false })}
        backBtn={false}
        continueBtnType="button"
        handleSubmit={() => history.push(routePath.WELCOME_CHELLO)}
      />
    </>
  );
};

export default LinkAccountSoft;
