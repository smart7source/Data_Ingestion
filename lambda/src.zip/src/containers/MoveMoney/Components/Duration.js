import { Grid, Typography, Box } from '@mui/material';
import PropTypes from 'prop-types';
import moment from 'moment';

import { formatTransactionDate, monthNames } from 'utils';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

const {
  endsOn: ENDS_ON,
  transactions: TRANSACTIONS,
  duration: DURATION,
  until: UNTIL,
} = strings;

function Duration({
  frequency,
  transferDateDuration,
  transferTransactionLimit,
  transferDate,
  transferEndDate,
}) {
  function checkType() {
    if (transferDateDuration === 'endDate') {
      return `${ENDS_ON} ${formatTransactionDate(transferEndDate)}`;
    }
    const frequencyValue = parseInt(frequency?.slice(0, 1), 10);
    const transactionLimit = Number(transferTransactionLimit);
    let endDate;

    if (frequency?.endsWith('M')) {
      endDate = moment(transferDate).add(
        frequencyValue * transactionLimit,
        'M',
      );
    } else if (frequency === '7D') {
      endDate = moment(transferDate).add(transactionLimit, 'w');
    } else if (frequency === '14D') {
      endDate = moment(transferDate).add(2 * transactionLimit, 'w');
    } else {
      endDate = moment(transferDate).add(Math.ceil(transactionLimit / 5), 'w');
    }

    if (!endDate) return '';
    const endMonthName = monthNames[endDate.month()];
    return `${transferTransactionLimit} ${TRANSACTIONS} (${UNTIL} ${endMonthName} ${endDate.year()})`;
  }

  if (frequency !== 'one-time') {
    return (
      <Grid container item xs={12} className={classes.reviewTransferContainer}>
        <Grid item xs={5}>
          <Box pr={1}>
            <Typography
              align="right"
              variant="h3"
              component="h3"
              color="#3C3C3C"
            >
              {DURATION}
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={7}>
          <Typography
            varian="body1"
            className={classes.reviewTransferImportant}
          >
            {checkType()}
          </Typography>
        </Grid>
      </Grid>
    );
  }
  return null;
}

export default Duration;
Duration.propTypes = {
  frequency: PropTypes.string,
  transferDateDuration: PropTypes.string,
  transferTransactionLimit: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  transferDate: PropTypes.oneOfType([
    PropTypes.instanceOf(Date),
    PropTypes.string,
  ]),
  transferEndDate: PropTypes.oneOfType([
    PropTypes.instanceOf(Date),
    PropTypes.string,
  ]),
};

Duration.defaultProps = {
  frequency: '',
  transferDateDuration: '',
  transferTransactionLimit: '',
  transferDate: '',
  transferEndDate: '',
};
