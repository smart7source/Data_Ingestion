import { Grid, Typography, Box } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

const { note: NOTE } = strings;
function Note({ transferNote }) {
  if (transferNote) {
    return (
      <Grid container item xs={12} className={classes.reviewTransferContainer}>
        <Grid item xs={5}>
          <Box pr={1}>
            <Typography
              align="right"
              variant="h3"
              component="h3"
              color="#3C3C3C"
            >
              {NOTE}
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={7}>
          <Typography
            variant="body1"
            className={classes.reviewTransferImportant}
          >
            {transferNote}
          </Typography>
        </Grid>
      </Grid>
    );
  }
  return null;
}

export default Note;
Note.propTypes = {
  transferNote: PropTypes.string,
};

Note.defaultProps = {
  transferNote: '',
};
