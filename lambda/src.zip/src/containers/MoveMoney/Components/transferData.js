import moment from 'moment';

export const transfersActivityData = [
  {
    amount: 100,
    from: 'Citi Business Checking *7636',
    to: 'Boost by Chello *1111',
    date: 'Feb 01, 2022',
    status: 'Verified',
  },
  {
    amount: 100,
    from: 'Boost by Chello *1111',
    to: 'Citi Business Checking *7636',
    date: 'Feb 01, 2022',
    status: 'Entered',
  },
  {
    amount: 100,
    from: 'Citi Business Checking *7636',
    to: 'Boost by Chello *1111',
    date: 'Feb 01, 2022',
    status: 'In Process',
  },
  {
    amount: 100,
    from: 'Citi Business Checking *7636',
    to: 'Boost by Chello *1111',
    date: 'Feb 01, 2022',
    status: 'Completed',
  },
  {
    amount: 100,
    from: 'Boost by Chello *1111',
    to: 'Citi Business Checking *7636',
    date: 'Feb 01, 2022',
    status: 'Canceled',
  },
  {
    amount: 100,
    from: 'Boost by Chello *1111',
    to: 'Citi Business Checking *7636',
    date: 'Feb 01, 2022',
    status: 'Return',
  },
];

export const rows = [
  { value: '5', name: '5' },
  { value: '10', name: '10' },
  { value: '25', name: '25' },
  { value: '50', name: '50' },
  { value: '100', name: '100' },
];

export const DUMMY_DATA_FROM = [
  { value: 'chello-loan-term', name: 'Boost by Chello', number: '4321' },
];
export const DUMMY_DATA_TO = [
  {
    value: 'city-business-checking',
    name: 'City Business Checking',
    number: '1199',
  },
];

export const DUMMY_DATA = [
  {
    value: 'chello-loan-term-1',
    name: 'Boost by Chello1',
    number: '4321',
    type: 'internal',
  },
  {
    value: 'chello-loan-term-2',
    name: 'Boost by Chello2',
    number: '3210',
    type: 'internal',
  },
  {
    value: 'city-business-checking',
    name: 'City Business Checking',
    number: '1199',
    type: 'external',
  },
  {
    value: 'jp-morgan-checking',
    name: 'JP Morgan Checking',
    number: '2109',
    type: 'external',
  },
];

export const frequencyList = [
  { value: 'one-time', name: 'One-time' },
  { value: '1D', name: 'Daily' },
  { value: '7D', name: 'Weekly' },
  { value: '14D', name: 'Every two weeks' },
  { value: '1M', name: 'Monthly' },
  { value: '3M', name: 'Every three months' },
];
export const monthPreparedList = [
  { value: '1', name: '1st' },
  { value: '5', name: '5th' },
  { value: '15', name: '15th' },
  { value: '20', name: '20th' },
  { value: 'E', name: 'Last day' },
  { value: 'customDate', name: 'Custom day' },
];
export const days = [
  { value: 'Monday', name: 'M' },
  { value: 'Tuesday', name: 'T' },
  { value: 'Wednesday', name: 'W' },
  { value: 'Thursday', name: 'TH' },
  { value: 'Friday', name: 'F' },
];

export const transferActivityFrequency = [
  { value: 'last7Days', name: 'Last 7 days' },
  { value: 'lastMonth', name: 'Last month' },
  { value: 'lastQuarter', name: 'Last quarter' },
  { value: 'last6Months', name: 'Last 6 months' },
  { value: 'lastYear', name: 'Last year' },
  { value: 'customDateRange', name: 'Custom date range' },
];
export const transferActivityStatus = [
  { value: '', name: 'All' },
  { value: '4', name: 'Completed' },
  { value: '3', name: 'In process' },
  { value: '5', name: 'Cancelled' },
  { value: '6', name: 'Return' },
];
export const transferActivityNotes = [
  { value: 'hasNote', name: 'Has Note' },
  { value: 'noNote', name: 'No Note' },
];
export const transferActivitySortBy = [
  { value: '-orderDtm', name: 'Newest to oldest' },
  { value: 'orderDtm', name: 'Oldest to newest' },
];

export const getTransferDates = (
  transferActivityFrequencyParam,
  dataRangeFrom,
  dataRangeTo,
) => {
  let fromDate;
  let toDate;
  toDate = moment(new Date());

  switch (transferActivityFrequencyParam) {
    case 'last7Days':
      fromDate = moment(toDate).subtract(7, 'days');
      break;

    case 'lastMonth':
      fromDate = moment(toDate).subtract(1, 'month').startOf('month');
      toDate = fromDate.clone().endOf('month');
      break;

    case 'lastQuarter':
      fromDate = moment(toDate).subtract(1, 'quarter').startOf('quarter');
      toDate = fromDate.clone().endOf('quarter');
      break;

    case 'last6Months':
      fromDate = moment().subtract(6, 'months').startOf('month');
      toDate = moment(fromDate).add(5, 'months').endOf('month');

      break;

    case 'lastYear':
      fromDate = moment()
        .subtract(moment().format('MM') - 1, 'month')
        .subtract(1, 'year')
        .startOf('month');
      toDate = moment(fromDate).add(11, 'months').endOf('month');
      break;

    default:
      fromDate = moment(dataRangeFrom.toString());
      toDate = moment(dataRangeTo.toString());
      break;
  }
  return { fromDate, toDate };
};
