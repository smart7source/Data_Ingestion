import { Box } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import { disableWeekends, maxDate } from 'utils';
import { DatePicker } from 'components';

const { date: DATE, selectDate: SELECT_DATE } = strings;

// const disableWeekends = (date) => date.getDay() === 0 || date.getDay() === 6;

const StartDate = (props) => {
  const { control, errors, transferEndDateValue } = props;

  const transferStartMaxDate = transferEndDateValue
    ? new Date(transferEndDateValue)
    : new Date(maxDate);

  return (
    <Box mx={3}>
      <DatePicker
        label={DATE}
        placeHolder={SELECT_DATE}
        id="transferDate"
        name="transferDate"
        control={control}
        dataTestid="start-date"
        minDateValue={new Date()}
        maxDateValue={transferStartMaxDate}
        returnDateFormat="YYYY-MM-DD"
        shouldDisableDate={disableWeekends}
        error={!!errors.transferDate}
        errorText={errors.transferDate && errors.transferDate.message}
      />
    </Box>
  );
};

export default StartDate;
StartDate.propTypes = {
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  transferEndDateValue: PropTypes.string,
};

StartDate.defaultProps = {
  control: {},
  errors: {},
  transferEndDateValue: '',
};
