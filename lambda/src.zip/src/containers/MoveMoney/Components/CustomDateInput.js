import { Grid, Box } from '@mui/material';
import PropTypes from 'prop-types';

import { CustomInput } from 'components';
import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

const { enter: ENTER } = strings;

const WatchFrequencyCustomDate = (props) => {
  const { setValue, control, errors, frequencyMonthly, displayDate } = props;
  if (frequencyMonthly === 'customDate' || displayDate) {
    setValue('isFrequencyMonthlyCustomDate', true);
    return (
      <Grid item xs={8} xl={6}>
        <Box mx={3}>
          <CustomInput
            control={control}
            classes={classes.numberInput}
            id="frequencyMonthlyCustomDate"
            name="frequencyMonthlyCustomDate"
            type="number"
            placeholder={`${ENTER} 1 - 31`}
            error={!!errors.frequencyMonthlyCustomDate}
            errorText={errors.frequencyMonthlyCustomDate?.message}
          />
        </Box>
      </Grid>
    );
  }
  setValue('isFrequencyMonthlyCustomDate', false);
  return null;
};

export default WatchFrequencyCustomDate;
WatchFrequencyCustomDate.propTypes = {
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  frequencyMonthly: PropTypes.string,
  setValue: PropTypes.instanceOf(Object),
  displayDate: PropTypes.bool,
};

WatchFrequencyCustomDate.defaultProps = {
  control: {},
  errors: {},
  frequencyMonthly: '',
  setValue: {},
  displayDate: false,
};
