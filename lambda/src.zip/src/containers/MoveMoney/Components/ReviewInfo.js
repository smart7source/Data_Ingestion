import { Box, Grid, Paper, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import globalClasses from 'style/globalStyle.module.scss';
import { displayFrequencyString, formatTransactionDate } from 'utils';

import Duration from './Duration';
import Note from './Note';

const { amount: AMOUNT, date: DATE, frequency: FREQUENCY } = strings;
const ReviewInfo = (props) => {
  const {
    amount,
    frequencyMonthly,
    frequencyMonthlyCustomDate,
    transferNote,
    frequency,
    transferDateDuration,
    transferTransactionLimit,
    transferDate,
    transferEndDate,
  } = props;
  return (
    <Paper elevation={0} className={globalClasses.reviewTransferHolder}>
      <Grid
        container
        alignItems="flex-start"
        direction="column"
        justifyContent="space-around"
      >
        <Grid
          container
          item
          xs={12}
          className={globalClasses.reviewTransferContainer}
        >
          <Grid item xs={5} alignItems="center">
            <Box pr={1}>
              <Typography
                align="right"
                variant="h3"
                component="h3"
                color="#3C3C3C"
              >
                {AMOUNT}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={7}>
            <Typography
              variant="p1"
              className={globalClasses.reviewTransferImportant}
            >
              {amount}
            </Typography>
          </Grid>
        </Grid>
        <Grid
          container
          item
          xs={12}
          className={globalClasses.reviewTransferContainer}
        >
          <Grid item xs={5}>
            <Box pr={1}>
              <Typography
                align="right"
                variant="h3"
                component="h3"
                color="#3C3C3C"
              >
                {DATE}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={7}>
            <Typography
              variant="p1"
              className={globalClasses.reviewTransferImportant}
            >
              {formatTransactionDate(transferDate)}
            </Typography>
          </Grid>
        </Grid>
        {frequency && (
          <Grid
            container
            item
            xs={12}
            className={globalClasses.reviewTransferContainer}
          >
            <Grid item xs={5}>
              <Box pr={1}>
                <Typography
                  align="right"
                  variant="h3"
                  component="h3"
                  color="#3C3C3C"
                >
                  {FREQUENCY}
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={7}>
              <Typography
                variant="p1"
                className={globalClasses.reviewTransferImportant}
              >
                {displayFrequencyString(
                  frequency === '1B' ? '1D' : frequency,
                  frequencyMonthly,
                  frequencyMonthlyCustomDate,
                )}
              </Typography>
            </Grid>
          </Grid>
        )}
        <Duration
          frequency={frequency}
          transferDateDuration={transferDateDuration}
          transferTransactionLimit={transferTransactionLimit}
          transferDate={transferDate}
          transferEndDate={transferEndDate}
        />
        <Note transferNote={transferNote} />
      </Grid>
    </Paper>
  );
};

export default ReviewInfo;
ReviewInfo.propTypes = {
  amount: PropTypes.string,
  frequencyMonthly: PropTypes.string,
  transferNote: PropTypes.string,
  frequency: PropTypes.string,
  transferDateDuration: PropTypes.string,
  frequencyMonthlyCustomDate: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  transferTransactionLimit: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  transferDate: PropTypes.oneOfType([
    PropTypes.instanceOf(Date),
    PropTypes.string,
  ]),
  transferEndDate: PropTypes.oneOfType([
    PropTypes.instanceOf(Date),
    PropTypes.string,
  ]),
};

ReviewInfo.defaultProps = {
  amount: '',
  frequencyMonthly: '',
  frequencyMonthlyCustomDate: '',
  transferNote: '',
  frequency: '',
  transferDateDuration: '',
  transferTransactionLimit: '',
  transferDate: '',
  transferEndDate: '',
};
