import { Grid, Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import globalClasses from 'style/globalStyle.module.scss';
import strings from 'localization/translation';
import { CustomSelectBox, DatePicker } from 'components';

import { transferActivityFrequency } from './transferData';

const { dateRange: DATA_RANGE, from: FROM, to: TO } = strings;

const DataRange = ({ control, watch, resetField }) => (
  <Grid item xs={12} md={5} lg={4}>
    <Box mr={1}>
      <CustomSelectBox
        name="transferActivityFrequency"
        id="transferActivityFrequency"
        options={transferActivityFrequency}
        hideSelect
        label={DATA_RANGE}
        control={control}
        dataTestid="transferActivityFrequency"
      />
    </Box>
    {watch('transferActivityFrequency') === 'customDateRange' && (
      <Grid
        container
        item
        xs={12}
        direction="row"
        style={{ position: 'relative' }}
      >
        <Grid item xs={6}>
          <Box mr={1}>
            <DatePicker
              name="dataRangeFrom"
              id="dataRangeFrom"
              label={FROM}
              control={control}
              dataTestid="dataRangeFrom"
            />
          </Box>
        </Grid>
        <Grid item xs={6}>
          <Box mr={1}>
            <DatePicker
              name="dataRangeTo"
              id="dataRangeTo"
              label={TO}
              control={control}
              dataTestid="dataRangeTo"
            />
          </Box>
        </Grid>
        <Typography
          variant="p1SemiBold"
          component="p"
          color="#3C3C3C"
          className={globalClasses.clearBtn}
          onClick={() => {
            resetField('dataRangeTo');
            resetField('dataRangeFrom');
          }}
        >
          Clear
        </Typography>
      </Grid>
    )}
  </Grid>
);

export default DataRange;

DataRange.propTypes = {
  control: PropTypes.instanceOf(Object),
  watch: PropTypes.instanceOf(Object),
  resetField: PropTypes.func.isRequired,
};

DataRange.defaultProps = {
  control: {},
  watch: {},
};
