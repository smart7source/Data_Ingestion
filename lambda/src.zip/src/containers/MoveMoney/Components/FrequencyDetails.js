import { Grid, Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import { CustomSelectBox } from 'components';
import strings from 'localization/translation';
import mmClasses from 'style/MoveMoney.module.scss';

import CustomDateInput from './CustomDateInput';

const { onThe: ON_THE } = strings;

const RenderFrequencyDetails = (props) => {
  const {
    control,
    errors,
    setValue,
    monthPreparedList,
    frequency,
    frequencyMonthly,
  } = props;

  const monthlyArray = ['1', '5', '15', '20', 'E'];
  const displayCustomDate =
    frequencyMonthly && !monthlyArray.includes(frequencyMonthly);

  if (frequency === '1M' || frequency === '3M') {
    setValue('isFrequencyMonthly', true);
    return (
      <Grid container item xs={12}>
        <Grid item xs={12} lg={2}>
          <Box py={2} pr={1} mx={3} className={mmClasses.frequencyOnThe}>
            <Typography varian="body1" align="left">
              {ON_THE}
            </Typography>
          </Box>
        </Grid>
        {!displayCustomDate && (
          <Grid item xs={8} lg={6}>
            <Box mx={3}>
              <CustomSelectBox
                hideSelect
                id="frequencyMonthly"
                name="frequencyMonthly"
                control={control}
                options={monthPreparedList}
                error={!!errors.frequencyMonthly}
                errorText={errors.frequencyMonthly?.message}
              />
            </Box>
          </Grid>
        )}
        {displayCustomDate && (
          <CustomDateInput
            setValue={setValue}
            control={control}
            errors={errors}
            frequencyMonthly={frequencyMonthly}
            displayDate={displayCustomDate}
          />
        )}
      </Grid>
    );
  }
  setValue('isFrequencyMonthly', false);
  return null;
};

export default RenderFrequencyDetails;
RenderFrequencyDetails.propTypes = {
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  setValue: PropTypes.instanceOf(Object),
  monthPreparedList: PropTypes.instanceOf(Object),
  frequency: PropTypes.string,
  frequencyMonthly: PropTypes.string,
};

RenderFrequencyDetails.defaultProps = {
  control: {},
  errors: {},
  setValue: {},
  monthPreparedList: {},
  frequency: '',
  frequencyMonthly: '',
};
