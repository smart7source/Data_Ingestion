import { ThemeProvider } from '@mui/material';
import { render } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import strings from 'localization/translation';
import { useForm } from 'react-hook-form';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import CustomDateInput from '../CustomDateInput';

const history = createMemoryHistory();

const initialState = {
  moveMoney: {
    activeAccounts: [],
  },
};
const store = configureStore();

function TestElement({ frequencyMonthly }) {
  const { control, errors, setValue } = useForm({
    defaultValues: {
      frequencyMonthly,
    },
  });

  const currentProps = {
    setValue,
    control,
    errors,
    frequencyMonthly,
    displayDate: false,
  };

  return (
    <ThemeProvider theme={theme}>
      <Provider store={store(initialState)}>
        <Router history={history}>
          <CustomDateInput {...currentProps} />
        </Router>
      </Provider>
    </ThemeProvider>
  );
}

describe('CustomDateInput Test', () => {
  it('should render correctly', () => {
    const { queryByPlaceholderText } = render(
      <TestElement frequencyMonthly="customDate" />,
    );
    expect(queryByPlaceholderText(/Enter 1 - 31/i)).toBeInTheDocument();
  });

  it('should not render custominput when frequency does not monthly', () => {
    const { queryByPlaceholderText } = render(<TestElement />);
    expect(queryByPlaceholderText(/Enter 1 - 31/i)).not.toBeInTheDocument();
  });
});
