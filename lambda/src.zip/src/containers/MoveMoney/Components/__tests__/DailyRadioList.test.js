import { ThemeProvider } from '@mui/material';
import { render } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import strings from 'localization/translation';
import { useForm, Controller } from 'react-hook-form';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import DailyRadioList from '../DailyRadioList';
import { days } from '../transferData';

const history = createMemoryHistory();

const initialState = {
  moveMoney: {
    activeAccounts: [],
  },
};
const store = configureStore();

function TestElement() {
  const { control, errors, setValue, watch, getValues } = useForm();

  const currentProps = {
    label: strings.noteOptional,
    id: 'test_id',
    name: 'transferNote',
    control,
    errors,
    watch,
    setValue,
    Controller,
    getValues,
    days,
  };

  return (
    <ThemeProvider theme={theme}>
      <Provider store={store(initialState)}>
        <Router history={history}>
          <DailyRadioList {...currentProps} />
        </Router>
      </Provider>
    </ThemeProvider>
  );
}

describe('DailyRadioList Test', () => {
  it('should render correctly', () => {
    const { queryAllByRole } = render(<TestElement />);
    expect(queryAllByRole('radio').length).toBe(10);
  });
});
