import {
  Grid,
  Box,
  RadioGroup,
  Radio,
  InputLabel,
  FormControlLabel,
  FormControl,
  Typography,
} from '@mui/material';
import { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Controller, useWatch } from 'react-hook-form';

import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';
import { disableWeekends, minDate } from 'utils';
import { NumberInput, DatePicker } from 'components';

const {
  duration: DURATION,
  numberOfTransactions: NUMBER_OF_TRANSACTIONS,
  endDate: END_DATE,
  selectDate: SELECT_DATE,
  enter: ENTER,
} = strings;

const EndDate = (props) => {
  const { control, setValue, errors, resetField, transferDateValue } = props;

  const transferStartMinDate = transferDateValue
    ? new Date(transferDateValue)
    : new Date(minDate);

  const [frequency, transferDateDuration] = useWatch({
    control,
    name: ['frequency', 'transferDateDuration'],
  });

  useEffect(() => {
    if (transferDateDuration === 'numberOfTransactions') {
      resetField('transferEndDate');
    } else {
      resetField('transferTransactionLimit');
    }
  }, [transferDateDuration, resetField]);

  if (frequency && frequency !== 'one-time') {
    setValue('isTransferDateDuration', true);
    return (
      <Grid
        container
        item
        xs={12}
        lg={8}
        xl={6}
        data-testid="duration-conponent"
      >
        <Box mx={3}>
          <InputLabel
            data-testid="duration"
            htmlFor={DURATION}
            // style={{ fontW/eight: 'Semi Bold' }}
          >
            {DURATION}
          </InputLabel>
        </Box>
        <Grid item xs={12}>
          <Box mx={3}>
            <Controller
              render={({ field }) => (
                <FormControl error={!!errors.transferDateDuration} fullWidth>
                  <RadioGroup
                    {...field}
                    value={field.value || ''}
                    sx={{ marginTop: '5px' }}
                  >
                    <FormControlLabel
                      data-testid="noOfTransaction"
                      htmlFor="noOfTrasactionsRadio"
                      value="numberOfTransactions"
                      control={
                        <Radio color="primary" id="noOfTrasactionsRadio" />
                      }
                      label={
                        <Typography variant="p1">
                          {NUMBER_OF_TRANSACTIONS}
                        </Typography>
                      }
                    />
                    {field.value === 'numberOfTransactions' && (
                      <Box>
                        <NumberInput
                          placeHolder={`${ENTER} 1 - 99`}
                          id="transferTransactionLimit"
                          name="transferTransactionLimit"
                          dataTestId="numberTransaction"
                          decimalScale={0}
                          control={control}
                          error={!!errors.transferTransactionLimit}
                          errorText={errors.transferTransactionLimit?.message}
                        />
                      </Box>
                    )}
                    <FormControlLabel
                      htmlFor="endDateRadio"
                      value="endDate"
                      data-testid="endDate"
                      control={<Radio color="primary" id="endDateRadio" />}
                      label={<Typography variant="p1">{END_DATE}</Typography>}
                    />
                    {field.value === 'endDate' && (
                      <Box>
                        <DatePicker
                          placeHolder={SELECT_DATE}
                          id="transferEndDate"
                          name="transferEndDate"
                          dataTestid="end-date"
                          returnDateFormat="YYYY-MM-DD"
                          control={control}
                          minDateValue={transferStartMinDate}
                          shouldDisableDate={disableWeekends}
                          error={!!errors.transferEndDate}
                          errorText={errors.transferEndDate?.message}
                        />
                      </Box>
                    )}
                  </RadioGroup>
                </FormControl>
              )}
              name="transferDateDuration"
              id="transferDateDuration"
              control={control}
            />
          </Box>
          <Box className={classes.freqencyDivider} />
        </Grid>
      </Grid>
    );
  }
  setValue('isTransferDateDuration', false);
  return null;
};

export default EndDate;
EndDate.propTypes = {
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  setValue: PropTypes.instanceOf(Object),
  transferDateValue: PropTypes.string,
  resetField: PropTypes.func.isRequired,
};

EndDate.defaultProps = {
  control: {},
  errors: {},
  setValue: {},
  transferDateValue: '',
};
