import { Grid, FormControl, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { Controller } from 'react-hook-form';

import classes from 'style/globalStyle.module.scss';

import { days } from './transferData';

const DailyRadioList = (props) => {
  const { control, errors, getValues, setValue } = props;

  return (
    <Grid item xs={5} mt={0.6}>
      <Controller
        render={() => (
          <FormControl error={!!errors.certify}>
            <div className={classes.radioHolder}>
              {days.map((day) => (
                // eslint-disable-next-line jsx-a11y/click-events-have-key-events
                <div
                  className={classes.radioDay}
                  key={day.value}
                  role="radio"
                  aria-checked={getValues('frequencyWeeklyDay') === day.name}
                  tabIndex="0"
                  onClick={() => setValue('frequencyWeeklyDay', day.name)}
                >
                  <input
                    type="radio"
                    name="frequencyWeeklyDay"
                    value={day.name}
                    onChange={() => setValue('frequencyWeeklyDay', day.name)}
                    checked={getValues('frequencyWeeklyDay') === day.name}
                  />
                  <div className={classes.radioDay}>
                    <Typography variant="body1">{day.name}</Typography>
                  </div>
                </div>
              ))}
            </div>
          </FormControl>
        )}
        name="frequencyWeeklyDay"
        id="frequencyWeeklyDay"
        control={control}
      />
    </Grid>
  );
};

export default DailyRadioList;
DailyRadioList.propTypes = {
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  getValues: PropTypes.oneOfType([
    PropTypes.instanceOf(Object),
    PropTypes.func,
  ]),
  setValue: PropTypes.instanceOf(Object),
};

DailyRadioList.defaultProps = {
  control: {},
  errors: {},
  getValues: {},
  setValue: {},
};
