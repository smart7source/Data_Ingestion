import {
  Dialog,
  DialogContent,
  DialogTitle,
  Typography,
  IconButton,
} from '@mui/material';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import { useSelector, useDispatch } from 'react-redux';

import CustomIcon from 'components/UIElements/CustomIcon';
import { defaultFnPropTypes } from 'utils';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import classes from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import strings from 'localization/translation';
import { showEditDialog } from 'store/actions/MoveMoneyActions';

import MakeTransfer from '../MakeTransfer/MakeTransfer';

const { editTransfer: EDIT_TRANSFER } = strings;
const EditTransfer = ({ onClose, formData, reloadApi }) => {
  const dispatch = useDispatch();

  const open = useSelector((state) => state.moveMoney.showEditDialog);

  const handleClose = () => {
    dispatch(showEditDialog(false));
  };

  return (
    <Dialog open={open} maxWidth="md" fullWidth>
      <IconButton
        aria-label="close"
        size="small"
        className={classes.closeIcon}
        data-testid="edit-transfer-close"
        onClick={handleClose}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={mmClasses.customCloseIcon}
        />
      </IconButton>
      <DialogTitle>
        <Typography
          variant="h1"
          component="p"
          className={clsx(classes.boldText, classes.reviewTransferImportant)}
        >
          {EDIT_TRANSFER}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <MakeTransfer
          elevation={0}
          formData={formData}
          onCancel={handleClose}
          isEditMode
          reloadApi={reloadApi}
          //  onSubmit={(data) => onSubmit(data)}
        />
      </DialogContent>
    </Dialog>
  );
};

export default EditTransfer;

EditTransfer.propTypes = {
  onClose: PropTypes.func,
  formData: PropTypes.instanceOf(Object),
  reloadApi: PropTypes.func,
};
EditTransfer.defaultProps = {
  onClose: defaultFnPropTypes,
  formData: {},
  reloadApi: defaultFnPropTypes,
};
