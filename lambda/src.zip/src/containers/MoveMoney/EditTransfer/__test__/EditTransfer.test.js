import { render, screen } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';

import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';

import EditTransfer from '../EditTransfer';
import theme from 'style/theme';

const history = createMemoryHistory({});

const initialState = {
  moveMoney: {
    activeAccounts: [],
    showEditDialog: true,
  },
};
const mockStore = configureStore();

function renderElement() {
  return render(
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <Provider store={mockStore(initialState)}>
          <Router history={history}>
            <EditTransfer />
          </Router>
        </Provider>
      </ThemeProvider>
    </StyledEngineProvider>,
  );
}

describe('should test EditTransfer component', () => {
  it('should render correctly', async () => {
    renderElement();
    expect(await screen.findByText('Edit transfer')).toBeInTheDocument();
  });
});
