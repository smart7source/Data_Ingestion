/* eslint-disable max-lines */
import { Box, Button, Grid, Paper } from '@mui/material';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { yupResolver } from '@hookform/resolvers/yup';
import moment from 'moment';

import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import {
  CustomInput,
  CustomSelectBox,
  NumberInput,
  Notification,
} from 'components';
import strings from 'localization/translation';
import actionTypes from 'store/ActionTypes';
import classes from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import { defaultFnPropTypes, convertToAmt } from 'utils';
import {
  openTransferReview,
  openTransferConfirm,
  setSelectedAccount,
} from 'store/actions/MoveMoneyActions';
import { setLoader } from 'store/actions';

import makeTransferSchema from '../makeTransferSchema';
import EndDate from '../Components/EndDate';
import FrequencyDetails from '../Components/FrequencyDetails';
import { frequencyList, monthPreparedList } from '../Components/transferData';
import StartDate from '../Components/StartDate';
import ReviewTransfer from '../ReviewTransfer/ReviewTransfer';
import TransferConfirmation from '../TransferConfirmation/TransferConfirmation';
import LinkedAccountSimpleSelector from '../../../components/FormElements/LinkedAccountSimpleSelector';

import CreatePayload from './CreatePayload';

const {
  from: FROM,
  to: TO,
  frequency: FREQUENCY,
  amount: AMOUNT,
  boostNote: NOTE,
  noteOptional: NOTE_OPTIONAL,
  cancel: CANCEL,
  continue: CONTINUE,
  editTransfer: EDIT_TRANSFER,
  makeTransfer: MAKE_TRANSFER,
  reviewTransferTitle: REVIEW_TRANSFER_TITLE,
  reviewTransfersubTitle: REVIEW_TRANSFER_SUB_TITLE,
  outgoingmsg: OUTGOING_MSG,
  incomingmsg: INCOMING_MSG,
  insufficinetfunds: INSUFFICIENT_FUNDS_MESSGE,
} = strings;

const MakeTransfer = (props) => {
  const { formData, elevation = 1, onCancel, isEditMode, reloadApi } = props;
  const [loading, setButtonLoading] = useState(false);
  const [transferToOptions, setTransferToOptions] = useState([]);
  const [transferStatus, setTransferStatus] = useState('');
  const [transferId, setTransferId] = useState('');
  const [transferResponse, setTransferResponse] = useState([]);
  const [insufficientBal, setInsufficientBal] = useState(null);

  const dispatch = useDispatch();
  const { activeAccounts = [], selectedAccount = {} } = useSelector(
    (state) => state.moveMoney,
  );
  const showTransferReview = useSelector(
    (state) => state.moveMoney.openTransferReview,
  );
  const showTransferConfirm = useSelector(
    (state) => state.moveMoney.openTransferConfirm,
  );

  const {
    control,
    handleSubmit,
    watch,
    getValues,
    reset,
    setValue,
    resetField,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(makeTransferSchema),
    defaultValues: {
      amount: '',
      transferFrom: '',
      transferTo: '',
    },
  });
  const transferDateValue = getValues('transferDate');
  const transferEndDateValue = getValues('transferEndDate');

  const [
    frequency,
    transferDateDuration,
    frequencyMonthly,
    transferFrom,
    transferTo,
    amount,
  ] = useWatch({
    control,
    name: [
      'frequency',
      'transferDateDuration',
      'frequencyMonthly',
      'transferFrom',
      'transferTo',
      'amount',
    ],
  });
  useEffect(() => {
    dispatch({ type: actionTypes.REQUEST_ACTIVE_ACCOUNTS });
  }, [dispatch]);

  useEffect(() => {
    if (formData?.transferDetail) {
      const { transferDetail } = formData;
      const transObj = {
        transferId: formData?.transferId,
        transferFrom: transferDetail?.sourcePartyPosnId,
        transferTo: transferDetail?.counterPartyPosnId,
        amount: transferDetail?.transferAmt,
        transferNote: transferDetail?.note,
        transferDate: transferDetail?.transferDate,
        frequency:
          formData?.freq === 'One-time only'
            ? 'one-time'
            : transferDetail?.recurringTransfer?.frequency.replace('1B', '1D'),
        frequencyMonthly: transferDetail?.recurringTransfer?.frequencyOccurance,
        frequencyMonthlyCustomDate:
          transferDetail?.recurringTransfer?.frequencyOccurance,
        transferTransactionLimit:
          transferDetail?.recurringTransfer?.noOfOccurance,
        transferEndDate: transferDetail?.recurringTransfer?.endDate,
        transferDateDuration:
          transferDetail?.recurringTransfer?.endDate !== ''
            ? 'endDate'
            : 'numberOfTransactions',
      };
      reset(transObj);
    }
  }, [formData, reset]);

  useEffect(() => {
    if (
      frequency !== 'one-time' &&
      transferDateDuration === 'numberOfTransactions'
    ) {
      return setValue('validationHelper', 'validateNumberOTrans');
    }
    if (frequency !== 'one-time' && transferDateDuration === 'endDate') {
      return setValue('validationHelper', 'validateendDate');
    }
    if (frequencyMonthly === 'customDate') {
      return setValue('validationHelperFreqDate', 'customDate');
    }
    return (() => {
      setValue('validationHelper', '');
      setValue('validationHelperFreqDate', '');
    })();
  }, [setValue, frequency, transferDateDuration, frequencyMonthly]);

  useEffect(() => {
    const isExternal =
      activeAccounts.findIndex(
        (item) => item.accTypNm === 'external' && item.posnId === transferFrom,
      ) > -1;
    if (isExternal) {
      setTransferToOptions([
        ...activeAccounts.filter((item) => item.accTypNm === 'internal'),
      ]);
    } else {
      setTransferToOptions([
        ...activeAccounts.filter((item) => item.accTypNm !== 'internal'),
      ]);
    }
  }, [activeAccounts, setValue, transferFrom, transferTo]);

  useEffect(() => {
    const { transferDetail } = formData;
    const availableBalance = activeAccounts.find(
      (item) => item.posnId === transferFrom,
    );

    const inputAmount = Number(
      isEditMode
        ? transferDetail?.transferAmt
        : convertToAmt({ value: amount ?? 0 }),
    );
    const isDisables =
      availableBalance?.availableBalance < inputAmount ||
      availableBalance?.availableBalance === 0;
    setInsufficientBal(isDisables);
  }, [transferFrom, activeAccounts, amount, formData, isEditMode]);

  const handleMakeTransfer = async (data, methodParam) => {
    const payload = CreatePayload(data, isEditMode);
    dispatch(setLoader(true));

    const trasactionType = activeAccounts.find(
      (item) => item.posnId === transferTo,
    );

    ApiClient[methodParam](serviceUrl.makeTransfer, payload)
      .then((response) => {
        const { body } = response;
        if (body?.transferId) {
          reset({});
          setTransferId(body?.transferId);
          setTransferStatus('success');
          setTransferResponse([
            {
              severity: 'info',
              message:
                trasactionType?.accTypNm === 'external'
                  ? OUTGOING_MSG.replace(
                      '<Date>',
                      moment(transferDateValue).format('MM/DD/YYYY'),
                    )
                  : INCOMING_MSG.replace(
                      '<Date>',
                      moment(transferDateValue).format('MM/DD/YYYY'),
                    ),
            },
          ]);
          setButtonLoading(false);
          if (isEditMode) {
            reloadApi();
          }
        } else {
          setTransferStatus('fail');
          setButtonLoading(false);
        }
      })
      .catch((error) => {
        reset({});
        setTransferStatus('fail');
        setButtonLoading(false);
        setTransferResponse([{ severity: 'error', message: error.message }]);
      })
      .finally(() => {
        dispatch(openTransferReview(false));
        dispatch(openTransferConfirm(true));
        dispatch(setLoader(false));
      });
  };

  const handleClickOpen = (data) => {
    dispatch(setSelectedAccount(data));
    dispatch(openTransferReview(true));
    // if (isEditMode) onCancel();
  };

  const handleClickConfirm = async () => {
    await handleMakeTransfer(getValues(), isEditMode ? 'put' : 'post');
  };

  const handleCancel = () => {
    reset();
    if (isEditMode) onCancel();
  };

  const callback = (value) => {
    if (value === 'one-time') return;
    reset({
      ...getValues(),
      frequencyMonthly: '',
      transferDateDuration: '',
      numberOfTransactions: '',
      transferEndDate: null,
      transferTransactionLimit: '',
      frequencyMonthlyCustomDate: '',
    });
  };

  useEffect(() => {
    if (transferFrom) setTransferResponse([]);
  }, [transferFrom]);

  return (
    <>
      {transferResponse && transferResponse.length > 0 && (
        <Box mb={2.5}>
          <Notification errors={transferResponse} needFocus />
        </Box>
      )}

      {insufficientBal && (
        <Box mb={2.5}>
          <Notification
            errors={[
              {
                severity: 'error',
                message: INSUFFICIENT_FUNDS_MESSGE,
              },
            ]}
            needFocus
          />
        </Box>
      )}
      <form onSubmit={handleSubmit(handleClickOpen)} data-testid="form">
        {showTransferReview && (
          <ReviewTransfer
            title={REVIEW_TRANSFER_TITLE}
            subtitle={REVIEW_TRANSFER_SUB_TITLE}
            altTitle="review-transfer"
            altDescr="modal-to-confirm-the-transfer"
            formData={selectedAccount}
            handleClickConfirm={handleClickConfirm}
            buttonForward={isEditMode ? EDIT_TRANSFER : MAKE_TRANSFER}
            buttonBack={CANCEL}
            loading={loading}
          />
        )}
        {showTransferConfirm && (
          <TransferConfirmation
            formData={selectedAccount}
            transferStatus={transferStatus}
            transferId={transferId}
            reset={reset}
            closeEditModal={isEditMode ? onCancel : defaultFnPropTypes}
          />
        )}

        <Paper className={classes.container} elevation={elevation}>
          <Grid container>
            <Grid container item xs={12}>
              <Grid container item xs={12} lg={6}>
                <Grid item xs={12}>
                  <Box mx={3}>
                    <LinkedAccountSimpleSelector
                      mmFlag
                      label={FROM}
                      id="transferFrom"
                      name="transferFrom"
                      control={control}
                      dataTestid="fromBtn"
                      bankAccounts={[...activeAccounts]}
                      error={!!errors.transferFrom}
                      errorText={errors.transferFrom?.message}
                    />
                  </Box>
                </Grid>
              </Grid>
              <Grid container item xs={12} lg={6}>
                <Grid item xs={12}>
                  <Box mx={3}>
                    <LinkedAccountSimpleSelector
                      mmFlag
                      label={TO}
                      id="transferTo"
                      name="transferTo"
                      control={control}
                      dataTestid="toBtn"
                      bankAccounts={transferToOptions}
                      error={!!errors.transferTo}
                      errorText={errors.transferTo?.message}
                      disabled={!getValues('transferFrom')}
                    />
                  </Box>
                </Grid>
              </Grid>
            </Grid>
            <Grid container item xs={12}>
              <Box mx={3} className={mmClasses.boxWidth}>
                <hr color="#EBEBEB" />
              </Box>
            </Grid>

            <Grid container item xs={12}>
              <Grid container item xs={12} lg={6}>
                <Grid item xs={12}>
                  <Box mx={3} mt={3} className={classes.inputAccount}>
                    <NumberInput
                      label={AMOUNT}
                      id="amount"
                      name="amount"
                      placeHolder="$ 0.00"
                      dataTestId="amount-field"
                      prefix="$ "
                      fixedDecimalScale
                      control={control}
                      error={!!errors.amount}
                      errorText={errors.amount?.message}
                    />
                  </Box>
                </Grid>
              </Grid>
              <Grid container item xs={12} lg={6}>
                <Grid item xs={12}>
                  <Box mx={3} mt={3}>
                    <CustomSelectBox
                      dataTestid="frequencyBtn"
                      label={FREQUENCY}
                      id="frequency"
                      name="frequency"
                      control={control}
                      options={frequencyList}
                      error={!!errors.frequency}
                      errorText={errors.frequency?.message}
                      SelectProps={{
                        displayEmpty: true,
                      }}
                      callback={callback}
                    />
                  </Box>
                </Grid>
              </Grid>
            </Grid>
            <Grid container item xs={12}>
              <Grid item xs={12} lg={6} order={{ xs: 2, sm: 2, md: 2, lg: 1 }}>
                <StartDate
                  control={control}
                  errors={errors}
                  transferEndDateValue={transferEndDateValue}
                />
                <Box mx={3} className={mmClasses.note}>
                  <CustomInput
                    label={NOTE}
                    optionalLabel="Optional"
                    id="transferNote"
                    name="transferNote"
                    control={control}
                    error={!!errors.transferNote}
                    errorText={errors.transferNote?.message}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} lg={6} order={{ xs: 1, sm: 1, md: 1, lg: 2 }}>
                <FrequencyDetails
                  control={control}
                  errors={errors}
                  setValue={setValue}
                  frequency={frequency}
                  frequencyMonthly={frequencyMonthly}
                  monthPreparedList={monthPreparedList}
                />
                <EndDate
                  control={control}
                  watch={watch}
                  setValue={setValue}
                  errors={errors}
                  transferDateValue={transferDateValue}
                  getValues={getValues}
                  resetField={resetField}
                />
              </Grid>
            </Grid>

            <Grid item xs={12} lg={6} className={mmClasses.noteOptional}>
              <Box mx={3} mt={3}>
                <CustomInput
                  label={NOTE_OPTIONAL}
                  id="transferNote"
                  name="transferNote"
                  control={control}
                  error={!!errors.transferNote}
                  errorText={errors.transferNote?.message}
                />
              </Box>
            </Grid>

            <Grid container item xs={12}>
              <Grid container item xs={12} justifyContent="space-between">
                <Grid item>
                  <Box ml={3} mt={2}>
                    <Button
                      className={classes.makeTransferButton}
                      size="large"
                      variant="contained"
                      onClick={handleCancel}
                    >
                      {CANCEL}
                    </Button>
                  </Box>
                </Grid>
                <Grid item>
                  <Box mr={3} mt={2}>
                    <Button
                      className={classes.makeTransferButton}
                      size="large"
                      fullWidth
                      variant="contained"
                      color="primary"
                      type="submit"
                      disabled={insufficientBal}
                    >
                      {CONTINUE}
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Paper>
      </form>
    </>
  );
};

export default MakeTransfer;

MakeTransfer.propTypes = {
  elevation: PropTypes.number,
  formData: PropTypes.instanceOf(Object),
  onCancel: PropTypes.func,
  isEditMode: PropTypes.bool,
  reloadApi: PropTypes.func,
};

MakeTransfer.defaultProps = {
  elevation: 1,
  formData: {},
  onCancel: defaultFnPropTypes,
  isEditMode: false,
  reloadApi: defaultFnPropTypes,
};
