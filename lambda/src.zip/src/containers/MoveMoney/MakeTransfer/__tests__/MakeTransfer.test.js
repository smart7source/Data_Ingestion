import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { ThemeProvider } from '@mui/material';

import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';
import axios from 'axios';

import strings from 'localization/translation';
import MakeTransfer from '../MakeTransfer';
import theme from 'style/theme';
import { renderWithProviderAndRouter } from 'testHelpers';

const history = createMemoryHistory();

const initialState = {
  moveMoney: {
    activeAccounts: [
      {
        accNm: 'card1234',
        accPosNbr: '1234123412341234',
        accTypNm: 'internal',
        accId: '123456',
        posnId: '4hFnUGvqo8qHDV----5F-77-',
      },
      {
        accNm: 'card2222',
        accPosNbr: '1234123412341234',
        accTypNm: 'external',
        accId: '1234567',
        posnId: '4hUUPfvGX_gg1----VDF-E7-',
      },
    ],
  },
};
const store = configureStore();

jest.mock('axios');

const submitForm = async () => {
  await act(async () => {
    fireEvent.submit(screen.getByTestId('form'));
  });
};

function renderElement() {
  return render(
    <ThemeProvider theme={theme}>
      <Provider store={store(initialState)}>
        <Router history={history}>
          <MakeTransfer />
        </Router>
      </Provider>
    </ThemeProvider>,
  );
}

describe('should test initial condition', () => {
  beforeEach(() => {
    // axios.get.mockResolvedValue({
    //   moveMoney: {
    //     activeAccounts: [
    //       {
    //         accNm: 'card1234',
    //         accPosNbr: '1234123412341234',
    //         accTypNm: 'internal',
    //         accId: '123456',
    //         posnId: '4hFnUGvqo8qHDV----5F-77-',
    //       },
    //       {
    //         accNm: 'card2222',
    //         accPosNbr: '1234123412341234',
    //         accTypNm: 'external',
    //         accId: '1234567',
    //         posnId: '4hUUPfvGX_gg1----VDF-E7-',
    //       },
    //     ],
    //   },
    // });
    axios.post.mockResolvedValue({
      transferId: '',
    });
  });

  it('Test Continue Button to be Disabled if Required Form Fields are not filled', async () => {
    renderElement();
    const fromBtn = screen.getByTestId('fromBtn');
    const toBtn = screen.getByTestId('toBtn');
    const amountFiel = screen.getByTestId('amount-field');
    const startDateField = screen.getByTestId('start-date');

    await act(async () => {
      fireEvent.change(fromBtn, { target: { name: /card1234/i } });
      fireEvent.change(toBtn, { target: { name: /card2222/i } });
    });

    await act(async () => {
      fireEvent.change(startDateField, {
        name: '2023-10-10',
        value: '2023-10-10',
      });
    });

    await submitForm();
  });

  it('should test initial titles', () => {
    renderElement();
    expect(screen.getByText(strings.from)).toBeInTheDocument();
    expect(screen.getByText(strings.to)).toBeInTheDocument();

    // expect(screen.getAllByText(strings.frequency).length).toBe(2);
    // expect(screen.getAllByText(strings.date).length).toBe(2);
  });

  it('should have frequency list options', async () => {
    renderElement();
    const frequencyBtn = screen.getByTestId('frequencyBtn');
    expect(frequencyBtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.change(frequencyBtn, { target: { name: strings.oneTime } });
      fireEvent.change(frequencyBtn, { target: { name: strings.daily } });
      fireEvent.change(frequencyBtn, { target: { name: strings.weekly } });
      fireEvent.change(frequencyBtn, {
        target: { name: strings.everyTwoWeeks },
      });
      fireEvent.change(frequencyBtn, { target: { name: strings.monthly } });
      fireEvent.change(frequencyBtn, {
        target: { name: strings.everyThreeMonths },
      });
    });
  });

  it('should have frequency list options', async () => {
    renderElement();
    const frequencyBtn = screen.getByTestId('frequencyBtn');
    // const noOfTransaction = screen.getByTestId('noOfTransaction');
    // const endDate = screen.getByTestId('endDate');
    expect(frequencyBtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.change(frequencyBtn, { target: { value: 'one-time' } });
    });

    await act(async () => {
      fireEvent.change(frequencyBtn, { target: { value: '1D' } });
    });
    await waitFor(
      () =>
        expect(screen.getByTestId('duration-conponent')).toBeInTheDocument(),
      expect(screen.getByTestId('noOfTransaction')).toBeInTheDocument(),
      expect(screen.getByTestId('endDate')).toBeInTheDocument(),
    );

    await act(async () => {
      fireEvent.click(screen.getByLabelText('Number of transactions'));
    });

    await waitFor(() =>
      expect(screen.getByTestId('numberTransaction')).toBeInTheDocument(),
    );

    await act(async () => {
      fireEvent.click(screen.getByLabelText('End date'));
    });

    await waitFor(() =>
      expect(screen.getByTestId('end-date')).toBeInTheDocument(),
    );
  });

  //   it('should have frequency list options', async () => {
  //   renderElement();
  //   const frequencyBtn = screen.getByRole('button', { name: /one-time/i });
  //   expect(frequencyBtn).toBeInTheDocument();

  //       await act(async () => {
  //     fireEvent.change(frequencyBtn, { target: { name: /daily/i } });
  //   });

  //       await waitFor(() =>
  //         expect(screen.getByTestId('duration')).toBeInTheDocument()
  //   );
  // });

  it('should have cancel button', async () => {
    renderElement();
    const cancelBtn = screen.getByRole('button', { name: strings.cancel });
    expect(cancelBtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(cancelBtn);
    });
  });

  it('should not open dialog box if fields are empty', async () => {
    renderElement();
    const continueBtn = screen.getByRole('button', { name: strings.continue });
    expect(continueBtn).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(continueBtn);
    });

    await waitFor(() => {
      expect(screen.queryByTestId('review-transfer')).not.toBeInTheDocument();
    });
  });

  it('should open dialog box if fields are not empty', async () => {
    renderElement();
    const fromBtn = screen.getByTestId('fromBtn');
    const toBtn = screen.getByTestId('toBtn');
    const amountField = screen.getByTestId('amount-field');
    const frequencyBtn = screen.getByTestId('frequencyBtn');
    const startDate = screen.getByPlaceholderText('Select Date');
    const continueBtn = screen.getByRole('button', { name: strings.continue });

    await act(async () => {
      fireEvent.change(fromBtn, {
        target: { value: '4hFnUGvqo8qHDV----5F-77-' },
      });
      fireEvent.change(toBtn, {
        target: { value: '4hUUPfvGX_gg1----VDF-E7-' },
      });
      fireEvent.change(amountField, { target: { value: '$ 1.00' } });
      fireEvent.change(frequencyBtn, {
        target: { value: 'one-time' },
      });
    });

    await act(async () => {
      fireEvent.click(startDate);
    });
    await waitFor(() => {
      expect(screen.getByTestId('start-date')).toBeInTheDocument();
    });

    await act(async () => {
      fireEvent.change(screen.getByTestId('start-date'), {
        target: { value: '2022-05-24' },
      });
    });

    await act(async () => {
      fireEvent.click(continueBtn);
    });

    await waitFor(() => {
      expect(screen.getByRole('dialog')).toBeInTheDocument();
    });
  });
});
