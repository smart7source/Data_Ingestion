import moment from 'moment';

import { convertToAmt } from 'utils';

const CreatePayload = (payload, isEditMode = false) => {
  const apiPayload = {
    originSource: 1,
    transferSource: 1,
    network: 'ACH',
    transferAmt: convertToAmt({
      value: payload.amount ?? 0,
    }),
    transferDate: moment(payload.transferDate).format('YYYY-MM-DD'),
    sourceParty: {
      accountId: payload.transferFrom,
    },
    counterParty: {
      accountId: payload.transferTo,
    },
    note: payload.transferNote || '',
  };

  if (isEditMode) {
    apiPayload.transferId = payload.transferId;
  }

  if (payload.frequency !== 'one-time') {
    let frequencyOccurance;
    let tempTransactionLimit = '';
    let tempEndDate = '';
    if (payload.frequency === '1M' || payload.frequency === '3M') {
      if (payload.frequencyMonthly === 'customDate') {
        frequencyOccurance = payload.frequencyMonthlyCustomDate;
      } else {
        frequencyOccurance = payload.frequencyMonthly
          .replace('th', '')
          .replace('st', '');
      }
    }
    if (payload.transferDateDuration === 'numberOfTransactions') {
      tempTransactionLimit = payload.transferTransactionLimit;
    } else if (payload.transferDateDuration === 'endDate') {
      tempEndDate = payload.transferEndDate
        ? moment(payload.transferEndDate).format('YYYY-MM-DD')
        : '';
    }
    apiPayload.recurringTransfer = {
      endDate: tempEndDate,
      frequency: payload.frequency === '1D' ? '1B' : payload.frequency,
      noOfOccurance: tempTransactionLimit,
      frequencyOccurance,
    };
  }
  return apiPayload;
};

export default CreatePayload;
