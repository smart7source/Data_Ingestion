import { render, screen, waitFor } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';

import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';

import { reviewTransferFormMockData, activeAccountsMock } from 'testHelpers';
import theme from 'style/theme';
import strings from 'localization/translation';
import ReviewTransfer from '../ReviewTransfer';

const history = createMemoryHistory({});

const initialState = {
  moveMoney: {
    activeAccounts: activeAccountsMock.body,
    openTransferReview: true,
  },
};
const store = configureStore();

function renderElement({
  loading,
  handleClickConfirm = jest.fn(),
  formData,
  title = strings.reviewTransferTitle,
  subtitle = strings.reviewTransfersubTitle,
  buttonForward = strings.makeTransfer,
  buttonBack = strings.cancel,
  altTitle = 'Alt Title',
  altDescr = 'Alt Descr',
}) {
  return render(
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <Provider store={store(initialState)}>
          <Router history={history}>
            <ReviewTransfer
              loading={loading}
              title={title}
              subtitle={subtitle}
              formData={formData}
              handleClickConfirm={handleClickConfirm}
              buttonForward={buttonForward}
              buttonBack={buttonBack}
              altTitle={altTitle}
              altDescr={altDescr}
            />
          </Router>
        </Provider>
      </ThemeProvider>
    </StyledEngineProvider>,
  );
}

describe('should test ReviewTransfer component', () => {
  it('should render correctly', () => {
    renderElement({ title: 'Review Transfer' });
    expect(screen.getByText('Review Transfer')).toBeInTheDocument();
  });

  it('should render correctly frequencyMonthly is lastDay', async () => {
    renderElement({
      title: 'Review Transfer',
      formData: { ...reviewTransferFormMockData, frequencyMonthly: 'E' },
    });
    await waitFor(async () => {
      expect(
        screen.queryByText(/Monthly, Last day of the month/gi),
      ).toBeInTheDocument();
    });
  });

  it('should render correctly frequencyMonthly is customDate', () => {
    renderElement({
      title: 'Review Transfer',
      formData: {
        ...reviewTransferFormMockData,
        frequencyMonthly: 'customDate',
        frequencyMonthlyCustomDate: '23',
      },
    });

    expect(
      screen.getByText(/Monthly, 23rd of the month/gi),
    ).toBeInTheDocument();
  });
});
