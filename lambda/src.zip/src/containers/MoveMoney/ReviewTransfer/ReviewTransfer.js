import {
  Button,
  Dialog,
  Grid,
  Typography,
  Box,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as ArrowRight } from 'assets/svg/arrow-right-1.svg';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';
import globalClasses from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import { openTransferReview } from 'store/actions/MoveMoneyActions';

import ReviewInfo from '../Components/ReviewInfo';
// import internalClasses from '../MoveMoney.module.scss';

const { transferFrom: FROM, transferTo: TO } = strings;

function ReviewTransfer({
  loading,
  handleClickConfirm,
  formData,
  title,
  subtitle,
  buttonForward,
  buttonBack,
  altTitle,
  altDescr,
}) {
  const {
    amount,
    frequencyMonthly,
    frequencyMonthlyCustomDate,
    transferNote,
    frequency,
    transferDateDuration,
    transferTransactionLimit,
    transferDate,
    transferEndDate,
    transferFrom,
    transferTo,
  } = formData;
  const dispatch = useDispatch();
  const { activeAccounts } = useSelector((state) => state.moveMoney);
  const showTransferReview = useSelector(
    (state) => state.moveMoney.openTransferReview,
  );

  const selectedFrom = activeAccounts.find(
    (account) => account.posnId === transferFrom,
  );

  const selectedTo = activeAccounts.find(
    (account) => account.posnId === transferTo,
  );

  const handleClose = () => {
    dispatch(openTransferReview(false));
  };

  return (
    <Dialog
      open={showTransferReview}
      keepMounted
      fullWidth
      onClose={handleClose}
      aria-labelledby={altTitle}
      aria-describedby={altDescr}
      data-testid="review-transfer"
    >
      <Grid container item xs={12}>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          size="large"
          className={globalClasses.closeIcon}
        >
          <CustomIcon
            component={Close}
            color="grey.800"
            inheritViewBox
            className={mmClasses.customCloseIcon}
          />
        </IconButton>
      </Grid>
      <DialogTitle id={altTitle}>
        <Typography className={globalClasses.dialogTitle}>{title}</Typography>
        <Typography>
          {subtitle && (
            <span className={globalClasses.titleSpan}>{subtitle}</span>
          )}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <DialogContentText id={altDescr} component="div">
          <Grid container alignItems="center" className={mmClasses.gap25}>
            <Grid container item xs={12}>
              <img
                className={globalClasses.dialogSvg}
                src={`${process.env.PUBLIC_URL}/images/transition/Paper_plane.gif`}
                alt="Cancel Transfer"
              />
            </Grid>
            <Grid container item xs={12}>
              <Grid container>
                <Grid item xs={5}>
                  <Box mb={2}>
                    <Typography variant="h3" component="h3" color="#3C3C3C">
                      {FROM}
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={2} />
                <Grid item xs={5}>
                  <Box mb={2}>
                    <Typography variant="h3" component="h3" color="#3C3C3C">
                      {TO}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
              <Grid container>
                <Grid container item xs={5} alignItems="center">
                  <Grid item className={globalClasses.reviewTransferBankHolder}>
                    <Box className={mmClasses.reviewTransferBox}>
                      <Typography
                        variant="p1"
                        className={globalClasses.reviewTransferImportant}
                      >
                        {selectedFrom ? selectedFrom.accNm : 'Chello Loan Term'}
                      </Typography>
                      <Typography
                        variant="p1"
                        className={globalClasses.reviewTransferNumb}
                      >
                        {selectedFrom
                          ? `*${selectedFrom.accNbr.slice(-4)}`
                          : '*1111'}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
                <Grid item xs={2}>
                  <Box pt={1} className={mmClasses.arrow}>
                    <CustomIcon
                      component={ArrowRight}
                      color="grey.800"
                      inheritViewBox
                      className={mmClasses.arrowIcon}
                    />
                  </Box>
                </Grid>
                <Grid container item xs={5} alignItems="center">
                  <Grid item className={globalClasses.reviewTransferBankHolder}>
                    <Box className={mmClasses.reviewTransferBox}>
                      <Typography
                        variant="p1"
                        className={globalClasses.reviewTransferImportant}
                      >
                        {selectedTo
                          ? selectedTo.accNm
                          : 'City Business Checking'}
                      </Typography>
                      <Typography
                        variant="p1"
                        className={globalClasses.reviewTransferNumb}
                      >
                        {selectedTo
                          ? `*${selectedTo.accNbr.slice(-4)}`
                          : '*7635'}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Grid container item xs={12}>
              <ReviewInfo
                amount={amount}
                frequencyMonthly={frequencyMonthly}
                frequencyMonthlyCustomDate={frequencyMonthlyCustomDate}
                transferNote={transferNote}
                frequency={frequency}
                transferDateDuration={transferDateDuration}
                transferTransactionLimit={transferTransactionLimit}
                transferDate={transferDate}
                transferEndDate={transferEndDate}
              />
            </Grid>
          </Grid>
        </DialogContentText>
      </DialogContent>
      <DialogActions className={mmClasses.cancelModalButtons}>
        <Button
          onClick={handleClose}
          color="secondary"
          variant="contained"
          className={mmClasses.cancelModalButton}
        >
          {buttonBack}
        </Button>
        {!loading ? (
          <Button
            onClick={handleClickConfirm}
            color="primary"
            variant="contained"
            className={mmClasses.cancelModalButton}
          >
            {buttonForward}
          </Button>
        ) : (
          <LoadingButton loading variant="contained">
            {buttonForward}
          </LoadingButton>
        )}
      </DialogActions>
    </Dialog>
  );
}

export default ReviewTransfer;

ReviewTransfer.propTypes = {
  loading: PropTypes.bool,
  handleClickConfirm: PropTypes.func,
  title: PropTypes.string,
  subtitle: PropTypes.string,
  buttonForward: PropTypes.string,
  buttonBack: PropTypes.string,
  altTitle: PropTypes.string,
  altDescr: PropTypes.string,
  formData: PropTypes.instanceOf(Object),
};

ReviewTransfer.defaultProps = {
  loading: false,
  handleClickConfirm: defaultFnPropTypes,
  title: '',
  subtitle: '',
  buttonForward: '',
  buttonBack: '',
  altTitle: '',
  altDescr: '',
  formData: {},
};
