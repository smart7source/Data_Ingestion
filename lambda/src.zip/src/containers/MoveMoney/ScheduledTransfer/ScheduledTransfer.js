import {
  Box,
  Grid,
  CircularProgress,
  Paper,
  Table,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  TableBody,
} from '@mui/material';
import { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import strings from 'localization/translation';
import BackToTop from 'components/UIElements/BackToTop';
import { Notification } from 'components';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import {
  showEditDialog,
  showCancelDialog,
} from 'store/actions/MoveMoneyActions';
import { setSelectedTransactionIndex } from 'store/actions/OneAccountActions';
import { useInfiniteScroll } from 'hooks';
import { setLoader } from 'store/actions';
import mmClasses from 'style/MoveMoney.module.scss';

import ScheduledTransferTableRow from '../ScheduledTransferTableRow/ScheduledTransferTableRow';
// import classes from '../MoveMoney.module.scss';
import EditTransfer from '../EditTransfer/EditTransfer';
import CancelTransfer from '../CancelTransfer/CancelTransfer';
import CancelConfirmation from '../CancelConfirmation/CancelConfirmation';

const {
  date: DATE,
  from: FROM,
  to: TO,
  frequency: FREQUENCY,
  duration: DURATION,
  amount: AMOUNT,
  youCurrentlyHaveNoScheduledTransfers: NO_TRANSFERS,
  cancelTransfer: CANCEL_TRANSFER,
  exitDialogMessage5: GO_BACK,
  stopTransferHeading: STOP_TRANSFER_HEADING,
} = strings;

const options = [
  {
    name: 'Edit',
  },
  {
    name: 'Cancel transfer',
  },
];

const ScheduledTransfer = () => {
  const dispatch = useDispatch();
  const [transfers, setTransfers] = useState([]);
  const [prevSkip, setPrevSkip] = useState(0);
  const [count, setCount] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);
  const [errMsgs, setErrMsgs] = useState([]);
  const [showAtPx, setShowAtPx] = useState(0);
  const [scrollToPx, setScrollToPx] = useState(0);
  const filterWidgetRef = useRef(null);

  const [cancelling, setCancelling] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [confirmationModal, setConfirmationModal] = useState(false);

  const selectedIndex = useSelector(
    (state) => state.OneAccount.selectedTransactionIndex,
  );
  const getTransfers = async (params = {}, isReload = false) => {
    try {
      setIsLoaded(false);
      const response = await ApiClient.get(serviceUrl.makeTransfer, {
        params,
      });
      const { scheduledTransfers } = response?.body;
      let tempSkip = 0;
      if (isReload) {
        setTransfers(scheduledTransfers);
      } else {
        setTransfers([...transfers, ...scheduledTransfers]);
        tempSkip = prevSkip;
      }
      setCount(scheduledTransfers.length);
      setPrevSkip(tempSkip + 10);
    } catch (error) {
      setErrMsgs([{ severity: 'error', message: error.message }]);
    } finally {
      setIsLoaded(true);
    }
  };

  useEffect(() => {
    getTransfers({ skip: 0, top: 10 });
  }, []);

  const loadMore = () => {
    if (count !== 0) {
      getTransfers({ skip: prevSkip, top: 10 });
    }
  };

  const lastElRef = useInfiniteScroll({
    loading: !isLoaded,
    hasMore: true,
    loadMore,
  });

  const reloadApi = () => {
    getTransfers({ skip: 0, top: 10 }, true);
  };

  const onMenuOptionClick = (option, index) => {
    dispatch(setSelectedTransactionIndex(index));
    if (option.name === 'Edit') {
      dispatch(showEditDialog(true));
    }
    if (option.name === 'Cancel transfer') {
      dispatch(showCancelDialog(true));
    }
  };

  const handleClickConfirm = async () => {
    const isRecurringFrequency =
      transfers?.[selectedIndex]?.transferDetail?.recurringTransfer
        ?.frequency !== undefined;
    const transferId = transfers?.[selectedIndex]?.transferId || '';
    dispatch(setLoader(true));
    setCancelling(true);
    try {
      const response = await ApiClient.delete(
        `${serviceUrl.cancelTransfer}/${transferId}`,
        {
          data: { cancelSeries: isRecurringFrequency || false },
        },
      );
      if (response) {
        setIsSuccess(true);
      }
    } catch (error) {
      setIsSuccess(false);
    } finally {
      // setCancelModal(false);
      setConfirmationModal(true);
      dispatch(setLoader(false));
      dispatch(showCancelDialog(false));
      setCancelling(false);
    }
  };

  const handleConfirmClose = () => {
    reloadApi();
    setConfirmationModal(false);
  };

  useEffect(() => {
    const { offsetTop = 0, offsetHeight = 0 } = filterWidgetRef.current || {};
    setShowAtPx(200);
    setScrollToPx(offsetTop);
  }, []);

  return (
    <>
      {errMsgs && errMsgs.length > 0 && (
        <Box mb={2.5}>
          <Notification errors={errMsgs} needFocus />
        </Box>
      )}
      <Paper
        className={mmClasses.scheduledTransfer}
        elevation={1}
        ref={filterWidgetRef}
      >
        <Grid className={mmClasses.scheduleTransferActivityStyle}>
          <Table
            data-testid="scheduled-transfer"
            className={mmClasses.scheduledTransferStyle}
          >
            <TableHead>
              <TableRow className={mmClasses.scheduleTransferTableHead}>
                <TableCell>{DATE}</TableCell>
                <TableCell>{FROM}</TableCell>
                <TableCell>{TO}</TableCell>
                <TableCell>
                  {FREQUENCY}/{DURATION}
                </TableCell>
                <TableCell>{AMOUNT}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transfers?.length
                ? transfers.map((transfer, index) => (
                    <ScheduledTransferTableRow
                      key={index}
                      index={index}
                      transfer={transfer}
                      reloadApi={reloadApi}
                      kebabOptions={options}
                      account="chello"
                      onMenuOptionClick={(option) =>
                        onMenuOptionClick(option, index)
                      }
                      lastElRef={
                        transfers.length === index + 1 ? lastElRef : null
                      }
                    />
                  ))
                : isLoaded && (
                    <TableRow>
                      <TableCell colSpan="10">
                        <Box className={mmClasses.noData}>
                          <Typography
                            variant="p1SemiBold"
                            component="p"
                            align="center"
                          >
                            {NO_TRANSFERS}
                          </Typography>
                        </Box>
                      </TableCell>
                    </TableRow>
                  )}
            </TableBody>
          </Table>
        </Grid>
        <BackToTop scrollToPx={scrollToPx} showAtPx={showAtPx} />

        {!isLoaded && (
          <Box display="flex" justifyContent="center" width="100%">
            <CircularProgress />
          </Box>
        )}
      </Paper>
      {transfers && transfers?.length > 0 && (
        <EditTransfer
          formData={transfers?.[selectedIndex] || []}
          reloadApi={reloadApi}
        />
      )}
      {transfers && transfers?.length > 0 && (
        <CancelTransfer
          transfer={transfers?.[selectedIndex] || []}
          title={STOP_TRANSFER_HEADING}
          altTitle="cancel-transfer"
          altDescr="modal-to-cancel-the-transfer"
          cancelling={cancelling}
          handleClickConfirm={handleClickConfirm}
          buttonForward={CANCEL_TRANSFER}
          buttonBack={GO_BACK}
        />
      )}

      {transfers && transfers?.length > 0 && (
        <CancelConfirmation
          open={confirmationModal}
          handleClose={handleConfirmClose}
          transfer={transfers?.[selectedIndex] || []}
          isSuccess={isSuccess}
        />
      )}
    </>
  );
};

export default ScheduledTransfer;
