import { render, screen, wait, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { renderWithProviderAndRouter } from 'testHelpers';
import ScheduledTransfer from '../ScheduledTransfer';

const initialState = {
  moveMoney: {
    showEditDialog: false,
    showCancelDialog: false,
    activeAccounts: [
      {
        accNm: 'Plaid Checking',
        accId: '4hFnUGvqo8qHDV----5F-77-',
        accNbr: '1111222233330000',
        accMask: '1111',
        rtgnNbr: '011401533',
        wireRtgnNbr: '22222222',
        accPosNbr: '1',
        accTypNm: 'external',
        savanaAppId: '',
        posnId: '4hFnUGvqo8qHDV----5F-77-',
      },
      {
        accNm: 'Boostby Chello',
        accId: 'B72Upia686WBO3QA8jrcJm6GsLSqjPwGwFTtnPE8uFEIYj0GrQhgg==',
        accNbr: 'xxxx1354',
        accMask: '1111',
        rtgnNbr: '21508183',
        wireRtgnNbr: '22222222',
        accPosNbr: '1',
        accTypNm: 'internal',
        savanaAppId: '',
        posnId: '4hUUPfvGX_gg1----VDF-E7-',
      },
      {
        accNm: 'Plaid Saving',
        accId: '4hY_0wZk65q6bV----LF-77-',
        accNbr: '1111222233331111',
        accMask: '1111',
        rtgnNbr: '011401533',
        wireRtgnNbr: '011401533',
        accPosNbr: '1',
        accTypNm: 'external',
        savanaAppId: '',
        posnId: '4hY_0wZk65q6bV----LF-77-',
      },
    ],
  },
};

describe('should test initial condition', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('Should render sheduletransfer', async () => {
    renderWithProviderAndRouter(<ScheduledTransfer />, {
      render,
      wrapperProps: {
        initialState,
      },
    });
    expect(screen.getByTestId('scheduled-transfer')).toBeInTheDocument();
    await screen.findAllByText('Chello *0834');
  });

  it('Should display frequency', async () => {
    await waitFor(() =>
      expect(
        screen.getByRole('columnheader', {
          name: /frequency\/duration/i,
        }),
      ).toBeInTheDocument(),
    );
  });

  it('On Edit transfer', async () => {
    userEvent.click(screen.getByTestId('kebab-menu-chello-transaction-0-btn'));
    await screen.findByText('Edit');

    userEvent.click(screen.getByText('Edit'));

    expect(await screen.findByText('Edit transfer')).toBeInTheDocument();

    userEvent.click(screen.getByText('Cancel'));

    await waitFor(() => {
      expect(screen.queryByText('Edit transfer')).not.toBeInTheDocument();
    });
  });

  // it('On  Cancel selection', async () => {
  //   await screen.findByTestId('kebab-menu-chello-transaction-0-btn');
  //   userEvent.click(screen.getByTestId('kebab-menu-chello-transaction-0-btn'));
  //   await screen.findAllByText('Cancel transfer')[1];

  //   userEvent.click(screen.getAllByText('Cancel transfer')[1]);

  //   userEvent.click(screen.getByText('No, go back'));
  // });

  it('On confirm cancel transfer', async () => {
    screen.findByTestId('kebab-menu-chello-transaction-0-btn');
    userEvent.click(screen.getByTestId('kebab-menu-chello-transaction-0-btn'));

    await waitFor(() => {
      expect(screen.queryAllByText('Cancel transfer')[1]).toBeInTheDocument();
    });

    // await screen.findAllByText('Cancel transfer')[1];

    userEvent.click(screen.getAllByText('Cancel transfer')[1]);

    // await waitFor(() => {
    //   expect(
    //     screen.getByRole('button', {
    //       name: /cancel transfer/i,
    //     }),
    //   ).toBeInTheDocument();
    // });

    await waitFor(() => {
      expect(
        screen.getByRole('dialog', { labelledby: 'cancel-transfer' }),
      ).toBeInTheDocument();
    });

    userEvent.click(
      screen.getByRole('button', {
        name: /cancel transfer/i,
      }),
    );

    await waitFor(() => {
      expect(
        screen.getByRole('dialog', {
          labelledby: 'transfer-cancel-confirmation',
        }),
      ).toBeInTheDocument();
    });

    await screen.findByText('Confirmation');

    // await waitFor(() => {
    //   expect(screen.getByText('Confirmation')).toBeInTheDocument();
    // });
    await screen.findByText('Ok');
    userEvent.click(screen.getByText('Ok'));

    // await waitFor(() => {
    //   expect(
    //     screen.getByRole('dialog', {
    //       labelledby: 'transfer-cancel-confirmation',
    //     }),
    //   ).not.toBeInTheDocument();
    // });

    expect(
      screen.queryByText(screen.getByRole('dialog')),
    ).not.toBeInTheDocument();
  });
});
