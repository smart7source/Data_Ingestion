import { Box, TableCell, TableRow } from '@mui/material';
import PropTypes from 'prop-types';
import clsx from 'clsx';

import { currencyFormat } from 'utils';
import style from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';

const TransferActivityTableRow = (props) => {
  const { amount, transferFrom, transferTo, transferDate, status, lastElRef } =
    props;
  const elRef = lastElRef ? { ref: lastElRef } : {};

  return (
    <TableRow {...elRef}>
      <TableCell className={clsx(style.p1Paragraph)}>{transferDate}</TableCell>
      <TableCell className={style.p1Paragraph}>{status}</TableCell>
      <TableCell className={style.p1Paragraph}>{transferFrom}</TableCell>
      <TableCell className={style.p1Paragraph}>{transferTo}</TableCell>
      <TableCell
        role="cell"
        className={clsx(style.p2Paragraph, mmClasses.transferAlignRight)}
      >
        {currencyFormat(amount)}
      </TableCell>
    </TableRow>
  );
};

export default TransferActivityTableRow;

TransferActivityTableRow.propTypes = {
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  transferFrom: PropTypes.string,
  transferTo: PropTypes.string,
  transferDate: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Date),
  ]),
  status: PropTypes.string,
  lastElRef: PropTypes.instanceOf(Object),
};
TransferActivityTableRow.defaultProps = {
  amount: '',
  transferFrom: '',
  transferTo: '',
  transferDate: '',
  status: '',
  lastElRef: null,
};
