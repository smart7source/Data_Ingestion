/* eslint-disable max-lines */
import { useEffect, useState, useRef } from 'react';
import {
  Grid,
  Button,
  CircularProgress,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@mui/material';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import clsx from 'clsx';
import moment from 'moment';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Download } from 'assets/svg/download.svg';
import strings from 'localization/translation';
import { useInfiniteScroll } from 'hooks';
import { ReactComponent as NoTransfers } from 'assets/svg/no-transfers.svg';
import globalClasses from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import { CustomSelectBox, Notification } from 'components';
import BackToTop from 'components/UIElements/BackToTop';
import ApiClient from 'api/ApiClient';
import serviceUrl from 'api/UrlHelper';
import { download, getContentType } from 'utils/utility';
import { openExport } from 'store/actions/MoveMoneyActions';
import { setLoader } from 'store/actions';

import {
  transferActivityStatus,
  transferActivitySortBy,
  getTransferDates,
} from '../Components/transferData';
import TransferActivityList from '../TransferActivityList/TransferActivityList';
import DataRange from '../Components/DataRange';
import Export from '../Export/Export';
// import internalClasses from '../MoveMoney.module.scss';

import TransferActivityTableRow from './TransferActivityTableRow';

const {
  transactions: TRANSACTION,
  export: EXPORT,
  status: STATUS,
  sortBy: SORT_BY,
  go: GO,
  date: DATE,
  from: FROM,
  to: TO,
  amount: AMOUNT,
  youHaveNoPastTransfers: NO_TRANSFERS,
} = strings;

const TransferActivity = () => {
  const {
    control,
    getValues,
    setValue,
    watch,
    resetField,
    formState: { errors },
  } = useForm({
    mode: 'all',
    defaultValues: {
      transferActivityFrequency: 'last7Days',
      transferActivityStatus: '',
      transferActivitySortBy: '-orderDtm',
      formatDownload: 'CSV',
    },
  });
  const dispatch = useDispatch();
  const [transferActivities, setTransferActivities] = useState([]);
  const [totalActivitiesCount, setTotalActivitiesCount] = useState(0);
  const [errMsgs, setErrMsgs] = useState([]);
  const [prevSkip, setPrevSkip] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);
  const [showAtPx, setShowAtPx] = useState(0);
  const [scrollToPx, setScrollToPx] = useState(0);
  const filterWidgetRef = useRef(null);

  const getRecentTransferActivities = async (params = {}, isFilter = false) => {
    setIsLoaded(false);
    try {
      const response = await ApiClient.get(serviceUrl.getTransferActivity, {
        params,
      });
      const { recentTransfers, totalItemsCount } = response?.body;
      let tempSkip = 0;
      if (isFilter) {
        setTransferActivities(recentTransfers);
      } else {
        setTransferActivities([...transferActivities, ...recentTransfers]);
        tempSkip = prevSkip;
      }
      setTotalActivitiesCount(totalItemsCount);
      setPrevSkip(tempSkip + 10);
    } catch (error) {
      setErrMsgs([{ severity: 'error', message: error.message }]);
    } finally {
      setIsLoaded(true);
    }
  };

  useEffect(() => {
    const { params } = getParams();
    getRecentTransferActivities({ ...params, skip: 0, top: 10 });
  }, []);

  const getParams = () => {
    const { fromDate, toDate } = getTransferDates(
      getValues('transferActivityFrequency'),
      getValues('dataRangeFrom'),
      getValues('dataRangeTo'),
    );
    const params = {
      status: getValues('transferActivityStatus') || undefined,
      sortBy: getValues('transferActivitySortBy'),
      fromDate: moment(fromDate).format('YYYY-MM-DD'),
      toDate: moment(toDate).format('YYYY-MM-DD'),
      top: 10,
    };
    return { params };
  };

  const loadMore = () => {
    if (prevSkip <= totalActivitiesCount) {
      const { params } = getParams();
      getRecentTransferActivities({ ...params, skip: prevSkip });
    }
  };

  const lastElRef = useInfiniteScroll({
    loading: !isLoaded,
    hasMore: true,
    loadMore,
  });

  const statusFilter = () => {
    const { params } = getParams();
    getRecentTransferActivities({ ...params, skip: 0 }, true);
  };

  useEffect(() => {
    const { offsetTop = 0, offsetHeight = 0 } = filterWidgetRef.current || {};
    setShowAtPx(200);
    setScrollToPx(offsetTop);
  }, []);

  const handleExport = async () => {
    const { params } = getParams();
    const { top, ...restParams } = params;
    const contentType = getValues('formatDownload');
    const exportParams = {
      ...restParams,
      fileType: contentType,
    };
    try {
      dispatch(setLoader(true));
      const data = await ApiClient.get(serviceUrl.exportTransferActivity, {
        params: { ...exportParams },
      });
      download(
        `transfer-activity.${contentType.toLowerCase()}`,
        data?.body?.content,
        getContentType(contentType),
      );
    } catch (err) {
      setErrMsgs([{ severity: 'error', message: err.message }]);
    } finally {
      dispatch(openExport(false));
      dispatch(setLoader(false));
    }
  };

  return (
    <>
      {errMsgs && errMsgs.length > 0 && (
        <Box mb={2.5}>
          <Notification errors={errMsgs} needFocus />
        </Box>
      )}
      <Grid
        ref={filterWidgetRef}
        container
        data-testid="transfer-activity-container"
        className={clsx(
          globalClasses.container,
          mmClasses.transferActivityTable,
        )}
      >
        <Export
          handleSubmit={handleExport}
          getValues={getValues}
          setValue={setValue}
          control={control}
          errors={errors}
        />
        <Grid
          container
          justifyContent="space-between"
          alignItems="center"
          mb={2}
        >
          <Grid item xs={6}>
            <Typography
              variant="h2"
              component="h2"
              style={{ fontWeight: 'bold' }}
            >
              {`${
                TRANSACTION.charAt(0).toUpperCase() + TRANSACTION.slice(1)
              } (${totalActivitiesCount || 0})`}
            </Typography>
          </Grid>
          <Grid item xs={2} lg={2}>
            <Box pr={1}>
              <Button
                className={globalClasses.exportBtn}
                color="regular"
                size="small"
                onClick={() => dispatch(openExport(true))}
                startIcon={
                  <CustomIcon
                    component={Download}
                    color={
                      transferActivities?.length === 0 ? 'disabled' : 'primary'
                    }
                    inheritViewBox
                    className={mmClasses.exportSize}
                  />
                }
                disabled={transferActivities?.length === 0}
              >
                {EXPORT}
              </Button>
            </Box>
          </Grid>
        </Grid>
        <Grid container justifyContent="flex-start" alignItems="start">
          <DataRange control={control} watch={watch} resetField={resetField} />
          <Grid item xs={12} md={7} lg={2}>
            <Box mr={1} data-testid="transferActivityFilterOption">
              <CustomSelectBox
                name="transferActivityStatus"
                id="transferActivityStatus"
                options={transferActivityStatus}
                hideSelect
                label={STATUS}
                control={control}
                dataTestid="transferActivityStatus"
              />
            </Box>
          </Grid>

          <Grid item xs={12} md={5} lg={5}>
            <Box mr={1} data-testid="transferActivityFilterOption">
              <CustomSelectBox
                name="transferActivitySortBy"
                id="transferActivitySortBy"
                options={transferActivitySortBy}
                hideSelect
                label={SORT_BY}
                control={control}
                dataTestid="transferActivitySortBy"
              />
            </Box>
          </Grid>

          <Grid item xs={12} lg={1}>
            <Box mr={1} pt="31px" className={mmClasses.goButton}>
              <Button
                className={globalClasses.filterBtn}
                fullWidth
                variant="contained"
                color="secondary"
                size="large"
                onClick={statusFilter}
              >
                {GO}
              </Button>
            </Box>
          </Grid>
        </Grid>

        <Grid className={mmClasses.scheduleTransferActivityStyle}>
          <Table data-testid="transferActivityTable">
            <TableHead>
              <TableRow className={mmClasses.transferActivityHeader}>
                <TableCell>{DATE}</TableCell>

                <TableCell>{STATUS}</TableCell>
                <TableCell>{FROM}</TableCell>
                <TableCell>{TO}</TableCell>
                <TableCell>{AMOUNT}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody mx={3} className={mmClasses.boxWidth}>
              {transferActivities?.length
                ? transferActivities.map((section, i) => (
                    <TransferActivityTableRow
                      key={i}
                      amount={section.amount}
                      transferFrom={section.from}
                      transferTo={section.to}
                      transferDate={section.date}
                      status={section.status}
                      lastElRef={
                        transferActivities.length === i + 1 ? lastElRef : null
                      }
                    />
                  ))
                : isLoaded && (
                    <TableRow>
                      <TableCell colSpan="10">
                        <Box
                          display="flex"
                          flexDirection="column"
                          gap={1.5}
                          alignItems="center"
                          className={mmClasses.transferMargin}
                        >
                          <NoTransfers />
                          <Typography variant="h3" component="p" align="center">
                            {NO_TRANSFERS}
                          </Typography>
                        </Box>
                      </TableCell>
                    </TableRow>
                  )}
            </TableBody>
          </Table>
        </Grid>
        <BackToTop scrollToPx={scrollToPx} showAtPx={showAtPx} />

        {!isLoaded && (
          <Box
            display="flex"
            justifyContent="center"
            width="100%"
            data-testid="circular-spinner"
          >
            <CircularProgress />
          </Box>
        )}
      </Grid>
    </>
  );
};

export default TransferActivity;
