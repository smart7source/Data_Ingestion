import {
  act,
  fireEvent,
  render,
  waitFor,
  screen,
} from '@testing-library/react';
import { createMemoryHistory } from 'history';
import { renderWithProviderAndRouter } from 'testHelpers';
import { rest } from 'msw';

import serviceUrl from 'api/UrlHelper';
import server from 'apiMocks/server';

import TransferActivity from '../TransferActivity';

const history = createMemoryHistory();

const initialState = {
  moveMoney: {
    activeAccounts: [],
    openExport: false,
  },
};

const filterAPI = () => {
  server.use(
    rest.get(serviceUrl.getTransferActivity, (req, res, ctx) =>
      res(
        ctx.json({
          body: [
            {
              date: 'Jun 24, 2022',
              status: 'Completed',
              from: 'Wells Fargo Plaid Checking *0000',
              to: 'Chello *1354',
              amount: '6.00',
            },
          ],
        }),
      ),
    ),
  );
};

const exportAPI = () => {
  server.use(
    rest.get(serviceUrl.exportTransferActivity, (req, res, ctx) =>
      res.networkError('Failed to connect'),
    ),
  );
};

describe('TransferActivity Component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
    renderWithProviderAndRouter(<TransferActivity />, {
      render,
      wrapperProps: { initialState },
    });
  });

  it('should render TransferActivity page', async () => {
    expect(
      screen.getByTestId('transfer-activity-container'),
    ).toBeInTheDocument();
    await waitFor(() =>
      expect(screen.queryByTestId('circular-spinner')).not.toBeInTheDocument(),
    );
  });

  it('should filter transactions with completed status', async () => {
    filterAPI();
    const frequency = screen.getByTestId('transferActivityFrequency');
    const status = screen.getByTestId('transferActivityStatus');
    const sortBy = screen.getByTestId('transferActivitySortBy');
    const goBtn = screen.getByRole('button', { name: /Go/i });
    expect(frequency).toBeInTheDocument();
    expect(status).toBeInTheDocument();
    expect(sortBy).toBeInTheDocument();
    expect(goBtn).toBeInTheDocument();
    await waitFor(() =>
      expect(screen.queryByTestId('circular-spinner')).not.toBeInTheDocument(),
    );
    await act(async () => {
      fireEvent.change(frequency, { target: { value: 'last7Days' } });
      fireEvent.change(status, { target: { value: '4' } });
      fireEvent.change(sortBy, { target: { value: '-orderDtm' } });
    });
    await act(async () => {
      fireEvent.click(goBtn);
    });
    await waitFor(() => {
      expect(screen.queryByTestId('circular-spinner')).not.toBeInTheDocument();
      expect(document.querySelectorAll('tbody > tr')).toHaveLength(1);
    });
  });

  it('should export PDF', async () => {
    exportAPI();
    await waitFor(() =>
      expect(screen.queryByTestId('circular-spinner')).not.toBeInTheDocument(),
    );
    const exportBtn = screen.getByRole('button', { name: /Export/i });
    expect(exportBtn).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(exportBtn);
    });
    await waitFor(async () => {
      expect(
        screen.queryByTestId('transfer-activity-export'),
      ).toBeInTheDocument();
      const downloadBtn = screen.getByRole('button', { name: /Download/i });
      expect(downloadBtn).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(downloadBtn);
      });
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument();
      expect(
        screen.queryByTestId('transfer-activity-export'),
      ).toBeInTheDocument();
      expect(screen.queryByTestId('notification-alert')).toBeInTheDocument();
    });
  });
});
