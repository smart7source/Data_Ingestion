import * as Yup from 'yup';

import strings from 'localization/translation';
import { convertToAmt } from 'utils';

const { dateTypeError: DATE_TYPE_ERROR, maxCharacters: MAX_CHARCTERS } =
  strings;

const date = new Date();
date.setDate(date.getDate() - 1);

const makeTransferSchema = Yup.object().shape({
  transferDate: Yup.date()
    .nullable()
    .transform((curr, orig) => (orig === '' ? null : curr))
    .typeError(DATE_TYPE_ERROR)
    .min(date, 'Date must be present or future')
    .required('Date is required'),

  isTransferDateDuration: Yup.boolean(),
  transferDateDuration: Yup.string().when('isTransferDateDuration', {
    is: true,
    then: Yup.string().required('This field is required'),
    otherwise: Yup.string(),
  }),
  transferEndDate: Yup.date().when('isTransferDateDuration', {
    transferDateDuration: Yup.string(),
    is: true,
    then: Yup.date().when('transferDateDuration', {
      is: 'endDate',
      then: Yup.date()
        .nullable()
        .transform((curr, orig) => (orig === '' ? null : curr))
        .typeError(DATE_TYPE_ERROR)
        .default(new Date())
        .min(date, 'Date must be present or future')
        .required('Date is required'),
      otherwise: Yup.date().nullable(),
    }),
    otherwise: Yup.date().nullable(),
  }),
  // transferEndDate: Yup.date().when('validationHelper', {
  //   is: 'validateendDate',
  //   then: Yup.date()
  //     .nullable()
  //     .transform((curr, orig) => (orig === '' ? null : curr))
  //     .typeError(DATE_TYPE_ERROR)
  //     .default(new Date())
  //     .min(date, 'Date must be present or future')
  //     .required('Date is required'),
  //   otherwise: Yup.date().nullable(),
  // }),

  transferFrom: Yup.string().required('This field is required'),
  transferTo: Yup.string().required('This field is required'),

  isFrequencyMonthly: Yup.boolean(),
  frequencyMonthly: Yup.string().when('isFrequencyMonthly', {
    is: true,
    then: Yup.string().required('This field is required'),
    otherwise: Yup.string(),
  }),

  validationHelperFreqDate: Yup.string(),
  frequencyMonthlyCustomDate: Yup.string().when('validationHelperFreqDate', {
    is: 'customDate',
    then: Yup.string()
      .nullable()
      .required('This field is required')
      .test(
        'minimumDate',
        'Custom date should be between 1 and 31',
        (val) => Number(val?.replace(/,/g, '')) >= 1,
      )
      .test(
        'maximumDate',
        'Custom date should be between 1 and 31',
        (val) => Number(val?.replace(/,/g, '')) <= 31,
      ),
    otherwise: Yup.string(),
  }),

  validationHelper: Yup.string(),
  transferTransactionLimit: Yup.string().when('validationHelper', {
    is: 'validateNumberOTrans',
    then: Yup.string()
      .nullable()
      .required('This field is required')
      .test(
        'minimumTransaction',
        'Number of transactions should be at least 1',
        (val) => Number(val?.replace(/,/g, '')) >= 1,
      )
      .test(
        'maximumTransaction',
        'Number of transactions should be at most 99',
        (val) => Number(val?.replace(/,/g, '')) <= 99,
      ),
    otherwise: Yup.string(),
  }),

  frequency: Yup.string().required('Frequency is required'),
  amount: Yup.string()
    .matches(
      /((\$ )?)((?!(00+\d))\d*,*\d*)/g,
      'Transfer amount could not start with 00',
    )
    .required('This field is required')
    .test(
      'minimum',
      'Transfer amount should be more than $0',
      (value) => +convertToAmt({ value }) > 0,
    ),
  transferNote: Yup.string().max(150, MAX_CHARCTERS),
});

export default makeTransferSchema;
