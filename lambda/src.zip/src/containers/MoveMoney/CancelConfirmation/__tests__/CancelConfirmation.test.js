import { render, screen } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';

import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';

import { cancelTransferMock } from 'testHelpers';
import strings from 'localization/translation';
import CancelConfirmation from '../CancelConfirmation';
import theme from 'style/theme';

const history = createMemoryHistory({});

const initialState = {};
const mockStore = configureStore();

function renderElement({
  open,
  handleClose = jest.fn(),
  transfer = {},
  isSuccess,
}) {
  return render(
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <Provider store={mockStore(initialState)}>
          <Router history={history}>
            <CancelConfirmation
              open={open}
              transfer={transfer}
              handleClose={handleClose}
              isSuccess={isSuccess}
            />
          </Router>
        </Provider>
      </ThemeProvider>
    </StyledEngineProvider>,
  );
}

describe('should test CancelConfirmation component', () => {
  it('should render correctly', () => {
    renderElement({ open: true, isSuccess: true });
    expect(screen.getByTestId('cancel-confirmation')).toBeInTheDocument();
  });

  it('should check cancel success title', () => {
    renderElement({ open: true, isSuccess: true });
    expect(screen.getByTestId('cancel-confirmation-title')).toHaveTextContent(
      'You’ve pulled the brakes.',
    );
  });

  it('should check cancel failed title', () => {
    renderElement({ open: true, isSuccess: false });
    expect(screen.getByTestId('cancel-confirmation-title')).toHaveTextContent(
      'Your transfer could not be cancelled',
    );
  });

  it('should contain guide link if cancel is failed', () => {
    renderElement({ open: true, isSuccess: false });
    expect(screen.getByText(strings.heresWhatYouCanDo)).toBeInTheDocument();
  });

  it('should render cancel success text with transfer amount', async () => {
    renderElement({
      open: true,
      isSuccess: true,
      transfer: cancelTransferMock,
    });
    expect(await screen.getByText(/has been cancelled./i)).toBeInTheDocument();
  });

  it('should render cancel failed text with transfer amount', async () => {
    renderElement({
      open: true,
      isSuccess: false,
      transfer: cancelTransferMock,
    });
    expect(
      await screen.getByText(/has not been cancelled./i),
    ).toBeInTheDocument();
  });
});
