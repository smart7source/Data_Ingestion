import {
  Button,
  Dialog,
  IconButton,
  Grid,
  Typography,
  Box,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Link,
} from '@mui/material';
import clsx from 'clsx';
import PropTypes from 'prop-types';

import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle.svg';
import { ReactComponent as AlertCircle } from 'assets/svg/alert-circle.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import globalClasses from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import { defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';

// import internalClasses from '../MoveMoney.module.scss';

const {
  youvePulledTheBrakes: PULLED_BRAKES,
  yourTransferCouldNotBeCancelled: CANT_BE_CANCELLED,
  heresWhatYouCanDo: WHAT_CAN_DO,
  yourTransferOf: TRANSFER_OF,
  hasBeenCanceled: CANCELED,
  hasNotBeenCanceled: NOT_CANCELED,
  confirmation: CONFORMATION,
  date: DATE,
  ok: OK,
} = strings;

function CancelConfirmation({ open, handleClose, transfer, isSuccess }) {
  const { amount, transferId, date } = transfer;
  return (
    <Dialog
      open={open}
      keepMounted
      fullWidth
      onClose={handleClose}
      aria-labelledby="transfer-cancel-confirmation"
      aria-describedby="transfer-cancel-confirmation"
      data-testid="cancel-confirmation"
    >
      <IconButton
        aria-label="close"
        size="small"
        className={globalClasses.closeIcon}
        data-testid="cancel-confirmation-close"
        onClick={handleClose}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={mmClasses.customCloseIcon}
        />
      </IconButton>
      <DialogTitle
        id="transfer-cancel-confirmation"
        className={globalClasses.dialogTitle}
        data-testid="cancel-confirmation-title"
      >
        <Typography variant="h1" component="span">
          {isSuccess ? PULLED_BRAKES : CANT_BE_CANCELLED}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <DialogContentText id="transfer-cannot-be-done" component="div">
          <Grid container alignItems="center">
            <Grid
              container
              item
              xs={12}
              spacing={2}
              alignItems="center"
              className={globalClasses.reviewTransferContainer}
            >
              <Grid item>
                <Box mb={1}>
                  {isSuccess ? (
                    <CustomIcon
                      component={CheckmarkCircle}
                      color="success"
                      inheritViewBox
                      className={mmClasses.customIcon}
                    />
                  ) : (
                    <CustomIcon
                      component={AlertCircle}
                      color="error"
                      inheritViewBox
                      className={mmClasses.customIcon}
                    />
                  )}
                </Box>
              </Grid>
              <Grid item>
                <Box mb={1} pb={1}>
                  {isSuccess ? (
                    <Typography
                      varian="p1"
                      className={globalClasses.reviewTransferImportant}
                    >
                      {`${TRANSFER_OF} $${amount} ${CANCELED}`}
                    </Typography>
                  ) : (
                    <Typography
                      varian="p1"
                      className={globalClasses.reviewTransferImportant}
                    >
                      {`${TRANSFER_OF} $${amount} ${NOT_CANCELED}`}
                    </Typography>
                  )}
                </Box>
              </Grid>
            </Grid>
            <Grid container item>
              {isSuccess ? (
                <img
                  className={globalClasses.dialogSvg}
                  src="/svg/cancel-transfer-success.svg"
                  alt="Successfully cancelled transfer"
                />
              ) : (
                <img
                  className={globalClasses.dialogSvg}
                  src="/svg/cancel-transfer-failed.svg"
                  alt="Failed to cancel the transfer"
                />
              )}
            </Grid>
            <Grid container item mb={1}>
              {!isSuccess && (
                <Link href="#" className={globalClasses.link}>
                  {WHAT_CAN_DO}
                </Link>
              )}
            </Grid>
            <Grid container item>
              <div className={globalClasses.reviewTransferHolder}>
                <Grid
                  container
                  alignItems="flex-start"
                  direction="column"
                  justifyContent="space-around"
                >
                  <Grid
                    container
                    item
                    xs={12}
                    className={globalClasses.reviewTransferContainer}
                  >
                    <Grid item xs={5}>
                      <Box pr={1}>
                        <Typography
                          varian="body1"
                          align="right"
                          className={clsx(
                            globalClasses.boldText,
                            globalClasses.reviewTransferImportant,
                          )}
                        >
                          {CONFORMATION}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={7}>
                      <Typography
                        varian="body1"
                        className={globalClasses.reviewTransferImportant}
                      >
                        {transferId}
                      </Typography>
                    </Grid>
                  </Grid>
                  <Grid
                    container
                    item
                    xs={12}
                    className={globalClasses.reviewTransferContainer}
                  >
                    <Grid item xs={5}>
                      <Box pr={1}>
                        <Typography
                          varian="body1"
                          align="right"
                          className={clsx(
                            globalClasses.boldText,
                            globalClasses.reviewTransferImportant,
                          )}
                        >
                          {DATE}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={7}>
                      <Typography
                        varian="body1"
                        className={globalClasses.reviewTransferImportant}
                      >
                        {date}
                      </Typography>
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            </Grid>
          </Grid>
        </DialogContentText>
      </DialogContent>
      <DialogActions className={mmClasses.cancelConfirmationButton}>
        <Button
          onClick={handleClose}
          color="primary"
          variant="contained"
          className={mmClasses.cancelModalButton}
        >
          {OK}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default CancelConfirmation;

CancelConfirmation.propTypes = {
  open: PropTypes.bool,
  handleClose: PropTypes.func,
  isSuccess: PropTypes.bool,
  transfer: PropTypes.instanceOf(Object),
};

CancelConfirmation.defaultProps = {
  open: false,
  handleClose: defaultFnPropTypes,
  isSuccess: false,
  transfer: {},
};
