import {
  Button,
  Dialog,
  IconButton,
  Grid,
  Typography,
  Box,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';

import { ReactComponent as ArrowRight } from 'assets/svg/arrow-right-1.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';
import globalClasses from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import { showCancelDialog } from 'store/actions/MoveMoneyActions';

import ReviewInfo from '../Components/ReviewInfo';
// import internalClasses from '../MoveMoney.module.scss';

const { transferFrom: FROM, transferTo: TO } = strings;
const CancelTransfer = ({
  handleClickConfirm,
  transfer,
  title,
  buttonForward,
  buttonBack,
  altTitle,
  altDescr,
  cancelling,
}) => {
  const dispatch = useDispatch();

  const open = useSelector((state) => state.moveMoney.showCancelDialog);
  const handleClose = () => {
    dispatch(showCancelDialog(false));
  };
  return (
    <Dialog
      open={open}
      keepMounted
      fullWidth
      maxWidth="sm"
      aria-labelledby={altTitle}
      aria-describedby={altDescr}
    >
      <IconButton
        onClick={handleClose}
        aria-label="close"
        size="small"
        className={globalClasses.closeIcon}
        data-testid="cancel-transfer-close"
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={mmClasses.customCloseIcon}
        />
      </IconButton>
      <DialogTitle id={altTitle} className={globalClasses.dialogTitle}>
        {title}
      </DialogTitle>
      <DialogContent>
        <DialogContentText id={altDescr} component="div">
          <Grid container alignItems="center" className={mmClasses.gap25}>
            <Grid container item xs={12}>
              <img
                className={globalClasses.dialogSvg}
                src="/svg/cancel-transfer-main.svg"
                alt="Cancel Transfer"
              />
            </Grid>
            <Grid container item xs={12}>
              <Grid container>
                <Grid item xs={5}>
                  <Box mb={2}>
                    <Typography
                      className={clsx(
                        globalClasses.boldText,
                        globalClasses.reviewTransferImportant,
                      )}
                    >
                      {FROM}
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={2} />
                <Grid item xs={5}>
                  <Box mb={2}>
                    <Typography
                      className={clsx(
                        globalClasses.boldText,
                        globalClasses.reviewTransferImportant,
                      )}
                    >
                      {TO}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
              <Grid container>
                <Grid container item xs={5} alignItems="center">
                  <Grid item className={globalClasses.reviewTransferBankHolder}>
                    <Box className={mmClasses.reviewTransferBox}>
                      <Typography
                        varian="body1"
                        className={globalClasses.reviewTransferImportant}
                      >
                        {transfer?.from?.slice(0, -6)}
                      </Typography>
                      <Typography
                        varian="body1"
                        className={globalClasses.reviewTransferNumb}
                      >
                        {transfer?.from?.slice(-4)}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
                <Grid item xs={2}>
                  <Box pt={1} className={mmClasses.arrow}>
                    <CustomIcon
                      component={ArrowRight}
                      color="grey.800"
                      inheritViewBox
                      className={mmClasses.arrowIcon}
                    />
                  </Box>
                </Grid>
                <Grid container item xs={5} alignItems="center">
                  <Grid item className={globalClasses.reviewTransferBankHolder}>
                    <Box className={mmClasses.reviewTransferBox}>
                      <Typography
                        varian="body1"
                        className={globalClasses.reviewTransferImportant}
                      >
                        {transfer?.to?.slice(0, -6)}
                      </Typography>
                      <Typography
                        varian="body1"
                        className={globalClasses.reviewTransferNumb}
                      >
                        {transfer?.to?.slice(-4)}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Grid container item xs={12}>
              <ReviewInfo
                amount={transfer?.amount}
                frequencyMonthly={
                  transfer?.transferDetail?.recurringTransfer
                    ?.frequencyOccurance
                }
                frequencyMonthlyCustomDate={
                  transfer?.transferDetail?.recurringTransfer?.noOfOccurance
                }
                transferNote={transfer?.transferDetail?.note}
                frequency={
                  transfer?.freq === 'One-time only'
                    ? 'one-time'
                    : transfer?.transferDetail?.recurringTransfer?.frequency?.slice(
                        0,
                        3,
                      )
                }
                transferDateDuration={
                  transfer?.transferDetail?.recurringTransfer?.endDate !== ''
                    ? 'endDate'
                    : 'numberOfTransactions'
                }
                transferTransactionLimit={
                  transfer?.transferDetail?.recurringTransfer?.noOfOccurance
                }
                transferDate={transfer?.transferDetail?.transferDate}
                transferEndDate={
                  transfer?.transferDetail?.recurringTransfer?.endDate
                }
              />
            </Grid>
          </Grid>
        </DialogContentText>
      </DialogContent>
      <DialogActions className={mmClasses.cancelModalButtons}>
        <Button
          onClick={handleClose}
          color="secondary"
          variant="contained"
          disabled={cancelling}
          className={mmClasses.cancelModalButton}
        >
          {buttonBack}
        </Button>
        <LoadingButton
          loading={cancelling}
          onClick={handleClickConfirm}
          color="primary"
          variant="contained"
          className={mmClasses.cancelModalButton}
        >
          {buttonForward}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
};

export default CancelTransfer;

CancelTransfer.propTypes = {
  handleClickConfirm: PropTypes.func,
  title: PropTypes.string,
  buttonForward: PropTypes.string,
  buttonBack: PropTypes.string,
  altTitle: PropTypes.string,
  altDescr: PropTypes.string,
  cancelling: PropTypes.bool,
  transfer: PropTypes.instanceOf(Object),
};

CancelTransfer.defaultProps = {
  handleClickConfirm: defaultFnPropTypes,
  title: '',
  buttonForward: '',
  buttonBack: '',
  altTitle: '',
  altDescr: '',
  cancelling: false,
  transfer: {},
};
