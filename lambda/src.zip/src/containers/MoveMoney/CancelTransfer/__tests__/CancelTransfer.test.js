import { render, screen } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import Amplify, { Auth } from 'aws-amplify';
import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';
import awsConfigure from 'aws-exports';
import CancelTransfer from '../CancelTransfer';
import theme from 'style/theme';
import userEvent from '@testing-library/user-event';

Amplify.configure(awsConfigure);
const history = createMemoryHistory({});

const initialState = {
  moveMoney: {
    showCancelDialog: true,
  },
};
const store = configureStore();

jest.mock('axios');

const mockObj1 = {
  amount: '100',
  date: 'May 05, 2022',
  freq: 'Every month, 5th of the month, remain: 10',
  from: 'Chello *0834',
  to: 'Chase Plaid Saving *1111',
  transferId: '4hdNmx0dgOnX4----VLF-8w-',
};

const mockGetValues = (key) => {
  switch (key) {
    case 'frequency':
      return 'yearly';
    case 'transferDate._d':
    case 'transferEndDate._d':
      return {
        getMonth: function () {
          return 'Jan';
        },
        getDate: function () {
          return 'Date';
        },
        getFullYear: function () {
          return '2021';
        },
      };
    default:
      return null;
  }
};

function renderElement() {
  return render(
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <Provider store={store(initialState)}>
          <Router history={history}>
            <CancelTransfer title="Want to stop this transfer?" />
          </Router>
        </Provider>
      </ThemeProvider>
    </StyledEngineProvider>,
  );
}

describe('should test CancelTransfer component', () => {
  it('should render correctly', async () => {
    renderElement();

    expect(
      await screen.findByText('Want to stop this transfer?'),
    ).toBeInTheDocument();
  });

  /*** it('should render correctly frequencyMonthly is lastDay', () => {
    const mockGetValues = (key) => {
      switch (key) {
        case 'frequency':
          return 'monthly';
        case 'frequencyMonthly':
          return 'lastDay';
        default:
          null;
      }
    };

    renderElement({
      open: true,
      title: 'Cancel Transfer',
      getValues: mockGetValues,
    });
    expect(
      screen.getByText(/Monthly, Last day of the month/gi),
    ).toBeInTheDocument();
  });

  it('should render correctly frequencyMonthly is customDate', () => {
    const mockGetValues = (key) => {
      switch (key) {
        case 'frequency':
          return 'monthly';
        case 'frequencyMonthly':
          return 'customDate';
        case 'frequencyMonthlyCustomDate':
          return '3';
        default:
          null;
      }
    };

    renderElement({
      open: true,
      title: 'Cancel Transfer',
      getValues: mockGetValues,
    });

    expect(screen.getByText(/Monthly, 3th of the month/gi)).toBeInTheDocument();
  });

  it('should render correctly frequencyMonthly is other', () => {
    const mockGetValues = (key) => {
      switch (key) {
        case 'frequency':
          return 'monthly';
        case 'frequencyMonthly':
          return 'other';
        case 'frequencyMonthlyCustomDate':
          return '3';
        default:
          null;
      }
    };

    renderElement({
      open: true,
      title: 'Cancel Transfer',
      getValues: mockGetValues,
    });

    expect(
      screen.getByText(/Monthly, other of the month/gi),
    ).toBeInTheDocument();
  }); **/
});
