import { render, screen } from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';
import { useForm } from 'react-hook-form';

import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';

import Export from '../Export';
import theme from 'style/theme';

const history = createMemoryHistory({});

const initialState = {
  moveMoney: {
    openExport: true,
  },
};
const mockStore = configureStore();

const SampleComponent = () => {
  const { control } = useForm();
  const currentProps = {
    open: true,
    handleClose: jest.fn(),
    getValues: jest.fn(),
    control,
  };

  return <Export {...currentProps} />;
};

function renderElement() {
  return render(
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <Provider store={mockStore(initialState)}>
          <Router history={history}>
            <SampleComponent />
          </Router>
        </Provider>
      </ThemeProvider>
    </StyledEngineProvider>,
  );
}

describe('should test Export component', () => {
  it('should render correctly', () => {
    renderElement();
    expect(screen.getByTestId('transfer-activity-export')).toBeInTheDocument();
  });

  // it('should render correctly', () => {
  //   renderElement(false);
  //   expect(screen.getByTestId('transfer-activity-export')).toBeInTheDocument();
  // });
});
