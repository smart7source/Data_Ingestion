import {
  Button,
  Grid,
  Box,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Typography,
  IconButton,
} from '@mui/material';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';

import { defaultFnPropTypes } from 'utils';
import globalClasses from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import strings from 'localization/translation';
import { openExport } from 'store/actions/MoveMoneyActions';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import CustomIcon from 'components/UIElements/CustomIcon';

import Classes from '../../OneAccount/OneAccount.module.scss';

const {
  onTheMenuToday: ON_THE_MENU,
  activityReports: REPORTS,
  pickYours: PICK_YOURS,
  spreadsheetSoftware: SPREADSHEET,
  PDFPortableDocumentFormat: PDF_FORMAT,
  quickbooks: QUICK_BOOKS,
  download: DOWNLOAD,
} = strings;
export default function Export({ handleSubmit, getValues, setValue, control }) {
  const dispatch = useDispatch();

  const transferExport = useSelector((state) => state.moveMoney.openExport);

  const handleClose = () => {
    dispatch(openExport(false));
  };

  return (
    <Dialog
      fullWidth
      maxWidth="sm"
      open={transferExport}
      aria-labelledby="select-your-report-format-dialog"
      data-testid="transfer-activity-export"
    >
      <IconButton
        aria-label="close"
        size="small"
        className={Classes.closeIcon}
        onClick={handleClose}
        data-testid="transaction-detail-close-btn"
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={mmClasses.customCloseIcon}
        />
      </IconButton>
      <DialogTitle
        id="select-your-report-format-dialog"
        data-testid="export-title"
        className={globalClasses.dialogTitle}
      >
        <Typography component="span" variant="h1" color="grey.800">
          {ON_THE_MENU}
          <br />
          {REPORTS}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Grid container>
          <Grid container item justifyContent="center">
            <picture>
              <source
                media="(max-width: 599px)"
                srcSet="/images/export-modal-small.png"
                width="220"
                height="162"
              />
              <source
                media="(min-width: 600px)"
                srcSet="/images/export-modal.png"
                width="422"
                height="162"
              />
              <img
                src="/images/export-modal.png"
                alt="export"
                style={{ width: '100%', height: 'auto' }}
              />
            </picture>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="h3" color="#000">
              {PICK_YOURS}
            </Typography>
          </Grid>
          <Box>
            <Controller
              render={() => (
                <FormControl>
                  <RadioGroup
                    aria-label="position"
                    name="position"
                    value={getValues('formatDownload')}
                    onChange={(event, value) =>
                      setValue('formatDownload', value)
                    }
                    style={{ marginTop: '5px' }}
                  >
                    <FormControlLabel
                      value="CSV"
                      control={<Radio color="primary" />}
                      label={SPREADSHEET}
                    />
                    <FormControlLabel
                      value="PDF"
                      control={<Radio color="primary" />}
                      label={PDF_FORMAT}
                    />
                    <FormControlLabel
                      value="QBO"
                      control={<Radio color="primary" />}
                      label={QUICK_BOOKS}
                    />
                  </RadioGroup>
                </FormControl>
              )}
              name="formatDownload"
              id="formatDownload"
              control={control}
            />
          </Box>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Grid
          container
          justifyContent="space-between"
          className={globalClasses.transferBtnContainer}
        >
          <Grid item className={globalClasses.transferBtnsection}>
            <Box ml={3} className={globalClasses.transferBtDivison}>
              <Button
                className={globalClasses.makeTransferButton}
                size="large"
                variant="contained"
                onClick={handleClose}
              >
                Cancel
              </Button>
            </Box>
          </Grid>
          <Grid item className={globalClasses.transferBtnsection}>
            <Box mr={2} className={globalClasses.transferBtDivison}>
              <Button
                onClick={handleSubmit}
                className={globalClasses.makeTransferButton}
                color="primary"
                size="large"
                variant="contained"
              >
                {DOWNLOAD}
              </Button>
            </Box>
          </Grid>
        </Grid>
      </DialogActions>
    </Dialog>
  );
}
Export.propTypes = {
  handleSubmit: PropTypes.func,
  getValues: PropTypes.oneOfType([
    PropTypes.instanceOf(Object),
    PropTypes.func,
  ]),
  setValue: PropTypes.func,
  control: PropTypes.instanceOf(Object),
};
Export.defaultProps = {
  handleSubmit: defaultFnPropTypes,
  getValues: defaultFnPropTypes,
  setValue: defaultFnPropTypes,
  control: {},
};
