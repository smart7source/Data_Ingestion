/* eslint-disable max-lines */
import {
  Button,
  IconButton,
  Dialog,
  Grid,
  Typography,
  Box,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';

import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle.svg';
import { ReactComponent as AlertCircle } from 'assets/svg/alert-circle.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { defaultFnPropTypes, formatTransactionDate } from 'utils';
import strings from 'localization/translation';
import globalClasses from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import {
  openTransferConfirm,
  setSelectedAccount,
} from 'store/actions/MoveMoneyActions';

// import internalClasses from '../MoveMoney.module.scss';

const {
  someoneNeedsToTakeACloserLook: NEED_CLOSER_LOOK,
  somethingsWeighingYourDown: WEIGHIN_DOWN,
  timeToBoogie: TIME_TO_BOOGIE,
  confirmation: CONFIRMATION,
  date: DATE,
  ok: OK,
  mmTransferLimitExceed: MMTRANSFERLIMITEXCEED,
  mmTransferDeclined: MMTRANSFERDECLINE,
  mmTransferSubmited: MMTRANSFERSUBMITED,
} = strings;

function TransferConfirmation({
  transferStatus,
  transferId,
  reset,
  formData,
  closeEditModal,
}) {
  const { amount, transferDate } = formData;
  const dispatch = useDispatch();
  const showTransferConfirm = useSelector(
    (state) => state.moveMoney.openTransferConfirm,
  );

  function isSuccessTitle() {
    switch (transferStatus) {
      case 'amountLimit':
        return NEED_CLOSER_LOOK;
      case 'fail':
        return WEIGHIN_DOWN;
      default:
        return TIME_TO_BOOGIE;
    }
  }

  function isSuccessContent() {
    switch (transferStatus) {
      case 'amountLimit':
        return MMTRANSFERLIMITEXCEED?.replace('<amount>', amount);
      case 'fail':
        return MMTRANSFERDECLINE?.replace('<amount>', amount);
      default:
        return MMTRANSFERSUBMITED?.replace('<amount>', amount);
    }
  }

  function isSuccessImage() {
    switch (transferStatus) {
      case 'amountLimit':
        return (
          <img
            className={globalClasses.dialogSvg}
            src="/svg/confirmation-closer-look.svg"
            alt="Transfer needs a closer look"
          />
        );
      case 'fail':
        return (
          <img
            className={globalClasses.dialogSvg}
            src="/svg/confirmation-failed.svg"
            alt="Transfer was declined"
          />
        );
      default:
        return (
          <img
            className={globalClasses.dialogSvg}
            src="/svg/confirmation-success.svg"
            alt="Transfer is successeful"
          />
        );
    }
  }

  const handleClose = () => {
    reset({});
    closeEditModal();
    dispatch(setSelectedAccount({}));
    dispatch(openTransferConfirm(false));
  };

  return (
    <Dialog
      open={showTransferConfirm}
      keepMounted
      fullWidth
      onClose={handleClose}
      aria-labelledby="transfer-confirmation"
      aria-describedby="confirmation-modal-window"
      data-testid="transfer-confirmation-id"
    >
      <Grid container item xs={12}>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          size="small"
          className={globalClasses.closeIcon}
          data-testid="transfer-confirmation-closeIcon"
        >
          <CustomIcon
            component={Close}
            color="grey.800"
            inheritViewBox
            className={mmClasses.customCloseIcon}
          />
        </IconButton>
      </Grid>
      <DialogTitle
        id="transfer-confirmation"
        className={globalClasses.dialogTitle}
        data-testid="transfer-confirmation-title"
      >
        {isSuccessTitle()}
      </DialogTitle>
      <DialogContent>
        <DialogContentText id="confirmation-modal-window" component="div">
          <Grid container alignItems="center">
            <Grid
              container
              item
              xs={12}
              py={1}
              className={globalClasses.reviewTransferContainer}
            >
              <Grid item xs={1}>
                <Box mb={1}>
                  {transferStatus === 'fail' && (
                    <CustomIcon
                      component={AlertCircle}
                      color="error"
                      inheritViewBox
                      className={mmClasses.customIcon}
                    />
                  )}
                  {transferStatus === 'amountLimit' && (
                    <CustomIcon
                      component={AlertCircle}
                      color="warning"
                      inheritViewBox
                      className={mmClasses.customIcon}
                    />
                  )}
                  {transferStatus === 'success' && (
                    <CustomIcon
                      component={CheckmarkCircle}
                      color="success"
                      inheritViewBox
                      className={mmClasses.customIcon}
                    />
                  )}
                </Box>
              </Grid>
              <Grid item xs={11}>
                <Box mb={1}>
                  <Typography
                    data-testid="status-content"
                    variant="body1"
                    className={globalClasses.reviewTransferImportant}
                  >
                    {isSuccessContent()}
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </Grid>
          <Grid container item xs={12}>
            {isSuccessImage()}
          </Grid>
          <Grid container item xs={12} mt={1}>
            {transferStatus === 'success' && (
              <div
                className={globalClasses.reviewTransferHolder}
                data-testid="confirmation-block"
              >
                <Grid
                  container
                  alignItems="flex-start"
                  direction="column"
                  justifyContent="space-around"
                  my={1}
                >
                  <Grid
                    container
                    item
                    xs={12}
                    className={globalClasses.reviewTransferContainer}
                  >
                    <Grid item xs={5}>
                      <Box pr={1}>
                        <Typography
                          variant="body1"
                          align="right"
                          className={clsx(
                            globalClasses.boldText,
                            globalClasses.reviewTransferImportant,
                          )}
                        >
                          {CONFIRMATION}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={7}>
                      <Box>
                        <Typography
                          variant="p1"
                          className={globalClasses.reviewTransferImportant}
                        >
                          {transferId}
                        </Typography>
                      </Box>
                    </Grid>

                    <Grid item xs={5}>
                      <Box pr={1}>
                        <Typography
                          variant="body1"
                          align="right"
                          className={clsx(
                            globalClasses.boldText,
                            globalClasses.reviewTransferImportant,
                          )}
                          style={{ fontWeight: 'Semi Bold' }}
                        >
                          {DATE}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={7}>
                      <Box>
                        <Typography
                          variant="p1"
                          className={globalClasses.reviewTransferImportant}
                        >
                          {formatTransactionDate(transferDate)}
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            )}
          </Grid>
        </DialogContentText>
      </DialogContent>
      <DialogActions className={mmClasses.cancelModalButtonsConfirmation}>
        <Button
          onClick={handleClose}
          color="primary"
          variant="contained"
          className={mmClasses.cancelModalButton}
        >
          {OK}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default TransferConfirmation;

TransferConfirmation.propTypes = {
  transferStatus: PropTypes.string,
  transferId: PropTypes.string,
  reset: PropTypes.func,
  formData: PropTypes.instanceOf(Object),
  closeEditModal: PropTypes.func,
};

TransferConfirmation.defaultProps = {
  transferStatus: 'success',
  transferId: '',
  reset: defaultFnPropTypes,
  formData: {},
  closeEditModal: defaultFnPropTypes,
};
