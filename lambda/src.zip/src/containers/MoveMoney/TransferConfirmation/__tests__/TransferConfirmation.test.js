import { render, screen, act, fireEvent } from '@testing-library/react';
import { ThemeProvider } from '@mui/material';

import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';

import TransferConfirmation from '../TransferConfirmation';
import theme from 'style/theme';

const history = createMemoryHistory({});

const initialState = {
  moveMoney: {
    openTransferConfirm: true,
  },
};
const mockStore = configureStore();

const formDataMock = {
  amount: '$100',
  transferDate: '2022-12-10',
};

function renderElement({
  transferStatus,
  transferId,
  reset,
  formData,
  closeEditModal,
}) {
  return render(
    <ThemeProvider theme={theme}>
      <Provider store={mockStore(initialState)}>
        <Router history={history}>
          <TransferConfirmation
            formData={formDataMock}
            transferStatus={transferStatus}
            transferId={transferId}
            reset={reset}
            closeEditModal={closeEditModal}
          />
        </Router>
      </Provider>
    </ThemeProvider>,
  );
}

describe('Should test TransferConfirmation component', () => {
  it('Should have dialog screen', () => {
    renderElement({ transferStatus: 'success', transferId: 'T1' });
    expect(screen.getByTestId('transfer-confirmation-id')).toBeInTheDocument();
    expect(screen.getByTestId('transfer-confirmation-title')).toHaveTextContent(
      'Time to boogie.',
    );
    expect(screen.getByTestId('status-content')).toHaveTextContent(
      'Your transfer of $100 has been submitted',
    );
    expect(screen.getByTestId('confirmation-block')).toBeInTheDocument();
  });

  it('Should check fail status title', () => {
    renderElement({ transferId: 'T2', transferStatus: 'fail' });
    expect(screen.getByTestId('transfer-confirmation-title')).toHaveTextContent(
      'Something’s weighing your $ down.',
    );
    expect(screen.getByTestId('status-content')).toHaveTextContent(
      'Your transfer of $100 has been declined',
    );
  });

  it('Should check amount limit status title', () => {
    renderElement({ transferId: 'T3', transferStatus: 'amountLimit' });
    expect(screen.getByTestId('transfer-confirmation-title')).toHaveTextContent(
      'Someone needs to take a closer look.',
    );
    expect(screen.getByTestId('status-content')).toHaveTextContent(
      'Your $100 transfer exceeds the limit and needs to be authorized by an approved user. We will send you a notification once this has gone through.',
    );
  });

  it('Should close Transfer Confirmation Modal', async () => {
    renderElement({ transferStatus: 'success' });
    const dialogComp = screen.getByRole('button', { name: 'Ok' }); // screen.getByTestId('transfer-confirmation-closeIcon');
    expect(dialogComp).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(dialogComp);
    });
    expect(screen.queryByText(/Time To boggie./i)).not.toBeInTheDocument();
  });
});
