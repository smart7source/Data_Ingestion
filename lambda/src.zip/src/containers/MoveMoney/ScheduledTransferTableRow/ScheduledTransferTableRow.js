import { Box, TableCell, TableRow } from '@mui/material';
import PropTypes from 'prop-types';
import clsx from 'clsx';

import { KebabMenu } from 'components';
import { currencyFormat, defaultFnPropTypes } from 'utils';
import style from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';

// import classes from '../MoveMoney.module.scss';

const ScheduledTransferTableRow = ({
  transfer,
  kebabOptions,
  account,
  index,
  onMenuOptionClick,
  lastElRef,
}) => {
  const { date, from, to, freq, amount } = transfer;

  const elRef = lastElRef ? { ref: lastElRef } : {};
  const id = `${account}-transaction-${index}`;
  const ariaLabel = `${account} account transaction ${index + 1}`;

  return (
    <>
      <TableRow {...elRef} key={index}>
        <TableCell className={clsx(style.p2Paragraph)}>{date}</TableCell>
        <TableCell className={style.p2Paragraph}>{from}</TableCell>
        <TableCell className={style.p2Paragraph}>{to}</TableCell>
        <TableCell className={style.p2Paragraph}>{freq}</TableCell>
        <TableCell className={clsx(style.p2Paragraph)}>
          <Box className={mmClasses.scheduleTransferKebaCell}>
            {currencyFormat(amount)}
            <KebabMenu
              options={kebabOptions}
              ariaLabel={ariaLabel}
              id={id}
              onMenuOptionClick={onMenuOptionClick}
            />
          </Box>
        </TableCell>
      </TableRow>
    </>
  );
};

export default ScheduledTransferTableRow;

ScheduledTransferTableRow.propTypes = {
  transfer: PropTypes.instanceOf(Object),
  kebabOptions: PropTypes.instanceOf(Object),
  onMenuOptionClick: PropTypes.func,
  index: PropTypes.number,
  account: PropTypes.string,
  lastElRef: PropTypes.instanceOf(Object),
};
ScheduledTransferTableRow.defaultProps = {
  transfer: {},
  kebabOptions: [],
  onMenuOptionClick: defaultFnPropTypes,
  index: 0,
  account: 'chello',
  lastElRef: null,
};
