import {  Table,TableBody } from '@mui/material';
import {
  act,
  render,
  fireEvent,
  waitFor,
  screen,
} from '@testing-library/react';
import { createMemoryHistory } from 'history';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import ScheduledTransferTableRow from '../ScheduledTransferTableRow';
import axios from 'axios';

const history = createMemoryHistory();

jest.mock('axios');

const initialState = {
  moveMoney: {
    activeAccounts: [],
  },
};

const store = configureStore();

function TestElement() {
  const currentProps = {
    transfer: {
      amount: '10.00',
      date: 'May 05, 2022',
      freq: 'Every month, 5th of the month, remain: 10',
      from: 'Chello *0834',
      to: 'Chase Plaid Saving *1111',
      transferId: '4hh3-ofwr80RFV--1F9F-8w-',
    },
    reloadApi: jest.fn(),
  };

  return (
    <Provider store={store(initialState)}>
      <Router history={history}>
        <Table>
          <TableBody>
            <ScheduledTransferTableRow {...currentProps} />
          </TableBody>
        </Table>
      </Router>
    </Provider>
  );
}

describe('ScheduledTransferTableRow Test', () => {
  it('should render correctly', async () => {
    render(<TestElement />);
    expect(screen.getByText('$10.00')).toBeInTheDocument();
  });
});