export const externalAccounts = [
  {
    accountOwner: 'Cognizant',
    financialInstitution: 'Citi Business Checking',
    accountNumber: '7635',
    status: 'Active',
  },
  {
    accountOwner: 'Cognizant',
    financialInstitution: 'JPMorgan Chase Bank',
    accountNumber: '4567',
    status: 'Inactive',
  },
  {
    accountOwner: 'Cognizant',
    financialInstitution: 'Synchrony Bank',
    accountNumber: '1234',
    status: 'Pending',
  },
  {
    accountOwner: 'Cognizant',
    financialInstitution: 'Synchrony Bank',
    accountNumber: '7890',
    status: 'Verifying',
  },
  {
    accountOwner: 'Cognizant',
    financialInstitution: 'Synchrony Bank',
    accountNumber: '7899',
    status: 'Failed',
  },
];

export const statusMappings = [
  { label: 'Closed', value: 0 },
  { label: 'Active', value: 1, linkLabel: 'Unlink' },
  {
    label: 'Inactive',
    value: 2,
  },
  { label: 'Pending', value: 3, linkLabel: 'Verify' },
  { label: 'Verifying', value: 4 },
  { label: 'Failed', value: 5 },
  { label: 'Frozen', value: 6 },
];

export const statusOrder = [
  { label: 'Ascending', value: 0 },
  { label: 'Descending', value: 1 },
];
