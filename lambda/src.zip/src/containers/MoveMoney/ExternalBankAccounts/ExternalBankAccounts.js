import { useEffect, useState, useCallback } from 'react';
import {
  Box,
  Button,
  Link,
  Paper,
  Table,
  TableCell,
  TableBody,
  TableHead,
  TableRow,
  Typography,
  Grid,
} from '@mui/material';
import PropTypes from 'prop-types';

import { ReactComponent as ChevronUp } from 'assets/svg/chevron-up.svg';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import LinkPlaid from 'containers/Funding/LinkExternalBank/components/LinkPlaid';
import { Notification } from 'components';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import strings from 'localization/translation';
import { p1ParagraphSemiBold } from 'style/variables';
import globalClasses from 'style/globalStyle.module.scss';
import mmClasses from 'style/MoveMoney.module.scss';
import { defaultFnPropTypes } from 'utils';
import LinkedAccountSelectorOption from 'components/FormElements/LinkedAccountSelectorOption';

// import internalClasses from '../MoveMoney.module.scss';

import { statusMappings } from './ExternalBankAccounts.data';

const {
  addAccount: ADD_ACCOUNT,
  accountOwner: ACCOUNT_OWNER,
  addAccountSuccess: ADD_SUCCESS,
  addAccountFailure: ADD_FAILURE,
  financialInstitution: FINANCIAL_INST,
  accountNumberLast4Digit: ACC_NBR,
  status,
} = strings;

const AddButton = (props) => {
  const { dataTestid, onClick } = props;

  return (
    <Button
      className={globalClasses.mmCtaWithIcon}
      color="primary"
      data-testid={dataTestid}
      onClick={onClick}
    >
      <Box component="span" className={globalClasses.addAccountsIcon} />
      {ADD_ACCOUNT}
    </Button>
  );
};

AddButton.propTypes = {
  dataTestid: PropTypes.string,
  onClick: PropTypes.func,
};
AddButton.defaultProps = {
  dataTestid: '',
  onClick: defaultFnPropTypes,
};

const ExternalBankAccounts = () => {
  const [bankAccounts, setBankAccounts] = useState([]);
  const [errMsgs, setErrMsgs] = useState([]);
  const [bankActiveAccounts, setBankActiveAccounts] = useState([]);
  const [ascending, setAscending] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);

  const fetchBankAccounts = useCallback(async () => {
    setIsLoaded(false);
    try {
      const response = await ApiClient.get(serviceUrl.getExternalBankAccounts);
      const { body = [] } = response;
      const list = body.sort(
        (a, b) => a.status - b.status || a.name.localeCompare(b.acctTitle),
      );
      console.log({ list });
      setBankAccounts(list);
    } catch (error) {
      setErrMsgs([{ severity: 'error', message: error.message }]);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    fetchBankAccounts();
  }, [fetchBankAccounts]);

  const onLinkedAcc = useCallback(() => {
    setErrMsgs([{ severity: 'success', message: ADD_SUCCESS }]);
    fetchBankAccounts();
  }, [fetchBankAccounts]);

  const onError = (e) => {
    if (typeof e === 'object') {
      setErrMsgs([{ severity: 'error', message: ADD_FAILURE }]);
    } else {
      setErrMsgs([{ severity: 'error', message: e }]);
    }
  };

  const handleSort = () => {
    const list = bankAccounts.sort(
      !ascending
        ? (a, b) => a.status - b.status || a.name.localeCompare(b.acctTitle)
        : (a, b) => b.status - a.status || a.name.localeCompare(b.acctTitle),
    );
    setAscending(!ascending);
    setBankAccounts(list);
  };

  useEffect(() => {
    const findActive = bankAccounts.filter((item) => item.status === 1);
    setBankActiveAccounts(findActive);
  }, [bankAccounts]);

  const handleUpdateStatus = (account) => async (event) => {
    event.preventDefault();
    if (account.status === 1) {
      // Active status
      try {
        await ApiClient.put(
          `${serviceUrl.unlinkExternalBankAccount}${account.id}`,
        );
        await fetchBankAccounts();
      } catch (error) {
        setErrMsgs([{ severity: 'error', message: error.message }]);
      }
    }
  };

  const renderStatus = (account) => {
    const mapping = statusMappings.find(
      (item) => item.value === account.status,
    );

    const statusRules = () => {
      if (
        mapping.linkLabel === 'Verify' ||
        (mapping.linkLabel === 'Unlink' && bankActiveAccounts.length >= 2)
      ) {
        return (
          <>
            <TableCell>
              <Box className={mmClasses.externalBankTableStatusCell}>
                <Link
                  href="#"
                  color="primary"
                  onClick={handleUpdateStatus(account)}
                  underline="hover"
                >
                  {mapping.linkLabel}
                </Link>
              </Box>
            </TableCell>
          </>
        );
      }
      return <TableCell />;
    };

    if (!mapping) return null;

    return (
      <>
        {/* <Box sx={{ display: 'flex', justifyContent: 'flex-start' }}> */}
        <TableCell> {mapping.label} </TableCell>
        {statusRules()}
        {/* </Box> */}
      </>
    );
  };

  const sortIcon = ascending ? ChevronDown : ChevronUp;

  return (
    <>
      {errMsgs && errMsgs.length > 0 && (
        <Box mb={2.5}>
          <Notification errors={errMsgs} needFocus />
        </Box>
      )}
      <Paper
        className={mmClasses.externalBank}
        elevation={1}
        data-testid="external-bank-accounts-container"
      >
        <Box display="flex" justifyContent="space-between">
          <Typography
            variant="h2"
            component="h2"
            style={{ fontWeight: 'bold' }}
          >
            Your linked bank accounts
          </Typography>
          <LinkPlaid onLinkedAcc={onLinkedAcc} onError={onError}>
            <AddButton dataTestid="link-external-bank-button" />
          </LinkPlaid>
        </Box>
        {isLoaded ? (
          <Grid className={mmClasses.scheduleTransferActivityStyle}>
            <Table
              className={mmClasses.externalBankTable}
              data-testid="external-bank-accounts"
            >
              <TableHead>
                <TableRow className={mmClasses.externalBankTableHeader}>
                  <TableCell>{FINANCIAL_INST}</TableCell>
                  <TableCell>{ACCOUNT_OWNER}</TableCell>
                  <TableCell>{ACC_NBR}</TableCell>
                  <TableCell>
                    <Button
                      className={mmClasses.statusBtn}
                      variant="standard"
                      data-testid="external-bank-accounts-sortby"
                      onClick={handleSort}
                      fullWidth
                      // sx={{
                      //   height: '100%',
                      //   padding: {
                      //     xs: '45px 1rem',
                      //     sm: '25px 1rem',
                      //     lg: '15px 1rem',
                      //   },
                      //   display: 'flex',
                      //   justifyContent: 'space-between',
                      //   // ...p1ParagraphSemiBold,
                      // }}
                      endIcon={
                        <CustomIcon
                          component={sortIcon}
                          inheritViewBox
                          color="grey.800"
                          className={mmClasses.sortIcon}
                        />
                      }
                    >
                      <Typography
                        variant="p1"
                        component="p"
                        className={mmClasses.status}
                      >
                        {status}
                      </Typography>
                    </Button>
                  </TableCell>
                  <TableCell />
                </TableRow>
              </TableHead>
              <TableBody>
                {bankAccounts &&
                  bankAccounts.map((account, index) => (
                    <TableRow key={index}>
                      <TableCell className={globalClasses.p1Paragraph}>
                        <LinkedAccountSelectorOption
                          imgSrc={`${serviceUrl.externalBankImagesPath}${account?.institutionId}.png`}
                          alt=""
                          name={account.name}
                        />
                      </TableCell>
                      <TableCell className={globalClasses.p1Paragraph}>
                        {account.acctTitle}
                      </TableCell>
                      <TableCell className={globalClasses.p1Paragraph}>
                        {account.acctNbr.slice(-4)}
                      </TableCell>
                      {renderStatus(account)}
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </Grid>
        ) : (
          <Box display="flex" justifyContent="center" width="100%" />
        )}
      </Paper>
    </>
  );
};

export default ExternalBankAccounts;
