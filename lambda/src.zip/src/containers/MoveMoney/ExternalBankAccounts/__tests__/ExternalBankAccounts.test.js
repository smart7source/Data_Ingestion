import {
  fireEvent,
  render,
  screen,
  waitFor,
  act,
} from '@testing-library/react';
import { ThemeProvider, StyledEngineProvider } from '@mui/material';

import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';
import { usePlaidLink } from 'react-plaid-link';

import ExternalBankAccounts from '../ExternalBankAccounts';
import theme from 'style/theme';
import ApiClient from 'api/ApiClient';

const history = createMemoryHistory({});

const initialState = {
  oneAccount: {
    linkToken: 'link-sandbox-0a752f64-c8ab-4492-8123-edc28c87f269',
  },
};
const mockStore = configureStore();

const mockExternalBankAccounts = [
  {
    id: '4gTXY0k-f2omrV---1PF-77-',
    acctNbr: '1111222233331111',
    acctTitle: 'Plaid Silver Standard 0.1% Interest Saving',
    name: 'Wells Fargo',
    desc: 'Plaid Saving',
    status: 1,
  },
];
jest.mock('api/ApiClient');
jest.mock('react-plaid-link', () => ({
  ...jest.requireActual('react-plaid-link'),
  usePlaidLink: jest.fn(),
}));

function renderElement() {
  return render(
    <Provider store={mockStore(initialState)}>
      <StyledEngineProvider injectFirst>
        <ThemeProvider theme={theme}>
          <Router history={history}>
            <ExternalBankAccounts />
          </Router>
        </ThemeProvider>
      </StyledEngineProvider>
    </Provider>,
  );
}

describe('should test ExternalBankAccounts component', () => {
  beforeAll(() => {});
  beforeEach(() => {
    ApiClient.get = jest.fn().mockResolvedValue({
      body: mockExternalBankAccounts,
    });
    usePlaidLink.mockImplementation(() => ({ ready: true, open: jest.fn() }));
  });

  afterEach(() => {
    ApiClient.get.mockClear();
    usePlaidLink.mockClear();
  });

  it('should render correctly', async () => {
    await act(async () => {
      renderElement();
    });

    await waitFor(
      () =>
        expect(
          screen.getByTestId('external-bank-accounts'),
        ).toBeInTheDocument(),
      expect(document.querySelectorAll('tbody > tr').length).toBe(
        mockExternalBankAccounts.length,
      ),
      expect(
        screen.queryByText(mockExternalBankAccounts[0].acctTitle),
      ).toBeInTheDocument(),
    );
  });

  it('should have sortby dropdown', async () => {
    await act(async () => {
      renderElement();
    });
    expect(
      screen.getByTestId('external-bank-accounts-sortby'),
    ).toBeInTheDocument();
  });
  it('should open plaid link', async () => {
    ApiClient.post = jest.fn().mockResolvedValue({
      body: {
        vendor: 'Plaid',
        token: 'link-sandbox-f56d49a7-77fc-4202-87ad-0c0298808efd',
        expiration: '2021-12-09T15:49:04Z',
        request_id: 'zwbWXLGE43Sy8dR',
      },
    });

    const mockOpen = jest.fn();
    await act(async () => {
      usePlaidLink.mockImplementation(() => ({ ready: true, open: mockOpen }));
      renderElement();
    });

    expect(screen.getByTestId('link-external-bank-button')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('link-external-bank-button'));

    await waitFor(() => {
      expect(mockOpen).toHaveBeenCalled();
    });
    ApiClient.post.mockClear();
  });

  it('should unlink external bank account', async () => {
    const mockDeleteApi = jest.fn();
    ApiClient.put = jest.fn().mockResolvedValue();
    await act(async () => {
      renderElement();
    });
    /** await waitFor(() => {
      fireEvent.click(screen.getByText(/unlink/i));
    }); */
  });

  // it('should disable link external bank account button if plaid is NOT ready', async () => {
  //   usePlaidLink.mockImplementation(() => ({ ready: false, open: jest.fn() }));
  //   await act(async () => {
  //     renderElement();
  //   });
  //   expect(screen.getByTestId('link-external-bank-button')).toHaveClass(
  //     'Mui-disabled',
  //   );
  // });
  it('should enable link external bank account button if plaid is ready', async () => {
    usePlaidLink.mockImplementation(() => ({ ready: true, open: jest.fn() }));
    await act(async () => {
      renderElement();
    });
    expect(screen.getByTestId('link-external-bank-button')).not.toHaveClass(
      'Mui-disabled',
    );
  });
});
