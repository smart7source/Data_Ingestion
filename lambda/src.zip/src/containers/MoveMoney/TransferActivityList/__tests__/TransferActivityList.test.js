import { ThemeProvider } from '@mui/material';
import { render } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import TransferActivityList from '../TransferActivityList';

const history = createMemoryHistory();

const initialState = {
  moveMoney: {
    activeAccounts: [],
  },
};
const store = configureStore();

function TestElement({ transferDate }) {
  const currentProps = {
    amount: 100,
    transferFrom: 'Citi Business Checking *7636',
    transferTo: 'Boost by Chello *1111',
    transferDate,
    status: 'Verified',
  };

  return (
    <ThemeProvider theme={theme}>
      <Provider store={store(initialState)}>
        <Router history={history}>
          <TransferActivityList {...currentProps} />
        </Router>
      </Provider>
    </ThemeProvider>
  );
}

describe('TransferActivityList Test', () => {
  it('should render correctly', () => {
    const { queryByText } = render(<TestElement transferDate={'06/15/2021'} />);
    expect(queryByText(/Citi Business Checking/i)).toBeInTheDocument();
  });

  it('should render correctly without date', () => {
    const { queryByText } = render(<TestElement />);
    expect(queryByText(/Citi Business Checking/i)).toBeInTheDocument();
  });
});
