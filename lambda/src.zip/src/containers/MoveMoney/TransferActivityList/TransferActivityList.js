import { Grid, Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import { currencyFormat } from 'utils';

const { from: FROM, to: TO } = strings;

const TransferActivityList = (props) => {
  const { amount, transferFrom, transferTo, transferDate, status, lastElRef } =
    props;

  const elRef = lastElRef ? { ref: lastElRef } : {};

  return (
    <>
      <Grid
        item
        container
        xs={12}
        direction="row"
        justifyContent="space-between"
        {...elRef}
      >
        <Box width="100%" bgcolor="#F9FAFB" mt={1} py={1.5} pl={1}>
          <Typography variant="body1">{transferDate}</Typography>
        </Box>
        <Grid container py={3} px={1}>
          <Grid container justifyContent="space-between" my={1}>
            <Grid item xs={2}>
              <Typography
                variant="body1"
                align="right"
                mr={2}
                fontWeight="bold"
              >
                {FROM}
              </Typography>
            </Grid>
            <Grid item xs={7}>
              <Typography variant="body1">{transferFrom}</Typography>
            </Grid>
            <Grid item xs={3}>
              <Typography variant="body1" align="right">
                {currencyFormat(amount)}
              </Typography>
            </Grid>
          </Grid>
          <Grid container justifyContent="space-between" my={1}>
            <Grid item xs={2}>
              <Typography
                variant="body1"
                align="right"
                mr={2}
                fontWeight="bold"
              >
                {TO}
              </Typography>
            </Grid>
            <Grid item xs={7}>
              <Typography variant="body1">{transferTo}</Typography>
            </Grid>
            <Grid item xs={3}>
              <Typography variant="body1" align="right">
                {status}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default TransferActivityList;

TransferActivityList.propTypes = {
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  transferFrom: PropTypes.string,
  transferTo: PropTypes.string,
  transferDate: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Date),
  ]),
  status: PropTypes.string,
  lastElRef: PropTypes.instanceOf(Object),
};
TransferActivityList.defaultProps = {
  amount: '',
  transferFrom: '',
  transferTo: '',
  transferDate: '',
  status: '',
  lastElRef: null,
};
