import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import { createMemoryHistory } from 'history';
import { renderWithProviderAndRouter } from 'testHelpers';

import MoveMoneyHome from '../MoveMoneyHome';

const history = createMemoryHistory();

const initialState = {
  moveMoney: {
    activeAccounts: [],
    openExport: false,
  },
};

describe('should test initial condition', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
    renderWithProviderAndRouter(<MoveMoneyHome />, {
      render,
      wrapperProps: { initialState },
    });
  });

  it('should render title', () => {
    expect(screen.getByText('Move money')).toBeInTheDocument();
  });

  it('should render make transfer page for initial', () => {
    expect(screen.getByTestId('form')).toBeInTheDocument();
  });

  it('should render scheduled transfer when click on the tab', async () => {
    await act(async () => {
      fireEvent.click(screen.getByText('Scheduled transfers'));
    });
    await waitFor(() => {
      expect(screen.getByTestId('scheduled-transfer')).toBeInTheDocument();
    });
  });

  it('should render transfer activity when click on the tab', async () => {
    await act(async () => {
      fireEvent.click(screen.getByText('Transfer activity'));
    });
    await waitFor(() => {
      expect(
        screen.getByTestId('transfer-activity-container'),
      ).toBeInTheDocument();
    });
  });
});
