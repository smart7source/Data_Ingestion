import { Box, Paper, Tab, Tabs, Typography } from '@mui/material';
import React from 'react';

import classes from 'style/DashboardStyle.module.scss';
import strings from 'localization/translation';
import TabPanel from 'containers/Dashboard/components/TabPanel';
import mmClasses from 'style/MoveMoney.module.scss';

import ExternalBankAccounts from '../ExternalBankAccounts';
import MakeTransfer from '../MakeTransfer/MakeTransfer';
import TransferActivity from '../TransferActivity/TransferActivity';
import ScheduledTransfer from '../ScheduledTransfer/ScheduledTransfer';

const {
  moveMoney,
  makeTransfer,
  scheduledTransfer,
  transferActivity,
  externalBankAccounts,
} = strings;

function a11yProps(index) {
  return {
    id: `tab-${index}`,
    'aria-controls': `tabpanel-${index}`,
  };
}

const MoveMoneyHome = () => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box className={mmClasses.moveMoneyStyle}>
      <Paper className={classes.pageHeader} elevation={1}>
        <Typography variant="h1">{moveMoney}</Typography>
        <Tabs
          aria-label="move money"
          indicatorColor="primary"
          textColor="inherit"
          variant="scrollable"
          scrollButtons="auto"
          value={value}
          onChange={handleChange}
        >
          <Tab
            label={makeTransfer}
            {...a11yProps(0)}
            className={classes.tabHeading}
          />
          <Tab
            label={scheduledTransfer}
            {...a11yProps(1)}
            className={classes.tabHeading}
          />
          <Tab
            label={transferActivity}
            {...a11yProps(2)}
            className={classes.tabHeading}
          />
          <Tab
            label={externalBankAccounts}
            {...a11yProps(3)}
            className={classes.tabHeading}
          />
        </Tabs>
      </Paper>
      <Box component="main" flexGrow={1}>
        <TabPanel value={value} index={0}>
          <MakeTransfer tabChange={handleChange} />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <ScheduledTransfer />
        </TabPanel>
        <TabPanel value={value} index={2}>
          <TransferActivity />
        </TabPanel>
        <TabPanel value={value} index={3}>
          <ExternalBankAccounts />
        </TabPanel>
      </Box>
    </Box>
  );
};

export default MoveMoneyHome;
