import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Typography, Box, Tab, Tabs, Paper } from '@mui/material';

import { useRefData } from 'hooks';
import { bitPracticeInfoRefKeys } from 'utils';
import strings from 'localization/translation';
import classes from 'style/DashboardStyle.module.scss';
import {
  fetchPersonalInfoData,
  updateSettingsStatus,
  fetchPracticeInfoData,
} from 'store/actions';
import { Notification } from 'components';
import ExternalBankAccounts from 'containers/MoveMoney/ExternalBankAccounts/ExternalBankAccounts';
import TabPanel from 'containers/Dashboard/components/TabPanel';

import Team from './Team';
import VerifyAddressDialog from './Profile/EditPersonalInfoSettings/VerifyAddressDialogSettings';
import Notifications from './Notifications/Notifications';
import AccountInfoSettings from './Profile/AccountInfoSettings';
import PracticeInfoSettings from './Profile/PracticeInfoSettings';
import PersonalInfoSettings from './Profile/PersonalInfoSettings';
import EditPracticeInfoSettings from './Profile/EditPracticeInfoSettings/EditPracticeInfoSettings';
import EditPersonalInfoSettings from './Profile/EditPersonalInfoSettings/EditPersonalInfoSettings';
import './Profile/Profile.scss';
import LinkedPlatforms from './LinkedPlatforms/LinkedPlatforms';
import AddDocumentsSettings from './Profile/AddDocuments/AddDocumentsSettings';

const {
  settings,
  profile,
  linkedPlatforms,
  linkedBankAccounts,
  notifications,
  team,
  subscriptions,
} = strings;

const Settings = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [tabSettings, setTabSettings] = useState(0);
  const [isTeamsEditing, setIsTeamsEditing] = useState(false);
  const [showAddDocuments, setShowAddDocuments] = useState(true);
  const { page, isEditing, errorMessages } = useSelector(
    (state) => state.settings,
  );
  const dispatch = useDispatch();
  useRefData(bitPracticeInfoRefKeys);
  useEffect(() => {
    [fetchPersonalInfoData(), fetchPracticeInfoData()].forEach(dispatch);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const tabHandleChange = (e, newValue) => {
    setTabSettings(newValue);
    dispatch(updateSettingsStatus({ page, isEditing: false }));
    setIsTeamsEditing(!showAddDocuments);
  };

  const showDialog = () => {
    setOpenDialog(!openDialog);
  };

  const addDocsHandleChange = () => {
    setShowAddDocuments(!showAddDocuments);
  };

  const editOpen = (status = isEditing, data = page) => {
    dispatch(updateSettingsStatus({ page: data, isEditing: status }));
  };

  let memberProfile;

  if (isEditing) {
    if (page === 'personal') {
      memberProfile = (
        <>
          <AccountInfoSettings />
          <EditPersonalInfoSettings
            editOpen={editOpen}
            openDialog={showDialog}
          />
          <PracticeInfoSettings editOpen={editOpen} />
        </>
      );
    }
    if (page === 'practice') {
      memberProfile = (
        <>
          <AccountInfoSettings />
          <PersonalInfoSettings editOpen={editOpen} />
          <EditPracticeInfoSettings
            editOpen={editOpen}
            addDocs={addDocsHandleChange}
          />
        </>
      );
    }
  } else {
    memberProfile = (
      <>
        <AccountInfoSettings />
        <PersonalInfoSettings editOpen={editOpen} />
        <PracticeInfoSettings editOpen={editOpen} />
      </>
    );
  }

  return (
    <>
      <Box>
        <Paper className={classes.pageHeader} elevation={1}>
          <Typography variant="h1">{settings}</Typography>
          <Tabs
            aria-label="settings"
            value={tabSettings}
            onChange={tabHandleChange}
            indicatorColor="primary"
            textColor="inherit"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab label={profile} className={classes.tabHeading} />
            <Tab label={linkedPlatforms} className={classes.tabHeading} />
            <Tab label={linkedBankAccounts} className={classes.tabHeading} />
            <Tab label={notifications} className={classes.tabHeading} />
            <Tab label={team} className={classes.tabHeading} />
            <Tab label={subscriptions} className={classes.tabHeading} />
          </Tabs>
        </Paper>
        <TabPanel value={tabSettings} index={0}>
          <>
            {showAddDocuments && <Notification errors={errorMessages} />}
            {showAddDocuments && <Box mr={1}>{memberProfile}</Box>}
            {showAddDocuments || (
              <AddDocumentsSettings showDocs={addDocsHandleChange} />
            )}
            {openDialog && <VerifyAddressDialog closeDialog={showDialog} />}
          </>
        </TabPanel>
        <TabPanel value={tabSettings} index={1}>
          <LinkedPlatforms />
        </TabPanel>
        <TabPanel value={tabSettings} index={2}>
          <ExternalBankAccounts />
        </TabPanel>
        <TabPanel value={tabSettings} index={3}>
          <Box mr={1}>
            <Notifications />
          </Box>
        </TabPanel>
        <TabPanel value={tabSettings} index={4}>
          <Team />
        </TabPanel>
        <TabPanel value={tabSettings} index={5}>
          {subscriptions}
        </TabPanel>
      </Box>
    </>
  );
};

export default Settings;
