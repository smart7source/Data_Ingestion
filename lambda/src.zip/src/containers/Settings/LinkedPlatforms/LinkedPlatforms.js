import {
  Typography,
  Grid,
  Box,
  Paper,
  Card,
  CardContent,
  CardActions,
  IconButton,
  Link,
} from '@mui/material';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as Plus } from 'assets/svg/plus.svg';
import { ReactComponent as plusCircle } from 'assets/svg/plus-circle.svg';
import classes from 'style/globalStyle.module.scss';
import { ReactComponent as minusCircle } from 'assets/svg/minus-circle.svg';
import strings from 'localization/translation';

import './LinkedPlatforms.scss';

const LinkedPlatforms = () => (
  <>
    <Paper elevation={2}>
      <Box p={3}>
        <Grid
          direction="row"
          container
          justifyContent="space-between"
          sx={{ mb: 3 }}
        >
          <Grid item>
            <Typography variant="h2" color="grey.900">
              {strings.yourLinkedPlatforms}
            </Typography>
          </Grid>
          <Grid item>
            <Box display={{ xs: 'none', sm: 'block' }}>
              <Link
                href="/#"
                color="inherit"
                underline="hover"
                className={classes.faqLink}
                style={{ display: 'flex', alignItems: 'center' }}
              >
                <CustomIcon
                  component={Plus}
                  color="primary"
                  sx={{
                    fontSize: 14,
                    verticalAlign: 'middle',
                    marginRight: '7px',
                  }}
                  inheritViewBox
                />
                <Typography variant="button">
                  {strings.addNewPlatform}
                </Typography>
              </Link>
            </Box>
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item>
            <Card className="linkedPlatforms">
              <CardContent>
                <div className="image" data-testid="xero">
                  <Link
                    href="https://www.xero.com"
                    underline="none"
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    <img
                      src={`${process.env.PUBLIC_URL}/images/Xero-logo.png`}
                      alt="xero"
                    />
                  </Link>
                </div>
              </CardContent>
              <CardActions className="actions">
                <IconButton aria-label="delete" size="large">
                  <CustomIcon
                    component={minusCircle}
                    inheritViewBox
                    sx={{ fontSize: 20, color: '#231F20' }}
                  />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
          <Grid item>
            <Card className="linkedPlatforms">
              <CardContent>
                <div className="image" data-testid="intuit">
                  <Link
                    href="https://www.intuit.com"
                    underline="none"
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    <img
                      src={`${process.env.PUBLIC_URL}/images/Intuit-logo.png`}
                      alt="intuit"
                    />
                  </Link>
                </div>
              </CardContent>
              <CardActions className="actions">
                <IconButton aria-label="add" size="large">
                  <CustomIcon
                    component={plusCircle}
                    inheritViewBox
                    sx={{ fontSize: 20, color: '#231F20' }}
                  />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
        </Grid>
        <Grid item>
          <Box mt={12} display={{ xs: 'block', sm: 'none' }}>
            <Link
              href="/#"
              color="inherit"
              underline="hover"
              className={classes.faqLink}
              style={{ display: 'flex', alignItems: 'center' }}
            >
              <CustomIcon
                component={Plus}
                color="primary"
                sx={{
                  fontSize: 14,
                  verticalAlign: 'middle',
                  marginRight: '7px',
                }}
                inheritViewBox
              />
              <Typography variant="button">{strings.addNewPlatform}</Typography>
            </Link>
          </Box>
        </Grid>
      </Box>
    </Paper>
  </>
);

export default LinkedPlatforms;
