import { render, screen, fireEvent, act } from '@testing-library/react';
import { Auth } from 'aws-amplify';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('Testing Linked Platforms tab of Settings Screen', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });

    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: routePath.SETTINGS,
        render,
      }),
    );
  });

  it('should select tab Linked Platforms', () => {
    const tab = screen.getByRole('tab', { name: 'Linked Platforms' });
    fireEvent.click(tab);
    expect(screen.getByRole('tab', { selected: true })).toHaveTextContent(
      'Linked Platforms',
    );
  });

  it('should display linked platforms tab content', async () => {
    const tab = screen.getByRole('tab', { name: 'Linked Platforms' });
    fireEvent.click(tab);

    expect(screen.getByText('Your linked platforms')).toBeInTheDocument();
    const buttonAdd = screen.getAllByText('Add new platform');
    expect(buttonAdd[1]).toBeInTheDocument();
    expect(buttonAdd[2]).toBeNull;
    expect(screen.getByTestId(/xero/i)).toBeInTheDocument();
    expect(screen.getByTestId(/intuit/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/delete/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/add/i)).toBeInTheDocument();
  });
});
