import {
  Link,
  Box,
  Grid,
  Button,
  Dialog,
  DialogContent,
  FormHelperText,
} from '@mui/material';
import IconButton from '@mui/material/IconButton';
// import OtpInput from 'react-otp-input';
import PropTypes from 'prop-types';

import { ReactComponent as Close } from 'assets/svg/close.svg';
import { defaultFnPropTypes } from 'utils';
import FormHead from 'containers/OnBoarding/components/FormHead';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import { CustomOtp } from 'components';

const { verifyYourPhone3, verifyYourPhone4, verificationMessage3, ok } =
  strings;
const VerificationPhone = ({
  otp,
  otpSubmit,
  otpChange,
  resendOtp,
  inlineError,
  verifyOpen,
  setVerifyOpen,
  onClose,
  numberVerified,
}) => {
  const resendCode = async (e) => {
    e.preventDefault();
    resendOtp();
  };

  return (
    <>
      <Dialog open={verifyOpen} width={{ sm: '270px' }}>
        <Grid container justifyContent="flex-end">
          <Box display={{ xs: 'none', sm: 'block' }}>
            <IconButton
              onClick={() => {
                setVerifyOpen(false);
                onClose?.();
              }}
              size="large"
            >
              <Close
                fill="grey.800"
                style={{
                  width: '14px',
                  height: '14px',
                }}
              />
            </IconButton>
          </Box>
        </Grid>
        <DialogContent>
          <Box m={2}>
            <form onSubmit={otpSubmit} data-testid="form">
              <Box>
                <FormHead
                  heading={verifyYourPhone3}
                  subHeading={verifyYourPhone4}
                />
              </Box>
              {!!inlineError && (
                <Box
                  data-testid="otp-error"
                  component={FormHelperText}
                  display="flex"
                >
                  <Box
                    sx={{ color: '#900A0A' }}
                    flexGrow="1"
                    component="span"
                    width="0px"
                  >
                    {inlineError}
                  </Box>
                </Box>
              )}
              <CustomOtp
                value={otp}
                onChange={otpChange}
                containerStyle={classes.otpContainer}
                numInputs={6}
                focusStyle={classes.focusOtp}
                shouldAutoFocus
                inputStyle={classes.verifyPhoneInput}
                isInputNum
              />
              <Box marginTop={3}>
                <Link
                  href="/#"
                  onClick={resendCode}
                  component="button"
                  className={classes.link}
                  underline="always"
                  color="grey.650"
                >
                  {verificationMessage3}
                </Link>
              </Box>

              <Box marginTop={3}>
                <Grid container justifyContent="flex-end">
                  <Button
                    variant="contained"
                    color="primary"
                    disabled={otp.length !== 6}
                    size="OnbCtnBtn"
                    type="submit"
                    onClick={numberVerified}
                  >
                    {ok}
                  </Button>
                </Grid>
              </Box>
            </form>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default VerificationPhone;
VerificationPhone.propTypes = {
  otp: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  otpSubmit: PropTypes.func,
  otpChange: PropTypes.func,
  resendOtp: PropTypes.func,
  onClose: PropTypes.func,
  verifyOpen: PropTypes.bool,
  inlineError: PropTypes.string,
  setVerifyOpen: PropTypes.func,
  numberVerified: PropTypes.func,
};
VerificationPhone.defaultProps = {
  otp: '',
  otpSubmit: defaultFnPropTypes,
  otpChange: defaultFnPropTypes,
  resendOtp: defaultFnPropTypes,
  onClose: defaultFnPropTypes,
  verifyOpen: false,
  inlineError: '',
  setVerifyOpen: defaultFnPropTypes,
  numberVerified: defaultFnPropTypes,
};
