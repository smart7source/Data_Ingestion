import { Typography, Grid } from '@mui/material';

import strings from 'localization/translation';

const { boostAccount, email, textMessage, notificationInbox } = strings;
export default function NotificationHeading() {
  return (
    <Grid container>
      <Grid item xs={5} container>
        <Typography variant="h3" color="grey.900">
          {boostAccount}
        </Typography>
      </Grid>
      <Grid item xs={2} container alignItems="center">
        <Typography variant="h3" color="grey.900">
          {email}
        </Typography>
      </Grid>
      <Grid item xs={2} container alignItems="center">
        <Grid container justifyContent="center">
          <Typography variant="h3" color="grey.500">
            {textMessage}
          </Typography>
        </Grid>
      </Grid>
      <Grid item xs={3} container alignItems="center">
        <Grid container justifyContent="center">
          <Typography variant="h3" color="grey.900" align="center">
            {notificationInbox}
          </Typography>
        </Grid>
      </Grid>
    </Grid>
  );
}
