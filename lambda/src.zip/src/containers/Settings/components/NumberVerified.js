import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Grid,
  IconButton,
  Button,
  Box,
} from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

const { ok, numberVerified, gotYourDigits } = strings;
const NumberVerified = ({ closeModal }) => (
  <>
    <Dialog aria-labelledby="customized-dialog-title" open maxWidth="sm">
      <Grid container justifyContent="flex-end">
        <Box display={{ lg: 'block', sm: 'block', xs: 'none' }}>
          <IconButton
            //   onClick={() => {
            //     setVerifyOpen(false);
            //     onClose?.();
            //   }}
            onClick={closeModal}
            size="large"
          >
            <Close
              fill="grey.800"
              style={{
                width: '14px',
                height: '14px',
              }}
            />
          </IconButton>
        </Box>
      </Grid>
      <DialogTitle>
        <Grid>
          <Grid item>
            <Typography mt={2} variant="h1" xs={12} sm={12} color="grey.900">
              {gotYourDigits}
            </Typography>
          </Grid>
        </Grid>
      </DialogTitle>
      <DialogContent>
        <Grid item>
          <Typography
            variant="p1"
            color="grey.900"
            xs={12}
            display={{ lg: 'block', sm: 'block', xs: 'none' }}
          >
            {numberVerified}
          </Typography>
        </Grid>
        <img
          className={classes.phoneImage}
          src={`${process.env.PUBLIC_URL}/images/phoneNumberChanged.png`}
          alt="number verified"
        />
        <Grid>
          <Typography
            variant="p1"
            color="grey.900"
            xs={12}
            display={{ lg: 'none', sm: 'none', xs: 'block' }}
          >
            {numberVerified}
          </Typography>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Box display="flex" justifyContent="flex-end">
          <Button
            type="submit"
            variant="contained"
            color="primary"
            size="OnbCtnBtn"
            onClick={closeModal}
          >
            {ok}
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  </>
);

export default NumberVerified;

NumberVerified.propTypes = {
  closeModal: PropTypes.func,
};
NumberVerified.defaultProps = {
  closeModal: defaultFnPropTypes,
};
