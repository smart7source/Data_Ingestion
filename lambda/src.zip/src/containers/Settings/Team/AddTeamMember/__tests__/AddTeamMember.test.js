import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react/pure';

import { renderWithProviderAndRouter } from 'testHelpers';
import AddTeamMember from '../index';

const onHandleBack = jest.fn();
const onAdd = jest.fn();
function TestElement() {
  return <AddTeamMember onHandleBack={onHandleBack} onAdd={onAdd} />;
}

describe('Testing Add Team Member component', () => {
  beforeAll(() => {
    renderWithProviderAndRouter(<TestElement />, {
      render,
    });
  });
  it('should render the Add Team Member component', async () => {
    expect(screen.getByText('Add new team member')).toBeInTheDocument();
    expect(screen.queryByTestId(/add-member-ssn/i)).toBeInTheDocument();
    expect(
      screen.queryByTestId(/settings-teamembers-resStatus/),
    ).toBeInTheDocument();
    expect(screen.queryByTestId(/percentageOwnership/)).toBeInTheDocument();
    expect(screen.queryByTestId(/add-team-member-cancel/)).toBeInTheDocument();
    expect(screen.queryByTestId(/add-team-member-btn/)).toBeInTheDocument();
  });

  it('should show error messages on submit', async () => {
    const submitButton = screen.queryByTestId(/add-team-member-btn/);
    await act(async () => fireEvent.click(submitButton));
    expect(
      screen.queryByText("Please select your/team's role from the list"),
    ).toBeInTheDocument();
    expect(
      screen.queryAllByText('Missing required fields').length,
    ).toBeGreaterThan(1);
  });
  it('should show teams list on clicking cancel', async () => {
    const cancelButton = screen.queryByTestId(/add-team-member-cancel/);
    await act(async () => fireEvent.click(cancelButton));
    expect(onHandleBack).toBeCalled();
  });
  it('should be able to successfully edit the fields', async () => {
    const submitButton = screen.queryByTestId(/add-team-member-btn/);
    await act(async () => fireEvent.click(submitButton));
    expect(
      screen.queryByText("Please select your/team's role from the list"),
    ).toBeInTheDocument();
    const roleField = screen.queryByTestId(/indPrimaryRole/);
    expect(roleField).toBeInTheDocument();
    await act(async () => {
      fireEvent.change(roleField, { target: { value: '2' } });
    });
    expect(
      screen.queryByText("Please select your/team's role from the list"),
    ).not.toBeInTheDocument();
  });
});
