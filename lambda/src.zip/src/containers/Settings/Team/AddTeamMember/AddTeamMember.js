import {
  Box,
  Typography,
  Grid,
  Button,
  Divider,
  TextField,
  MenuItem,
  InputLabel,
} from '@mui/material';
import PropTypes from 'prop-types';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm, Controller } from 'react-hook-form';
import { useSelector } from 'react-redux';

import {
  CustomSelectBox,
  CustomIcon,
  CustomCheckbox,
  PercentageInput,
  NumberInput,
} from 'components';
import strings from 'localization/translation';
import { ReactComponent as CornerUpLeft } from 'assets/svg/corner-up-left.svg';
import { defaultFnPropTypes } from 'utils';
import globalClasses from 'style/globalStyle.module.scss';
import { settingsAddteamValidationsSchema } from 'helpers/ValidationSchema';
import { useRefData } from 'hooks';

import AddMemberBasicDetails from '../AddMemberBasicDetails/AddMemberBasicDetails';

const {
  socialSecurityNumber,
  residencyStatus,
  addTeamFormPrimaryRole,
  addTeamFormSelectRole,
  percentageOwnership,
  controlingPerson,
  addNewTeamMember: ADD_NEW_TEAM_MEMBER,
  addTeamMemberTxt: ADD_TEAM_MEMBER,
  cancel: CANCEL,
} = strings;

const AddTeamMember = ({ onHandleBack, onAdd }) => {
  const refData = useSelector((state) => state.global.refData);

  const {
    CHELLO_RESIDENCY_STATUS = [],
    CHELLO_INDIVIDUAL_ROLE = [],
    US_STATES = [],
    COUNTRY_CODE = [],
  } = refData;
  useRefData([
    'CHELLO_RESIDENCY_STATUS',
    'CHELLO_INDIVIDUAL_ROLE',
    'US_STATES',
    'COUNTRY_CODE',
  ]);

  const {
    control,
    watch,
    resetField,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(settingsAddteamValidationsSchema),
  });
  const handleOwnership = (value) => {
    if (value !== '1') {
      resetField('ownership');
    }
  };

  return (
    <Box display="flex" flexDirection="column" alignItems="flex-start" p="20px">
      <>
        <Box
          component="span"
          display="flex"
          alignItems="center"
          gap={1.25}
          mb="18px"
        >
          <Box
            sx={{
              display: 'inline-block',
              cursor: 'pointer',
            }}
            onClick={onHandleBack}
            data-testid="back_icon"
          >
            <CustomIcon
              component={CornerUpLeft}
              inheritViewBox
              color="primary"
              sx={{ fontSize: 20 }}
            />
          </Box>
          <Divider orientation="vertical" sx={{ height: '32px' }} />
          <Typography component="h2" variant="h2" color="grey.900">
            {ADD_NEW_TEAM_MEMBER}
          </Typography>
        </Box>
        <form
          onSubmit={handleSubmit(onAdd)}
          data-testid="settings-add-member-form"
        >
          <Grid container columnSpacing={2}>
            <AddMemberBasicDetails
              control={control}
              errors={errors}
              usStates={US_STATES}
              countryCode={COUNTRY_CODE}
            />

            <Grid item xs={12} sm={6}>
              <NumberInput
                label={
                  <Typography variant="h3" component="p" color="grey.800">
                    {socialSecurityNumber}
                  </Typography>
                }
                format="###-##-####"
                id="ssn"
                name="ssn"
                dataTestId="add-member-ssn"
                control={control}
                error={!!errors.ssn}
                errorText={errors?.ssn?.message}
                thousandSeparator={false}
                mask="_"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6}>
              <CustomSelectBox
                label={
                  <Typography variant="h3" component="p" color="grey.800">
                    {residencyStatus}
                  </Typography>
                }
                options={CHELLO_RESIDENCY_STATUS}
                name="resStatus"
                id="resStatus"
                control={control}
                error={!!errors.resStatus}
                errorText={errors.resStatus?.message}
                dataTestid="settings-teamembers-resStatus"
              />
            </Grid>
            <Grid item xs={6} sm={6}>
              <InputLabel htmlFor="role" id="role">
                {addTeamFormPrimaryRole}
              </InputLabel>
              <Controller
                name="role"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    onChange={(e) => {
                      field.onChange(e.target.value);
                      handleOwnership(e.target.value);
                    }}
                    value={field?.value || ''}
                    autoComplete="off"
                    variant="outlined"
                    size="small"
                    fullWidth
                    margin="dense"
                    select
                    inputProps={{ 'data-testid': 'indPrimaryRole' }}
                    error={!!errors.role}
                    helperText={errors.role && errors.role.message}
                    SelectProps={{
                      displayEmpty: true,
                      SelectDisplayProps: {
                        'data-testid': 'id-role',
                      },
                      classes: {
                        select: field.value
                          ? ''
                          : globalClasses.defaultSelectPlaceholder,
                      },
                    }}
                  >
                    <MenuItem
                      className={globalClasses.selectMenuItem}
                      data-testid="default-option"
                      value=""
                      selected
                    >
                      {addTeamFormSelectRole}
                    </MenuItem>
                    {CHELLO_INDIVIDUAL_ROLE.map((ele1, index1) => (
                      <MenuItem
                        className={globalClasses.selectMenuItem}
                        data-testid={`option${index1}`}
                        value={ele1.value}
                        key={index1}
                      >
                        {ele1.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>
            <Grid item xs={6} sm={6}>
              <PercentageInput
                error={!!errors.ownership}
                errorText={errors.ownership && errors.ownership.message}
                name="ownership"
                id="ownership"
                control={control}
                margin="dense"
                label={percentageOwnership}
                disabled={watch('role') !== '1'}
                inputProps={{
                  'data-testid': 'percentageOwnership',
                }}
              />
            </Grid>

            <Grid item xl={6} sx={{ marginBottom: '30px', marginTop: '0px' }}>
              <CustomCheckbox
                name="controlingPerson"
                id="controlingPerson"
                defaultValue={false}
                control={control}
                label={
                  <Typography variant="h3" component="p" color="grey.800">
                    {controlingPerson}
                  </Typography>
                }
              />
            </Grid>
          </Grid>
          <Box>
            <Grid justifyContent="space-between" container>
              <Grid item>
                <Button
                  variant="contained"
                  size="OnbCtnBtn"
                  data-testid="add-team-member-cancel"
                  onClick={onHandleBack}
                >
                  {CANCEL}
                </Button>
              </Grid>
              <Grid item>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  data-testid="add-team-member-btn"
                >
                  {ADD_TEAM_MEMBER}
                </Button>
              </Grid>
            </Grid>
          </Box>
        </form>
      </>
    </Box>
  );
};

export default AddTeamMember;
AddTeamMember.propTypes = {
  onHandleBack: PropTypes.func,
  onAdd: PropTypes.func,
};
AddTeamMember.defaultProps = {
  onHandleBack: defaultFnPropTypes,
  onAdd: defaultFnPropTypes,
};
