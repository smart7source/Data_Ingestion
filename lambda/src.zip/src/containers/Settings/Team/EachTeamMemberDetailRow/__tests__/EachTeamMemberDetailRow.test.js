import { render, screen } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter, refDataMock } from 'testHelpers';
import EachTeamMemberDetailRow from '../index';

const initialState = {
  global: {
    refData: {
      CHELLO_INDIVIDUAL_ROLE: refDataMock.CHELLO_INDIVIDUAL_ROLE.body,
    },
  },
};

function TestElement() {
  const details = {
    primaryApplicant: 'Y',
    firstName: 'john',
    lastName: 'Doe',
    phone: '1234567890',
    email: 'johndoe@email.com',
    address: 'address line 1',
    city: 'Dallas',
    state: 'TX',
    zip: '12345-1234',
    role: '1',
    percentageOwnership: '50%',
    controlingPerson: true,
  };
  return (
    <table>
      <tbody>
        <EachTeamMemberDetailRow details={details} />
      </tbody>
    </table>
  );
}

describe('Testing EachTeamMemberDetailRow component', () => {
  beforeAll(() => {
    renderWithProviderAndRouter(<TestElement />, {
      render,
      wrapperProps: { initialState },
    });
  });
  it('should display ownership details of member', async () => {
    expect(screen.getByText('50%')).toBeInTheDocument();
  });

  it('should display Role of member', async () => {
    expect(screen.getByText('Owner')).toBeInTheDocument();
  });

  it('Controlling person checkbox should be checked', async () => {
    expect(screen.getByTestId('view-team-controlling-person')).toBeChecked();
  });

  it('Should display more details on opening the accordion', async () => {
    userEvent.click(screen.getByTestId('view-team-accordion-down'));
    expect(screen.getByTestId('view-team-accordion-up')).toBeInTheDocument();
    expect(
      screen.getByText('address line 1, Dallas, TX 12345-1234'),
    ).toBeInTheDocument();
  });
});
