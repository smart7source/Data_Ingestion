import { useState } from 'react';
import { Box, TableCell, TableRow, IconButton, Checkbox } from '@mui/material';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';
import { useSelector } from 'react-redux';

import { CustomIcon } from 'components';
import { ReactComponent as ChevronUp } from 'assets/svg/chevron-up.svg';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';
import Classes from 'containers/OneAccount/OneAccount.module.scss';

import DisplayUserSettings from '../DisplayUserSettings/DisplayUserSettings';
import EachTeamMemberDetails from '../EachTeamMemberDetails/EachTeamMemberDetails';

const EachTeamMemberDetailRow = (props) => {
  const { details } = props;
  const {
    primaryApplicant,
    firstName,
    lastName,
    phone,
    email,
    address,
    city,
    state,
    zip,
    role,
    percentageOwnership,
    controlingPerson,
  } = details;
  const [open, setOpen] = useState(false);

  const refData = useSelector((reducerState) => reducerState.global.refData);
  const { CHELLO_INDIVIDUAL_ROLE } = refData;

  const ownershipValue =
    (CHELLO_INDIVIDUAL_ROLE || []).find((item) => item.value === role)?.name ||
    '';

  return (
    <>
      <TableRow
        sx={{
          backgroundColor: open && 'grey.200',
          borderBottom: !open && '1px solid #B4B4B4',
        }}
      >
        <TableCell>
          <Box
            className={Classes.transactionColGroup}
            display="flex"
            alignItems="center"
            gap={1.25}
          >
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={() => setOpen(!open)}
              style={{ height: 'fit-content' }}
            >
              {open ? (
                <CustomIcon
                  component={ChevronUp}
                  color="grey.800"
                  inheritViewBox
                  sx={{ width: '12px', height: '12px' }}
                  data-testid="view-team-accordion-up"
                />
              ) : (
                <CustomIcon
                  component={ChevronDown}
                  color="grey.800"
                  inheritViewBox
                  sx={{ width: '12px', height: '12px' }}
                  data-testid="view-team-accordion-down"
                />
              )}
            </IconButton>
            <DisplayUserSettings
              ele={{
                firstName,
                lastName,
                email,
                primaryApplicant,
              }}
            />
          </Box>
        </TableCell>
        <TableCell>{ownershipValue}</TableCell>
        <TableCell
          sx={{
            '&.MuiTableCell-root': {
              padding: '20px 20px 20px 27px',
            },
          }}
        >
          <NumberFormat
            value={percentageOwnership}
            displayType="text"
            suffix="%"
          />
        </TableCell>
        <TableCell sx={{ textAlign: 'center' }}>
          <Checkbox
            inputProps={{ 'data-testid': 'view-team-controlling-person' }}
            color="primary"
            disabled
            checked={controlingPerson}
            sx={{
              '&.Mui-checked': {
                color: '#B4B4B4',
              },
              '&.Mui-disabled': {
                color: '#B4B4B4',
              },
            }}
          />
        </TableCell>
      </TableRow>
      {open && (
        <TableRow sx={{ backgroundColor: 'grey.200' }}>
          <TableCell
            colSpan={4}
            sx={{
              padding: '0',
              borderBottomLeftRadius: '10px',
              borderBottomRightRadius: '10px',
            }}
          >
            <Box>
              <EachTeamMemberDetails
                address={address}
                city={city}
                state={state}
                zip={zip}
                phone={phone}
              />
            </Box>
          </TableCell>
        </TableRow>
      )}
    </>
  );
};

export default EachTeamMemberDetailRow;

EachTeamMemberDetailRow.propTypes = {
  details: PropTypes.instanceOf(Object),
};

EachTeamMemberDetailRow.defaultProps = {
  details: {},
};
