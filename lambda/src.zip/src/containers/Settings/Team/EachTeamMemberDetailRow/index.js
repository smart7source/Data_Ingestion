import EachTeamMemberDetailRow from './EachTeamMemberDetailRow';

export default EachTeamMemberDetailRow;
