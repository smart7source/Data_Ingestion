import { Grid, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import {
  CustomInput,
  CustomSelectBox,
  DatePicker,
  NumberInput,
} from 'components';
import strings from 'localization/translation';

const {
  firstName,
  lastName,
  email,
  phone,
  addressLine1,
  city,
  state: STATE,
  zipCode,
  dateOfBirth: DATEOFBIRTH,
  countryOfResidency,
} = strings;

const AddMemberBasicDetails = ({ control, errors, usStates, countryCode }) => (
  <>
    <Grid item xs={12} sm={6}>
      <CustomInput
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {firstName}
          </Typography>
        }
        id="firstName"
        defaultValue=""
        error={!!errors.firstName}
        inputProps={{ maxLength: 50 }}
        errorText={errors.firstName && errors.firstName.message}
        name="firstName"
        control={control}
        dataTestid="settings-add-team-first-name"
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <CustomInput
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {lastName}
          </Typography>
        }
        id="lastName"
        defaultValue=""
        error={!!errors.lastName}
        inputProps={{ maxLength: 50 }}
        errorText={errors.lastName && errors.lastName.message}
        name="lastName"
        control={control}
        dataTestid="settings-add-team-last-name"
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <CustomInput
        type="email"
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {email}
          </Typography>
        }
        defaultValue=""
        error={!!errors.email}
        errorText={errors.email && errors.email.message}
        name="email"
        control={control}
        id="setting-add-team-email"
        dataTestid="settings-add-team-email"
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <NumberInput
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {phone}
          </Typography>
        }
        format="###-###-####"
        id="phone"
        name="phone"
        dataTestId="settings-add-team-phone"
        control={control}
        error={!!errors.phone}
        errorText={errors?.phone?.message}
        thousandSeparator={false}
        mask="_"
      />
    </Grid>
    <Grid item xs={12} sm={12}>
      <CustomInput
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {addressLine1}
          </Typography>
        }
        defaultValue=""
        error={!!errors.address}
        inputProps={{ maxLength: 100 }}
        errorText={errors.address && errors.address.message}
        id="address"
        name="address"
        control={control}
        dataTestid="settings-add-team-address-line1"
      />
    </Grid>
    <Grid item xs={12} sm={7}>
      <CustomInput
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {city}
          </Typography>
        }
        defaultValue=""
        error={!!errors.city}
        errorText={errors.city && errors.city.message}
        name="city"
        control={control}
        id="city"
        dataTestid="settings-add-team-address-city"
      />
    </Grid>
    <Grid item xs={12} sm={2}>
      <CustomSelectBox
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {STATE}
          </Typography>
        }
        defaultValue=""
        options={usStates}
        error={!!errors.state}
        errorText={errors.state && errors.state.message}
        name="state"
        control={control}
        dataTestid="settings-add-team-state-code"
      />
    </Grid>
    <Grid item xs={12} sm={3}>
      <NumberInput
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {zipCode}
          </Typography>
        }
        name="zip"
        id="zip"
        format="#####-####"
        dataTestId="add-team-zipcodee"
        control={control}
        error={!!errors.zip}
        errorText={errors.zip && errors.zip.message}
        thousandSeparator={false}
        mask="_"
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <DatePicker
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {DATEOFBIRTH}
          </Typography>
        }
        id="dob"
        name="dob"
        control={control}
        dataTestid="date-of-birth"
        error={!!errors.dob}
        errorText={errors?.dob?.message}
        maxDateValue={
          new Date(new Date().setFullYear(new Date().getFullYear() - 18))
        }
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <CustomSelectBox
        label={
          <Typography variant="h3" component="p" color="grey.800">
            {countryOfResidency}
          </Typography>
        }
        defaultValue=""
        options={countryCode}
        name="country"
        id="add-team-country-of-residency"
        control={control}
        dataTestid="add-team-country-of-residency"
        error={!!errors.country}
        errorText={errors?.country?.message}
      />
    </Grid>
  </>
);

export default AddMemberBasicDetails;

AddMemberBasicDetails.propTypes = {
  control: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  usStates: PropTypes.instanceOf(Object),
  countryCode: PropTypes.instanceOf(Object),
};
AddMemberBasicDetails.defaultProps = {
  control: {},
  errors: {},
  usStates: [],
  countryCode: [],
};
