import { render, screen } from '@testing-library/react/pure';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

import { renderWithProviderAndRouter } from 'testHelpers';
import { settingsAddteamValidationsSchema } from 'helpers/ValidationSchema';
import AddMemberBasicDetails from '../index';

function TestElement() {
  const {
    control,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(settingsAddteamValidationsSchema),
  });

  return (
    <AddMemberBasicDetails
      control={control}
      errors={errors}
      usStates={[]}
      countryCode={[]}
    />
  );
}

describe('Testing Add Member Basic details component', () => {
  beforeAll(() => {
    renderWithProviderAndRouter(<TestElement />, {
      render,
    });
  });
  it('should render the Add Member Basic details component', async () => {
    expect(screen.getByLabelText('First name')).toBeInTheDocument();
    expect(screen.getByLabelText('Last name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Phone')).toBeInTheDocument();
    expect(screen.getByLabelText('Address')).toBeInTheDocument();
    expect(screen.getByLabelText('Date of birth')).toBeInTheDocument();
  });

  // TODO: Add functional test cases after adding client validations
});
