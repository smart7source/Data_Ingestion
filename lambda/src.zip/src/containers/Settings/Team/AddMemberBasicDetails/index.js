import AddMemberBasicDetails from './AddMemberBasicDetails';

export default AddMemberBasicDetails;
