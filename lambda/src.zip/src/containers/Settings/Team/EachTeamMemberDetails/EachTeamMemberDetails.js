import {
  Typography,
  Box,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Grid,
  Divider,
} from '@mui/material';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';

import { CustomIcon } from 'components';
import { ReactComponent as Checkmark } from 'assets/svg/checkmark.svg';
import strings from 'localization/translation';

const {
  address: ADDRESS,
  phone: PHONE,
  authorizationDetails: AUTHORIZATION_DETAILS,
} = strings;

const EachTeamMemberDetails = (props) => {
  const { address, city, state, zip, phone } = props;
  const roleDetails = [
    'One Time - Create / Edit Transfers',
    'One Time - Approve Transfers',
    'Self Approve Limit upto $ 20,000.00',
    'Recurring - Create / Edit Transfers',
    'Recurring - Approve Transfers',
    'Delete Transfers',
  ];

  let fullAddress = '-';
  if (address) {
    fullAddress = `${address}, ${city}, ${state} ${zip}`;
  }

  return (
    <Box sx={{ paddingInlineStart: '82px' }}>
      <Divider sx={{ borderColor: 'grey.500' }} />
      <Box p={3} pl={0} pb={0}>
        <Grid container rowSpacing={1} columnSpacing={2}>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {ADDRESS}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="gray.650">
                  {fullAddress}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {PHONE}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  <NumberFormat
                    value={phone}
                    displayType="text"
                    format="###-###-####"
                  />
                </Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>

      <Typography variant="p1SemiBold">{AUTHORIZATION_DETAILS}</Typography>

      <List
        sx={{
          paddingTop: '0px',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          rowGap: '15px',
        }}
      >
        {roleDetails.map((x, index) => (
          <ListItem sx={{ paddingTop: '0px', paddingLeft: '0px' }} key={index}>
            <ListItemIcon>
              <CustomIcon
                component={Checkmark}
                color="#008947"
                inheritViewBox
                sx={{ fontSize: '20px' }}
              />
            </ListItemIcon>
            <ListItemText primary={x} />
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default EachTeamMemberDetails;
EachTeamMemberDetails.propTypes = {
  address: PropTypes.string,
  city: PropTypes.string,
  state: PropTypes.string,
  zip: PropTypes.string,
  phone: PropTypes.string,
};
EachTeamMemberDetails.defaultProps = {
  address: '',
  city: '',
  state: '',
  zip: '',
  phone: '',
};
