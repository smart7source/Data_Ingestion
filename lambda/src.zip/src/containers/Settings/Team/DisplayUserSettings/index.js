import DisplayUserSettings from './DisplayUserSettings';

export default DisplayUserSettings;
