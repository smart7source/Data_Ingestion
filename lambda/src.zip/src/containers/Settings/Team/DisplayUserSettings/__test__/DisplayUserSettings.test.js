import { screen, render } from '@testing-library/react';
import DisplayUserSettings from '../DisplayUserSettings';

const user = {
  firstName: 'John',
  lastName: 'Doe',
  email: 'johndoe@gmail.com',
  primaryApplicant: 'Y',
};
describe('Rendering DisplayUserSettings component', () => {
  it('should render the compoent correctly', () => {
    render(<DisplayUserSettings ele={user} index={1} />);
    expect(screen.getByText(/john doe/i)).toBeInTheDocument();
    expect(screen.getByText(/johndoe@gmail.com/i)).toBeInTheDocument();
    expect(screen.getByAltText(/profile/i)).toBeInTheDocument();
  });
});
