import { Box, Typography, Avatar } from '@mui/material';
import PropTypes from 'prop-types';

import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

const { buildTeamYou: BUILD_TEAM_YOU } = strings;
export default function DisplayUserSettings({
  ele: { firstName, lastName, email, primaryApplicant },
}) {
  return (
    <Box display="flex" alignItems="center">
      <Avatar
        src={`${process.env.PUBLIC_URL}/images/profile.png`}
        alt="profile"
        className={classes.teamImg}
      />
      <Typography component="span" className={classes.teamName}>
        <div>
          <strong>
            {firstName} {lastName}{' '}
            {primaryApplicant === 'Y' && (
              <Typography component="span" color="primary">
                {BUILD_TEAM_YOU}
              </Typography>
            )}
          </strong>
        </div>
        <Box sx={{ mt: 1 }}>
          <small>{email}</small>
        </Box>
      </Typography>
    </Box>
  );
}

DisplayUserSettings.propTypes = {
  ele: PropTypes.instanceOf(Object),
};
DisplayUserSettings.defaultProps = {
  ele: {},
};
