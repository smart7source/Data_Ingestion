import ControllingPersonInfoDialog from './ControllingPersonInfoDialog';

export default ControllingPersonInfoDialog;
