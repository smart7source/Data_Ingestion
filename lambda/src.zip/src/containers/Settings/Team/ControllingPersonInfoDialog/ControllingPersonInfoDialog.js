import {
  IconButton,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  Divider,
} from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import CustomIcon from 'components/UIElements/CustomIcon';
import strings from 'localization/translation';

const {
  controlingPerson: CONTROLLING_PERSON,
  controllingPersonDialogMsg1: CONTROLLING_PERSON_MSG,
  controllingPersonDialogMsg2: CONTROLLING_PRSN_MSG,
} = strings;
function ControllingPersonInfoDialog({ onClose }) {
  return (
    <Dialog open onClose={onClose}>
      <DialogTitle sx={{ m: 0, p: 2 }} className={classes.noPadding}>
        <Typography variant="h3" component="p" color="grey.800">
          {CONTROLLING_PERSON}
        </Typography>
        <IconButton
          aria-label="close"
          size="small"
          className={classes.closeIcon}
          sx={{ marginTop: '10px' }}
          data-testid="controlling-person-close"
          onClick={onClose}
        >
          <CustomIcon
            component={Close}
            color="grey.800"
            inheritViewBox
            sx={{ width: '14px', height: '14px' }}
          />
        </IconButton>
      </DialogTitle>
      <Divider />
      <DialogContent>
        <DialogContentText>
          <Typography variant="p1" color="grey.900">
            {CONTROLLING_PERSON_MSG}
          </Typography>
        </DialogContentText>
        <DialogContentText sx={{ marginTop: '10px' }}>
          <Typography variant="p1" color="grey.900">
            {CONTROLLING_PRSN_MSG}
          </Typography>
        </DialogContentText>
      </DialogContent>
    </Dialog>
  );
}

export default ControllingPersonInfoDialog;
ControllingPersonInfoDialog.propTypes = {
  onClose: PropTypes.func,
};
ControllingPersonInfoDialog.defaultProps = {
  onClose: defaultFnPropTypes,
};
