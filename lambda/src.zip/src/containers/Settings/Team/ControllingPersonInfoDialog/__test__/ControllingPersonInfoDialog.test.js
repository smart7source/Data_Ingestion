import { render, screen } from '@testing-library/react/pure';

import { renderWithProviderAndRouter } from 'testHelpers';
import ControllingPersonInfoDialog from '../index';

function TestElement() {
  return <ControllingPersonInfoDialog />;
}

describe('Testing Controlling Person Info Dialog component', () => {
  beforeAll(() => {
    renderWithProviderAndRouter(<TestElement />, {
      render,
    });
  });
  it('should render Controlling Person Info Dialog component', async () => {
    expect(screen.getByText('Controlling Person')).toBeInTheDocument();
  });
});
