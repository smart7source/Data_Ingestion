import { useCallback } from 'react';
import { Box, Typography, Grid, Button, Paper } from '@mui/material';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { yupResolver } from '@hookform/resolvers/yup';
import PropTypes from 'prop-types';
import moment from 'moment';

import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';
import { updatePracticeInfo, updateSettingsInfoFailure } from 'store/actions';
import { editPracticeInfoSettingsSchema } from 'helpers/ValidationSchema';
import strings from 'localization/translation';
import { useClearNotification } from 'hooks';

import EditPracInfoSetForm from './Components/EditPracInfoSetForm';

const { practiceInfo, save, cancel } = strings;

const EditPracticeInfoSettings = ({ editOpen, addDocs }) => {
  const { practiceInfoData, errorMessages } = useSelector(
    (state) => state.settings,
  );
  const dispatch = useDispatch();
  const refData = useSelector((state) => state.global.refData);
  const { US_STATES: statesData, CHELLO_LEGAL_ENTITY: structureData } = refData;
  const {
    watch,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(editPracticeInfoSettingsSchema),
    defaultValues: {
      ...practiceInfoData,
      establishedDate: moment(practiceInfoData?.establishedDate, [
        'YYYY-MM-DD',
      ]).calendar(),
      legalStructure: structureData?.find?.(
        (structure) => structure.value === practiceInfoData.legalStructure,
      )?.value,
    },
  });

  const submitHandler = (data) => {
    const payload = {
      ...data,
      legalStructure: structureData?.find?.(
        (structure) => structure.value === data.legalStructure,
      )?.value,
    };
    dispatch(updatePracticeInfo(payload));
  };
  const clearFn = useCallback(() => {
    dispatch(updateSettingsInfoFailure([]));
  }, [dispatch]);
  useClearNotification({
    watch,
    clear: errorMessages?.length,
    clearFn,
  });
  return (
    <>
      <form
        onSubmit={handleSubmit(submitHandler)}
        data-testid="settings-practice-info-form"
      >
        <Paper elevation={2}>
          <Box p={3} mt={3}>
            <Grid direction="row" container spacing={2} sx={{ mb: 3 }}>
              <Grid item>
                <Typography variant="h2" color="grey.900">
                  {practiceInfo}
                </Typography>
              </Grid>
            </Grid>
            <EditPracInfoSetForm
              practiceInfoData={practiceInfoData}
              statesData={statesData}
              structureData={structureData}
              control={control}
              errors={errors}
            />
            <Grid container justifyContent="space-between">
              <Grid item>
                <Button
                  variant="contained"
                  size="OnbCtnBtn"
                  onClick={() => editOpen(false)}
                >
                  {cancel}
                </Button>
              </Grid>
              <Grid item>
                <Button
                  type="submit"
                  onClick={addDocs}
                  variant="contained"
                  color="primary"
                  className={classes.saveButton}
                  data-testid="edit-practice-info-settings-save-btn"
                >
                  {save}
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Paper>
      </form>
    </>
  );
};

export default EditPracticeInfoSettings;

EditPracticeInfoSettings.propTypes = {
  editOpen: PropTypes.func,
  addDocs: PropTypes.func,
};
EditPracticeInfoSettings.defaultProps = {
  editOpen: defaultFnPropTypes,
  addDocs: defaultFnPropTypes,
};
