import { Box, Grid } from '@mui/material';
import PropTypes from 'prop-types';

import {
  CustomInput,
  DatePicker,
  MaskInput,
  CustomSelectBox,
} from 'components';
import strings from 'localization/translation';

const {
  businessLegalName,
  businessPhone,
  businessEmail,
  businessAddress,
  doingBusiness,
  dateBusinessEstablished,
} = strings;

const EditPracInfoSetForm = ({
  statesData,
  structureData,
  control,
  errors,
  practiceInfoData,
}) => {
  const {
    orgAddressLine1,
    orgCityName,
    orgStateCode,
    orgZipCode,
    orgPhoneNumber,
    orgTaxId,
    orgEmail,
    orgName,
    dbaName,
    stateLegalInfo,
    legalStructure,
  } = practiceInfoData;

  return (
    <>
      <Box className="formBox">
        <Grid container columnSpacing={2}>
          <Grid item xs={12} sm={6}>
            <CustomInput
              label={businessLegalName}
              name="orgName"
              id="orgName"
              defaultValue={orgName}
              error={!!errors.orgName}
              inputProps={{ maxLength: 50 }}
              errorText={errors.orgName && errors.orgName.message}
              control={control}
              dataTestid="settings-business-legal-name"
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <MaskInput
              disabled
              label={strings.EIN}
              name="orgTaxId"
              id="orgTaxId"
              defaultValue={orgTaxId}
              mask="99-9999999"
              control={control}
            />
          </Grid>
          {/* <Grid item xs={12} sm={6}>
            <CustomInput
              disabled
              label={percentageOwnership}
              name="percentOwnership"
              id="percentOwnership"
              defaultValue={`Owner (${percentOwnership}% ownership)`}
              control={control}
            />
          </Grid> */}
          <Grid item xs={12} sm={6}>
            <CustomInput
              label={doingBusiness}
              name="dbaName"
              id="dbaName"
              defaultValue={dbaName}
              inputProps={{ maxLength: 50 }}
              control={control}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <MaskInput
              label={businessPhone}
              name="orgPhoneNumber"
              id="orgPhoneNumber"
              defaultValue={orgPhoneNumber}
              mask="+1-999-999-9999"
              maskChar="_"
              alwaysShowMask
              error={!!errors.orgPhoneNumber}
              errorText={errors.orgPhoneNumber && errors.orgPhoneNumber.message}
              control={control}
              withoutCntryCode
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <DatePicker
              label={dateBusinessEstablished}
              name="establishedDate"
              id="establishedDate"
              control={control}
              error={!!errors.establishedDate}
              errorText={
                errors.establishedDate && errors.establishedDate.message
              }
              dataTestid="settings-operation-start-date"
              disabled
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <CustomInput
              type="email"
              label={businessEmail}
              name="orgEmail"
              id="orgEmail"
              defaultValue={orgEmail}
              error={!!errors.orgEmail}
              errorText={errors.orgEmail && errors.orgEmail.message}
              control={control}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <CustomSelectBox
              label={strings.stateLegalFormation}
              name="stateLegalInfo"
              id="stateLegalInfo"
              defaultValue={stateLegalInfo}
              options={statesData}
              error={!!errors.stateLegalInfo}
              errorText={errors.stateLegalInfo && errors.stateLegalInfo.message}
              control={control}
              disabled
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <CustomInput
              label={businessAddress}
              name="orgAddressLine1"
              id="orgAddressLine1"
              defaultValue={orgAddressLine1}
              error={!!errors.orgAddressLine1}
              errorText={
                errors.orgAddressLine1 && errors.orgAddressLine1.message
              }
              inputProps={{ maxLength: 100 }}
              control={control}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <CustomSelectBox
              label={strings.businessLegalStructure}
              name="legalStructure"
              id="legalStructure"
              options={structureData}
              defaultValue={
                structureData?.find?.(
                  (structure) => structure.name === legalStructure,
                )?.value
              }
              error={!!errors.legalStructure}
              errorText={errors.legalStructure && errors.legalStructure.message}
              control={control}
              disabled
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <CustomInput
              label={strings.city}
              name="orgCityName"
              id="orgCityName"
              defaultValue={orgCityName}
              error={!!errors.orgCityName}
              errorText={errors.orgCityName && errors.orgCityName.message}
              inputProps={{ maxLength: 40 }}
              control={control}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <CustomSelectBox
              label={strings.state}
              name="orgStateCode"
              id="orgStateCode"
              options={statesData}
              defaultValue={orgStateCode}
              error={!!errors.orgStateCode}
              errorText={errors.orgStateCode && errors.orgStateCode.message}
              control={control}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <MaskInput
              label={strings.zipCode}
              name="orgZipCode"
              id="orgZipCode"
              defaultValue={orgZipCode}
              control={control}
              mask="99999-9999"
              maskChar={null}
              error={!!errors.orgZipCode}
              errorText={errors.orgZipCode && errors.orgZipCode.message}
              isZipCode
              dataTestid="settings-personal-info-zipcode"
              outputMasked
            />
          </Grid>
        </Grid>
      </Box>
    </>
  );
};
export default EditPracInfoSetForm;

EditPracInfoSetForm.propTypes = {
  practiceInfoData: PropTypes.instanceOf(Object),
  errors: PropTypes.instanceOf(Object),
  control: PropTypes.instanceOf(Object).isRequired,
  statesData: PropTypes.arrayOf(PropTypes.any),
  structureData: PropTypes.arrayOf(PropTypes.any),
};
EditPracInfoSetForm.defaultProps = {
  practiceInfoData: {},
  errors: {},
  statesData: [],
  structureData: [],
};
