import { Box, Typography, Grid, Button, Paper } from '@mui/material';
import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import PropTypes from 'prop-types';
import moment from 'moment';

import { defaultFnPropTypes, formatDateToString } from 'utils';
import {
  CustomInput,
  MaskInput,
  CustomSelectBox,
  DatePicker,
} from 'components';
import { updatePersonalInfo, updateSettingsInfoFailure } from 'store/actions';
import { editPersonalInfoSettingsSchema } from 'helpers/ValidationSchema';
import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';
import { useClearNotification } from 'hooks';

const {
  personalInfo,
  firstName,
  lastName,
  email,
  phone,
  addressLine1,
  city,
  state: STATE,
  zipCode,
  dateOfBirth: DATEOFBIRTH,
  countryOfResidency,
  socialSecurityNumber,
  cancel,
  save,
} = strings;
const EditPersonalInfoSettings = ({ editOpen, openDialog }) => {
  const refData = useSelector((state) => state.global.refData);
  const {
    BUSINESS_TYPE: businessTypeData,
    COUNTRY_CODE: countryOfOperationData,
    CHELLO_NAIC_CODE: naicCodeData,
    US_STATES: statesData,
    CHELLO_LEGAL_ENTITY: structureData,
  } = refData;
  const settings = useSelector((state) => state.settings);
  const { personalInfoData, errorMessages } = settings;
  const dispatch = useDispatch();
  const {
    control,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(editPersonalInfoSettingsSchema),
    defaultValues: {
      ...personalInfoData,
      dob: moment(personalInfoData?.dob, ['YYYY-MM-DD']).calendar(),
    },
  });

  const submitHandler = (data) => {
    let { dob } = data;
    if (dob && typeof dob === 'object') {
      dob = formatDateToString(dob);
    }
    dispatch(updatePersonalInfo({ ...data, dob }));
  };

  const clearFn = useCallback(() => {
    dispatch(updateSettingsInfoFailure([]));
  }, [dispatch]);
  useClearNotification({
    watch,
    clear: errorMessages?.length,
    clearFn,
  });

  return (
    <>
      <Paper elevation={2}>
        <Box p={3} mt={3}>
          <form
            onSubmit={handleSubmit(submitHandler)}
            data-testid="settings-personal-info-form"
          >
            <Box className="formBox">
              <Grid direction="row" container spacing={2} sx={{ mb: 3 }}>
                <Grid item>
                  <Typography variant="h2" color="grey.900">
                    {personalInfo}
                  </Typography>
                </Grid>
              </Grid>
              <Grid container columnSpacing={2}>
                <Grid item xs={12} sm={6}>
                  <CustomInput
                    label={firstName}
                    id="firstName"
                    defaultValue={personalInfoData.firstName}
                    // error={!!errors.firstName}
                    // inputProps={{ maxLength: 50 }}
                    // errorText={errors.firstName && errors.firstName.message}
                    name="firstName"
                    control={control}
                    dataTestid="settings-personal-info-first-name"
                    disabled
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <CustomInput
                    label={lastName}
                    id="lastName"
                    defaultValue={personalInfoData.lastName}
                    // error={!!errors.lastName}
                    // inputProps={{ maxLength: 50 }}
                    // errorText={errors.lastName && errors.lastName.message}
                    name="lastName"
                    control={control}
                    dataTestid="settings-personal-info-last-name"
                    disabled
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <CustomInput
                    type="email"
                    label={email}
                    defaultValue={personalInfoData.email}
                    error={!!errors.email}
                    errorText={errors.email && errors.email.message}
                    name="email"
                    control={control}
                    id="edit-personal-info-setting-email"
                    dataTestid="settings-personal-info-email"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <MaskInput
                    label={phone}
                    name="phone"
                    id="phone"
                    defaultValue={personalInfoData.phone}
                    control={control}
                    mask="+1-999-999-9999"
                    maskChar="_"
                    alwaysShowMask
                    error={!!errors.phone}
                    errorText={errors.phone && errors.phone.message}
                    dataTestid="settings-personal-info-phone"
                    withoutCntryCode
                  />
                </Grid>
                <Grid item xs={12} sm={12}>
                  <CustomInput
                    label={addressLine1}
                    defaultValue={personalInfoData.address}
                    error={!!errors.address}
                    inputProps={{ maxLength: 100 }}
                    errorText={errors.address && errors.address.message}
                    id="address"
                    name="address"
                    control={control}
                    dataTestid="settings-personal-info-address-line1"
                  />
                </Grid>
                <Grid item xs={12} sm={7}>
                  <CustomInput
                    label={city}
                    defaultValue={personalInfoData.city}
                    error={!!errors.city}
                    errorText={errors.city && errors.city.message}
                    name="city"
                    control={control}
                    id="city"
                    dataTestid="settings-personal-info-address-city"
                  />
                </Grid>
                <Grid item xs={12} sm={2}>
                  <CustomSelectBox
                    label={STATE}
                    defaultValue={personalInfoData.state}
                    options={statesData}
                    error={!!errors.state}
                    errorText={errors.state && errors.state.message}
                    name="state"
                    control={control}
                    dataTestid="settings-personal-info-state-code"
                  />
                </Grid>
                <Grid item xs={12} sm={3}>
                  <MaskInput
                    label={zipCode}
                    name="zip"
                    id="zip"
                    defaultValue={personalInfoData.zip}
                    control={control}
                    mask="99999-9999"
                    maskChar={null}
                    error={!!errors.zip}
                    errorText={errors.zip && errors.zip.message}
                    isZipCode
                    dataTestid="settings-personal-info-zipcode"
                    outputMasked
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <DatePicker
                    label={DATEOFBIRTH}
                    id="dob"
                    name="dob"
                    control={control}
                    dataTestid="date-of-birth"
                    // error={!!errors.dob}
                    // errorText={errors?.dob?.message}
                    maxDateValue={
                      new Date(
                        new Date().setFullYear(new Date().getFullYear() - 18),
                      )
                    }
                    disabled
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <CustomSelectBox
                    label={countryOfResidency}
                    disabled
                    defaultValue={personalInfoData.country}
                    options={countryOfOperationData}
                    name="country"
                    control={control}
                    dataTestid="settings-personal-info-country-of-residency"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <MaskInput
                    label={socialSecurityNumber}
                    name="ssn"
                    id="ssn"
                    // disabled
                    defaultValue={personalInfoData.ssn}
                    control={control}
                    mask="999-99-9999"
                    error={!!errors.ssn}
                    errorText={errors?.ssn?.message}
                    maskChar={null}
                    dataTestid="settings-personal-info-ssn"
                  />
                </Grid>
              </Grid>
              <Box>
                <Grid justifyContent="space-between" container>
                  <Grid item>
                    <Button
                      variant="contained"
                      size="OnbCtnBtn"
                      onClick={() => {
                        editOpen(false);
                        clearFn();
                      }}
                      data-testid="settings-personal-info-cancel"
                    >
                      {cancel}
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      // onClick={openDialog}
                      type="submit"
                      variant="contained"
                      color="primary"
                      className={classes.saveButton}
                      data-testid="edit-personal-info-settings-save-btn"
                    >
                      {save}
                    </Button>
                  </Grid>
                </Grid>
              </Box>
            </Box>
          </form>
        </Box>
      </Paper>
    </>
  );
};
export default EditPersonalInfoSettings;

EditPersonalInfoSettings.propTypes = {
  editOpen: PropTypes.func,
  openDialog: PropTypes.func,
};
EditPersonalInfoSettings.defaultProps = {
  editOpen: defaultFnPropTypes,
  openDialog: defaultFnPropTypes,
};
