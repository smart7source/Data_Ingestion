import {
  Button,
  Dialog,
  DialogContent,
  Typography,
  DialogActions,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  FormLabel,
  Box,
  DialogTitle,
  Grid,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useState } from 'react';
import { NavLink } from 'react-router-dom';

import strings from 'localization/translation';
import { routePath } from 'routes';
import { defaultFnPropTypes } from 'utils';
import classes from 'style/globalStyle.module.scss';

const {
  continueBtnName,
  verifyAddDlogHeading,
  verifyAddDlogSubHeading,
  crntAddressLbl,
  sgstdAddressLbl,
  editAdddress,
  status,
} = strings;

const VerifyAddressDialog = ({
  crntFullAdd,
  suggestedAdd,
  //   handleContinue,
  page,
  handleClose,
  closeDialog,
  addressStatus,
}) => {
  const [prefAddress, setPrefAddress] = useState('C');
  return (
    <Dialog
      aria-labelledby="customized-dialog-title"
      open
      fullWidth
      maxWidth="sm"
    >
      <DialogTitle>
        Verify address
        <Typography mt={2}>
          We checked your entered address with USPS and it suggested the changes
          below.
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box>
          <FormControl>
            <RadioGroup
              aria-label="verify address"
              name="address"
              defaultValue="C"
              data-testid="prefAddRadio"
              onChange={(e) => setPrefAddress(e.target.value)}
            >
              <FormLabel
                sx={{
                  marginTop: 0,
                  marginBottom: '5px',
                  color: 'grey.800',
                }}
              >
                {crntAddressLbl} {`( ${status}: ${addressStatus} )`}
              </FormLabel>
              <FormControlLabel
                value="C"
                control={<Radio className={classes.radioLabelAlignment} />}
                label={crntFullAdd}
              />
              <FormLabel
                sx={{
                  marginTop: '10px',
                  marginBottom: '5px',
                  color: 'grey.800',
                }}
              >
                {sgstdAddressLbl}
              </FormLabel>
              <FormControlLabel
                value="S"
                control={<Radio className={classes.radioLabelAlignment} />}
                label={suggestedAdd}
              />
            </RadioGroup>
          </FormControl>
        </Box>
      </DialogContent>
      <DialogActions className={classes.spacing}>
        <Grid container justifyContent="space-between">
          <Grid item>
            <Button variant="contained" size="OnbCtnBtn" onClick={closeDialog}>
              Cancel
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              color="primary"
              //   onClick={() => handleContinue(prefAddress)}
              disableElevation
              data-testid="continue_btn"
            >
              {continueBtnName}
            </Button>
          </Grid>
        </Grid>
      </DialogActions>
    </Dialog>
  );
};

export default VerifyAddressDialog;

VerifyAddressDialog.propTypes = {
  //   handleContinue: PropTypes.func.isRequired,
  crntFullAdd: PropTypes.node,
  suggestedAdd: PropTypes.node,
  page: PropTypes.string,
  handleClose: PropTypes.func,
  addressStatus: PropTypes.string,
  closeDialog: PropTypes.func,
};

VerifyAddressDialog.defaultProps = {
  crntFullAdd: <></>,
  suggestedAdd: <></>,
  page: '',
  handleClose: defaultFnPropTypes,
  addressStatus: '',
  closeDialog: defaultFnPropTypes,
};
