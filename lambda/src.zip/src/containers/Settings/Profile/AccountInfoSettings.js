import { useState, useEffect } from 'react';
import { Typography, Grid, Box, Link, Paper } from '@mui/material';
import { useSelector } from 'react-redux';
import { Auth } from 'aws-amplify';

import classes from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

import SuccessModal from '../../Dashboard/components/SuccessModal';

import EditPassword from './EditPassword/EditPassword';

const { accountInfo, username: USERNAME, passwordLable, change } = strings;
const AccountInfoSettings = () => {
  const isOpen = useSelector((state) => state.global.isOpen);
  const [openPassword, setOpenPassword] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    Auth.currentAuthenticatedUser().then((user) => {
      setUsername(user.username);
    });
  }, []);

  const openModalPassword = () => {
    setOpenPassword(false);
  };

  return (
    <>
      <Paper elevation={2}>
        <Box p={3}>
          <Grid direction="row" container spacing={3}>
            <Grid item>
              <Typography mb={3} variant="h2" color="grey.900">
                {accountInfo}
              </Typography>
            </Grid>
          </Grid>
          <Grid container rowSpacing={1} columnSpacing={2}>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {USERNAME}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {username}
                  </Typography>
                </Box>
              </Box>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Grid container direction="row" justifyContent="space-between">
                  <Grid item>
                    <Typography variant="p1" color="grey.650">
                      {passwordLable}
                    </Typography>
                  </Grid>
                  <Grid item className={classes.formExtra}>
                    <Link
                      component="button"
                      onClick={() => setOpenPassword(true)}
                      className={classes.link}
                      data-testid="settings-change-password-btn"
                    >
                      {change}
                    </Link>
                  </Grid>
                </Grid>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    *********
                  </Typography>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Paper>
      {openPassword && (
        <EditPassword
          openPassword={openPassword}
          openModalPassword={openModalPassword}
        />
      )}
      {isOpen && <SuccessModal />}
    </>
  );
};

export default AccountInfoSettings;
