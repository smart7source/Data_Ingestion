import { useMemo } from 'react';
import { Box, Typography, Grid, IconButton, Paper } from '@mui/material';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import moment from 'moment';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as editIcon } from 'assets/svg/editIcon.svg';
import strings from 'localization/translation';
import { defaultFnPropTypes } from 'utils';
import { ComponentSpinner } from 'components';

const {
  practiceInfo: practiceInfoString,
  businessLegalName: businessLegalNameString,
  businessPhone: businessPhoneString,
  businessEmail: businessEmailString,
  businessAddress: businessAddressString,
  cityStateZip: cityStateZipString,
  EIN: EINString,
  businessDBAName: businessDBANameString,
  dateEstablished: dateEstablishedString,
  stateLegalFormation: stateLegalFormationString,
  businessLegalStructure: businessLegalStructureString,
} = strings;

const PracticeInfoSettings = ({ editOpen }) => {
  const settings = useSelector((state) => state.settings);
  const {
    orgAddressLine1,
    orgCityName,
    orgStateCode,
    orgZipCode,
    orgPhoneNumber,
    orgTaxId,
    orgEmail,
    orgName,
    dbaName,
    establishedDate,
    stateLegalInfo,
    legalStructure,
  } = settings?.practiceInfoData;
  const { practiceInfoLoading } = settings;
  const refData = useSelector((state) => state.global.refData);
  const { US_STATES: statesData, CHELLO_LEGAL_ENTITY: structureData } = refData;

  const stateName = useMemo(
    () => statesData?.find?.((state) => state.value === stateLegalInfo)?.name,
    [stateLegalInfo, statesData],
  );

  const legalStructureName = useMemo(
    () =>
      structureData?.find((legalEntity) => legalEntity.value === legalStructure)
        ?.name,
    [legalStructure, structureData],
  );

  const formattedOrgPhoneNumber = useMemo(
    () =>
      (orgPhoneNumber?.length === 10
        ? `1${orgPhoneNumber}`
        : orgPhoneNumber
      )?.replace(/^([1])(\d{3})(\d{3})(\d{4}).*/, '+$1-$2-$3-$4'),
    [orgPhoneNumber],
  );

  const orgCityNameorgStateCodeorgZipCode = useMemo(
    () => [orgCityName, orgStateCode, orgZipCode].filter((x) => x).join(', '),
    [orgCityName, orgStateCode, orgZipCode],
  );

  return (
    <Paper sx={{ position: 'relative' }} elevation={2}>
      <ComponentSpinner open={practiceInfoLoading} />
      <Box p={3} mt={3}>
        <Grid
          direction="row"
          container
          spacing={2}
          alignItems="center"
          justifyContent={{ xs: 'space-between', sm: 'flex-start' }}
          sx={{ mb: 3 }}
        >
          <Grid item>
            <Typography variant="h2" color="grey.900">
              {practiceInfoString}
            </Typography>
          </Grid>
          <Grid item>
            <IconButton
              aria-label="edit-button"
              data-testid="practice-edit-icon"
              onClick={() => editOpen(true, 'practice')}
            >
              <CustomIcon
                component={editIcon}
                color="#000"
                inheritViewBox
                sx={{ fontSize: 20 }}
              />
            </IconButton>
          </Grid>
        </Grid>
        <Grid container rowSpacing={1} columnSpacing={2}>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {businessLegalNameString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {orgName}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {EINString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {orgTaxId?.replace(/(\d{2})(\d{7})/, '$1-$2')}
                </Typography>
              </Box>
            </Box>
          </Grid>
          {/* <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {percentageOwnershipString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {percentOwnership}
                </Typography>
              </Box>
            </Box>
          </Grid> */}
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {businessDBANameString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {dbaName}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {businessPhoneString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {formattedOrgPhoneNumber}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {dateEstablishedString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {establishedDate
                    ? moment(establishedDate, ['YYYY-MM-DD']).calendar()
                    : ''}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {businessEmailString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {orgEmail}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {stateLegalFormationString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {stateName}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {businessAddressString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="h3" color="gray.900">
                  {orgAddressLine1}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {businessLegalStructureString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {legalStructureName}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box mb={2}>
              <Typography variant="p1" color="grey.650">
                {cityStateZipString}
              </Typography>
              <Box className="formSettings">
                <Typography variant="p1SemiBold" color="grey.650">
                  {orgCityNameorgStateCodeorgZipCode}
                </Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Paper>
  );
};

export default PracticeInfoSettings;
PracticeInfoSettings.propTypes = {
  editOpen: PropTypes.func,
};
PracticeInfoSettings.defaultProps = {
  editOpen: defaultFnPropTypes,
};
