import {
  Typography,
  Grid,
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { Auth } from 'aws-amplify';

import { CustomInput, ErrorHelper } from 'components';
import classes from 'style/globalStyle.module.scss';
import { openSuccessModal } from 'store/actions';
import { changePasswordSchema } from 'helpers/ValidationSchema';
import strings from 'localization/translation';
import { defaultFnPropTypes } from 'utils';
import { useConfirmPasswordTrigger } from 'hooks';

const {
  changeYourPassword,
  currentPassword,
  newPassword: NEWPASSWORD,
  confirmPassword,
  cancel,
  passwordIncorrect,
  continue: CONTINUE,
} = strings;
const EditPassword = ({ openPassword, openModalPassword }) => {
  const dispatch = useDispatch();
  const {
    control,
    watch,
    handleSubmit,
    trigger,
    getValues,
    setError,
    formState: { errors },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(changePasswordSchema),
  });

  const submitHandler = (newData, e) => {
    e.preventDefault();
    const { newPassword, oldPassword } = newData;
    Auth.currentAuthenticatedUser()
      .then((user) => Auth.changePassword(user, oldPassword, newPassword))
      .then((data) => {
        openModalPassword(false);
        dispatch(openSuccessModal(true));
      })
      .catch((error) => {
        let message;
        if (error.message === 'Incorrect username or password.') {
          message = passwordIncorrect;
        } else {
          message = error.message;
        }
        setError('oldPassword', { type: 'password', message });
      });
  };

  const getNewPass = getValues('newPassword');
  const oldPass = watch('oldPassword');
  const confirmPass = getValues('confirmPassword');
  const newPass = watch('newPassword');
  useConfirmPasswordTrigger({
    trigger,
    confirmPass,
    newPass,
    oldPass,
    getNewPass,
  });

  return (
    <Dialog
      open={openPassword}
      fullWidth
      data-testid="settings-change-your-password-dialog"
    >
      <form onSubmit={handleSubmit(submitHandler)} data-testid="form1">
        <Box display="flex" alignItems="center">
          <Box flexGrow={1}>
            <DialogTitle>
              <Typography component="span" variant="h1" color="grey.650">
                {changeYourPassword}
              </Typography>
            </DialogTitle>
          </Box>
        </Box>
        <DialogContent>
          <Grid item sm={12} md={12}>
            <Box>
              <CustomInput
                autoFocus
                fullWidth
                type="password"
                name="oldPassword"
                id="oldPassword"
                dataTestid="password-input"
                label={currentPassword}
                control={control}
                error={!!errors.oldPassword}
                errorText={errors.oldPassword && errors.oldPassword.message}
              />
            </Box>
            <Box>
              <CustomInput
                type="password"
                name="newPassword"
                id="newPassword"
                dataTestid="password-input1"
                label={NEWPASSWORD}
                control={control}
                error={!!errors.newPassword}
                errorText={errors.newPassword && errors.newPassword.message}
              />
            </Box>
            <Box mb={1}>
              <ErrorHelper value={newPass} />
            </Box>
            <Box>
              <CustomInput
                type="password"
                name="confirmPassword"
                dataTestid="password-input2"
                id="confirmPassword"
                label={confirmPassword}
                control={control}
                error={!!errors.confirmPassword}
                errorText={
                  errors.confirmPassword && errors.confirmPassword.message
                }
              />
            </Box>
          </Grid>
        </DialogContent>
        <DialogActions className={classes.dialogButton}>
          <Button
            variant="contained"
            size="OnbCtnBtn"
            className={classes.cancelButtonNew}
            onClick={() => openModalPassword(false)}
          >
            {cancel}
          </Button>
          <Button
            type="submit"
            color="primary"
            variant="contained"
            className={classes.saveButton}
          >
            {CONTINUE}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};
export default EditPassword;

EditPassword.propTypes = {
  openPassword: PropTypes.bool,
  openModalPassword: PropTypes.func,
};
EditPassword.defaultProps = {
  openPassword: false,
  openModalPassword: defaultFnPropTypes,
};
