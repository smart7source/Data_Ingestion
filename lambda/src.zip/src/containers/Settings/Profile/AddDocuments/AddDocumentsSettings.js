/* eslint-disable max-lines */
import {
  Box,
  Grid,
  Link,
  Button,
  Typography,
  Avatar,
  IconButton,
  Paper,
} from '@mui/material';
import { useSelector } from 'react-redux';
import { useState } from 'react';
import PropTypes from 'prop-types';

import { ReactComponent as cornerUpLeft } from 'assets/svg/corner-up-left.svg';
import { readFileDataAsBase64, defaultFnPropTypes } from 'utils';
import { useOnboarding } from 'hooks';
import { addDocPgInfo } from 'helpers/URLConfiguration';
import routePath from 'routes/routePath';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';
import serviceUrl from 'api/UrlHelper';
import ApiClient from 'api/ApiClient';
import { LinearProgressWithLabel } from 'components';
import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as FileText } from 'assets/svg/file-text.svg';
import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle-2.svg';
import { ReactComponent as AlertCircle } from 'assets/svg/alert-circle.svg';
import RightPanelLayout from 'containers/OnBoarding/components/RightPanelLayout';
import UploadFile from 'containers/OnBoarding/AddDocuments/components/UploadFile';

const { upload, uploadFailed, replace } = strings;

const { pageId, pageKey } = addDocPgInfo;

const AddDocuments = ({ showDocs, editteamflag, onBacktoTeam }) => {
  const [showUploadModel, setShowUploadModel] = useState(false);
  const [activeDocument, setActiveDocument] = useState();
  const payload = useSelector((state) => state.onBoarding.payload);
  const [prg, setPrg] = useState({});
  const { [pageKey]: reqDocList = [] } = payload || {};
  const { saveDataInRedux, exitHandler } = useOnboarding({
    savedData: reqDocList,
    url: serviceUrl.getUploadDocs,
    pageKey,
    pageId,
    curPageId: payload.curPageId,
  });
  const handleSubmit = (event) => {
    event.preventDefault();
    const formData = {
      curPageId: pageId,
      [pageKey]: reqDocList,
    };
    saveDataInRedux({
      formData,
      customPath: routePath.DOCUMENT_LOADER,
    });
  };

  const saveUploadedFile = (uploadFileObj) => {
    const cloneDoc = [...reqDocList];
    const obj = {
      ...cloneDoc[activeDocument],
      ...uploadFileObj,
    };
    cloneDoc[activeDocument] = obj;
    const formData = {
      [pageKey]: cloneDoc,
    };
    saveDataInRedux({
      formData,
      moveToNext: false,
    });
  };

  const uploadFile = (file, data, timer) => {
    const { uploadProgress, uploadStatus, ...rest } = data;
    ApiClient.post(serviceUrl.uploadSingleDoc, rest)
      .then(() => {
        clearInterval(timer);
        setPrg((preState) => ({ ...preState, [activeDocument]: 100 }));
        setTimeout(() => {
          saveUploadedFile({
            uploadStatus: true,
            documentContents: file.name,
            uploadProgress: 1,
          });
        }, 2000);
      })
      .catch(() => {
        saveUploadedFile({
          uploadStatus: false,
          documentContents: file.name,
          uploadProgress: 2,
        });
      });
  };

  const getSubmissionDoc = (file) => {
    const { type } = file;
    const ext = type.split('/');
    saveUploadedFile({ uploadProgress: 0 });
    setShowUploadModel(!showUploadModel);
    const timer = setInterval(() => {
      setPrg((preState) => {
        if (preState[activeDocument]) {
          const random = preState[activeDocument] + 10;
          return { ...preState, [activeDocument]: random > 100 ? 100 : random };
        }
        return { ...preState, [activeDocument]: 10 };
      });
    }, 1000);
    readFileDataAsBase64(file).then((response) => {
      const data = {
        ...reqDocList[activeDocument],
        docExtension: ext[1],
        documentContents: response,
      };
      uploadFile(file, data, timer);
    });
  };

  const handleUpload = (event, index) => {
    event.preventDefault();
    setActiveDocument(index);
    setShowUploadModel(!showUploadModel);
  };

  const handleClose = (e) => {
    e.preventDefault();
    setShowUploadModel(!showUploadModel);
  };

  const showUploadProgress = (status, index) => {
    if (status === 0) {
      return (
        <Box sx={{ width: '100%' }} mt={1}>
          <LinearProgressWithLabel value={prg[index] || 0} />
        </Box>
      );
    }
    return null;
  };

  const showStatus = (ele) => {
    if (ele.uploadProgress === 2) {
      return (
        <Avatar sx={{ bgcolor: 'error.main' }}>
          <CustomIcon
            component={AlertCircle}
            color="grey.100"
            inheritViewBox
            sx={{ fontSize: 20 }}
          />
        </Avatar>
      );
    }
    if (ele.uploadProgress === 1) {
      return (
        <Avatar sx={{ bgcolor: 'success.main' }}>
          <CustomIcon
            component={CheckmarkCircle}
            color="grey.100"
            inheritViewBox
            sx={{ fontSize: 20 }}
          />
        </Avatar>
      );
    }
    if (!ele.uploadStatus) {
      return (
        <Avatar sx={{ bgcolor: 'primary.main' }}>
          <CustomIcon
            component={FileText}
            color="grey.100"
            inheritViewBox
            sx={{ fontSize: 20 }}
          />
        </Avatar>
      );
    }
    if (ele.uploadStatus) {
      return (
        <Avatar sx={{ bgcolor: 'success.main' }}>
          <CustomIcon
            component={CheckmarkCircle}
            color="grey.100"
            inheritViewBox
            sx={{ fontSize: 20 }}
          />
        </Avatar>
      );
    }
    return null;
  };

  const showBackToTeamBtn =
    reqDocList && reqDocList?.some((ele) => !ele.uploadStatus);

  return (
    <>
      <Paper elevation={2}>
        <Box p={3}>
          <form onSubmit={handleSubmit} data-testid="addDocumentsForm">
            <Box
              style={{
                marginBottom: '20px',
                paddingBottom: '20px',
                borderBottom: '1px solid #EBEBEB',
              }}
            >
              <Grid container>
                <Grid item style={{ borderRight: '1px solid #DCDCDC' }}>
                  <IconButton aria-label="close" onClick={showDocs}>
                    <CustomIcon
                      component={cornerUpLeft}
                      color="primary"
                      sx={{
                        fontSize: 16,
                        verticalAlign: 'middle',
                        marginRight: '7px',
                      }}
                      inheritViewBox
                    />
                  </IconButton>
                </Grid>
                <Grid item style={{ paddingLeft: '10px' }}>
                  <Typography variant="h2" color="grey.900">
                    {strings.addDocumentsHeading}
                  </Typography>
                </Grid>
              </Grid>
              <Grid mt={2}>
                <Typography variant="p1" color="grey.800">
                  {!editteamflag
                    ? strings.changesBusinessLegalName
                    : strings.editchangesBusinessLegalName}
                </Typography>
              </Grid>
            </Box>
            <RightPanelLayout maxWidth="600px">
              {reqDocList.map((ele, index) => (
                <Grid container className={classes.uploadRow} key={index}>
                  <Grid item xs={1}>
                    {showStatus(ele)}
                  </Grid>
                  <Grid item xs={8} container alignItems="center">
                    <Box>
                      <Typography variant="h3">{ele.docName}</Typography>
                      {ele?.uploadProgress !== 2 ? (
                        <Typography variant="p3" color="action.disabled">
                          {ele?.documentContents}
                        </Typography>
                      ) : (
                        <Typography variant="p3" color="error.main">
                          {uploadFailed}
                        </Typography>
                      )}
                    </Box>
                    {showUploadProgress(ele?.uploadProgress, index)}
                  </Grid>
                  <Grid
                    item
                    xs={3}
                    container
                    alignItems="center"
                    justifyContent="flex-end"
                  >
                    {!ele?.uploadStatus ? (
                      <Link
                        component="button"
                        href="/#"
                        onClick={(e) => handleUpload(e, index)}
                        className={classes.link}
                      >
                        {upload}
                      </Link>
                    ) : (
                      <Link
                        component="button"
                        href="/#"
                        onClick={(e) => e.preventDefault()}
                        className={classes.link}
                      >
                        {replace}
                      </Link>
                    )}
                  </Grid>
                </Grid>
              ))}
            </RightPanelLayout>
            {editteamflag && !showBackToTeamBtn && (
              <Box>
                <Grid justifyContent="right" container>
                  <Grid item>
                    <Button
                      variant="contained"
                      color="primary"
                      data-testid="back-to-team-save"
                      onClick={onBacktoTeam}
                    >
                      {strings.backToTeam}
                    </Button>
                  </Grid>
                </Grid>
              </Box>
            )}
          </form>
          {showUploadModel && (
            <UploadFile
              handleUpload={handleUpload}
              getSubmissionDoc={getSubmissionDoc}
              docInfo={reqDocList[activeDocument]}
              handleClose={handleClose}
            />
          )}
        </Box>
      </Paper>
    </>
  );
};

export default AddDocuments;

AddDocuments.propTypes = {
  showDocs: PropTypes.func,
  editteamflag: PropTypes.bool,
  onBacktoTeam: PropTypes.func,
};
AddDocuments.defaultProps = {
  showDocs: defaultFnPropTypes,
  editteamflag: false,
  onBacktoTeam: defaultFnPropTypes,
};
