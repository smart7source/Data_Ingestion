import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Auth } from 'aws-amplify';

import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const submitForm = async () => {
  await act(async () => {
    fireEvent.submit(screen.getByTestId('form1'));
  });
};

const promiseResolve = () => {
  return Promise.resolve({
    message: 'Success',
  });
};

const promiseReject = () => {
  return Promise.reject({
    message: 'Error',
  });
};

describe('Test Change Password in settings page', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });

    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: routePath.SETTINGS,
        render,
      }),
    );
    userEvent.click(screen.getByTestId('settings-change-password-btn'));
  });

  it('should render change your password dialog', () => {
    expect(
      screen.getByTestId('settings-change-your-password-dialog'),
    ).toBeInTheDocument();
  });

  it('Should show error message, when fields are empty', async () => {
    await submitForm();
    expect(
      screen.getByText('Current password is required'),
    ).toBeInTheDocument();
    await submitForm();
    expect(screen.getByText('Password is required')).toBeInTheDocument();
    expect(
      screen.getByText('Confirm Password is required'),
    ).toBeInTheDocument();
  });

  it('Should show dialog on successful password change', async () => {
    jest.spyOn(Auth, 'changePassword').mockImplementation(() => {
      return promiseResolve();
    });

    userEvent.type(screen.getByTestId('password-input'), 'Pass1@123');
    userEvent.type(screen.getByTestId('password-input1'), 'Pass@123');
    userEvent.type(screen.getByTestId('password-input2'), 'Pass@123');

    await submitForm();
    await waitFor(() => {
      expect(screen.getByText("You've changed locks.")).toBeInTheDocument();
    });
  });

  it('Should close change your password dialog on clicking cancel button', async () => {
    userEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(
      screen.queryByTestId('settings-change-your-password-dialog'),
    ).not.toBeInTheDocument();
  });

  it('Should display error if user type same password password', async () => {
    jest.spyOn(Auth, 'changePassword').mockImplementation(() => {
      return promiseReject();
    });

    userEvent.type(screen.getByTestId('password-input'), 'Pass@1234');
    userEvent.type(screen.getByTestId('password-input1'), 'Pass@1234');
    userEvent.type(screen.getByTestId('password-input2'), 'Pass@1234');

    await submitForm();
    expect(
      screen.getByText(
        'The current password cannot match with a new password.',
      ),
    ).toBeInTheDocument();
  });
});
