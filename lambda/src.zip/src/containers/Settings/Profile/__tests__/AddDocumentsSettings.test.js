import {
    render,
    screen,
    fireEvent,
    act,
    waitFor,
  } from '@testing-library/react';
  import { Provider } from 'react-redux';
  import { createMemoryHistory } from 'history';
  import configureStore from 'store/configureStore';
  import routePath from 'routes/routePath';
  import AddDocuments from '../AddDocuments/AddDocumentsSettings';
  import { Router, MemoryRouter, Route } from 'react-router-dom';
  import strings from 'localization/translation';
  import { readFileDataAsBase64 } from 'utils';
  import {
    onBoardingStateMock,
    onBoardingStateEmptyMock,
    cognitoUserMock,
    cognitoCurrentSessionMock,
    mockUseHistory,
  } from 'testHelpers';
  import { rest } from 'msw';
  import serviceUrl from 'api/UrlHelper';
  import Auth from '@aws-amplify/auth';
  import App from 'containers/App/App';
  import server from 'apiMocks/server';
  
  let testFn = readFileDataAsBase64;
  const history = createMemoryHistory();
  
  // const store = configureStore(onBoardingStateMock);
  jest.useFakeTimers();
  
  const renderExtBtn = () => {
    const exitBtn = screen.getByRole('button', { name: strings.exit });
    expect(exitBtn).toBeDefined();
    fireEvent.click(exitBtn);
  };
  const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
  const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);
  
  const uploadFile = async () => {
    const mockFn = jest.fn();
    const docList = screen.getAllByRole('button', { name: /Upload/i });
    fireEvent.click(docList[0], { preventDefault: mockFn });
    const uploadDialog = await waitFor(() => screen.getByRole('dialog'));
    expect(uploadDialog).toBeInTheDocument();
    const browseFilesLink = await waitFor(() => screen.getByText(/Browse/i));
    await act(async () => {
      fireEvent.click(browseFilesLink);
    });
    var fileel = document.querySelector('input');
    return fileel;
  };
  const { addDocumentsHeading } = strings;
  
  describe('Render Add Documents component', () => {
    const mockStore = configureStore(onBoardingStateMock);
    let testHistory, testLocation;
    beforeEach(async () => {
      jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
        return promiseResolveCurrentUser;
      });
      jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
        return promiseResolveCurrentSession;
      });
      await act(async () =>
        render(
          <Provider store={mockStore}>
            <Router history={history}>
              <AddDocuments />
            </Router>
          </Provider>,
        ),
      );
    });
    it('should render heading Text ', async () => {
      await waitFor(async () => {
        const heading = screen.getByText('Add documents');
        expect(heading).toBeInTheDocument();
      });
    });
    it('should render doc list for selected Business Legal Structure ', () => {
      const docList = screen.getAllByRole('button', { name: /upload/i });
      expect(docList).toHaveLength(3);
    });
    it('should upload file on click/drop 1', async () => {
      testFn = jest.fn().mockResolvedValue('datainbytes');
      var fileel = await uploadFile();
  
      fireEvent.drop(fileel, {
        dataTransfer: {
          files: [
            new File(['(⌐□_□)'], 'chucknorris.jpg', {
              type: 'image/jpg',
              name: 'chucknorris',
            }),
          ],
          clearData: jest.fn(),
        },
      });
      expect(screen.getByText(/chucknorris.jpg/i)).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(screen.getByRole('button', { name: /Upload/i }));
      });
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
    });
  
    it('should upload file on click/drop 2', async () => {
      testFn = jest.fn().mockResolvedValue('datainbytes');
      var fileel = await uploadFile();
  
      fireEvent.drop(fileel, {
        dataTransfer: {
          files: [
            new File(['(⌐□_□)'], 'chucknorris1.jpg', {
              type: 'image/jpg',
              name: 'chucknorris1',
            }),
          ],
          clearData: jest.fn(),
        },
      });
      expect(screen.getByText(/chucknorris1.jpg/i)).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(screen.getByRole('button', { name: 'Upload' }));
      });
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
    });

    it('should upload file unsuccessfully on click/drop ', async () => {
      server.use(
        rest.post(serviceUrl.uploadSingleDoc, (req, res, ctx) => {
          res.networkError('Failed to connect');
        }),
      );
      testFn = jest.fn().mockResolvedValue('datainbytes');
      var fileel = await uploadFile();
  
      fireEvent.drop(fileel, {
        dataTransfer: {
          files: [
            new File(['(⌐□_□)'], 'chucknorris1.jpg', {
              type: 'image/jpg',
              name: 'chucknorris1',
            }),
          ],
          clearData: jest.fn(),
        },
      });
      expect(screen.getByText(/chucknorris1.jpg/i)).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(screen.getByRole('button', { name: 'Upload' }));
      });
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
    });
  
    it('should able to replace and delete uploaded files', async () => {
      testFn = jest.fn().mockResolvedValue('datainbytes');
      var fileel = await uploadFile();
  
      fireEvent.drop(fileel, {
        dataTransfer: {
          files: [
            new File(['(⌐□_□)'], 'chucknorris11.jpg', {
              type: 'image/jpg',
              name: 'chucknorris1',
            }),
          ],
          clearData: jest.fn(),
        },
      });
      expect(screen.getByText(/chucknorris11.jpg/i)).toBeInTheDocument();
      await act(async () => {
        fireEvent.click(screen.getByRole('button', { name: 'Upload' }));
      });
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
      await waitFor(async () => screen.queryByText('100% uploaded'));
      // await waitFor(async () => screen.queryByText('Upload successfully'));
      await act(async () => {
        jest.runOnlyPendingTimers();
      });
  
      await waitFor(async () => {
        const delItems = screen.queryAllByRole('link', { name: 'Replace' });
        // expect(delItems.length).toBeGreaterThan(0);
        // fireEvent.click(delItems[0], { preventDefault: jest.fn() });
      });
    });
  });
  
  describe('Render async Add Documents component', () => {
    const mockStore = configureStore(onBoardingStateEmptyMock);
    let testHistory, testLocation;
    beforeEach(async () => {
      jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
        return promiseResolveCurrentUser;
      });
      jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
        return promiseResolveCurrentSession;
      });
      await act(async () =>
        render(
          // <MemoryRouter initialEntries={[routePath.ADD_DOCUMENTS]}>
          //   <Provider store={mockStore}>
          //     <App />
          //   </Provider>
          //   <Route
          //     path="*"
          //     render={({ history, location }) => {
          //       testHistory = history;
          //       testLocation = location;
          //       return null;
          //     }}
          //   />
          // </MemoryRouter>,
          <Provider store={mockStore}>
            <Router history={history}>
              <AddDocuments />
            </Router>
          </Provider>,
        ),
      );
    });
    test('render component with inital data', async () => {
      await waitFor(async () => {
        const delItems = screen.queryAllByRole('link', { name: 'Replace' });
        expect(delItems.length).toEqual(0);
  
        const frm = screen.getByTestId('addDocumentsForm');
        await act(async () => {
          fireEvent.submit(frm);
        });
        expect(history.location.pathname).toBe(routePath.DOCUMENT_LOADER);
      });
    });
  });
  