import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
  waitForElementToBeRemoved,
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import refDataMock from '../../../../testHelpers/mocks/refDataMock';
import { Auth } from 'aws-amplify';

import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';

const transformRefData = {};
Object.keys(refDataMock).forEach((item) => {
  transformRefData[item] = refDataMock[item].body;
});
const initialState = {
  settings: {
    page: '',
    isEditing: false,
    personalInfoData: {},
    practiceInfoData: {},
  },
  global: {
    loading: false,
    loader: [],
    error: false,
    errorMessage: '',
    showExitModal: false,
    isOpen: false,
    message: '',
    refData: {
      ...transformRefData,
    },
    isAuthenticated: false,
    floatingChatbot: {
      enableFloatingChatbot: false,
      maximize: true,
    },
  },
};

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('Testing PracticeInfo Settings in profile tab', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });

    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: routePath.SETTINGS,
        render,
        wrapperProps: { initialState },
      }),
    );
    await waitFor(() =>
      expect(screen.queryByText('The Clinic')).toBeInTheDocument(),
    );
  });

  it('should render page with initial setup', () => {
    const tabs = screen.getAllByRole('tab');
    expect(tabs).toHaveLength(6);
  });

  it('should select profile by default', () => {
    const profileTab = screen.getByRole('tab', { selected: true });
    expect(profileTab).toBeInTheDocument();
  });

  it('should display practice info Field', async () => {
    expect(screen.getByText('Business legal name')).toBeInTheDocument();
    // expect(screen.getByText('Ownership')).toBeInTheDocument();
    expect(screen.getByText('Business phone')).toBeInTheDocument();
    expect(screen.getByText('Business email')).toBeInTheDocument();
    expect(screen.getByText('Business address')).toBeInTheDocument();
    expect(screen.getByText('EIN')).toBeInTheDocument();
    expect(
      screen.getByText('Doing business as (DBA) name'),
    ).toBeInTheDocument();
    expect(screen.getByText('Date established')).toBeInTheDocument();
    expect(screen.getByText('State of legal formation')).toBeInTheDocument();
    expect(screen.getByText('Business legal structure')).toBeInTheDocument();
  });

  it('should display practice info Data', async () => {
    await waitFor(() =>
      expect(screen.getByText('The Clinic')).toBeInTheDocument(),
    );
    // expect(screen.getByText('51')).toBeInTheDocument();
  });

  // it('should display edit practice window on clicking edit button', async () => {
  //   await act(async () => {
  //     fireEvent.click(screen.getByTestId('practice-edit-icon'));
  //   });
  //   expect(
  //     screen.getByTestId('settings-practice-info-form'),
  //   ).toBeInTheDocument();
  //   expect(
  //     screen.getByTestId('settings-business-legal-name'),
  //   ).toBeInTheDocument();
  //   const businessLegalName = screen.getByTestId(
  //     'settings-business-legal-name',
  //   );
  //   await act(async () => userEvent.clear(businessLegalName));
  //   await act(async () =>
  //     fireEvent.change(businessLegalName, {
  //       target: { value: 'sample' },
  //     }),
  //   );
  //   expect(businessLegalName).toHaveValue('sample');
  //   await act(async () => {
  //     userEvent.click(
  //       screen.getByTestId('edit-practice-info-settings-save-btn'),
  //     );
  //   });
  //   await waitFor(
  //     () =>
  //       expect(screen.queryByTestId('settings-practice-info-form')).not
  //         .toBeInTheDocument,
  //   );
  //   await waitFor(() =>
  //     expect(screen.queryByTestId(/practice-edit-icon/i)).toBeInTheDocument(),
  //   );
  //   expect(screen.getByText('sample')).toBeInTheDocument();
  // });

  it('should close edit practice window on clicking cancel button', async () => {
    await waitFor(() =>
      expect(screen.getByText('The Clinic')).toBeInTheDocument(),
    );
    await act(async () => {
      fireEvent.click(screen.getByTestId('practice-edit-icon'));
    });
    expect(
      screen.getByTestId('settings-practice-info-form'),
    ).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    });
    expect(screen.getByTestId('practice-edit-icon')).toBeInTheDocument();
  });

  it('navigate to different tab on selection', async () => {
    const tabs = screen.getAllByRole('tab');
    await act(async () => {
      fireEvent.click(tabs[1]);
    });
    expect(screen.getAllByText('Linked Platforms')).toHaveLength(1);
    await act(async () => {
      fireEvent.click(tabs[2]);
    });
    expect(screen.getAllByText('Linked bank accounts')).toHaveLength(1);
    await act(async () => {
      fireEvent.click(tabs[3]);
    });
    expect(screen.getAllByText('Notifications')).toHaveLength(1);
    await act(async () => {
      fireEvent.click(tabs[4]);
    });
    expect(screen.getAllByText('Team')).toHaveLength(1);
    expect(screen.getAllByText('Subscriptions')).toHaveLength(1);
  });
});
