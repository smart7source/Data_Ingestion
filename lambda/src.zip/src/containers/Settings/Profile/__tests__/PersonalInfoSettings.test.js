import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import refDataMock from '../../../../testHelpers/mocks/refDataMock';
import { Auth } from 'aws-amplify';
import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';
import PersonalInfoSettings from '../PersonalInfoSettings'
const transformRefData = {};
Object.keys(refDataMock).forEach((item) => {
  transformRefData[item] = refDataMock[item].body;
});
const initialState = {
  settings: {
    page: '',
    isEditing: false,
    personalInfoData: { firstName: 'Andrew',
      lastName:'Michael',
      phone:'+1-651-332-5675',
      email:'mandradi@lakewood.com',
      dob:'04/12/1982',
      ssn:'***-**-3820',
      address:'21 Crest Ave',
      city:'Lakewood',
      state:'CA',
      zip:'92122',
      country:'United States of America'},
    practiceInfoData: {},
  },
  global: {
    loading: false,
    loader: [],
    error: false,
    errorMessage: '',
    showExitModal: false,
    isOpen: false,
    message: '',
    refData: {
      ...transformRefData,
    },
    isAuthenticated: false,
    floatingChatbot: {
      enableFloatingChatbot: false,
      maximize: true,
    },
  },
};

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const enterOTP = () => {
  userEvent.type(screen.getByLabelText(/Digit 1/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 2/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 3/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 4/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 5/i), '1');
  userEvent.type(screen.getByLabelText(/Digit 6/i), '1');
};

const submitForm = async () => {
  await act(async () => {
    fireEvent.submit(screen.getByTestId('form'));
  });
};

describe('Testing ProfileInfo settings in profile tab', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });

    await act(async () =>
      renderWithProviderAndRouter(<PersonalInfoSettings />, {
        // route: routePath.SETTINGS,
        render,
        wrapperProps: { initialState },
      }),
    );
    await waitFor(() => expect(screen.getByText('Andrew')).toBeInTheDocument());
  });

  // it('should render page with initial setup', () => {
  //   const tabs = screen.getAllByRole('tab');
  //   expect(tabs).toHaveLength(6);
  // });

  // it('should select profile by default', () => {
  //   const profileTab = screen.getByRole('tab', { selected: true });
  //   expect(profileTab).toBeInTheDocument();
  // });

  it('should display personal info Fields', async () => {
    expect(screen.getByText('Personal Info')).toBeInTheDocument();
    expect(screen.getByText('First name')).toBeInTheDocument();
    expect(screen.getByText('Last name')).toBeInTheDocument();
    expect(screen.getByText('Email')).toBeInTheDocument();
    expect(screen.getByText('Phone')).toBeInTheDocument();
    expect(screen.getByText('Address')).toBeInTheDocument();
    expect(screen.getByText('Date of birth')).toBeInTheDocument();
    expect(screen.getByText('Social Security Number')).toBeInTheDocument();
    expect(screen.getByText('Country of Residence')).toBeInTheDocument();
    expect(screen.getByTestId(/dob/i)).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Verify' }));
    });
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('should display personal info Data', async () => {
    expect(screen.getByText('Personal Info')).toBeInTheDocument();
    expect(screen.getByText('Andrew')).toBeInTheDocument();
    expect(screen.getByText('Michael')).toBeInTheDocument();
    expect(screen.getByText('mandradi@lakewood.com')).toBeInTheDocument();
    expect(screen.getByText('21 Crest Ave')).toBeInTheDocument();
    // expect(screen.getByText('04/12/1982')).toBeInTheDocument();
    expect(screen.getByText('3820')).toBeInTheDocument();
    expect(screen.getByText('+1-651-332-5675')).toBeInTheDocument();
    expect(screen.getByText('Lakewood, CA, 92122')).toBeInTheDocument();
    // expect(await screen.findByText('United States of America')).toBeInTheDocument();
  });

  it('should show number verified dialog on submitting the otp', async () => {
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Verify' }));
    });
    enterOTP();
    await submitForm();
    expect(
      await screen.findByText("We've got your digits!"),
    ).toBeInTheDocument();
  });

  // it('should display edit personal window on clicking edit button', async () => {
  //   await act(async () => {
  //     fireEvent.click(screen.getByTestId(/personal-edit-icon/i));
  //   });
  //   expect(
  //     screen.getByTestId('settings-personal-info-form'),
  //   ).toBeInTheDocument();
  // });

  // it('navigate to different tab on selection', async () => {
  //   const tabs = screen.getAllByRole('tab');
  //   await act(async () => {
  //     fireEvent.click(tabs[1]);
  //   });
  //   expect(screen.getAllByText('Linked Platforms')).toHaveLength(1);
  //   await act(async () => {
  //     fireEvent.click(tabs[2]);
  //   });
  //   expect(screen.getAllByText('Linked bank accounts')).toHaveLength(1);
  //   await act(async () => {
  //     fireEvent.click(tabs[3]);
  //   });
  //   expect(screen.getAllByText('Notifications')).toHaveLength(1);
  //   await act(async () => {
  //     fireEvent.click(tabs[4]);
  //   });
  //   expect(screen.getAllByText('Team')).toHaveLength(1);
  //   expect(screen.getAllByText('Subscriptions')).toHaveLength(1);
  // });
});
