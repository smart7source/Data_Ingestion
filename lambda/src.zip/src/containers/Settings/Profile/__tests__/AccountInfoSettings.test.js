import { render, screen, fireEvent, act } from '@testing-library/react';
import { Auth } from 'aws-amplify';

import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

describe('Testing AccountInfo Settings in profile tab', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });

    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: routePath.SETTINGS,
        render,
      }),
    );
  });
  it('should select profile by default', () => {
    const profileTab = screen.getByRole('tab', { selected: true });
    expect(profileTab).toBeInTheDocument();
  });
  it('should display account info', async () => {
    expect(screen.getByText('Account Info')).toBeInTheDocument();
    expect(screen.getByText('Username')).toBeInTheDocument();
    expect(screen.queryByText('xxx')).toBeInTheDocument();
    expect(screen.getByText('Password')).toBeInTheDocument();
    expect(screen.getByText('*********')).toBeInTheDocument();
  });
  it('should display Change your password modal', async () => {
    expect(screen.getByText('Account Info')).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Change' }));
    });
    expect(screen.getByRole('dialog')).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
      expect(screen.queryByRole('dialog')).toBeNull;
    });
  });
});
