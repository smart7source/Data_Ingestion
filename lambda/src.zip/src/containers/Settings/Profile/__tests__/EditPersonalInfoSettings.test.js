import {
  render,
  screen,
  fireEvent,
  act,
  waitFor,
  waitForElementToBeRemoved,
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Auth } from 'aws-amplify';

import {
  cognitoUserMock,
  cognitoCurrentSessionMock,
  renderWithProviderAndRouter,
} from 'testHelpers';
import { routePath } from 'routes';
import App from 'containers/App/App';
import refDataMock from '../../../../testHelpers/mocks/refDataMock';

const promiseResolveCurrentUser = Promise.resolve(cognitoUserMock);
const promiseResolveCurrentSession = Promise.resolve(cognitoCurrentSessionMock);

const transformRefData = {};
Object.keys(refDataMock).forEach((item) => {
  transformRefData[item] = refDataMock[item].body;
});

const initialState = {
  settings: {
    page: '',
    isEditing: false,
    personalInfoData: {},
    practiceInfoData: {},
    payload: {
      username: 'mandradi',
      password: '********',
    },
  },
  global: {
    loading: true,
    loader: [],
    error: false,
    errorMessage: '',
    showExitModal: false,
    isOpen: false,
    message: '',
    refData: {
      ...transformRefData,
    },
    isAuthenticated: false,
    floatingChatbot: {
      enableFloatingChatbot: false,
      maximize: true,
    },
  },
};
const submitForm = async () => {
  await act(async () =>
    userEvent.click(screen.getByTestId('edit-personal-info-settings-save-btn')),
  );
};

describe('Test Edit personal information in settings page', () => {
  beforeEach(async () => {
    jest.spyOn(Auth, 'currentAuthenticatedUser').mockImplementation(() => {
      return promiseResolveCurrentUser;
    });
    jest.spyOn(Auth, 'currentSession').mockImplementation(() => {
      return promiseResolveCurrentSession;
    });

    await act(async () =>
      renderWithProviderAndRouter(<App />, {
        route: routePath.SETTINGS,
        render,
        wrapperProps: { initialState },
      }),
    );
    await waitFor(() =>
      expect(screen.queryByText('Andrew')).toBeInTheDocument(),
    );
    userEvent.click(screen.getByTestId('personal-edit-icon'));
  });

  it('should enable editing the personal info', () => {
    expect(
      screen.getByTestId('settings-personal-info-form'),
    ).toBeInTheDocument();
  });

  it('Should show error message, when fields are empty', async () => {
    // userEvent.clear(screen.getByTestId('settings-personal-info-first-name'));
    // userEvent.clear(screen.getByTestId('settings-personal-info-last-name'));
    userEvent.clear(screen.getByTestId('settings-personal-info-email'));
    userEvent.clear(screen.getByTestId('settings-personal-info-address-line1'));
    userEvent.clear(screen.getByTestId('settings-personal-info-address-city'));
    userEvent.clear(screen.getByTestId('settings-personal-info-phone'));
    userEvent.clear(screen.getByTestId('settings-personal-info-zipcode'));
    userEvent.clear(screen.getByTestId('settings-personal-info-state-code'));
    await submitForm();
    // expect(
    //   screen.getByText('Please provide your first name'),
    // ).toBeInTheDocument();
    // expect(
    //   screen.getByText('Please provide your last name'),
    // ).toBeInTheDocument();
    expect(
      screen.getAllByText("It looks like you've missed something").length,
    ).toBeGreaterThan(1);
  });

  it('Should update the info on save', async () => {
    await act(async () =>
      userEvent.clear(
        screen.getByTestId('settings-personal-info-address-line1'),
      ),
    );
    await act(async () =>
      userEvent.type(
        screen.getByTestId('settings-personal-info-address-line1'),
        '290 WASHINGTON ST',
        { delay: 1 },
      ),
    );
    await submitForm();
    await waitForElementToBeRemoved(() =>
      screen.getByTestId('settings-personal-info-form'),
    );
    expect(screen.getByText('290 WASHINGTON ST')).toBeInTheDocument();
  });

  it('Should cancel changes on clicking cancel button', async () => {
    userEvent.click(screen.getByTestId('settings-personal-info-cancel'));
      expect(await screen.findByTestId('personal-edit-icon')).toBeInTheDocument();
  });
});
