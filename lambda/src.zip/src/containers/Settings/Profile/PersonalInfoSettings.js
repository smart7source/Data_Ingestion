import { useState, useMemo } from 'react';
import { Typography, Grid, Box, IconButton, Link, Paper } from '@mui/material';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import moment from 'moment';

import CustomIcon from 'components/UIElements/CustomIcon';
import { ReactComponent as editIcon } from 'assets/svg/editIcon.svg';
import { defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';
import { useRefData } from 'hooks';
import classes from 'style/globalStyle.module.scss';
import { ComponentSpinner } from 'components';

import NumberVerified from '../components/NumberVerified';
import VerificationPhone from '../components/VerificationPhone';

const {
  personalInfo: personalInfoString,
  firstName: firstNameString,
  lastName: lastNameString,
  email: emailString,
  phone: phoneString,
  verifyYourPhone: verifyYourPhoneString,
  verify: verifyString,
  address: addressString,
  cityStateZip: cityStateZipString,
  dateOfBirth: dateOfBirthString,
  countryOfResidence: countryOfResidenceString,
  socialSecurityNumber: socialSecurityNumberString,
} = strings;
const PersonalInfoSettings = ({ editOpen }) => {
  const refData = useSelector((state) => state.global.refData);
  const { COUNTRY_CODE: countryList } = refData;
  const settings = useSelector((state) => state.settings);
  const {
    firstName,
    lastName,
    phone,
    email,
    dob,
    ssn,
    address,
    city,
    state,
    zip,
    country,
  } = settings?.personalInfoData;
  useRefData(['COUNTRY_CODE']);
  const { personalInfoLoading } = settings;
  const [alert] = useState(true);
  const [verifyOpen, setVerifyOpen] = useState(false);
  const [otp, setOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [numberVerified, setNumberVerified] = useState(false);

  const closeNumberModal = (event) => {
    setVerifyOpen(false);
  };

  const formattedPhoneNumber = useMemo(
    () =>
      (phone?.length === 10 ? `1${phone}` : phone)?.replace(
        /^([1])(\d{3})(\d{3})(\d{4}).*/,
        '+$1-$2-$3-$4',
      ),
    [phone],
  );
  const formattedSocialSecurityNumber = useMemo(
    () =>
      ssn
        ?.replace(/[^\d]/g, '')
        .replace(/^(\d{3})(\d{2})(\d{4}).*/, '***-**-$3'),
    [ssn],
  );
  const countryName = countryList?.find?.((cty) => cty.value === country)?.name;
  const cityStateZip = useMemo(
    () => [city, state, zip].filter((x) => x).join(', '),
    [city, state, zip],
  );
  const otpChange = (value) => {
    setOtp(value);
  };
  const closeModal = () => {
    setNumberVerified(false);
  };
  const otpSubmit = async (e) => {
    e.preventDefault();
    setVerifyOpen(false);
    setNumberVerified(true);
  };
  const resendOtp = () => {
    setOtp('');
  };
  return (
    <>
      <Paper sx={{ position: 'relative' }} elevation={2}>
        <ComponentSpinner open={personalInfoLoading} />
        <Box p={3} mt={3}>
          <Grid
            direction="row"
            container
            spacing={2}
            alignItems="center"
            sx={{ mb: 3 }}
            justifyContent={{ xs: 'space-between', sm: 'flex-start' }}
          >
            <Grid item>
              <Typography variant="h2" color="grey.900">
                {personalInfoString}
              </Typography>
            </Grid>
            <Grid item>
              <IconButton
                aria-label="edit"
                onClick={() => editOpen(true, 'personal')}
                data-testid="personal-edit-icon"
                size="small"
              >
                <CustomIcon
                  component={editIcon}
                  color="#000"
                  inheritViewBox
                  sx={{ fontSize: 20 }}
                />
              </IconButton>
            </Grid>
          </Grid>
          <Grid container rowSpacing={1} columnSpacing={2}>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {firstNameString}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="gray.650">
                    {firstName}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {lastNameString}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {lastName}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {emailString}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {email}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Grid container justifyContent="space-between">
                  <Grid item>
                    <Grid
                      container
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={2}
                    >
                      <Grid item>
                        <Typography variant="p1" color="grey.650">
                          {phoneString}
                        </Typography>
                      </Grid>
                      <Grid item>
                        {alert && (
                          <Typography variant="p2" color="error">
                            {verifyYourPhoneString}
                          </Typography>
                        )}
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item className={classes.formExtra}>
                    <Link
                      component="button"
                      className={classes.link}
                      data-testid="verify-phone-number"
                      onClick={async () => {
                        setVerifyOpen(true);
                        await new Promise(() => Promise.resolve());
                      }}
                    >
                      {verifyString}
                    </Link>
                  </Grid>
                </Grid>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {formattedPhoneNumber}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {addressString}
                </Typography>
                <Box className="formSettings">
                  <Typography
                    variant="p1SemiBold"
                    color="grey.650"
                    data-testid="address"
                  >
                    {address}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {cityStateZipString}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {cityStateZip}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {dateOfBirthString}
                </Typography>
                <Box className="formSettings">
                  <Typography
                    variant="p1SemiBold"
                    color="grey.650"
                    data-testid="dob"
                  >
                    {dob ? moment(dob, ['YYYY-MM-DD']).calendar() : ''}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {countryOfResidenceString}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {countryName}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box mb={2}>
                <Typography variant="p1" color="grey.650">
                  {socialSecurityNumberString}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {formattedSocialSecurityNumber}
                  </Typography>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Box>
        {verifyOpen && (
          <VerificationPhone
            otpChange={otpChange}
            otp={otp}
            inlineError={otpError}
            otpSubmit={otpSubmit}
            resendOtp={resendOtp}
            verifyOpen={verifyOpen}
            setVerifyOpen={setVerifyOpen}
            onClose={() => setOtpError('')}
            close={closeNumberModal}
          />
        )}
        {numberVerified && <NumberVerified closeModal={closeModal} />}
      </Paper>
    </>
  );
};
export default PersonalInfoSettings;
PersonalInfoSettings.propTypes = {
  editOpen: PropTypes.func,
};
PersonalInfoSettings.defaultProps = {
  editOpen: defaultFnPropTypes,
};
