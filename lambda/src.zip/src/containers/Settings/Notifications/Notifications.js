import ContactMethod from './ContactMethod';
import NotificationSettings from './NotificationSettings';

const Notifications = () => (
  <>
    <ContactMethod />
    <NotificationSettings />
  </>
);

export default Notifications;
