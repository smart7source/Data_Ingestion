import { useState, useEffect } from 'react';
import { Typography, Grid, Box, Link, Paper, IconButton } from '@mui/material';
import { useSelector } from 'react-redux';

import { ReactComponent as Edit } from 'assets/svg/edit.svg';
import { Notification } from 'components';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

import VerificationPhone from '../components/VerificationPhone';

const { contactMethod, email, mobileNumber, verifyYourPhone, verifyP1 } =
  strings;
const ContactMethod = () => {
  const settings = useSelector((state) => state.settings);
  const { payload } = settings;
  const [errorMsgs, setErrorMsgs] = useState([]);
  const [alert] = useState(true);
  const [verifyOpen, setVerifyOpen] = useState(false);
  const [otp, setOtp] = useState('');

  const otpChange = (value) => {
    setOtp(value);
  };

  const otpSubmit = async (e) => {
    e.preventDefault();
    setVerifyOpen(false);
    setOtp('');
  };

  const resendOtp = () => {
    setOtp('');
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setErrorMsgs([
        {
          message: (
            <Typography variant="p2" color="grey.800">
              'Please verify your phone number before we can send text message
              notifications'
            </Typography>
          ),
        },
      ]);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <Box mb={3}>
        <Paper elevation={2}>
          <Notification errors={errorMsgs} />
        </Paper>
      </Box>
      <Paper elevation={2}>
        <Box mb={2} p={3}>
          <Grid direction="row" container spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="h2" color="grey.900">
                {contactMethod}
              </Typography>
            </Grid>
            <Grid item>
              <IconButton aria-label="edit" data-testid="edit-icon">
                <Edit
                  fill="grey.800"
                  style={{
                    fontSize: 22,
                  }}
                />
              </IconButton>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={12} md={12} lg={12}>
            <Grid item xs={12}>
              <Box my={2}>
                <Typography variant="p1" color="grey.650">
                  {email}
                </Typography>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" data-testid="user-email">
                    {payload?.electronicMailAddress}
                  </Typography>
                </Box>
              </Box>
              <Box mb={2}>
                <Grid container alignItems="center">
                  <Grid item xs={3}>
                    <Typography variant="p1" color="grey.650">
                      {mobileNumber}
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    {alert && (
                      <Typography color="error" variant="p2">
                        {verifyYourPhone}
                      </Typography>
                    )}
                  </Grid>
                  <Grid item xs={2}>
                    <Grid container justifyContent="flex-end">
                      <Grid item>
                        <Link
                          data-testid="verify-button"
                          component="button"
                          className={classes.link}
                          color="grey.800"
                          underline="always"
                          onClick={() => setVerifyOpen(true)}
                        >
                          {verifyP1}
                        </Link>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Box className="formSettings">
                  <Typography variant="p1SemiBold" color="grey.650">
                    {payload?.phoneNumber}
                  </Typography>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Paper>
      {verifyOpen && (
        <VerificationPhone
          otpChange={otpChange}
          otp={otp}
          otpSubmit={otpSubmit}
          resendOtp={resendOtp}
          verifyOpen={verifyOpen}
          setVerifyOpen={setVerifyOpen}
        />
      )}
    </>
  );
};

export default ContactMethod;
