import { Typography, Grid, Box, Paper, Button } from '@mui/material';
import { useForm } from 'react-hook-form';

import { CustomCheckbox, CustomInput } from 'components';
import strings from 'localization/translation';
import classes from 'style/globalStyle.module.scss';

import NotificationHeading from '../components/NotificationHeading';

const { notificationSettings, sendMeNotification, cancel, save } = strings;
const NotificationSettings = () => {
  const { control, handleSubmit } = useForm({
    mode: 'all',
  });

  const fields = [
    {
      name: 'Current balance under$',
    },
    {
      name: 'Withdrawal over$',
    },
    {
      name: 'Deposit over$',
    },
    {
      name: 'Monthly statement',
    },
    {
      name: 'Dynamic overdraft',
    },
    {
      name: 'Help centre conversation',
    },
  ];

  // eslint-disable-next-line
  const submitHandler = (data) => {};

  return (
    <>
      <Paper elevation={2}>
        <Box p={3}>
          <Grid direction="row" container spacing={3}>
            <Box my={2} ml={3}>
              <Grid item>
                <Typography color="grey.900" variant="h2">
                  {notificationSettings}
                </Typography>
                <Typography variant="p1" color="grey.900">
                  {sendMeNotification}
                </Typography>
              </Grid>
            </Box>
          </Grid>
          <NotificationHeading />
          <form onSubmit={handleSubmit(submitHandler)}>
            {fields.slice(0, 3).map((el, index) => (
              <Grid direction="row" container key={index} spacing={1}>
                <Grid item xs={5} container alignItems="center">
                  <Grid container>
                    <Grid item xs={8} container alignItems="center">
                      <Typography variant="p1" color="grey.900">
                        {el.name}
                      </Typography>
                    </Grid>
                    <Grid item xs={4} container alignItems="center">
                      <CustomInput
                        name={`amount.${el.name}`}
                        id={`amount.${el.name}`}
                        inputProps={{ maxLength: 5 }}
                        control={control}
                        fullWidth={false}
                        margin="normal"
                      />
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={2} container alignItems="center">
                  <CustomCheckbox
                    name={`email.${el.name}`}
                    id={`email.${el.name}`}
                    control={control}
                    color="primary"
                  />
                </Grid>
                <Grid item xs={2} container alignItems="center">
                  <Grid container justifyContent="center">
                    <CustomCheckbox
                      name={`text.${el.name}`}
                      id={`text.${el.name}`}
                      control={control}
                      color="primary"
                    />
                  </Grid>
                </Grid>
                <Grid item xs={3} container alignItems="center">
                  <Grid container justifyContent="center">
                    <CustomCheckbox
                      name={`inbox.${el.name}`}
                      id={`inbox.${el.name}`}
                      control={control}
                      color="primary"
                    />
                  </Grid>
                </Grid>
              </Grid>
            ))}
            {fields.slice(3, 6).map((el, index) => (
              <Grid direction="row" container key={index} spacing={1}>
                <Grid item xs={5} container alignItems="center">
                  <Grid container justifyContent="flex-end">
                    <Typography variant="p1" color="grey.900">
                      {el.name}
                    </Typography>
                  </Grid>
                </Grid>
                <Grid item xs={2} container alignItems="center">
                  <CustomCheckbox
                    name={`email.${el.name}`}
                    id={`email.${el.name}`}
                    control={control}
                    color="primary"
                  />
                </Grid>
                <Grid item xs={2} container alignItems="center">
                  <Grid container justifyContent="center">
                    <CustomCheckbox
                      name={`text.${el.name}`}
                      id={`text.${el.name}`}
                      control={control}
                      color="primary"
                    />
                  </Grid>
                </Grid>
                <Grid item xs={3} container alignItems="center">
                  <Grid container justifyContent="center">
                    <CustomCheckbox
                      name={`inbox.${el.name}`}
                      id={`inbox.${el.name}`}
                      control={control}
                      color="primary"
                    />
                  </Grid>
                </Grid>
              </Grid>
            ))}
            <Grid justifyContent="space-between" container>
              <Grid item>
                <Button
                  variant="contained"
                  size="OnbCtnBtn"
                  data-testid="settings-personal-info-cancel"
                >
                  {cancel}
                </Button>
              </Grid>
              <Grid item>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.saveButton}
                >
                  {save}
                </Button>
              </Grid>
            </Grid>
          </form>
        </Box>
      </Paper>
    </>
  );
};

export default NotificationSettings;
