import * as Yup from 'yup';

import strings from 'localization/translation';
import {
  convertToAmt,
  setMaxDate,
  removeDateTime,
  disableWeekends,
} from 'utils';

const date = new Date();
date.setDate(date.getDate() - 1);

const {
  boostMinDate: BOOST_MIN_DATE,
  boostMaxDate: BOOST_MAX_DATE,
  dateTypeError: DATE_TYPE_ERROR,
  maxCharacters: MAX_CHARCTERS,
} = strings;

const validateField = (selectedOption) => {
  if (selectedOption !== 'recurring') {
    return true;
  }
  return false;
};
const validateDate = (selectedDate) => {
  if (selectedDate && selectedDate !== '') {
    return true;
  }
  return false;
};

const addDollar = (val) =>
  convertToAmt({
    value: val,
    prefix: '$ ',
    addSeparator: true,
  });
const maxValidation = (value, maxVal) => +convertToAmt({ value }) <= maxVal;
const minValidation = (value, minVal) => +convertToAmt({ value }) >= minVal;
const matchTotal = (value, minVal) => +convertToAmt({ value }) === minVal;

export const addDateTime = (initialDate) => {
  initialDate.setHours(23, 59, 59, 99);
  const timeAddedDate = new Date(initialDate);
  return timeAddedDate;
};

export const payitSchema = (minVal, maxVal) =>
  Yup.object().shape({
    payItAmount: Yup.string(),
    amount: Yup.string().when('payItAmount', {
      is: 'enterAmount',
      then: Yup.string()
        .required('Amount cannot be empty')
        .test(
          'max amount',
          `Amount cannot be greater than ${addDollar(maxVal)}`,
          (val) => maxValidation(val, maxVal),
        )
        .test(
          'min amount',
          `Amount cannot be lesser than ${addDollar(minVal)}`,
          (val) => minValidation(val, minVal),
        ),
    }),
    payItRecurringAmount: Yup.string(),
    recurringAmount: Yup.string().when('payItRecurringAmount', {
      is: 'setAmount',
      then: Yup.string()
        .required('Amount cannot be empty')
        .test(
          'max amount',
          `Amount cannot be greater than ${addDollar(maxVal)}`,
          (val) => maxValidation(val, maxVal),
        )
        .test(
          'min amount',
          `Amount cannot be lesser than ${addDollar(minVal)}`,
          (val) => minValidation(val, minVal),
        ),
    }),
    numberoftransaction: Yup.string().when('payItAmount', {
      is: 'recurring',
      then: Yup.string().when('recurringType', {
        is: 'numberoftransaction',
        then: Yup.string()
          .nullable()
          .required('Number of Transactions is required')
          .test(
            'minimumTransaction',
            'Number of transactions should be at least 2',
            (val) => Number(val?.replace(/,/g, '')) >= 2,
          )
          .test(
            'maximumTransaction',
            'Number of transactions should be at most 99',
            (val) => Number(val?.replace(/,/g, '')) <= 99,
          ),
        otherwise: Yup.string(),
      }),
    }),
    endDate: Yup.date().when('payItAmount', {
      is: 'recurring',
      then: Yup.date().when('recurringType', {
        is: 'end-date',
        then: Yup.date()
          .nullable()
          .transform((curr, orig) => (orig === '' ? null : curr))
          .typeError(DATE_TYPE_ERROR)
          .min(removeDateTime(new Date()), BOOST_MIN_DATE)
          .max(setMaxDate(new Date(), 364), BOOST_MAX_DATE)
          .required('Date is required')
          .test(
            'disable weekends',
            'Transactions are not allowed in weekends',
            (endDate) => validateDate(endDate) && !disableWeekends(endDate),
          ),
        otherwise: Yup.date()
          .nullable()
          .transform((curr, orig) => (orig === '' ? null : curr)),
      }),
      otherwise: Yup.date()
        .nullable()
        .transform((curr, orig) => (orig === '' ? null : curr)),
    }),
    selectedLinkedAccount: Yup.string().when('payItAmount', {
      is: 'recurring',
      then: Yup.string().required('Please select an account'),
    }),
    paymentDate: Yup.date().when('payItAmount', {
      is: (payItAmount) => validateField(payItAmount),
      then: Yup.date()
        .nullable()
        .transform((curr, orig) => (orig === '' ? null : curr))
        .typeError(DATE_TYPE_ERROR)
        .min(removeDateTime(new Date()), BOOST_MIN_DATE)
        .max(setMaxDate(new Date(), 364), BOOST_MAX_DATE)
        .required('Date is required')
        .test(
          'disable weekends',
          'Transactions are not allowed in weekends',
          (paymentDate) =>
            validateDate(paymentDate) && !disableWeekends(paymentDate),
        ),
      bankAccount: Yup.string(),
    }),
    payItTotal: Yup.string()
      .when('payItAmount', {
        is: 'enterAmount',
        then: Yup.string().oneOf(
          [Yup.ref('amount'), null],
          'amount should match',
        ),
      })
      .when('payItAmount', {
        is: 'minimumPayment',
        then: Yup.string().test(
          'minPayment',
          `Amount cannot be lesser than ${addDollar(minVal)}`,
          (val) => matchTotal(val, minVal),
        ),
      })
      .when('payItAmount', {
        is: 'payFull',
        then: Yup.string().test(
          'payFull',
          `Amount cannot be greater than ${addDollar(maxVal)}`,
          (val) => matchTotal(val, maxVal),
        ),
      }),
  });

export const boostNowSchema = (val) =>
  Yup.object().shape({
    boostAmountRadio: Yup.string(),
    boostInputAmount: Yup.string()
      .when('boostAmountRadio', {
        is: 'boostEnteredAmount',
        then: Yup.string()
          .required('Amount cannot be empty')
          .test(
            'max amount',
            `Amount cannot be greater than ${convertToAmt({
              value: val,
              prefix: '$ ',
              addSeparator: true,
            })}`,
            (value) => +convertToAmt({ value }) <= val,
          ),
      })
      .when('boostAmountRadio', {
        is: 'boostEnteredAmount',
        then: Yup.string().test(
          'minPayment',
          `Amount cannot be lesser than ${addDollar(1)}`,
          (value) => +convertToAmt({ value }) >= 1,
        ),
      }),
    transferDate: Yup.date()
      .nullable()
      .transform((curr, orig) => (orig === '' ? null : curr))
      .typeError(DATE_TYPE_ERROR)
      .min(removeDateTime(new Date()), BOOST_MIN_DATE)
      .max(setMaxDate(new Date(), 364), BOOST_MAX_DATE)
      .required('Date is required')
      .test(
        'disable weekends',
        'Transactions are not allowed in weekends',
        (transferDate) =>
          validateDate(transferDate) && !disableWeekends(transferDate),
      ),
    boostNote: Yup.string().max(150, MAX_CHARCTERS),
    bankAccount: Yup.string(),
    selectedLinkedAccount: Yup.string().required('Please select an account'),
  });

export const transactionFilterSchema = Yup.object().shape({
  searchText: Yup.string(),
  searchType: Yup.string(),
  fromDate: Yup.date()
    .nullable()
    .transform((curr, orig) => (orig === '' ? null : curr))
    .when('toDate', {
      is: (toDate) => toDate && addDateTime(toDate),
      then: Yup.date()
        .max(Yup.ref('toDate'), 'From date cannot be greater than to date')
        .nullable()
        .transform((curr, orig) => (orig === '' ? null : curr))
        .required('From date is required on giving to date'),
      otherwise: Yup.date()
        .nullable()
        .transform((curr, orig) => (orig === '' ? null : curr))
        .typeError('Please enter a valid date')
        .max(
          addDateTime(new Date()),
          "From date cannot be greater than today's date",
        ),
    })
    .typeError('Please enter a valid date')
    .max(
      addDateTime(new Date()),
      "From date cannot be greater than today's date",
    ),

  toDate: Yup.date()
    .nullable()
    .transform((curr, orig) => (orig === '' ? null : curr))
    .typeError('Please enter a valid date')
    .max(
      addDateTime(new Date()),
      "To date cannot be greater than today's date",
    ),
});
