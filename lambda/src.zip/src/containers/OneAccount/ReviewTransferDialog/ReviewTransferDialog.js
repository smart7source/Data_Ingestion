import {
  Box,
  Typography,
  Dialog,
  Button,
  IconButton,
  DialogTitle,
  DialogActions,
  DialogContent,
  useMediaQuery,
} from '@mui/material';
import PropTypes from 'prop-types';

import { ReactComponent as DownArrow } from 'assets/svg/arrow-down-2.svg';
import { ReactComponent as RightArrow } from 'assets/svg/arrow-right-1.svg';
import { CustomIcon } from 'components';
import { defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';
import { ReactComponent as Close } from 'assets/svg/close.svg';

import Classes from '../OneAccount.module.scss';
import ReviewTransferInfo from '../ReviewTransferInfo';

const {
  reviewTransferTitle: REVIEW_TRANSFER_TITLE,
  reviewTransfersubTitle: REVIEW_TRANSFER_SUB_TITLE,
  cancel: CANCEL,
  continue: CONTINUE,
  transferFrom: TRANSFER_FROM,
  transferTo: TRANSFER_TO,
} = strings;

const ReviewTransferDialog = (props) => {
  const aboveMd = useMediaQuery((theme) => theme.breakpoints.up('md'));

  const {
    open,
    handleClose,
    handleSubmit,
    transferFrom,
    transferToName,
    transferToNo,
    amount,
    date,
    frequency,
    duration,
    note,
  } = props;
  return (
    <Dialog open={open} className={Classes.reviewTransferDialog}>
      <IconButton
        aria-label="close"
        size="small"
        className={Classes.closeIcon}
        onClick={handleClose}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={Classes.closeIconSize}
        />
      </IconButton>
      <DialogTitle className={Classes.noPadding} mb={1.25}>
        <Box display="flex" flexDirection="column" gap={0.5}>
          <Typography
            variant="h1"
            component="span"
            className={Classes.noPadding}
          >
            {REVIEW_TRANSFER_TITLE}
          </Typography>
          <Typography variant="p1" component="span">
            {REVIEW_TRANSFER_SUB_TITLE}
          </Typography>
        </Box>
      </DialogTitle>
      <DialogContent classes={{ root: Classes.noPadding }}>
        <Box className={Classes.imageWrapper}>
          <picture>
            <source
              media="(max-width: 599px)"
              srcSet="/images/review-transfer-small.png"
              width="225"
              height="88"
            />
            <source
              media="(min-width: 600px)"
              srcSet="/images/review-transfer.png"
              width="600"
              height="93"
            />
            <img
              width="600"
              height="93"
              src="/images/review-transfer.png"
              alt="Review transfer"
              style={{ width: '100%', height: 'auto' }}
            />
          </picture>
        </Box>
        <Box mb={1.25} className={Classes.transferContent}>
          <Box className={Classes.transferContentInner}>
            <Typography variant="h3">{TRANSFER_FROM}</Typography>
            {transferFrom.map((x, index) => (
              <Box className={Classes.reviewTransferBankHolder} key={index}>
                <Typography variant="p1">{x?.bankName}</Typography>
                <Typography variant="p2" component="p">
                  {`${x?.accNo}`}
                </Typography>
              </Box>
            ))}
          </Box>
          <Box className={Classes.iconWrapper}>
            <CustomIcon
              component={aboveMd ? RightArrow : DownArrow}
              color="grey.800"
              className={Classes.iconSize}
            />
          </Box>
          <Box className={Classes.transferContentInner}>
            <Typography variant="h3">{TRANSFER_TO}</Typography>
            <Box className={Classes.reviewTransferBankHolder}>
              <Typography variant="p1">{transferToName}</Typography>
              <Typography variant="p2" component="p">
                {transferToNo}
              </Typography>
            </Box>
          </Box>
        </Box>
        <ReviewTransferInfo
          amount={amount}
          date={date}
          frequency={frequency}
          duration={duration}
          note={note}
        />
      </DialogContent>

      <DialogActions className={Classes.buttonWrapper}>
        <Button
          variant="contained"
          data-testid="one-account-review-cancel"
          onClick={handleClose}
        >
          {CANCEL}
        </Button>

        <Button
          variant="contained"
          color="primary"
          data-testid="oneaccount-review-submit"
          onClick={handleSubmit}
        >
          {CONTINUE}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ReviewTransferDialog;
ReviewTransferDialog.propTypes = {
  open: PropTypes.bool,
  handleClose: PropTypes.func,
  handleSubmit: PropTypes.func,
  transferFrom: PropTypes.instanceOf(Object),
  transferToName: PropTypes.string,
  transferToNo: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  date: PropTypes.oneOfType([PropTypes.instanceOf(Date), PropTypes.string]),
  frequency: PropTypes.string,
  duration: PropTypes.string,
  note: PropTypes.string,
};
ReviewTransferDialog.defaultProps = {
  open: false,
  handleClose: defaultFnPropTypes,
  handleSubmit: defaultFnPropTypes,
  transferFrom: [],
  transferToName: '',
  transferToNo: '',
  amount: '',
  date: '',
  frequency: '',
  duration: '',
  note: '',
};
