import ReviewTransferDialog from './ReviewTransferDialog';

export default ReviewTransferDialog;
