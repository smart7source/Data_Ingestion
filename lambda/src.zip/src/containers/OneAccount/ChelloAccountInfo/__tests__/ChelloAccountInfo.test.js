import { render, screen, act } from '@testing-library/react/pure';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';
import strings from 'localization/translation';

const { lineOfCredit: LINE_OF_CREDIT } = strings;

describe('Testing ChelloAccount Info component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });
  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should display chello account basic info', () => {
    expect(screen.getByText(LINE_OF_CREDIT)).toBeInTheDocument();
  });
  it('should display chello account balance info', async () => {
    expect(await screen.findByText('$ 1,300.00')).toBeInTheDocument();
  });
  it('should display chello account other info', () => {
    expect(
      screen.getByText('Past payment due immediately:'),
    ).toBeInTheDocument();
  });
});
