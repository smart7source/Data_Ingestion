import { Grid, Divider } from '@mui/material';
import { useSelector } from 'react-redux';

import {
  getDynamicLineOfCreditsAccountDetails,
  maskAccountNumberAndPosnNumber,
  getSpendBalancePercentage,
} from 'utils';

import Classes from '../OneAccount.module.scss';
import ChelloAccountBasicInfo from '../ChelloAccountBasicInfo';
import ChelloAccountBalanceInfo from '../ChelloAccountBalanceInfo';
import ChelloAccountOtherInfo from '../ChelloAccountOtherInfo';

const ChelloAccountInfo = () => {
  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount.chelloAccountDetails,
  );

  const {
    avlbToSpdtBalAmt: availableToSpendBalanceAmount = 0,
    intRate: interestRate = 0,
    otsgFeesAmt: outstandingBalance = 0,
    pastPymtDueImitAmt: pastPaymentDue = 0,
    pymtDueAmt: paymentDue = 0,
    utlzBalAmt: utilizedAmount = 0,
    apprvBalAmt: totalLimit = 0,
    accNbr: accountNumber = '',
    posnNbr: posnNumber = '',
  } = getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const availableToSpendBalancePercentage = getSpendBalancePercentage(
    availableToSpendBalanceAmount,
    totalLimit,
  );

  const accNbrAndPosnNbr = maskAccountNumberAndPosnNumber(
    accountNumber,
    posnNumber,
  );

  return (
    <Grid container direction="column" className={Classes.chelloAccountInfo}>
      <ChelloAccountBasicInfo accountNumber={accNbrAndPosnNbr} />
      <ChelloAccountBalanceInfo
        utilizedAmount={utilizedAmount}
        availableToSpendBalanceAmount={availableToSpendBalanceAmount}
        availableToSpendBalancePercentage={availableToSpendBalancePercentage}
        totalLimit={totalLimit}
      />
      <ChelloAccountOtherInfo
        paymentDue={paymentDue}
        pastPaymentDue={pastPaymentDue}
        outstandingBalance={outstandingBalance}
        interestRate={interestRate}
      />
    </Grid>
  );
};

export default ChelloAccountInfo;
