import ChelloAccountInfo from './ChelloAccountInfo';

export default ChelloAccountInfo;
