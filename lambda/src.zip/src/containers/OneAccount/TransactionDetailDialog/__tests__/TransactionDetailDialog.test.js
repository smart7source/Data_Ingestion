import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Amplify } from 'aws-amplify';

import awsConfig from 'aws-exports';
import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

Amplify.configure(awsConfig);

let dialog;
describe('Transaction details dialog', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });
  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });
  it('should render chello tab', async () => {
    userEvent.click(screen.getByTestId('one-account-chello-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });

  it('should render details dialog', async () => {
    const kebabMenu = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-btn',
    );

    userEvent.click(kebabMenu);
    const menuItem = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-item-0',
    );

    userEvent.click(menuItem);
    dialog = await screen.findByText('Have a closer look');
    expect(dialog).toBeInTheDocument();
  });

  it('should open dispute dialog when dispute is clicked', async () => {
    userEvent.click(screen.getByTestId('transaction-detail-dispute-link'));
    const disputeDialog = await screen.findByText('Dispute a transaction');
    expect(disputeDialog).toBeInTheDocument();
  });
});

describe('Test transaction detail close', () => {
  it('should close dialog on close', async () => {
    const kebabMenu = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-btn',
    );

    userEvent.click(kebabMenu);
    const menuItem = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-item-0',
    );

    userEvent.click(menuItem);
    dialog = await screen.findByText('Have a closer look');
    userEvent.click(screen.getByTestId('transaction-detail-close-btn'));
    await waitFor(() => {
      expect(screen.queryByText('Have a closer look')).not.toBeInTheDocument();
    });
  });
});
