import {
  Box,
  Typography,
  Dialog,
  Link,
  Button,
  IconButton,
  DialogTitle,
  DialogActions,
  DialogContent,
} from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';

import {
  showDetailsDialog,
  showDisputeDialog,
} from 'store/actions/OneAccountActions';
import strings from 'localization/translation';
import { useFetchSelectedTransaction, useRefData } from 'hooks';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import {
  getDynamicLineOfCreditsAccountDetails,
  getAccountName,
  maskAccountNumber,
  decidePrefix,
} from 'utils';
import { CustomIcon } from 'components';
import global from 'style/globalStyle.module.scss';

import Classes from '../OneAccount.module.scss';
import TransactionInfo from '../TransactionInfo';

const {
  transactionDetailTitle: TITLE,
  somethingWrong: ANYTHING_WRONG,
  dispute: DISPUTE,
  close: CLOSE,
} = strings;

const TransactionDetailDialog = (props) => {
  const { disputeButton, accountType = 'chello' } = props;
  const {
    accountNumber = '',
    amount = '',
    date = '',
    description = '',
    type,
    category = '',
  } = useFetchSelectedTransaction(accountType);

  const dispatch = useDispatch();
  const showDetails = useSelector(
    (state) => state.OneAccount.showDetailsDialog,
  );

  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount.chelloAccountDetails,
  );

  const { accNbr, accNickName, accNm } =
    getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const account = getAccountName({
    bankNm: '',
    accNickName,
    accNm,
  });

  const maskLastFourDigitAccNbr = maskAccountNumber(accNbr);
  const chelloNameAndNumber = `${account} ${maskLastFourDigitAccNbr}`;

  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  const selectedLinkedAccount = [...linkedAccounts].find(
    (x) => x.accNbr === accountNumber,
  );

  const linkedAccount = getAccountName(selectedLinkedAccount || {});

  const linkedMaskLastFourDigitAccNbr = maskAccountNumber(accountNumber);
  const linkedNameAndNumber = `${linkedAccount} ${linkedMaskLastFourDigitAccNbr}`;

  const refData = useSelector((state) => state.global.refData);
  const {
    CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES: chelloTransactionPaymentType,
    LINKED_ACCOUNT_TRANSACTION_PAYMENT_TYPES: linkedAccTranasactionPaymentType,
  } = refData;

  useRefData([
    'CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES',
    'LINKED_ACCOUNT_TRANSACTION_PAYMENT_TYPES',
  ]);

  let accountNo = linkedNameAndNumber;
  let typeOrCategory = category;
  let paymentType = linkedAccTranasactionPaymentType;

  if (accountType === 'chello') {
    accountNo = chelloNameAndNumber;
    paymentType = chelloTransactionPaymentType;
    typeOrCategory = type;
  }

  const prefix = decidePrefix(typeOrCategory, paymentType);

  const showDispute = (e) => {
    e.preventDefault();
    dispatch(showDetailsDialog(false));
    dispatch(showDisputeDialog(true));
  };

  const handleClose = () => {
    dispatch(showDetailsDialog(false));
  };

  return (
    <Dialog
      open={showDetails}
      className={Classes.transactionDetail}
      aria-labelledby="transactionDetailModal"
    >
      <IconButton
        aria-label="close"
        size="small"
        className={Classes.closeIcon}
        onClick={handleClose}
        data-testid="transaction-detail-close-btn"
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={Classes.closeIconSize}
        />
      </IconButton>
      <DialogTitle className={Classes.noPadding}>
        <Typography component="span" variant="h1" id="transactionDetailModal">
          {TITLE}
        </Typography>
      </DialogTitle>
      <DialogContent className={Classes.dialogContentWrapper}>
        <Box className={Classes.imageContainer}>
          <img
            width="600"
            height="178"
            src={`${process.env.PUBLIC_URL}/images/chello-lamp.png`}
            alt="Chello Lamp"
            style={{ width: '100%', height: 'auto' }}
          />
        </Box>
        <TransactionInfo
          account={accountNo}
          type={typeOrCategory}
          amount={amount}
          date={date}
          description={description}
          prefix={prefix}
        />
        {disputeButton && (
          <Box className={Classes.disputeBox}>
            <Typography variant="p2" color="grey.800">
              {ANYTHING_WRONG}{' '}
            </Typography>
            <Link
              href="#"
              className={(Classes.disputeLink, global.link)}
              onClick={showDispute}
              data-testid="transaction-detail-dispute-link"
            >
              {DISPUTE}
            </Link>
          </Box>
        )}
      </DialogContent>

      <DialogActions className={Classes.noPadding}>
        <Box className={Classes.closeWrapper}>
          <Button variant="contained" onClick={handleClose}>
            <Typography variant="buttonMedium" color="grey.800">
              {CLOSE}
            </Typography>
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default TransactionDetailDialog;

TransactionDetailDialog.propTypes = {
  disputeButton: PropTypes.bool,
  accountType: PropTypes.string,
};

TransactionDetailDialog.defaultProps = {
  disputeButton: false,
  accountType: 'chello',
};
