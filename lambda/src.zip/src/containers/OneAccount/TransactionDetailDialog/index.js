import TransactionDetailDialog from './TransactionDetailDialog';

export default TransactionDetailDialog;
