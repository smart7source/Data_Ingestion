import NoLinkedAccounts from './NoLinkedAccounts';

export default NoLinkedAccounts;
