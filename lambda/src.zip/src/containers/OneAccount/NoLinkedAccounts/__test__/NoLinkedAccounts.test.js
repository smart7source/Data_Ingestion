import { render, screen, act, waitFor } from '@testing-library/react/pure';
import { Auth } from 'aws-amplify';
import { rest } from 'msw';

import {
  renderWithProviderAndRouter,
  emptyLinkedAccountsMock,
} from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';

describe('Test NoLinkedAccounts component', () => {
  beforeAll(() => {
    server.use(
      rest.get(serviceUrl.getAllAccountDetails, (req, res, ctx) =>
        res(ctx.json(emptyLinkedAccountsMock)),
      ),
    );
  });

  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render the one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should show "You have no linked accounts" text when linked accounts are available', async () => {
    expect(
      await screen.findByAltText('no linked accounts'),
    ).toBeInTheDocument();
  });
});
