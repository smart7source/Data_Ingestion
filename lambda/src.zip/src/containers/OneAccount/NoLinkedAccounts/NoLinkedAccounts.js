import { Box, TableCell, TableRow, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import Classes from '../OneAccount.module.scss';
import AddAccount from '../AddAccount';

const NoLinkedAccounts = ({ colSpan, message, addAccountBtn }) => (
  <TableRow>
    <TableCell colSpan={colSpan} className={Classes.transactionsPadding}>
      <Box
        display="flex"
        flexDirection="column"
        gap={1.5}
        alignItems="center"
        className={Classes.noLinkedAccount}
      >
        <Box>
          <img
            width="179"
            height="50"
            src={`${process.env.PUBLIC_URL}/images/no-linked-accts.png`}
            alt="no linked accounts"
            style={{ width: '100%', height: 'auto' }}
          />
        </Box>
        <Typography variant="p1SemiBold" component="p">
          {message}
        </Typography>
        {addAccountBtn && (
          <AddAccount dataTestid="chello-add-account-btn-no-account" />
        )}
      </Box>
    </TableCell>
  </TableRow>
);

export default NoLinkedAccounts;

NoLinkedAccounts.propTypes = {
  colSpan: PropTypes.number,
  message: PropTypes.string,
  addAccountBtn: PropTypes.bool,
};
NoLinkedAccounts.defaultProps = {
  colSpan: 2,
  message: '',
  addAccountBtn: false,
};
