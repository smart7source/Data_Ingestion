import { Box } from '@mui/material';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';

import strings from 'localization/translation';
import { CustomSelectBox } from 'components';
import { useRefData } from 'hooks';

const { disputeReason: DISPUTE_REASON } = strings;

const DisputeReason = (props) => {
  const { network, control, errors } = props;

  const refData = useSelector((state) => state.global.refData);
  const { [`DISPUTE_REASONS_FOR_${network}`]: disputeReasonList } = refData;

  useRefData([`DISPUTE_REASONS_FOR_${network}`]);

  return (
    <Box mt={2.5}>
      <CustomSelectBox
        dataTestid="disputeReason"
        label={DISPUTE_REASON}
        options={disputeReasonList}
        error={!!errors.disputeReason}
        errorText={errors.disputeReason && errors.disputeReason.message}
        name="disputeReason"
        control={control}
      />
    </Box>
  );
};
export default DisputeReason;

DisputeReason.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  network: PropTypes.string,
  errors: PropTypes.instanceOf(Object),
};
DisputeReason.defaultProps = {
  network: '',
  errors: {},
};
