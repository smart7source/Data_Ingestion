import {
  render,
  screen,
  fireEvent,
  waitFor,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Amplify } from 'aws-amplify';

import awsConfig from 'aws-exports';
import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

Amplify.configure(awsConfig);
const submitDispute = async () => {
  let disputeReason = screen.getByTestId('disputeReason');

  fireEvent.change(disputeReason, {
    target: { value: '1' },
  });

  const submitButton = await screen.findByTestId('oneaccount-dispute-submit');
  expect(submitButton).toBeEnabled();
  userEvent.click(submitButton);
  expect(
    await screen.findByText('We’re looking into this'),
  ).toBeInTheDocument();
  userEvent.click(await screen.findByTestId('dispute-confirm-ok'));
};

describe('Testing ChelloAccounts tab component', () => {
  let dialog;

  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });
  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });
  it('should render chello tab', async () => {
    userEvent.click(screen.getByTestId('one-account-chello-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });

  it('should display chello account details and chello insights', async () => {
    await screen.findByTestId('kebab-menu-chello-transaction-0-btn');
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();

    expect(screen.getByText('Chello Insights')).toBeInTheDocument();
  });
  it('should open details dialog for particular transaction when opted', async () => {
    const kebabMenu = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-btn',
    );

    userEvent.click(kebabMenu);
    const menuItem = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-item-0',
    );

    userEvent.click(menuItem);
    dialog = await screen.findByText('Have a closer look');

    expect(dialog).toBeInTheDocument();
  });
  it('should open dispute dialog and close', async () => {
    userEvent.click(screen.getByTestId('transaction-detail-dispute-link'));
    expect(
      await screen.findByText('Dispute a transaction'),
    ).toBeInTheDocument();
    userEvent.click(screen.getByTestId('one-account-dispute-cancel'));
  });
  it('should open details dialog', async () => {
    const kebabMenu = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-btn',
    );

    userEvent.click(kebabMenu);
    const menuItem = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-item-0',
    );

    userEvent.click(menuItem);
    dialog = await screen.findByText('Have a closer look');

    expect(dialog).toBeInTheDocument();
  });
  it('should close details dialog when closed', async () => {
    userEvent.click(screen.getByTestId('transaction-detail-close-btn'));
    await waitFor(() => {
      expect(screen.queryByText('Have a closer look')).not.toBeInTheDocument();
    });
  });
  it('should show dispute confirmation when dispute is submitted', async () => {
    const kebabMenu = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-btn',
    );

    userEvent.click(kebabMenu);
    const menuItem = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-item-1',
    );

    userEvent.click(menuItem);
    dialog = await screen.findByText('Dispute a transaction');

    expect(dialog).toBeInTheDocument();
    await submitDispute();
  });
});
