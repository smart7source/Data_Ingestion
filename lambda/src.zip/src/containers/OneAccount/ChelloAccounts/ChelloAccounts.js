import { Box } from '@mui/material';
import { useState, useEffect, memo } from 'react';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';

import {
  fetchChelloAccDetails,
  resetTransactionFilter,
} from 'store/actions/OneAccountActions';
import { Notification } from 'components';
import { NotificationContext } from 'contexts';
import { useHandleApiFailure } from 'hooks';

import ChelloInsights from '../ChelloInsights';
import ChelloAccountDetails from '../ChelloAccountDetails';
import TransactionDetailDialog from '../TransactionDetailDialog/TransactionDetailDialog';
import Classes from '../OneAccount.module.scss';
import DisputeConfirmationDialog from '../DisputeConfirmationDialog';
import DisputeChargeDialog from '../DisputeChargeDialog';

const ChelloAccounts = ({ handleTabChange }) => {
  const [notification, setNotification] = useState([]);
  const dispatch = useDispatch();
  const handleAPIFailure = useHandleApiFailure(setNotification);

  useEffect(() => {
    dispatch(fetchChelloAccDetails({ failureCallback: handleAPIFailure }));
  }, [dispatch, handleAPIFailure]);

  useEffect(
    () => () => {
      dispatch(resetTransactionFilter());
    },
    [dispatch],
  );

  return (
    <NotificationContext.Provider value={{ notification, setNotification }}>
      {!!notification.length && (
        <Box mb={2.5}>
          <Notification errors={notification} needFocus />
        </Box>
      )}
      <Box className={Classes.chellAccounts}>
        <ChelloAccountDetails handleTabChange={handleTabChange} />
        <ChelloInsights />
        <TransactionDetailDialog disputeButton />
        <DisputeChargeDialog />
        <DisputeConfirmationDialog />
      </Box>
    </NotificationContext.Provider>
  );
};

export default memo(ChelloAccounts);

ChelloAccounts.propTypes = {
  handleTabChange: PropTypes.func.isRequired,
};
