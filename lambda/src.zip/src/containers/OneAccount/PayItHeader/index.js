import PayItHeader from './PayItHeader';

export default PayItHeader;
