import { Grid, Box, Divider, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import { CustomIcon } from 'components';
import { ReactComponent as CornerUpLeft } from 'assets/svg/corner-up-left.svg';
import { defaultFnPropTypes } from 'utils';

import Classes from '../OneAccount.module.scss';

const PayItHeader = (props) => {
  const { handleClose, accNbrAndPosnNbr, title } = props;
  return (
    <Grid
      item
      xs={12}
      sm={12}
      container
      direction="row"
      justifyContent="space-between"
      alignItems="flex-start"
    >
      <Box component="span" className={Classes.boostNowTitle}>
        <Box
          className={Classes.cornerUpClass}
          onClick={handleClose}
          data-testid="back_icon"
        >
          <CustomIcon
            component={CornerUpLeft}
            inheritViewBox
            color="primary"
            className={Classes.iconSize}
          />
        </Box>
        <Divider orientation="vertical" className={Classes.dividerHeight} />
        <Typography component="h2" variant="h2" color="grey.900">
          {title}
        </Typography>
      </Box>
      <Typography variant="body1" color="grey.600">
        {accNbrAndPosnNbr}
      </Typography>
    </Grid>
  );
};

export default PayItHeader;

PayItHeader.propTypes = {
  handleClose: PropTypes.func,
  accNbrAndPosnNbr: PropTypes.string,
  title: PropTypes.string,
};
PayItHeader.defaultProps = {
  handleClose: defaultFnPropTypes,
  accNbrAndPosnNbr: '',
  title: '',
};
