const getFilteredAccounts = ({
  account,
  selectedLinkedAccount,
  linkedAccounts,
  accountNumber,
  positionId,
}) => {
  const filterAccountNumbers = [];

  if (account === 'external' && selectedLinkedAccount === 'all') {
    linkedAccounts.forEach((x) => {
      const { accNbr: linkedAccountNumber, posnId: linkedPositionId } = x;
      filterAccountNumbers.push({
        accountNo: linkedAccountNumber,
        positionId: linkedPositionId,
      });
    });
  } else if (account === 'external' && selectedLinkedAccount !== 'all') {
    const { posnId: linkedPositionId } = linkedAccounts.find(
      (x) => x.accNbr === selectedLinkedAccount,
    );
    filterAccountNumbers.push({
      accountNo: selectedLinkedAccount,
      positionId: linkedPositionId,
    });
  } else {
    filterAccountNumbers.push({
      accountNo: accountNumber,
      positionId,
    });
  }
  return filterAccountNumbers;
};

export default getFilteredAccounts;
