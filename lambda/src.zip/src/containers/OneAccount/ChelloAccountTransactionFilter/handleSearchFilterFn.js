import {
  fetchOneAccTransactions,
  setTransactionFilter,
} from 'store/actions/OneAccountActions';
import { formatDateToString } from 'utils';
import strings from 'localization/translation';

import getFilteredAccounts from './getFilteredAccounts';

const { noSearchCriteria: NO_SEARCH_CRITERIA } = strings;

const handleSearchAndFilterFn = (
  data,
  account,
  selectedLinkedAccount,
  linkedAccounts,
  accountNumber,
  positionId,
  dispatch,
  handleAPIFailure,
  setErrorMsgs,
) => {
  const { fromDate, toDate, searchType = '', searchText = '' } = data;

  if (
    fromDate ||
    toDate ||
    (searchType !== '' &&
      searchType.toLowerCase() !== 'type' &&
      searchType.toLowerCase() !== 'category') ||
    searchText
  ) {
    const filterAccountNumbers = getFilteredAccounts({
      account,
      selectedLinkedAccount,
      linkedAccounts,
      accountNumber,
      positionId,
    });
    filterAccountNumbers.forEach(
      ({ accountNo: filterAccountNumber, positionId: filterPositionId }) => {
        dispatch(
          fetchOneAccTransactions({
            positionId: filterPositionId,
            accountNumber: filterAccountNumber,
            fromDate: formatDateToString(fromDate, 'YYYY-MM-DD'),
            toDate: formatDateToString(toDate, 'YYYY-MM-DD'),
            searchType,
            searchText,
            account,
            failureCallback: handleAPIFailure,
          }),
        );
      },
    );
    dispatch(
      setTransactionFilter({
        fromDate,
        toDate,
        searchType,
        searchText,
      }),
    );
  } else {
    setErrorMsgs([{ severity: 'error', message: NO_SEARCH_CRITERIA }]);
  }
};

export default handleSearchAndFilterFn;
