import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import {
  renderWithProviderAndRouter,
  mockMatchMediaToDesktop,
} from 'testHelpers';
import ChelloAccountDetails from 'containers/OneAccount/ChelloAccountDetails';

const initialState = {
  OneAccount: {
    chelloAccountTransactions: [
      {
        accountNo: '9876-03',
        transactionId: '14567',
        date: 'Nov 22, 2021',
        description: 'Loan Advance to Chase Checking Ac 123451234',
        category: 'Transfer from Boost to external account',
        type: 'Transfer',
        amount: '500',
        balance: '615.00',
      },
      {
        accountNo: '9876-03',
        transactionId: '14568',
        date: 'Oct 12, 2021',
        description: '*Paid in full - Chase Checking Ac 123451234',
        category: 'Transfer from Boost to external account',
        type: 'Transfer',
        amount: '100.00',
        balance: '1115.00',
      },
      {
        accountNo: '9876-03',
        transactionId: '14569',
        date: 'Sep 2, 2021',
        description:
          'Loan partial payment - Bank of America Checing  Ac 123451234',
        category: 'Transfer from Boost to external account',
        type: 'Transfer',
        amount: '50.00',
        balance: '1215.00',
      },
      {
        accountNo: '9876-03',
        transactionId: '14566',
        date: 'Aug 15, 2021',
        description: 'Loan Advance  to Chase Checking Ac 123451234',
        category: 'Transfer from Boost to external account',
        type: 'Transfer',
        amount: '5.00',
        balance: '1265.00',
      },
    ],
    transactionFilter: {
      fromDate: '',
      toDate: '',
      searchType: '',
      searchTerm: '',
      nextPageKey: 'first',
    },
  },
};

describe('Testing ChelloAccounts tab component', () => {
  beforeAll(() => {
    mockMatchMediaToDesktop();
  });
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });
  it('should render chello account transactions with filter', async () => {
    const handleTabChange = jest.fn();
    renderWithProviderAndRouter(
      <ChelloAccountDetails handleTabChange={handleTabChange} />,
      {
        render,
        wrapperProps: {
          initialState,
        },
      },
    );
  });

  it('should show error when search icon clicked without any filter criteria', async () => {
    userEvent.click(screen.getByTestId('chello-filter-search'));
    await waitFor(() => {
      expect(
        screen.getByText(
          'No search criteria entered. Enter at least one to search for results',
        ),
      ).toBeInTheDocument();
    });
  });
  it('should filter records if any of search criteria is given', async () => {
    userEvent.type(
      screen.getByTestId('chello-transaction-search-text'),
      'loan',
    );

    userEvent.click(screen.getByTestId('chello-filter-search'));
    await screen.findAllByText('Loan Advance to Chase Checking Ac 123451234');
  });
  it('should show error if to date given and from date not given', async () => {
    const toDate = screen.getByLabelText('To');
    const today = new Date();
    const todayFormatted = today.toLocaleDateString('en', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });
    userEvent.type(toDate, todayFormatted);
    userEvent.click(screen.getByTestId('chello-filter-search'));
    await waitFor(() => {
      expect(
        screen.getByText('From date is required on giving to date'),
      ).toBeInTheDocument();
    });
  });
});
