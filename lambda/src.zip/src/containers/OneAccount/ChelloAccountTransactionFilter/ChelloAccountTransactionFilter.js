import { Box, Button, IconButton, Typography } from '@mui/material';
import { useForm, useWatch } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useState, useRef, useEffect, useCallback, useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import clsx from 'clsx';
import PropTypes from 'prop-types';

import {
  CustomInput,
  CustomSelectBox,
  DatePicker,
  Notification,
  CustomIcon,
} from 'components';
import strings from 'localization/translation';
import Export from 'containers/MoveMoney/Export/Export';
import { exportOneAccountTransactions } from 'store/actions/OneAccountActions';
import {
  formatDateToString,
  getDynamicLineOfCreditsAccountDetails,
  getContentType,
  download,
  minDate,
} from 'utils';
import { NotificationContext } from 'contexts';
import BackToTop from 'components/UIElements/BackToTop';
import { useClearNotification, useHandleApiFailure } from 'hooks';
import { ReactComponent as Search } from 'assets/svg/search.svg';
import globalClasses from 'style/globalStyle.module.scss';
import { openExport } from 'store/actions/MoveMoneyActions';
import { ReactComponent as Download } from 'assets/svg/download.svg';

import Classes from '../OneAccount.module.scss';
import { transactionFilterSchema } from '../oneAccountSchema';

import handleSearchFilterFn from './handleSearchFilterFn';

const { export: EXPORT, selectDate: SELECT_DATE } = strings;

const ChelloAccountTransactionFilter = (props) => {
  const contextValue = useContext(NotificationContext);
  const { setNotification } = contextValue;
  const {
    showExport,
    chelloTransactionFilterByOptions,
    account,
    selectedLinkedAccount = 'all',
  } = props;
  const filterWidgetRef = useRef(null);
  const [showAtPx, setShowAtPx] = useState(0);
  const [scrollToPx, setScrollToPx] = useState(0);
  const [errorMsgs, setErrorMsgs] = useState([]);

  const { fromDate: fromDateDefault, toDate: toDateDefault } = useSelector(
    (state) => state.OneAccount.transactionFilter,
  );

  const defaultType = account === 'external' ? 'Category' : 'Type';

  const {
    control,
    watch,
    getValues,
    setValue,
    formState: { errors },
    handleSubmit,
    reset,
  } = useForm({
    mode: 'onSubmit',
    resolver: yupResolver(transactionFilterSchema),
    defaultValues: {
      formatDownload: 'CSV',
      fromDate: fromDateDefault,
      toDate: toDateDefault,
    },
  });

  useEffect(() => {
    if (account) {
      reset({
        formatDownload: 'CSV',
        fromDate: fromDateDefault,
        toDate: toDateDefault,
      });
    }
  }, [account, defaultType, fromDateDefault, reset, toDateDefault]);

  const handleClickOpen = () => {
    dispatch(openExport(true));
  };

  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount?.chelloAccountDetails,
  );
  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  const { accNbr: accountNumber = '', posnId: positionId = '' } =
    getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const downloadChelloTransactions = (exportedData) => {
    try {
      const contentType = getValues('formatDownload');
      download(
        `chello-account-transactions.${contentType.toLowerCase()}`,
        exportedData,
        getContentType(contentType),
      );
    } catch (e) {
      // TODO handle error case for downloadChelloTransactions
    }
  };
  const dispatch = useDispatch();

  const handleExport = () => {
    const [
      type,
      transactionFromDate,
      transactionToDate,
      transactionSearchType,
      transactionSearchText,
    ] = getValues([
      'formatDownload',
      'fromDate',
      'toDate',
      'searchType',
      'searchText',
    ]);
    dispatch(
      exportOneAccountTransactions({
        positionId,
        accountNumber,
        fromDate: formatDateToString(transactionFromDate, 'YYYY-MM-DD'),
        toDate: formatDateToString(transactionToDate, 'YYYY-MM-DD'),
        searchType: transactionSearchType,
        searchText: transactionSearchText,
        type,
        successCallback: downloadChelloTransactions,
        failureCallback: handleExportFailure,
      }),
    );
    dispatch(openExport(false));
  };

  const handleExportFailure = (errResponse) => {
    setNotification([{ severity: 'error', message: errResponse }]);
  };
  useEffect(() => {
    if (Object.keys(errors).length) {
      setErrorMsgs([errors[Object.keys(errors)?.[0]]]);
    }
  }, [errors]);
  const clearFn = useCallback(() => {
    setErrorMsgs([]);
  }, []);
  useClearNotification({
    watch,
    clear: errorMsgs.length,
    clearFn,
  });

  const [watchFromDate, watchToDate] = useWatch({
    control,
    name: ['fromDate', 'toDate'],
  });

  const handleAPIFailure = useHandleApiFailure();

  const handleSearchAndFilter = (data) =>
    handleSearchFilterFn(
      data,
      account,
      selectedLinkedAccount,
      linkedAccounts,
      accountNumber,
      positionId,
      dispatch,
      handleAPIFailure,
      setErrorMsgs,
    );

  useEffect(() => {
    const { offsetTop = 0, offsetHeight = 0 } = filterWidgetRef.current || {};
    setShowAtPx(offsetTop + offsetHeight);
    setScrollToPx(offsetTop);
  }, []);

  return (
    <>
      <Notification errors={errorMsgs} />
      <Box
        ref={filterWidgetRef}
        className={Classes.chelloAccountsFilterWrapper}
      >
        {showExport && (
          <>
            <Export
              handleSubmit={handleExport}
              getValues={getValues}
              setValue={setValue}
              control={control}
              errors={errors}
            />
            <Button
              className={clsx(
                globalClasses.ctaWithIcon,
                Classes.transactionExportButton,
              )}
              data-testid="transaction-export-button"
              color="primary"
              onClick={handleClickOpen}
            >
              <CustomIcon
                component={Download}
                color="primary"
                className={Classes.closeIconSize}
                inheritViewBox
              />
              <Typography component="span" variant="buttonMedium">
                {EXPORT}
              </Typography>
            </Button>
          </>
        )}
        <form
          className={Classes.chelloAccountFilterOptions}
          onSubmit={handleSubmit(handleSearchAndFilter)}
        >
          <Box
            className={[
              Classes.filterOptionFieldWrapper,
              Classes.fromField,
            ].join(' ')}
          >
            <DatePicker
              label="From"
              placeHolder={SELECT_DATE}
              id="chello-transaction-from-date"
              name="fromDate"
              control={control}
              dataTestid="chello-transaction-from-date"
              maxDateValue={watchToDate || new Date()}
            />
          </Box>
          <Box className={Classes.filterOptionFieldWrapper}>
            <DatePicker
              label="To"
              placeHolder={SELECT_DATE}
              id="chello-transaction-to-date"
              name="toDate"
              control={control}
              dataTestid="chello-transaction-to-date"
              minDateValue={watchFromDate || new Date(minDate)}
              maxDateValue={new Date()}
            />
          </Box>
          <Box className={Classes.chelloAccountFilterByCategory}>
            <Box className={Classes.chelloAccountSearchCategory}>
              <CustomSelectBox
                id="chello-transaction-search-type"
                name="searchType"
                control={control}
                dataTestid="chello-transaction-search-type"
                options={chelloTransactionFilterByOptions}
                classes={Classes.searchCategoryBorder}
                placeHolderText={defaultType}
                hideSelect
              />
              <CustomInput
                id="chello-transaction-search-text"
                dataTestid="chello-transaction-search-text"
                name="searchText"
                placeholder="Search by description"
                control={control}
                classes={Classes.searchTermBorder}
              />

              <IconButton
                type="submit"
                className={Classes.searchIcon}
                data-testid="chello-filter-search"
              >
                <CustomIcon
                  component={Search}
                  color="grey.600"
                  className={Classes.iconSize}
                />
              </IconButton>
            </Box>
          </Box>
        </form>
        <BackToTop scrollToPx={scrollToPx} showAtPx={showAtPx} />
      </Box>
    </>
  );
};

export default ChelloAccountTransactionFilter;

ChelloAccountTransactionFilter.propTypes = {
  showExport: PropTypes.bool,
  chelloTransactionFilterByOptions: PropTypes.instanceOf(Object),
  account: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  selectedLinkedAccount: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
};

ChelloAccountTransactionFilter.defaultProps = {
  showExport: false,
  chelloTransactionFilterByOptions: [],
  account: 'chello',
  selectedLinkedAccount: 'all',
};
