import {
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import {
  fetchOneAccTransactions,
  showDetailsDialog,
  showDisputeDialog,
  setSelectedTransactionIndex,
} from 'store/actions/OneAccountActions';
import { useInfiniteScroll, useHandleApiFailure } from 'hooks';
import {
  getDynamicLineOfCreditsAccountDetails,
  formatDateToString,
  getFormattedTransactionDate,
} from 'utils';

import ChelloAccountEachTransaction from '../ChelloAccountEachTransaction';
import NoLinkedAccounts from '../NoLinkedAccounts';
import Classes from '../OneAccount.module.scss';

const {
  date: DATE,
  description: DESCRIPTION,
  type: TYPE,
  amount: AMOUNT,
  noTransfersToDisplay: NO_TRANFERS_TO_DISPLAY,
} = strings;

const ChelloAccountTransactions = (props) => {
  const { paymentTypes } = props;
  const dispatch = useDispatch();

  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount?.chelloAccountDetails,
  );

  const { accNbr: accountNumber = '', posnId: positionId = '' } =
    getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const chelloAccountTransactions = useSelector(
    (state) => state.OneAccount.chelloAccountTransactions,
  );

  const totalTransactions = chelloAccountTransactions.length;

  const loading = useSelector((state) => state.global.loading);

  const {
    fromDate,
    toDate,
    searchType = '',
    searchText = '',
    nextPageKey = 'first',
  } = useSelector((state) => state.OneAccount.transactionFilter);

  const handleAPIFailure = useHandleApiFailure();

  const loadMore = () => {
    if (accountNumber && nextPageKey && nextPageKey !== 'first') {
      dispatch(
        fetchOneAccTransactions({
          accountNumber,
          positionId,
          fromDate: formatDateToString(fromDate, 'YYYY-MM-DD'),
          toDate: formatDateToString(toDate, 'YYYY-MM-DD'),
          searchType,
          searchText,
          nextPageKey,
          loadMore: true,
          failureCallback: handleAPIFailure,
        }),
      );
    }
  };

  const lastElRef = useInfiniteScroll({
    loading,
    hasMore: true,
    loadMore,
  });
  const options = [
    {
      name: 'Details',
    },
    {
      name: 'Dispute',
    },
  ];

  const onMenuOptionClick = (option, index) => {
    dispatch(setSelectedTransactionIndex(index));
    if (option.name === 'Details') {
      dispatch(showDetailsDialog(true));
    }
    if (option.name === 'Dispute') {
      dispatch(showDisputeDialog(true));
    }
  };

  return (
    <Box className={Classes.chelloTransactionsTableWrapper}>
      <Table className={Classes.chelloTransactionsTable}>
        <TableHead>
          <TableRow>
            <TableCell>
              <Typography variant="p2Paragraph" component="p" color="grey.800">
                {DATE}
              </Typography>
            </TableCell>
            <TableCell className={Classes.transactionsTableHeadDescriptionCell}>
              <Typography variant="p2Paragraph" component="p" color="grey.800">
                {DESCRIPTION}
              </Typography>
            </TableCell>
            <TableCell>
              <Typography variant="p2Paragraph" component="p" color="grey.800">
                {TYPE}
              </Typography>
            </TableCell>
            <TableCell className={Classes.transactionsTableHeadAmountCell}>
              <Typography variant="p2Paragraph" component="p" color="grey.800">
                {AMOUNT}
              </Typography>
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {chelloAccountTransactions?.length ? (
            chelloAccountTransactions.map((eachTransaction, index) => {
              const {
                amount = '',
                balance = '',
                date = '',
                description = '',
                descriptionTwo = '',
                txnType: type = '',
                transactionId = '',
              } = eachTransaction;
              const key = `${transactionId}${index}`;
              const formattedDate = getFormattedTransactionDate(date);

              return (
                <ChelloAccountEachTransaction
                  key={key}
                  date={formattedDate}
                  descriptionOne={description}
                  descriptionTwo={descriptionTwo}
                  amount={amount}
                  balance={balance}
                  typeOrCategory={type}
                  index={index}
                  lastElRef={totalTransactions === index + 1 ? lastElRef : null}
                  onMenuOptionClick={(option) =>
                    onMenuOptionClick(option, index)
                  }
                  kebabOptions={options}
                  account="chello"
                  paymentTypes={paymentTypes}
                />
              );
            })
          ) : (
            <NoLinkedAccounts colSpan={4} message={NO_TRANFERS_TO_DISPLAY} />
          )}
        </TableBody>
      </Table>
    </Box>
  );
};

export default ChelloAccountTransactions;

ChelloAccountTransactions.propTypes = {
  paymentTypes: PropTypes.instanceOf(Array),
};

ChelloAccountTransactions.defaultProps = {
  paymentTypes: [],
};
