import { render, screen, act, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

describe('Testing PayIt Amount component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });
  it('should render payit part', async () => {
    userEvent.click(screen.getByTestId('chello-pay-it-btn'));
    await screen.findByTestId('amount-radio');
  });

  it('should be selected enter amount at start', () => {
    const enterAmount = screen.getByTestId('enter-amount-radio');
    expect(enterAmount).toBeChecked();
  });

  it('should disable enter amount if not selected', async () => {
    const minimumPayment = screen.getByTestId('minimum-payment');
    userEvent.click(minimumPayment);
    expect(await screen.findByTestId('enter-amount-field')).toBeDisabled();
  });
});
