import { useEffect } from 'react';
import {
  Grid,
  Box,
  RadioGroup,
  Radio,
  FormControlLabel,
  Typography,
} from '@mui/material';
import PropTypes from 'prop-types';
import { Controller, useWatch, useFormState } from 'react-hook-form';

import { NumberInput } from 'components';
import strings from 'localization/translation';
import { convertToAmt } from 'utils';
import globalClasses from 'style/globalStyle.module.scss';

import Classes from '../OneAccount.module.scss';
import ShowInfo from '../ShowInfo';

const {
  minimumPayment: MINIMUM_PAYMENT,
  enterAmount: ENTER_AMOUNT,
  payFull: PAY_FULL,
  recurring: RECURRING,
} = strings;

const PayIt = (props) => {
  const { control, resetField, minPayment, payFullBal } = props;
  const active = useWatch({
    control,
    name: 'payItAmount',
  });
  const { errors } = useFormState({
    control,
  });

  const minPay = convertToAmt({
    value: minPayment,
    prefix: '$ ',
    addSeparator: true,
  });

  const payFull = convertToAmt({
    value: payFullBal,
    prefix: '$ ',
    addSeparator: true,
  });
  useEffect(() => {
    resetField('amount');
  }, [active, resetField]);

  return (
    <Grid container>
      <Box>
        <Controller
          render={({ field }) => (
            <RadioGroup
              {...field}
              aria-label="position"
              name="position"
              data-testid="amount-radio"
              row
            >
              <Grid container alignItems="center" mb={1}>
                <Grid item xs={12} sm={7} lg={7}>
                  <FormControlLabel
                    value="minimumPayment"
                    classes={{
                      label: globalClasses.h3Headline,
                    }}
                    control={
                      <Radio
                        color="primary"
                        inputProps={{
                          'data-testid': 'minimum-payment',
                        }}
                      />
                    }
                    label={MINIMUM_PAYMENT}
                  />
                </Grid>
                <Grid item xs={12} sm={5} lg={5}>
                  <Typography
                    variant="h3"
                    component="span"
                    color={
                      active !== 'minimumPayment' ? 'grey.600' : 'grey.800'
                    }
                  >
                    {minPay}
                  </Typography>
                </Grid>
              </Grid>
              <Grid container alignItems="center" mb={1}>
                <Grid item xs={12} sm={7} lg={7}>
                  <FormControlLabel
                    value="enterAmount"
                    classes={{
                      label: globalClasses.h3Headline,
                    }}
                    control={
                      <Radio
                        color="primary"
                        inputProps={{
                          'data-testid': 'enter-amount-radio',
                        }}
                      />
                    }
                    label={ENTER_AMOUNT}
                  />
                </Grid>
                <Grid item xs={12} sm={5} lg={5}>
                  <Box maxWidth>
                    <NumberInput
                      id="amount"
                      name="amount"
                      placeHolder="$ 0.00"
                      dataTestId="enter-amount-field"
                      margin="none"
                      prefix="$ "
                      control={control}
                      disabled={active !== 'enterAmount'}
                      error={!!errors.amount}
                      errorText={errors.amount?.message}
                      fixedDecimalScale
                    />
                  </Box>
                </Grid>
              </Grid>
              <Grid container alignItems="center" mb={1}>
                <Grid item xs={12} sm={7} lg={7}>
                  <FormControlLabel
                    value="payFull"
                    classes={{
                      label: globalClasses.h3Headline,
                    }}
                    control={<Radio color="primary" />}
                    label={PAY_FULL}
                  />
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={5}
                  lg={5}
                  container
                  direction="row"
                  className={Classes.ChelloAccountInfo}
                >
                  <Box display="flex" alignItems="center" gap={1.25}>
                    <Typography
                      component="span"
                      variant="h3"
                      color={active !== 'payFull' ? 'grey.600' : 'grey.800'}
                    >
                      {payFull}
                    </Typography>
                    <ShowInfo content="Awaiting exact content.." />
                  </Box>
                </Grid>
              </Grid>
              <FormControlLabel
                value="recurring"
                classes={{
                  label: globalClasses.h3Headline,
                }}
                control={
                  <Radio
                    color="primary"
                    inputProps={{
                      'data-testid': 'pay-it-recurring',
                    }}
                  />
                }
                label={RECURRING}
              />
            </RadioGroup>
          )}
          name="payItAmount"
          id="payItAmount"
          control={control}
        />
      </Box>
    </Grid>
  );
};

export default PayIt;
PayIt.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  resetField: PropTypes.func.isRequired,
  minPayment: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  payFullBal: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
PayIt.defaultProps = {
  minPayment: '',
  payFullBal: '',
};
