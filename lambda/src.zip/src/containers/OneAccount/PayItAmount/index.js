import PayIt from './PayIt';

export default PayIt;
