import {
  convertToAmt,
  formatDateToString,
  maskAccountNumber,
  getAccountName,
  getFrequencyDays,
} from 'utils';

const createPayItPayload =
  ({
    payFullBal,
    linkedAccounts,
    setOpen,
    setTransferApiPayload,
    setTransferAmount,
    setSourceParties,
    setTransferDuration,
    positionId,
  }) =>
  (data) => {
    const {
      endDate,
      frequency,
      payItAmount: payAmount,
      payItNote,
      payItRecurringAmount,
      paymentDate = new Date(),
      selectedLinkedAccount,
      recurringAmount,
      bankAccounts,
      recurringType,
      numberoftransaction,
    } = data;
    let endateVal;
    const frequencyDays = getFrequencyDays(frequency);

    const apiPayload = {
      transferDate: formatDateToString(paymentDate, 'YYYY-MM-DD'),
      note: payItNote,
      transferDetail: [],
    };
    const details = {
      sourceParty: {
        accountId: '',
      },
      counterParty: {
        accountId: positionId,
      },
      transferAmt: '',
    };
    const eachSourcePartyDetail = { bankName: '', accNo: '' };
    const reviewSourcePartiesDetails = [];
    let totalAmtToPay = 0;

    if (payAmount === 'recurring') {
      const fromAcct = [...linkedAccounts].find(
        (x) => x.accNbr === selectedLinkedAccount,
      );

      const { accNbr, bankNm, posnId, accNickName, accNm } = fromAcct || {};

      if (recurringType === 'numberoftransaction') {
        endateVal = new Date();
        endateVal.setDate(
          endateVal.getDate() + frequencyDays * (numberoftransaction - 1),
        );
      } else {
        endateVal = endDate;
      }

      apiPayload.recurringTransfer = {
        endDate: formatDateToString(endateVal, 'YYYY-MM-DD'),
        frequency,
      };

      details.sourceParty = {
        accountId: posnId,
      };
      const recurringAmt =
        payItRecurringAmount === 'payTotal' ? payFullBal : recurringAmount;
      details.transferAmt = +convertToAmt({ value: recurringAmt });
      apiPayload.transferDetail.push({ ...details });

      const bankName = getAccountName({ bankNm, accNickName, accNm });

      eachSourcePartyDetail.bankName = bankName;
      eachSourcePartyDetail.accNo = maskAccountNumber(accNbr);
      totalAmtToPay = details.transferAmt;
      reviewSourcePartiesDetails.push({ ...eachSourcePartyDetail });
    } else {
      bankAccounts.forEach((item) => {
        const { debitAmount, accNbr, bankNm, posnId, accNickName, accNm } =
          item;
        if (debitAmount) {
          details.sourceParty = {
            accountId: posnId,
          };
          details.transferAmt = +convertToAmt({ value: debitAmount });
          apiPayload.transferDetail.push({ ...details });
          const bankName = getAccountName({ bankNm, accNickName, accNm });
          eachSourcePartyDetail.bankName = bankName;
          eachSourcePartyDetail.accNo = maskAccountNumber(accNbr);
          totalAmtToPay += details.transferAmt;
          reviewSourcePartiesDetails.push({ ...eachSourcePartyDetail });
        }
      });
    }
    setOpen(true);
    setTransferApiPayload(apiPayload);

    setTransferAmount(
      convertToAmt({
        value: totalAmtToPay,
        prefix: '$ ',
        addSeparator: true,
      }),
    );
    setSourceParties(reviewSourcePartiesDetails);
    setTransferDuration(apiPayload?.recurringTransfer?.endDate);
  };

export default createPayItPayload;
