import { Grid, Box, Divider } from '@mui/material';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState, memo } from 'react';
import PropTypes from 'prop-types';

import {
  openPayIt,
  oneAccountMakeATransfer,
  fetchAllAccDetails,
  fetchOneAccTransactions,
} from 'store/actions/OneAccountActions';
import strings from 'localization/translation';
import {
  getDynamicLineOfCreditsAccountDetails,
  maskAccountNumber,
  maskAccountNumberAndPosnNumber,
  getFrequencyName,
  handleTransferAPIComplete,
  getSpendBalancePercentage,
  getAccountName,
  formatDateToString,
} from 'utils';
import { useHandleApiFailure } from 'hooks';

import ChelloAccountBalanceInfo from '../ChelloAccountBalanceInfo';
import { payitSchema } from '../oneAccountSchema';
import Classes from '../OneAccount.module.scss';
import ReviewTransferDialog from '../ReviewTransferDialog';
import PayItAmount from '../PayItAmount';
import PayItFlow from '../PayItFlow';
import PayitHeader from '../PayItHeader';
import PayButtons from '../PayButtons';
import PayInDialogBox from '../oneAccountTransactionModel';

import createPayItPayload from './createPayItPayload';

const { payLoan: PAY_LOAN } = strings;

const ChelloAccountPayIt = (props) => {
  const { tab } = props;
  const [open, setOpen] = useState(false);
  const [sourceParties, setSourceParties] = useState([]);
  const [transferAmount, setTransferAmount] = useState('');
  const [transferDuration, setTransferDuration] = useState('');
  const [modal, setModal] = useState(false);
  const [transferCompletionDetails, setTransferCompleteStatus] = useState(null);
  const [transferApiPayload, setTransferApiPayload] = useState({});

  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount.chelloAccountDetails,
  );
  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  const {
    avlbToSpdtBalAmt: availableToSpendBalanceAmount = 0,
    utlzBalAmt: utilizedAmount = 0,
    accNbr: accountNumber = '',
    posnNbr: posnNumber = '',
    posnId: positionId = '',
    minimumPayment: minPayment = 0,
    payoffAmount: payFullBal = 0,
    apprvBalAmt: totalLimit = 0,
    accNickName,
    accNm,
  } = getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const dispatch = useDispatch();

  const {
    control,
    setValue,
    handleSubmit,
    watch,
    resetField,
    formState: { isValid },
  } = useForm({
    mode: 'onChange',
    resolver: yupResolver(payitSchema(minPayment, payFullBal)),
    defaultValues: {
      amount: '',
      payItNote: '',
      payItAmount: 'enterAmount',
      payItRecurringAmount: 'payTotal',
      frequency: '7D',
      payItTotal: '$ 0.00',
      bankAccounts: [],
      selectedLinkedAccount: '',
      recurringType: '',
      endDate: '',
      numberoftransaction: '',
    },
  });

  const payItAmount = watch('payItAmount');

  useEffect(() => {
    if (payItAmount === 'recurring') {
      resetField('paymentDate');
    } else {
      resetField('endDate');
      resetField('recurringAmount');
      resetField('selectedLinkedAccount');
      resetField('frequency');
      resetField('payItRecurringAmount');
    }
  }, [resetField, payItAmount]);

  useEffect(
    () => () => {
      dispatch(openPayIt(false));
    },
    [dispatch],
  );

  const bankAccounts = watch('bankAccounts');
  const hasBalError = bankAccounts.findIndex((x) => x.error) > -1;

  const btnProps = {};
  if (!isValid || hasBalError) {
    btnProps.disabled = true;
  } else {
    btnProps.color = 'primary';
  }

  const availableToSpendBalancePercentage = getSpendBalancePercentage(
    availableToSpendBalanceAmount,
    totalLimit,
  );

  const accNbrAndPosnNbr = maskAccountNumberAndPosnNumber(
    accountNumber,
    posnNumber,
  );
  const maskLastFourDigitAccNbr = maskAccountNumber(accountNumber);

  const handleClosePayIt = () => {
    dispatch(openPayIt(false));
  };

  const handleAPIComplete = (statusParam) => (params) => {
    setModal(true);
    handleTransferAPIComplete({
      setTransferCompleteStatus,
      ...statusParam,
      ...params,
    });
  };

  const handleOpen = createPayItPayload({
    payFullBal,
    linkedAccounts,
    setOpen,
    setTransferApiPayload,
    setTransferAmount,
    setSourceParties,
    setTransferDuration,
    positionId,
  });
  const handleClose = () => {
    setOpen(false);
  };
  const submitHandler = () => {
    setOpen(false);
    dispatch(
      oneAccountMakeATransfer({
        apiPayload: transferApiPayload,
        successCallback: handleAPIComplete({ status: 'success' }),
        failureCallback: handleAPIComplete({ status: 'error' }),
      }),
    );
  };
  const handleAPIFailure = useHandleApiFailure();
  const handleClosePayItModal = () => {
    dispatch(fetchAllAccDetails({ failureCallback: handleAPIFailure }));
    if (tab === 'chello') {
      dispatch(
        fetchOneAccTransactions({
          accountNumber,
          positionId,
          failureCallback: handleAPIFailure,
        }),
      );
    }
    setModal(false);
    handleClosePayIt();
  };

  const transactionDateFormatted = new Date(
    transferApiPayload?.transferDate,
  ).toLocaleDateString('en', {
    month: 'short',
    year: 'numeric',
    day: '2-digit',
  });

  const toBankName = getAccountName({
    bankNm: '',
    accNickName,
    accNm,
  });

  return (
    <form onSubmit={handleSubmit(handleOpen)} data-testid="form">
      <Grid container direction="column">
        <ReviewTransferDialog
          open={open}
          handleClose={handleClose}
          handleSubmit={submitHandler}
          transferFrom={sourceParties}
          transferToName={toBankName}
          transferToNo={maskLastFourDigitAccNbr}
          amount={transferAmount}
          date={transactionDateFormatted}
          frequency={getFrequencyName(
            transferApiPayload?.recurringTransfer?.frequency,
          )}
          duration={
            transferDuration
              ? formatDateToString(new Date(transferDuration), 'MM/DD/YYYY')
              : ''
          }
          note={transferApiPayload?.note || '-'}
        />
        <PayitHeader
          title={PAY_LOAN}
          handleClose={handleClosePayIt}
          accNbrAndPosnNbr={accNbrAndPosnNbr}
        />

        <Box mt={2.5}>
          <ChelloAccountBalanceInfo
            utilizedAmount={utilizedAmount}
            availableToSpendBalanceAmount={availableToSpendBalanceAmount}
            availableToSpendBalancePercentage={
              availableToSpendBalancePercentage
            }
            totalLimit={totalLimit}
          />
        </Box>

        <Grid container>
          <PayItAmount
            control={control}
            resetField={resetField}
            minPayment={minPayment}
            payFullBal={payFullBal}
          />
        </Grid>
        <Divider className={Classes.divider} />

        <PayItFlow
          control={control}
          setValue={setValue}
          payItAmount={payItAmount}
          payFullBal={payFullBal}
          minPayment={minPayment}
          resetField={resetField}
        />
        <PayButtons handleClosePayIt={handleClosePayIt} btnProps={btnProps} />
        <PayInDialogBox
          handleClosePayItModal={handleClosePayItModal}
          modal={modal}
          headTitle={transferCompletionDetails?.title}
          content={transferCompletionDetails?.content}
          status={transferCompletionDetails?.status}
          statusImage={transferCompletionDetails?.statusImage}
          confirmationId={transferCompletionDetails?.confirmationId}
          confirmationDate={transferCompletionDetails?.confirmationDate}
          amount={transferAmount}
        />
      </Grid>
    </form>
  );
};

export default memo(ChelloAccountPayIt);

ChelloAccountPayIt.propTypes = {
  tab: PropTypes.string,
};

ChelloAccountPayIt.defaultProps = {
  tab: 'all',
};
