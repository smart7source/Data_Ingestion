import {
  render,
  screen,
  waitFor,
  fireEvent,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import {
  renderWithProviderAndRouter,
  mockMatchMediaToDesktop,
} from 'testHelpers';
import { findNextWorkingDay } from 'utils';
import strings from 'localization/translation';

import ChelloAccountPayIt from '../index';

const { distributeTotalAmountIncludingInterestOverThePayment } = strings;

const initialState = {
  global: {
    loading: false,
    loader: [],
    refData: {
      TRANSFER_FREQUENCY: [
        { value: '1D', name: 'Daily' },
        { value: '7D', name: 'Weekly' },
        { value: '14D', name: 'Every two weeks' },
        { value: '1M', name: 'Monthly' },
        { value: '3M', name: 'Every three months' },
      ],
    },
    isAuthenticated: false,
    floatingChatbot: {
      enableFloatingChatbot: false,
      maximize: true,
    },
  },
  OneAccount: {
    chelloAccountDetails: {
      accounts: [
        {
          avlbToSpdtBalAmt: 5200,
          utlzBalAmt: 1300,
          pymtDueAmt: 120.04,
          pastPymtDueImitAmt: 120.04,
          otsgFeesAmt: 2.18,
          intRate: 6.55,
          accNm: 'Dynamic Line',
          posnNbr: '4hOVLwpsEIlbKV----1F-77-',
          accRtgNbr: '987651234',
          accNbr: '1234567890',
          apprvBalAmt: 15000,
          payoffAmount: 1600,
          minimumPayment: 50,
        },
      ],
    },
    linkedAccountDetails: [
      {
        posnId: '4hO_YImR1UiZFF----DF-77-',
        accId: '4hO_YImR1UiZFF----DF-77-',
        accNbr: '123443215678',
        accRtgNbr: '123456789',
        bankNm: 'Chase',
        avlbBalAmt: 10000,
        accNm: 'Checking',
      },
      {
        posnId: '4hOVLwpsEIlbKV----1F-77-',
        accId: '4hOVLwpsEIlbKV----1F-77-',
        accNbr: '987667895432',
        accRtgNbr: '123456789',
        bankNm: 'Wells Fargo',
        avlbBalAmt: 500,
        accNm: 'Savings',
      },
    ],
  },
};

describe('Testing ChelloAccount PayIt component Flow', () => {
  let paymentDate;
  let payAmount;

  beforeAll(() => {
    mockMatchMediaToDesktop();
    renderWithProviderAndRouter(<ChelloAccountPayIt />, {
      render,
      wrapperProps: {
        initialState,
      },
    });
  });
  it('should render the Pay it component', async () => {
    expect(screen.getByText('Pay loan')).toBeInTheDocument();
  });

  it('should show error when invalid date is entered', async () => {
    paymentDate = screen.getByTestId('payit-paymentDate');
    userEvent.type(paymentDate, '01/01/2000');
    expect(
      await screen.findByText("Date cannot be lesser than today's date"),
    ).toBeInTheDocument();
  });

  it('should accept a valid date value', async () => {
    userEvent.clear(paymentDate);
    const today = new Date();
    const nextWorkingDay = findNextWorkingDay(today).toLocaleDateString('en', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });
    userEvent.type(paymentDate, nextWorkingDay);
    await waitFor(() =>
      expect(
        screen.queryByText("Date cannot be lesser than today's date"),
      ).not.toBeInTheDocument(),
    );
    expect(
      screen.queryByText('Transactions are not allowed in weekends'),
    ).not.toBeInTheDocument();
  });

  it('should show error when amount is empty', async () => {
    payAmount = screen.getByTestId('enter-amount-field');
    userEvent.type(payAmount, '12.12');
    userEvent.clear(payAmount);

    expect(
      await screen.findByText('Amount cannot be empty'),
    ).toBeInTheDocument();
  });

  it('should accept a valid amount', async () => {
    fireEvent.change(payAmount, {
      target: {
        value: '1000',
      },
    });
    await waitFor(() =>
      expect(
        screen.queryByText('Amount cannot be empty'),
      ).not.toBeInTheDocument(),
    );
  });

  it('should enable the continue button when valid details are provided', async () => {
    fireEvent.change(screen.getByTestId('bankAccounts-0-debitAmount'), {
      target: {
        value: '1000',
      },
    });
    await waitFor(() => {
      expect(screen.getByText('Continue')).toBeEnabled();
    });
  });
  it('should open review transfer dialog on clicking continue', async () => {
    userEvent.click(screen.getByText('Continue'));
    expect(
      await screen.findByText('Your cash is ready for take-off.'),
    ).toBeInTheDocument();
  });
  it('should cancel after review', async () => {
    userEvent.click(screen.getByTestId('one-account-review-cancel'));
    await waitFor(() => {
      expect(
        screen.queryByText('Your cash is ready for take-off.'),
      ).not.toBeInTheDocument();
    });
  });
  it('should show pay it again', async () => {
    expect(await screen.findByText('Pay loan')).toBeInTheDocument();
  });

  it('should chose recurring flow', async () => {
    userEvent.click(await screen.findByTestId('pay-it-recurring'));
    expect(
      await screen.findByText(
        distributeTotalAmountIncludingInterestOverThePayment,
      ),
    ).toBeInTheDocument();
  });
  it('should accept valid inputs', async () => {
    await screen.findByTestId('end-date-radio');
    userEvent.click(screen.getByTestId('end-date-radio'));
    paymentDate = await screen.findByTestId('end-date-val');
    userEvent.type(paymentDate, '02/20/2023');

    const selectDropdown = screen.getByLabelText('Select bank account');

    userEvent.click(selectDropdown);
    expect(await screen.findByText('Checking *5678')).toBeInTheDocument();

    userEvent.click(screen.getByText('Checking *5678'));
    await screen.findByText('Checking *5678');
    expect(screen.getByText('Continue')).toBeEnabled();
  });
  it('should open review dialog on clicking continue', async () => {
    userEvent.click(screen.getByText('Continue'));
    expect(
      await screen.findByText('Your cash is ready for take-off.'),
    ).toBeInTheDocument();
  });
  it('should submit transfer request after review', async () => {
    userEvent.click(screen.getByTestId('oneaccount-review-submit'));
    await waitFor(() => {
      expect(
        screen.queryByText('Your cash is ready for take-off.'),
      ).not.toBeInTheDocument();
    });
  });
  it('should show payment confirmation dialog once transfer is done', async () => {
    expect(
      await screen.findByText(/Someone needs to take/i),
    ).toBeInTheDocument();
    userEvent.click(screen.getByText('Ok'));
    await waitFor(() => {
      expect(
        screen.queryByText(/Someone needs to take/i),
      ).not.toBeInTheDocument();
    });
  });
});
