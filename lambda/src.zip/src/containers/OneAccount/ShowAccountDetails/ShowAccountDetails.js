import { Box, Typography } from '@mui/material';
import { useSelector } from 'react-redux';

import strings from 'localization/translation';
import { getDynamicLineOfCreditsAccountDetails } from 'utils';

import Classes from '../OneAccount.module.scss';

const { accountNumber: ACCOUNT_NUMBER, routingNumber: ROUTING_NUMBER } =
  strings;

const ShowAccountDetails = () => {
  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount.chelloAccountDetails,
  );

  const {
    accNbr: accountNumber,
    posnNbr: posnNumber,
    accRtgNbr: routingNumber,
  } = getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  return (
    <Box className={Classes.showAccountDetails}>
      <Typography variant="p1SemiBold" component="p" color="grey.800">
        {ACCOUNT_NUMBER}
      </Typography>
      <Typography
        variant="p1"
        component="p"
        color="grey.800"
        className={Classes.rightAlign}
      >
        {`${accountNumber}-${posnNumber}`}
      </Typography>
      <Typography variant="p1SemiBold" component="p" color="grey.800">
        {ROUTING_NUMBER}
      </Typography>
      <Typography
        variant="p1"
        component="p"
        color="grey.800"
        className={Classes.rightAlign}
      >
        {routingNumber}
      </Typography>
    </Box>
  );
};

export default ShowAccountDetails;
