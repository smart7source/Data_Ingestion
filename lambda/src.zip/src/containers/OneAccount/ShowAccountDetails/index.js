import ShowAccountDetails from './ShowAccountDetails';

export default ShowAccountDetails;
