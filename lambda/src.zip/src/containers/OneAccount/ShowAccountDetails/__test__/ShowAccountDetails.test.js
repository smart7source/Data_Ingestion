import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

describe('Test ShowAccountDetails component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should render one account All tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });

  it('should display account number and accout routing number on clicking account number button', async () => {
    userEvent.click(screen.getByTestId('chello-account-details-btn'));
    const result = await screen.findAllByText('1234567890-1');
    expect(result.length).toBeGreaterThan(0);
    expect(screen.getByText('987651234')).toBeInTheDocument();
  });
});
