import { Button, Grid, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';

import Classes from '../OneAccount.module.scss';

const { cancel: CANCEL, continue: CONTINUE } = strings;

const PayButtons = ({ handleClosePayIt, btnProps }) => (
  <Grid item xs={12} sm={3} lg={6} mt={2} className={Classes.payItButton}>
    <Button variant="contained" onClick={handleClosePayIt}>
      <Typography variant="buttonMedium" component="span" color="grey.800">
        {CANCEL}
      </Typography>
    </Button>
    <Button variant="contained" type="submit" color="primary" {...btnProps}>
      {CONTINUE}
    </Button>
  </Grid>
);
export default PayButtons;

PayButtons.propTypes = {
  handleClosePayIt: PropTypes.func,
  btnProps: PropTypes.instanceOf(Object),
};
PayButtons.defaultProps = {
  handleClosePayIt: defaultFnPropTypes,
  btnProps: {},
};
