import PropTypes from 'prop-types';
import { Box, Typography } from '@mui/material';

import LinearProgressWithLabel from 'components/UIElements/LinearProgressWithLabel';
import { fileSizeFormatter, defaultFnPropTypes } from 'utils';
import CloseSvg from 'assets/close-icon.png';

import Classes from './styles.module.scss';

export default function UploadedDocumentsList({
  files,
  uploadPercentage,
  handleRemove,
}) {
  return (
    <Box className={Classes.uploadFileWrapper} gap={2.5}>
      {files &&
        files.map((file, index) => (
          <Box className={Classes.uploadFileListContainer} key={index}>
            <Box className={Classes.uploadFileIcon}>
              <img
                src={`${process.env.PUBLIC_URL}/svg/document-icon.svg`}
                alt="logo"
              />
            </Box>
            <Box className={Classes.uploadFileContent}>
              <Box className={Classes.uploadFileName}>
                <Typography variant="p2SemiBold" component="p">
                  {file?.name || ''}
                </Typography>
              </Box>
              <Box className={Classes.uploadFileSize}>
                <Typography variant="p3" component="p" color="grey.600">
                  {fileSizeFormatter(file?.size || '')}
                </Typography>
              </Box>
              <LinearProgressWithLabel value={uploadPercentage || 0} />
            </Box>
            <Box
              className={Classes.deleteuploadItem}
              onClick={() => handleRemove(file.name)}
            >
              <Typography variant="p2SemiBold" component="p">
                <img src={CloseSvg} alt="close" />
              </Typography>
            </Box>
          </Box>
        ))}
    </Box>
  );
}

UploadedDocumentsList.propTypes = {
  files: PropTypes.instanceOf(Array),
  uploadPercentage: PropTypes.number,
  handleRemove: PropTypes.func,
};

UploadedDocumentsList.defaultProps = {
  files: [],
  uploadPercentage: 0,
  handleRemove: defaultFnPropTypes,
};
