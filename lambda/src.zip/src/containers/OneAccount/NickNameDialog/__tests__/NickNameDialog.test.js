import { render, screen, act, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter, allAccountsMock } from 'testHelpers';
import NickNameDialog from '..';

function TestElement() {
  return <NickNameDialog />;
}

describe('Test Nick name Dialog Component', () => {
  beforeEach(async () => {
    renderWithProviderAndRouter(<TestElement />, {
      wrapperProps: {
        initialState: {
          OneAccount: {
            showNickNameDialog: true,
            selectedLinkedTransaction: {
              posnId: '4hO_YImR1UiZFF----DF-77-',
              accId: '4hO_YImR1UiZFF----DF-77-',
              accNbr: '123443215678',
              accRtgNbr: '123456789',
              bankNm: 'Chase',
              avlbBalAmt: 10000,
              accType: 'checkings',
              accNickName: 'chello',
              accNm: 'Checkings',
            },
            linkedAccountDetails: [
              {
                posnId: '4hO_YImR1UiZFF----DF-77-',
                accId: '4hO_YImR1UiZFF----DF-77-',
                accNbr: '123443215678',
                accRtgNbr: '123456789',
                bankNm: 'Chase',
                avlbBalAmt: 10000,
                accType: 'checkings',
                accNickName: 'chello',
                accNm: 'Checkings',
              },

              {
                posnId: '4hOVLwpsEIlbKV----1F-77-',
                accId: '4hOVLwpsEIlbKV----1F-77-',
                accNbr: '987667895432',
                accRtgNbr: '123456789',
                bankNm: 'Wells Fargo',
                avlbBalAmt: 500,
                accNm: 'Savings',
                accType: 'savings',
                accNickName: 'chello',
              },
            ],
            linkedAccountsGrouped: allAccountsMock.body.linkedaccounts,
          },
        },
      },
      render,
    });

    await waitFor(() => {
      expect(screen.getByText('Nickname for:')).toBeInTheDocument();
    });
  });
  it('should render nick name dialog', async () => {
    await waitFor(() => {
      expect(screen.getByTestId('linked-nick-name')).toHaveValue('chello');
    });
  });

  it('should change nick name', async () => {
    await waitFor(() => {
      expect(screen.getByText('Nickname for:')).toBeInTheDocument();
    });
    userEvent.clear(screen.getByTestId('linked-nick-name'));
    userEvent.type(screen.getByTestId('linked-nick-name'), 'mockname');
    await waitFor(() => {
      expect(screen.getByText('Save')).toBeEnabled();
    });
    userEvent.click(screen.getByText('Save'));
    await waitFor(() => {
      expect(screen.queryByText('Nickname for:')).not.toBeInTheDocument();
    });
  });
  it('should close on click cancel', async () => {
    await waitFor(() => {
      expect(screen.getByText('Nickname for:')).toBeInTheDocument();
    });
    userEvent.click(screen.getByTestId('nickname-remove'));
    await waitFor(() => {
      expect(screen.queryByText('Nickname for:')).not.toBeInTheDocument();
    });
  });
});
