import NickNameDialog from './NickNameDialog';

export default NickNameDialog;
