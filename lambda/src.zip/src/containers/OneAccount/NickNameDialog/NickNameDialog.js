import {
  Box,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  IconButton,
} from '@mui/material';
import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useSelector, useDispatch } from 'react-redux';

import { useHandleApiFailure } from 'hooks';
import strings from 'localization/translation';
import { nickNameSchema } from 'helpers/ValidationSchema';
import { CustomInput, CustomIcon } from 'components';
import {
  showNickNameDialog,
  updateNickname,
} from 'store/actions/OneAccountActions';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import globalClasses from 'style/globalStyle.module.scss';

import Classes from '../OneAccount.module.scss';

const {
  cancel: CANCEL,
  save: SAVE,
  NicknameTitle: NICKNAME_TITLE,
  RemoveNickname: REMOVE_NICKNAME,
} = strings;
const NickNameDialog = () => {
  const dispatch = useDispatch();
  const open = useSelector((state) => state.OneAccount.showNickNameDialog);

  const handleClose = () => {
    dispatch(showNickNameDialog(false));
  };

  const selectedLinkedAccount = useSelector(
    (state) => state.OneAccount.selectedLinkedTransaction,
  );

  const linkedAccountDetails = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );
  const selectedTransaction = linkedAccountDetails.find(
    (x) =>
      x.accNbr === selectedLinkedAccount.accNbr &&
      x.accId === selectedLinkedAccount.accId,
  );

  const selectedIndex = linkedAccountDetails.findIndex(
    (x) =>
      x.accNbr === selectedLinkedAccount.accNbr &&
      x.accId === selectedLinkedAccount.accId,
  );
  const { accNickName, accNm } = selectedTransaction || '';

  const {
    control,
    handleSubmit,
    reset,
    formState: { isValid },
  } = useForm({
    mode: 'all',
    resolver: yupResolver(nickNameSchema),
  });

  useEffect(() => {
    reset({ nickName: accNickName });
  }, [accNickName, reset]);

  const handleAPIFailure = useHandleApiFailure();
  const submitHandler = (data) => {
    const totalData = [...linkedAccountDetails];
    dispatch(
      updateNickname({
        apiPayload: {
          nickname: data.nickName,
          accountid: totalData?.[selectedIndex]?.accId || '',
          accountno: totalData?.[selectedIndex]?.accNbr || '',
          operation: 'update',
        },
        failureCallback: handleAPIFailure,
      }),
    );

    resetData();
  };

  const removeNickName = () => {
    const totalData = [...linkedAccountDetails];
    dispatch(
      updateNickname({
        apiPayload: {
          nickname: '',
          accountid: totalData?.[selectedIndex]?.accId || '',
          accountno: totalData?.[selectedIndex]?.accNbr || '',
          operation: 'delete',
        },
        failureCallback: handleAPIFailure,
      }),
    );

    resetData();
  };

  const resetData = () => {
    reset({ nickName: '' });
  };

  const btnProps = {};
  if (!isValid) {
    btnProps.disabled = true;
  } else {
    btnProps.color = 'primary';
  }

  return (
    <Dialog
      open={open}
      className={Classes.nickNameDialog}
      aria-labelledby="nickNameDialog"
    >
      <IconButton
        aria-label="close"
        size="small"
        className={Classes.closeIcon}
        data-testid="nick-name-close"
        onClick={() => {
          handleClose();
          resetData();
        }}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={Classes.closeIconSize}
        />
      </IconButton>
      <DialogTitle className={Classes.noPadding} id="nickNameDialog">
        <Box display="flex" alignItems="center" gap={1.25}>
          <Typography
            component="span"
            variant="h2"
            gutterBottom
            color="grey.900"
          >
            {NICKNAME_TITLE}
          </Typography>
          <Typography
            component="span"
            variant="p1SemiBold"
            color="darkGray.800"
            gutterBottom
          >
            {accNm}
          </Typography>
        </Box>
      </DialogTitle>
      <DialogContent className={Classes.noPadding}>
        <CustomInput
          name="nickName"
          id="nickName"
          control={control}
          dataTestid="linked-nick-name"
          inputProps={{ maxLength: 15 }}
          classes={[globalClasses.p2Paragraph, Classes.nickNameInputColor].join(
            ' ',
          )}
        />
      </DialogContent>
      <DialogActions className={Classes.buttonsWrapper}>
        {!accNickName || accNm === accNickName ? (
          <Button
            variant="contained"
            onClick={() => {
              handleClose();
              resetData();
            }}
            className={globalClasses.buttonMedium}
            data-testid="nickname-cancel"
          >
            {CANCEL}
          </Button>
        ) : (
          <Button
            variant="contained"
            onClick={removeNickName}
            className={globalClasses.buttonMedium}
            data-testid="nickname-remove"
          >
            {REMOVE_NICKNAME}
          </Button>
        )}

        <Button
          variant="contained"
          onClick={handleSubmit(submitHandler)}
          data-testid="nickname-save"
          {...btnProps}
        >
          {SAVE}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default NickNameDialog;
