import { Paper, Box, Typography, Link } from '@mui/material';
import { useSelector } from 'react-redux';

import strings from 'localization/translation';
import { CustomIcon } from 'components';
import { ReactComponent as Bulb } from 'assets/svg/bulb.svg';

import Classes from '../OneAccount.module.scss';
import ChelloInsightsSections from '../ChelloInsightsSections';

const {
  chelloInsights: CHELLO_INSIGHTS,
  insightsContent1: INSIGHTS_CONTENT1,
  insightsContent2: INSIGHTS_CONTENT2,
  boostNow: BOOST_NOW,
  planBoost: PLAN_BOOST,
  or: OR,
  insightsContent3: INSIGHTS_CONTENT3,
  insightsContent4Heading: INSIGHTS_CONTENT4_HEADING,
  insightsContent4: INSIGHTS_CONTENT4,
  insightsContent5Heading: INSIGHTS_CONTENT5_HEADING,
  insightsContent5: INSIGHTS_CONTENT5,
  insightsContent6Heading: INSIGHTS_CONTENT6_HEADING,
  insightsContent6: INSIGHTS_CONTENT6,
} = strings;

const ChelloInsights = () => {
  const chelloInsights = useSelector(
    (state) => state.OneAccount.chelloInsights,
  );
  const { whatIHaveAmt = '0.00', whatIOweAmt = '0.00' } = chelloInsights;
  return (
    <Paper className={Classes.oneAccountChelloInsights}>
      <Box className={Classes.insightWrapper}>
        <Box className={Classes.insightHeading}>
          <Box component="span">
            <CustomIcon
              component={Bulb}
              inheritViewBox
              color="primary"
              className={Classes.iconSize}
            />
          </Box>
          <Typography variant="h3" color="grey.800">
            {CHELLO_INSIGHTS}
          </Typography>
        </Box>
        <Box className={Classes.wrapAmntContainer}>
          <ChelloInsightsSections
            title={INSIGHTS_CONTENT1}
            amount={whatIHaveAmt}
            descVariant="body1"
          />
          <ChelloInsightsSections
            title={INSIGHTS_CONTENT2}
            amount={whatIOweAmt}
            descVariant="body1"
          />
        </Box>
        <Box className={Classes.chelloInsightsSections}>
          <Typography variant="body2" color="grey.800">
            <Link href="#" className={Classes.insigntLink} underline="hover">
              {BOOST_NOW}{' '}
            </Link>
            {OR}{' '}
            <Link href="#" className={Classes.insigntLink} underline="hover">
              {PLAN_BOOST}{' '}
            </Link>
            {INSIGHTS_CONTENT3}
          </Typography>
        </Box>
        <ChelloInsightsSections
          title={INSIGHTS_CONTENT4_HEADING}
          description={INSIGHTS_CONTENT4}
        />
        <ChelloInsightsSections
          title={INSIGHTS_CONTENT5_HEADING}
          description={INSIGHTS_CONTENT5}
        />
        <ChelloInsightsSections
          title={INSIGHTS_CONTENT6_HEADING}
          description={INSIGHTS_CONTENT6}
        />
      </Box>
    </Paper>
  );
};

export default ChelloInsights;
