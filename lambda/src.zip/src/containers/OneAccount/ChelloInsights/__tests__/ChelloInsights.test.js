import { render, screen } from '@testing-library/react/pure';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

describe('Test chello Insights', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should display What I owe amount, under all tab', async () => {
    expect(await screen.findByText('$ 1,420.04')).toBeInTheDocument();
  });
});
