import ChelloInsights from './ChelloInsights';

export default ChelloInsights;
