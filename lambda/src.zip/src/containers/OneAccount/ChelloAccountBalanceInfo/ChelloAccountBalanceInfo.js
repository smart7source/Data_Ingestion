import { styled } from '@mui/material/styles';
import NumberFormat from 'react-number-format';
import { Typography, Grid, Box, useMediaQuery } from '@mui/material';
import LinearProgress, {
  linearProgressClasses,
} from '@mui/material/LinearProgress';
import PropTypes from 'prop-types';

import strings from 'localization/translation';

import Classes from '../OneAccount.module.scss';

const { utilizedAmount: UTILIZE_AMOUNT, spendBalance: SPEND_BALANCE } = strings;

const BorderLinearProgress = styled(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor: '#DCDCDC',
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: '#A120D1',
  },
}));

const ChelloAccountBalanceInfo = (props) => {
  const belowSm = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const {
    utilizedAmount,
    availableToSpendBalanceAmount,
    availableToSpendBalancePercentage,
    totalLimit,
  } = props;

  return (
    <>
      <Grid
        item
        xs={12}
        sm={12}
        container
        direction="row"
        justifyContent="space-between"
        alignItems="flex-start"
      >
        <Grid item>
          <Typography
            variant={belowSm ? 'p3' : 'p2'}
            component="p"
            color="grey.800"
          >
            {UTILIZE_AMOUNT}
          </Typography>
          <Typography
            component="h1"
            variant={belowSm ? 'h2' : 'h1'}
            letterSpacing={0.8}
            color="grey.800"
          >
            <NumberFormat
              value={utilizedAmount}
              displayType="text"
              thousandSeparator
              prefix="$ "
              decimalScale="2"
              fixedDecimalScale
            />
          </Typography>
        </Grid>
        <Grid item>
          <Typography
            variant={belowSm ? 'p3' : 'p2'}
            component="p"
            color="grey.800"
          >
            {SPEND_BALANCE}
          </Typography>
          <Typography
            component="h1"
            variant={belowSm ? 'h2' : 'h1'}
            letterSpacing={0.8}
            className={Classes.availableBalanceText}
          >
            <NumberFormat
              value={availableToSpendBalanceAmount}
              displayType="text"
              thousandSeparator
              prefix="$ "
              decimalScale="2"
              fixedDecimalScale
            />
          </Typography>
        </Grid>
      </Grid>
      <Grid item xs={12} sm={12} container direction="column" gap={1.25}>
        <Box className={Classes.boostProgress}>
          <BorderLinearProgress
            variant="determinate"
            value={availableToSpendBalancePercentage}
          />
        </Box>
        <Typography
          variant="p2"
          component="p"
          color="#6B7280"
          alignSelf="flex-end"
        >
          <NumberFormat
            value={totalLimit}
            displayType="text"
            thousandSeparator
            prefix="$ "
            suffix=" limit"
            decimalScale="2"
            fixedDecimalScale
          />
        </Typography>
      </Grid>
    </>
  );
};

export default ChelloAccountBalanceInfo;

ChelloAccountBalanceInfo.propTypes = {
  utilizedAmount: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  availableToSpendBalanceAmount: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
  availableToSpendBalancePercentage: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
  totalLimit: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
};

ChelloAccountBalanceInfo.defaultProps = {
  utilizedAmount: '',
  availableToSpendBalanceAmount: '',
  availableToSpendBalancePercentage: '',
  totalLimit: '',
};
