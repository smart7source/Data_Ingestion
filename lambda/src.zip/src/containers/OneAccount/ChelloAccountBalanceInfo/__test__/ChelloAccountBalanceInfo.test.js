import { render, screen, act, waitFor } from '@testing-library/react/pure';

import { renderWithProviderAndRouter } from 'testHelpers';
import { routePath } from 'routes';
import Accounts from 'containers/OneAccount/Accounts';

describe('Testing ChelloAccountBalanceInfo component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });

  it('should display details of utilized amount and available to spend in progress bar under chello account details section', async () => {
    expect(await screen.findByText('$ 5,200.00')).toBeInTheDocument();
    expect(screen.getByText('$ 1,300.00')).toBeInTheDocument();
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });
});
