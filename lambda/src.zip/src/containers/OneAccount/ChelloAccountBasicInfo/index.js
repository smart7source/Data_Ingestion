import ChelloAccountBasicInfo from './ChelloAccountBasicInfo';

export default ChelloAccountBasicInfo;
