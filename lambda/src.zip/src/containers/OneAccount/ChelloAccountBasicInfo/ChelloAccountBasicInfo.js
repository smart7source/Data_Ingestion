import { Typography, Grid, Box, useMediaQuery } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';

import Classes from '../OneAccount.module.scss';
import ShowInfo from '../ShowInfo';

const {
  oneAccountBoostByChello: BOOST_BY_CHELLO,
  lineOfCredit: LINE_OF_CREDIT,
  infoContent: INFO_CONTENT,
} = strings;

const ChelloAccountBasicInfo = (props) => {
  const belowSm = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const { accountNumber } = props;

  return (
    <>
      <Grid
        item
        xs={12}
        sm={12}
        container
        direction="row"
        justifyContent="space-between"
        alignItems="center"
      >
        <Box component="span" className={Classes.chelloAccountsTitle}>
          <img
            src={`${process.env.PUBLIC_URL}/images/boost-logo.png`}
            alt="boost"
            height={belowSm ? '24px' : '32px'}
            width={belowSm ? '24px' : '32px'}
          />
          <Typography component="h2" variant="h2" color="grey.900">
            {BOOST_BY_CHELLO}
          </Typography>
          <ShowInfo content={INFO_CONTENT} />
        </Box>
        <Typography variant="p1" component="p" color="grey.600">
          {accountNumber}
        </Typography>
      </Grid>
      <Grid item xs={12} sm={12} container direction="row">
        <Box mb={4} mt={1.5}>
          <Typography
            className={Classes.chelloCaption}
            variant="p1"
            component="p"
            color="grey.800"
          >
            {LINE_OF_CREDIT}
          </Typography>
        </Box>
      </Grid>
    </>
  );
};

export default ChelloAccountBasicInfo;

ChelloAccountBasicInfo.propTypes = {
  accountNumber: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
};

ChelloAccountBasicInfo.defaultProps = {
  accountNumber: '',
};
