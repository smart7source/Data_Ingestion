import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';
import strings from 'localization/translation';

const { infoContent: INFO_CONTENT, lineOfCredit: LINE_OF_CREDIT } = strings;

describe('Testing ChelloAccount Basic Info component', () => {
  beforeEach(async () => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });

  it('should display chello account basic info', () => {
    expect(screen.getByText(LINE_OF_CREDIT)).toBeInTheDocument();
  });
  it('should display info when info icon is clicked', async () => {
    userEvent.click(screen.getByTestId('info-icon'));
    expect(await screen.findByText(INFO_CONTENT)).toBeInTheDocument();
  });
});
