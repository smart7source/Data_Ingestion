export { default } from './LinkedAccountEachTransaction';
