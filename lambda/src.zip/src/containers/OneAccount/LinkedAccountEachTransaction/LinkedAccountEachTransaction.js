import { useState, useEffect, memo } from 'react';
import {
  Box,
  Typography,
  IconButton,
  TableCell,
  TableRow,
  Chip,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
import NumberFormat from 'react-number-format';

import strings from 'localization/translation';
import { CustomIcon, KebabMenu } from 'components';
import serviceUrl from 'api/UrlHelper';
import {
  defaultFnPropTypes,
  formatDateToString,
  maskAccountNumber,
  isCheckingsAccount,
  getFormattedTransactionDate,
  getAccountName,
} from 'utils';
import { useInfiniteScroll, useHandleApiFailure } from 'hooks';
import {
  fetchOneAccTransactions,
  showDetailsDialog,
  setSelectedTransactionIndex,
  setLinkedAccountAccNbr,
} from 'store/actions/OneAccountActions';
import { ReactComponent as ChevronUp } from 'assets/svg/chevron-up.svg';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';

import ChelloAccountEachTransaction from '../ChelloAccountEachTransaction';
import NoLinkedAccounts from '../NoLinkedAccounts';
import Classes from '../OneAccount.module.scss';

const {
  savings: SAVINGS_ACCOUNT,
  checking: CHECKING_ACCOUNT,
  noTransaction: NO_TRANSACTION,
} = strings;

const LinkedAccountEachTransaction = (props) => {
  const {
    mainKebabOptions,
    onMainMenuOptionClick,
    index,
    defaultOpen,
    accountDetails,
    selectedLinkedAccount,
    paymentTypes,
  } = props;

  const [open, setOpen] = useState(defaultOpen);
  const dispatch = useDispatch();

  const listOptions = [
    {
      name: 'Details',
    },
  ];
  const id = `linked-account-${index}`;
  const ariaLabel = `linked transaction ${index}`;

  const accordionId = `linked-account-accordion-${index}`;

  const onListMenuOptionClick = (option, listindex, key) => {
    dispatch(setSelectedTransactionIndex(listindex));
    if (option.name === 'Details') {
      dispatch(setLinkedAccountAccNbr(key));
      dispatch(showDetailsDialog(true));
    }
  };

  const {
    accNbr = '',
    posnId: positionId = '',
    accSubType = '',
    avlbBalAmt = '',
    bankNm = '',
    accNickName = '',
    accNm = '',
    transactionsCount = '215',
    instId = 'chaseplus',
    logoFormat = 'png',
  } = accountDetails;

  const bankName = getAccountName({ bankNm, accNickName, accNm });

  const linkedAccountTransactions = useSelector(
    (state) => state.OneAccount.linkedAccountTransactions?.[accNbr] || [],
  );
  const totalTransactions = linkedAccountTransactions.length;

  useEffect(() => {
    setOpen(defaultOpen);
  }, [defaultOpen]);

  const accNnumber = maskAccountNumber(accNbr);

  const {
    fromDate,
    toDate,
    searchType = '',
    searchText = '',
    nextPageKey = 'first',
  } = useSelector((state) => state.OneAccount.transactionFilter);

  const loading = useSelector((state) => state.global.loading);

  const handleAPIFailure = useHandleApiFailure();

  const loadMore = () => {
    if (accNbr && nextPageKey && nextPageKey !== 'first') {
      dispatch(
        fetchOneAccTransactions({
          accountNumber: accNbr,
          positionId,
          fromDate: formatDateToString(fromDate, 'YYYY-MM-DD'),
          toDate: formatDateToString(toDate, 'YYYY-MM-DD'),
          searchType,
          searchText,
          nextPageKey,
          loadMore: true,
          account: 'external',
          failureCallback: handleAPIFailure,
        }),
      );
    }
  };

  const lastElRef = useInfiniteScroll({
    loading,
    hasMore: true,
    loadMore,
  });

  const accountType = isCheckingsAccount(accSubType)
    ? CHECKING_ACCOUNT
    : SAVINGS_ACCOUNT;

  return (
    <>
      <TableRow>
        <TableCell
          colSpan={4}
          component="th"
          scope="colgroup"
          className={Classes.transactionsPadding}
        >
          <Box className={Classes.transactionColGroup}>
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={() => setOpen(!open)}
            >
              {open ? (
                <CustomIcon
                  component={ChevronUp}
                  color="grey.800"
                  inheritViewBox
                  className={Classes.chevronIconSize}
                  data-testid={accordionId}
                />
              ) : (
                <CustomIcon
                  component={ChevronDown}
                  color="grey.800"
                  inheritViewBox
                  className={Classes.chevronIconSize}
                  data-testid={accordionId}
                />
              )}
            </IconButton>
            <Box className={Classes.transactionMainDataWrapper}>
              <Box className={Classes.transactionMainData}>
                <Box className={Classes.alignCenter}>
                  <img
                    width="25px"
                    height="25px"
                    style={{ borderRadius: '50%', alignSelf: 'center' }}
                    src={`${serviceUrl.externalBankImagesPath}${instId}.${logoFormat}`}
                    alt=""
                  />
                </Box>
                <Box className={Classes.bankDataWrapper}>
                  <Typography variant="p1SemiBold">{bankName}</Typography>
                  <Typography variant="p2">{accNnumber}</Typography>
                </Box>
                <Box>
                  <Chip
                    label={accountType}
                    color="success"
                    className={Classes.chip}
                  />
                </Box>
                <Typography variant="p2">{`(${transactionsCount})`}</Typography>
              </Box>
              <Box className={Classes.alignCenter}>
                <Typography variant="p1SemiBold">
                  <NumberFormat
                    value={avlbBalAmt}
                    displayType="text"
                    thousandSeparator
                    prefix="$ "
                    decimalScale="2"
                    fixedDecimalScale
                  />
                </Typography>
                <KebabMenu
                  options={mainKebabOptions}
                  onMenuOptionClick={onMainMenuOptionClick}
                  ariaLabel={ariaLabel}
                  id={id}
                />
              </Box>
            </Box>
          </Box>
        </TableCell>
      </TableRow>
      {open &&
        (linkedAccountTransactions?.length ? (
          linkedAccountTransactions.map((eachTransaction, listIndex) => {
            const {
              amount = '',
              balance = '',
              category = '',
              date = '',
              description = '',
              descriptionTwo = '',
              transactionId = '',
            } = eachTransaction;
            const key = `${transactionId}${listIndex}`;
            const formattedDate = getFormattedTransactionDate(date);

            return (
              <ChelloAccountEachTransaction
                key={key}
                date={formattedDate}
                descriptionOne={description}
                descriptionTwo={descriptionTwo}
                amount={amount}
                balance={balance}
                typeOrCategory={category}
                index={listIndex}
                onMenuOptionClick={(option) =>
                  onListMenuOptionClick(option, listIndex, accNbr)
                }
                kebabOptions={listOptions}
                account={`external-${index}`}
                lastElRef={
                  selectedLinkedAccount !== 'all' &&
                  totalTransactions === listIndex + 1
                    ? lastElRef
                    : null
                }
                paymentTypes={paymentTypes}
              />
            );
          })
        ) : (
          <NoLinkedAccounts colSpan={4} message={NO_TRANSACTION} />
        ))}
    </>
  );
};
export default memo(LinkedAccountEachTransaction);

LinkedAccountEachTransaction.propTypes = {
  mainKebabOptions: PropTypes.instanceOf(Object),
  onMainMenuOptionClick: PropTypes.func,
  index: PropTypes.number,
  defaultOpen: PropTypes.bool,
  accountDetails: PropTypes.instanceOf(Object),
  selectedLinkedAccount: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  paymentTypes: PropTypes.instanceOf(Array),
};
LinkedAccountEachTransaction.defaultProps = {
  mainKebabOptions: [],
  onMainMenuOptionClick: defaultFnPropTypes,
  index: 0,
  defaultOpen: false,
  accountDetails: {},
  selectedLinkedAccount: '',
  paymentTypes: [],
};
