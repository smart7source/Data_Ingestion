import {
  render,
  screen,
  waitFor,
  fireEvent,
} from '@testing-library/react/pure';
import { rest } from 'msw';
import userEvent from '@testing-library/user-event';

import {
  renderWithProviderAndRouter,
  mockMatchMediaToDesktop,
} from 'testHelpers';
import { findNextWorkingDay } from 'utils';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';

import ChelloAccountPayIt from '../../ChelloAccountPayIt';

const initialState = {
  OneAccount: {
    chelloAccountDetails: {
      accounts: [
        {
          avlbToSpdtBalAmt: 5200,
          utlzBalAmt: 1300,
          pymtDueAmt: 120.04,
          pastPymtDueImitAmt: 120.04,
          otsgFeesAmt: 2.18,
          intRate: 6.55,
          accNm: 'Dynamic Line',
          posnNbr: '4hOVLwpsEIlbKV----1F-77-',
          accRtgNbr: '987651234',
          accNbr: '1234567890',
          apprvBalAmt: 15000,
          payoffAmount: 1600,
          minimumPayment: 50,
        },
      ],
    },
    linkedAccountDetails: [
      {
        posnId: '4hO_YImR1UiZFF----DF-77-',
        accId: '4hO_YImR1UiZFF----DF-77-',
        accNbr: '123443215678',
        accRtgNbr: '123456789',
        bankNm: 'Chase',
        avlbBalAmt: 10000,
        accNm: 'Checking',
      },
      {
        posnId: '4hOVLwpsEIlbKV----1F-77-',
        accId: '4hOVLwpsEIlbKV----1F-77-',
        accNbr: '987667895432',
        accRtgNbr: '123456789',
        bankNm: 'Wells Fargo',
        avlbBalAmt: 500,
        accNm: 'Savings',
      },
    ],
  },
};
const postOneAccountSuccessMock = {
  status: {
    code: '200',
    description:
      'Some transfers are initiated successfully but some are failed',
  },
  body: {
    successResponseList: [
      {
        id: 'Test1',
        responseCode: 201,
        responseMessage: 'Transaction initiated successfully',
        customeResponseMessage: 'Success',
        value: {
          sourceParty: '4h8mVGoSm2u85----V9F-E7-',
          counterParty: '4h9kKvOSFAiReV----LF-77-',
          transferAmt: 10,
          transactionRequestNbr: '4heYaqk2jlWPY---0-TF-8w-',
          id: 'Test1',
        },
      },
      {
        id: 'Test2',
        responseCode: 201,
        responseMessage: 'Transaction initiated successfully',
        customeResponseMessage: 'Success',
        value: {
          sourceParty: '5h8mVGoSm2u85----V9F-E7-',
          counterParty: '5h9kKvOSFAiReV----LF-77-',
          transferAmt: 10,
          transactionRequestNbr: '4heYaqk2jlWPY---0-TF-8w-',
          id: 'Test2',
        },
      },
    ],
    errorResponseList: [],
  },
  header: {},
};

describe('Testing Payit confirmation modal Flow', () => {
  let paymentDate;
  let payAmount;

  beforeAll(() => {
    mockMatchMediaToDesktop();
    renderWithProviderAndRouter(<ChelloAccountPayIt />, {
      render,
      wrapperProps: {
        initialState,
      },
    });
  });
  it('should render the Pay it component', async () => {
    expect(screen.getByText('Pay loan')).toBeInTheDocument();
  });

  it('should accept a valid date value', async () => {
    paymentDate = screen.getByTestId('payit-paymentDate');
    const today = new Date();
    const nextWorkingDay = findNextWorkingDay(today).toLocaleDateString('en', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });
    userEvent.type(paymentDate, nextWorkingDay);
    await waitFor(() =>
      expect(
        screen.queryByText("Date cannot be lesser than today's date"),
      ).not.toBeInTheDocument(),
    );
    expect(
      screen.queryByText('Transactions are not allowed in weekends'),
    ).not.toBeInTheDocument();
  });

  it('should accept a valid amount', async () => {
    payAmount = screen.getByTestId('enter-amount-field');
    fireEvent.change(payAmount, {
      target: {
        value: '1000',
      },
    });
    await waitFor(() =>
      expect(
        screen.queryByText('Amount cannot be empty'),
      ).not.toBeInTheDocument(),
    );
  });

  it('should enable the continue button when valid details are provided', async () => {
    fireEvent.change(screen.getByTestId('bankAccounts-0-debitAmount'), {
      target: {
        value: '1000',
      },
    });
    await waitFor(() => {
      expect(screen.getByText('Continue')).toBeEnabled();
    });
  });
  it('should open review transfer dialog on clicking continue', async () => {
    userEvent.click(screen.getByText('Continue'));
    expect(
      await screen.findByText('Your cash is ready for take-off.'),
    ).toBeInTheDocument();
  });
  it('should submit transfer request after review', async () => {
    server.use(
      rest.post(serviceUrl.postOneAccountTransfer, (req, res, ctx) =>
        res(ctx.json(postOneAccountSuccessMock)),
      ),
    );

    userEvent.click(screen.getByTestId('oneaccount-review-submit'));
    await waitFor(() => {
      expect(
        screen.queryByText('Your cash is ready for take-off.'),
      ).not.toBeInTheDocument();
    });
  });
  it('should show payment confirmation dialog once transfer is done', async () => {
    await waitFor(async () => {
      expect(screen.getByText('Time to boogie.')).toBeInTheDocument();
    });
  });
});
