import TransactionConformModel from './TransactionConformModel';

export default TransactionConformModel;
