import PropTypes from 'prop-types';
import {
  Button,
  IconButton,
  Dialog,
  Grid,
  Typography,
  Box,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';

import globalClasses from 'style/globalStyle.module.scss';
import { CustomIcon } from 'components';
import { defaultFnPropTypes } from 'utils';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle.svg';
import { ReactComponent as AlertCircle } from 'assets/svg/alert-circle.svg';

import Classes from '../OneAccount.module.scss';

const TransactionConformModel = ({
  modal,
  headTitle,
  handleClosePayItModal,
  content,
  status,
  statusImage,
  confirmationId,
  confirmationDate,
  amount,
}) => {
  let customIconComponent;
  let customIconColor;
  if (status === 'success') {
    customIconComponent = CheckmarkCircle;
    customIconColor = 'success';
  } else if (status === 'failure') {
    customIconComponent = AlertCircle;
    customIconColor = 'error';
  } else {
    customIconComponent = AlertCircle;
    customIconColor = 'warning';
  }
  return (
    <>
      <Dialog
        open={modal}
        fullWidth
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className={Classes.payIndilogeContainer}
        maxWidth="sm"
      >
        <IconButton
          aria-label="close"
          size="small"
          className={Classes.closeIcon}
          onClick={handleClosePayItModal}
        >
          <CustomIcon
            component={Close}
            color="grey.800"
            inheritViewBox
            className={Classes.closeIconSize}
          />
        </IconButton>
        <DialogTitle
          id="alert-dialog-title"
          className={globalClasses.h1Headline}
        >
          {headTitle}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description" component="div">
            <Grid>
              <Grid>
                <Box
                  className={[
                    globalClasses.p1Paragraph,
                    Classes.payInheaderDialog,
                  ].join(' ')}
                >
                  <CustomIcon
                    component={customIconComponent}
                    color={customIconColor}
                    inheritViewBox
                    className={Classes.iconSize}
                  />

                  {content?.replace('<$amount>', amount)}
                </Box>
              </Grid>
              <Grid>
                <Box className={Classes.payIncontentDialog}>{statusImage}</Box>
              </Grid>
              {confirmationId.length > 0 && (
                <Box className={Classes.payInDetailsDialogContaine}>
                  <Box className={Classes.payInDetailsDialog}>
                    <Typography
                      variant="h3"
                      component="span"
                      className={Classes.firstChild}
                      align="right"
                    >
                      Confirmation
                    </Typography>
                    <Box>
                      {confirmationId.map((x, index) => (
                        <Typography component="span" align="left" key={index}>
                          {x}
                        </Typography>
                      ))}
                    </Box>
                    <Typography
                      variant="h3"
                      component="span"
                      className={Classes.firstChild}
                      align="right"
                    >
                      Date
                    </Typography>
                    <Typography component="span" align="left">
                      {confirmationDate}
                    </Typography>
                  </Box>
                </Box>
              )}
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleClosePayItModal}
            className={Classes.makePayInSuccBtn}
            color="primary"
            size="large"
            variant="contained"
          >
            Ok
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default TransactionConformModel;

TransactionConformModel.propTypes = {
  modal: PropTypes.bool,
  handleClosePayItModal: PropTypes.func,
  headTitle: PropTypes.string,
  content: PropTypes.string,
  status: PropTypes.string,
  confirmationId: PropTypes.instanceOf(Object),
  confirmationDate: PropTypes.string,
  statusImage: PropTypes.element,
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

TransactionConformModel.defaultProps = {
  modal: false,
  handleClosePayItModal: defaultFnPropTypes,
  headTitle: '',
  content: '',
  status: '',
  confirmationId: [],
  confirmationDate: '',
  statusImage: null,
  amount: '',
};
