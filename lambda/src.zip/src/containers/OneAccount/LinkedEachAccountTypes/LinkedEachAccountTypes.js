import { useState, useContext } from 'react';
import {
  Box,
  IconButton,
  TableCell,
  TableRow,
  Typography,
  useMediaQuery,
} from '@mui/material';
import NumberFormat from 'react-number-format';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
import clsx from 'clsx';

import {
  linkedAccountOptions,
  isCheckingsAccount,
  getAccountName,
  getNewMenuOptions,
} from 'utils';
import { useDisableUnlink, useHandleApiFailure } from 'hooks';
import strings from 'localization/translation';
import {
  setSelectedAccount,
  showNickNameDialog,
  unlinkAccount,
  fetchAllAccDetails,
} from 'store/actions/OneAccountActions';
import { ReactComponent as ChevronUp } from 'assets/svg/chevron-up.svg';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';
import { CustomIcon } from 'components';
import { NotificationContext } from 'contexts';

import Classes from '../OneAccount.module.scss';
import LinkedEachAccount from '../LinkedEachAccount';

const { savingsAccount: SAVINGS_ACCOUNT, checkingsAccount: CHECKING_ACCOUNT } =
  strings;

const LinkedEachAccountTypes = (props) => {
  const belowSm = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const contextValue = useContext(NotificationContext);
  const { setNotification } = contextValue;
  const dispatch = useDispatch();
  const { accountType, index } = props;
  const [open, setOpen] = useState(true);

  const linkedAccounts = useSelector(
    (state) =>
      state.OneAccount.linkedAccountsGrouped?.[accountType]?.accounts || [],
  );
  const total = useSelector(
    (state) =>
      state.OneAccount.linkedAccountsGrouped?.[accountType]?.total || [],
  );

  const origLinkedAccountDetails = useSelector(
    (state) => state.OneAccount.linkedAccountDetails || [],
  );

  const handleAPIFailure = useHandleApiFailure();

  const onMenuOptionClick = (account) => (option) => {
    const { posnId = '' } = account;
    dispatch(setSelectedAccount(account));
    if (option.name === 'Nickname' || option.name === 'Rename') {
      dispatch(showNickNameDialog(true));
    }
    if (option.name === 'Unlink') {
      if (origLinkedAccountDetails.length > 1) {
        dispatch(
          unlinkAccount({
            id: posnId,
            successCallback: handleApiSuccess,
            failureCallback: handleAPIFailure,
          }),
        );
      }
    }
  };

  const handleApiSuccess = () => {
    dispatch(fetchAllAccDetails({ failureCallback: handleAPIFailure }));
    setNotification([
      {
        severity: 'success',
        message: 'Account unlinked successfully',
      },
    ]);
  };

  const menuOptions = useDisableUnlink(linkedAccountOptions);

  const accType = isCheckingsAccount(accountType)
    ? CHECKING_ACCOUNT
    : SAVINGS_ACCOUNT;

  return (
    <>
      <TableRow>
        <TableCell
          colSpan={2}
          component="th"
          scope="colgroup"
          className={clsx(
            open ? Classes.accountZeroPadding : Classes.accountPadding,
            index === 0 ? Classes.firstAccountType : '',
          )}
        >
          <Box className={Classes.accountTableColGroup}>
            <Box display="flex" gap="5px" alignItems="center">
              <Typography variant="h3" color="grey.800">
                {accType}
              </Typography>
              {!belowSm && (
                <IconButton
                  aria-label="expand row"
                  size="small"
                  onClick={() => setOpen(!open)}
                >
                  {open ? (
                    <CustomIcon
                      component={ChevronUp}
                      color="grey.800"
                      inheritViewBox
                      className={Classes.chevronIconSize}
                    />
                  ) : (
                    <CustomIcon
                      component={ChevronDown}
                      color="grey.800"
                      inheritViewBox
                      className={Classes.chevronIconSize}
                    />
                  )}
                </IconButton>
              )}
            </Box>
            <Typography component="span" variant="h3" color="grey.800">
              <NumberFormat
                value={total}
                displayType="text"
                thousandSeparator
                prefix="$ "
                decimalScale="2"
                fixedDecimalScale
              />
            </Typography>
          </Box>
        </TableCell>
      </TableRow>
      {(open || belowSm) &&
        linkedAccounts.map((eachAcc, indx) => {
          const {
            instId = 'chaseplus',
            logoFormat = 'png',
            bankNm,
            accNickName,
            accNm,
            accNbr,
            avlbBalAmt,
          } = eachAcc;

          const bankName = getAccountName({ bankNm, accNickName, accNm });
          const newOptions = getNewMenuOptions(menuOptions, accNm, accNickName);

          return (
            <LinkedEachAccount
              logo={`${instId}.${logoFormat}`}
              accName={bankName}
              accNo={accNbr}
              balance={avlbBalAmt}
              index={indx}
              key={`${eachAcc.accNbr}-${indx}`}
              options={newOptions}
              onMenuOptionClick={onMenuOptionClick(eachAcc)}
            />
          );
        })}
    </>
  );
};

LinkedEachAccountTypes.propTypes = {
  accountType: PropTypes.string,
  index: PropTypes.number,
};

LinkedEachAccountTypes.defaultProps = {
  accountType: '',
  index: 0,
};

export default LinkedEachAccountTypes;
