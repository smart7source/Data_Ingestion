import LinkedEachAccountTypes from './LinkedEachAccountTypes';

export default LinkedEachAccountTypes;
