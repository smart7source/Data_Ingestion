import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';

import { renderWithProviderAndRouter, allAccountsMock } from 'testHelpers';
import NotificationContext from 'contexts/NotificationContext';

import AllAccountDetails from '../../AllAccountDetails';

describe('Test Linked Each Accounts Types Component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  const TestElement = () => {
    const [notification, setNotification] = useState([]);
    return (
      <NotificationContext.Provider value={{ notification, setNotification }}>
        {!!notification.length && (
          <div data-testid="notification-msg">{notification[0].message}</div>
        )}
        <AllAccountDetails />
      </NotificationContext.Provider>
    );
  };

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<TestElement />, {
      wrapperProps: {
        initialState: {
          OneAccount: {
            chelloAccountDetails: allAccountsMock.body.chelloaccounts,
            selectedLinkedTransaction: {},
            linkedAccountDetails: [
              {
                posnId: '4hO_YImR1UiZFF----DF-77-',
                accId: '4hO_YImR1UiZFF----DF-77-',
                accNbr: '123443215678',
                accRtgNbr: '123456789',
                bankNm: 'Chase',
                avlbBalAmt: 10000,
                accType: 'checkings',
                accNickName: 'external checking',
              },
              {
                posnId: '4hOVLwpsEIlbKV----1F-77-',
                accId: '4hOVLwpsEIlbKV----1F-77-',
                accNbr: '987667895432',
                accRtgNbr: '123456789',
                bankNm: 'Wells Fargo',
                avlbBalAmt: 500,
                accNm: 'Savings',
                accType: 'savings',
                accNickName: 'external savings',
              },
            ],
            linkedAccountsGrouped: allAccountsMock.body.linkedaccounts,
            showNickNameDialog: false,
            transactionFilter: {
              fromDate: '',
              toDate: '',
              searchType: '',
              searchTerm: '',
              nextPageKey: 'first',
            },
          },
          global: {
            refData: {},
            loader: [],
            isAuthenticated: false,
            floatingChatbot: {
              enableFloatingChatbot: false,
              maximize: true,
            },
          },
        },
      },
      render,
    });
    expect(await screen.findByText('external checking')).toBeInTheDocument();
  });

  it('should able to see menu options on accounts', async () => {
    const kebabMenu = screen.getAllByTestId(
      'kebab-menu-external-account-0-btn',
    )[0];
    const unlink = screen.findByText('Unlink');
    await waitFor(() => {
      expect(kebabMenu).toBeInTheDocument();
    });
    userEvent.click(kebabMenu);
    await unlink;
  });
  it('should unlink account', async () => {
    userEvent.click(screen.getByText('Unlink'));
    expect(await screen.findByTestId('notification-msg')).toBeInTheDocument();
  });
  it('should open nickname dialog', async () => {
    const kebabMenu = screen.getAllByTestId(
      'kebab-menu-external-account-0-btn',
    )[0];
    const Nickname = screen.findByText('Rename');
    await waitFor(() => {
      expect(kebabMenu).toBeInTheDocument();
    });
    userEvent.click(kebabMenu);
    await Nickname;
    userEvent.click(screen.getByText('Rename'));
  });
  it('should change nickname', async () => {
    await waitFor(() => {
      expect(screen.getByText('Nickname for:')).toBeInTheDocument();
    });
    userEvent.clear(screen.getByTestId('linked-nick-name'));
    userEvent.type(screen.getByTestId('linked-nick-name'), 'mockname');
    await waitFor(() => {
      expect(screen.getByText('Save')).toBeEnabled();
    });
    userEvent.click(screen.getByText('Save'));
    await waitFor(() => {
      expect(screen.getByText('mockname')).toBeInTheDocument();
    });
  });
});
