import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { memo } from 'react';
import NumberFormat from 'react-number-format';

import classes from '../OneAccount.module.scss';

const LinkedAccountSelectorCategory = (props) => {
  const { name, amount } = props;
  return (
    <Box className={classes.linkedAccountSelectorCategoryValue}>
      <Typography variant="p1" color="#464646">
        {name}
      </Typography>
      <Typography component="span" variant="p2SemiBold" color="#6B7280">
        <NumberFormat
          value={amount}
          displayType="text"
          thousandSeparator
          prefix="$ "
          decimalScale="2"
          fixedDecimalScale
        />
      </Typography>
    </Box>
  );
};

LinkedAccountSelectorCategory.propTypes = {
  name: PropTypes.string,
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

LinkedAccountSelectorCategory.defaultProps = {
  name: '',
  amount: '',
};
export default memo(LinkedAccountSelectorCategory);
