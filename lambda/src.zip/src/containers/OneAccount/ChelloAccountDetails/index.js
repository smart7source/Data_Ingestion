import ChelloAccountDetails from './ChelloAccountDetails';

export default ChelloAccountDetails;
