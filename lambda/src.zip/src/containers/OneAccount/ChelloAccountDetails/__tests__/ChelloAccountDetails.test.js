import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

describe('Testing ChelloAccount details component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });

  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });

  it('should render chello tab', async () => {
    userEvent.click(screen.getByTestId('one-account-chello-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });

  it('should display chello account info', async () => {
    await screen.findByTestId('kebab-menu-chello-transaction-0-btn');
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });

  it('should display transaction filter', () => {
    expect(screen.getByTestId('transaction-export-button')).toBeInTheDocument();
  });

  it('should display pay it view when pay it button is clicked', async () => {
    userEvent.click(screen.getByTestId('chello-pay-it-btn'));
    expect(await screen.findByText('Pay loan')).toBeInTheDocument();
  });
});
