import { Box, Paper } from '@mui/material';
import PropTypes from 'prop-types';

import Classes from '../OneAccount.module.scss';
import PayOrBoostChelloAccounts from '../PayOrBoostChelloAccounts';

const ChelloAccountDetails = ({ handleTabChange }) => (
  <Paper className={Classes.chelloAccountDetails}>
    <Box className={Classes.chelloAccountDetailsWrapper}>
      <PayOrBoostChelloAccounts handleTabChange={handleTabChange} />
    </Box>
  </Paper>
);

export default ChelloAccountDetails;

ChelloAccountDetails.propTypes = {
  handleTabChange: PropTypes.func.isRequired,
};
