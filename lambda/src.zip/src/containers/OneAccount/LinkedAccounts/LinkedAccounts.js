import { Box } from '@mui/material';
import { useState, useEffect, memo } from 'react';
import { useDispatch } from 'react-redux';

import {
  fetchLinkedAccDetails,
  resetTransactionFilter,
} from 'store/actions/OneAccountActions';
import { Notification } from 'components';
import { NotificationContext } from 'contexts';
import { useHandleApiFailure } from 'hooks';

import ChelloInsights from '../ChelloInsights';
import LinkedAccountDetails from '../LinkedAccountDetails';
import TransactionDetailDialog from '../TransactionDetailDialog/TransactionDetailDialog';
import Classes from '../OneAccount.module.scss';

const LinkedAccounts = () => {
  const dispatch = useDispatch();
  const [notification, setNotification] = useState([]);
  const handleAPIFailure = useHandleApiFailure(setNotification);
  useEffect(() => {
    dispatch(fetchLinkedAccDetails({ failureCallback: handleAPIFailure }));
  }, [dispatch, handleAPIFailure]);

  useEffect(
    () => () => {
      dispatch(resetTransactionFilter());
    },
    [dispatch],
  );
  return (
    <NotificationContext.Provider value={{ notification, setNotification }}>
      {!!notification.length && (
        <Box mb={2.5}>
          <Notification errors={notification} needFocus />
        </Box>
      )}
      <Box className={Classes.chellAccounts}>
        <LinkedAccountDetails />
        <ChelloInsights />
        <TransactionDetailDialog accountType="external" />
      </Box>
    </NotificationContext.Provider>
  );
};

export default memo(LinkedAccounts);
