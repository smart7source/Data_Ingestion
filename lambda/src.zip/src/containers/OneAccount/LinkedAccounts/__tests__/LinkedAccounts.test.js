import { render, screen } from '@testing-library/react/pure';
import { usePlaidLink } from 'react-plaid-link';
import { rest } from 'msw';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';

import LinkedAccounts from '..';


jest.mock('react-plaid-link', () => ({
  ...jest.requireActual('react-plaid-link'),
  usePlaidLink: jest.fn(),
}));

describe('Test Linked Accounts Component', () => {
  beforeEach(() => {
    usePlaidLink.mockImplementation(() => ({ ready: false, open: jest.fn() }));
  });
  it('should render linked accounts tab', async () => {
    renderWithProviderAndRouter(<LinkedAccounts />, { render });
  });

  it('should render linked account details', async () => {
    expect(
      screen.getByTestId('linked-tab-linked-account-heading'),
    ).toBeInTheDocument();
  });

  it('should render chello insights', () => {
    expect(screen.getByText('Chello Insights')).toBeInTheDocument();
  });

  it('should render Linked Accounts', async () => {
    expect(
      screen.queryByTestId('linked-tab-linked-account-heading'),
    ).toBeInTheDocument();
  });

  it('should show notification when add account api fails', async () => {
    server.use(
      rest.post(serviceUrl.getPlaidToken, (req, res, ctx) =>
        res(ctx.status(500)),
      ),
    );
    userEvent.click(screen.getByTestId('linked-add-account'));

    expect(
      await screen.findByTestId('notification-alert'),
    ).toBeInTheDocument();
  });
});
