import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';

import { useRefData } from 'hooks';

import ChelloAccountTransactions from '../ChelloAccountTransactions';
import ChelloAccountTransactionFilter from '../ChelloAccountTransactionFilter';
import ChelloAccountInfo from '../ChelloAccountInfo';
import ChelloAccountPayIt from '../ChelloAccountPayIt';
import AccountBoost from '../AccountBoost';

const PayOrBoostChelloAccounts = ({ handleTabChange }) => {
  const showPayIt = useSelector((state) => state.OneAccount.openPayIt);
  const showBoostNow = useSelector((state) => state.OneAccount.openBoostNow);
  const refData = useSelector((state) => state.global.refData);
  const {
    CHELLO_ACCOUNT_TRANSACTION_TYPES: chelloTransactionFilterByType,
    CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES: chelloTransactionPaymentType,
  } = refData;

  useRefData([
    'CHELLO_ACCOUNT_TRANSACTION_TYPES',
    'CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES',
  ]);

  return (
    <>
      {showPayIt && <ChelloAccountPayIt tab="chello" />}
      {showBoostNow && <AccountBoost tab="chello" />}
      {!showPayIt && !showBoostNow && (
        <>
          <ChelloAccountInfo handleTabChange={handleTabChange} />
          <ChelloAccountTransactionFilter
            showExport
            chelloTransactionFilterByOptions={chelloTransactionFilterByType}
          />
          <ChelloAccountTransactions
            paymentTypes={chelloTransactionPaymentType}
          />
        </>
      )}
    </>
  );
};

export default PayOrBoostChelloAccounts;

PayOrBoostChelloAccounts.propTypes = {
  handleTabChange: PropTypes.func.isRequired,
};
