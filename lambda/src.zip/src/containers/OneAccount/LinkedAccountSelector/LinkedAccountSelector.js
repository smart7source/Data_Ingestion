import {
  InputLabel,
  Select,
  FormControl,
  ListSubheader,
  MenuItem,
} from '@mui/material';
import { useSelector } from 'react-redux';
import { useMemo, memo } from 'react';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import { maskAccountNumber, isCheckingsAccount, getAccountName } from 'utils';
import serviceUrl from 'api/UrlHelper';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';

import classes from '../OneAccount.module.scss';
import LinkedAccountSelectorOption from '../../../components/FormElements/LinkedAccountSelectorOption';
import LinkedAccountSelectorCategory from '../LinkedAccountSelectorCategory';

const {
  linkedAccounts: LINKED_ACCOUNTS,
  savingsAccount: SAVINGS_ACCOUNT,
  checkingsAccount: CHECKING_ACCOUNT,
  allAccounts: ALL_ACCOUNTS,
} = strings;

const LinkedAccountSelector = (props) => {
  const { control } = props;
  const linkedAccountsGrouped = useSelector(
    (state) => state.OneAccount.linkedAccountsGrouped,
  );

  const allLinkedAccountsTotalBalance = useSelector(
    (state) => state.OneAccount.allLinkedAccountsTotalBalance,
  );

  const formattedLinkedAccountsGroups = useMemo(
    () =>
      Object.keys(linkedAccountsGrouped).reduce((acc, cur) => {
        const newAcc = [...acc];
        const { accounts, total } = linkedAccountsGrouped[cur];
        newAcc.push({ isAccType: true, name: cur, total });
        accounts.forEach((item) => newAcc.push({ ...item }));
        return newAcc;
      }, []),
    [linkedAccountsGrouped],
  );

  return (
    <Controller
      control={control}
      name="selectedLinkedAccount"
      render={({ field }) => (
        <FormControl className={classes.linkedAccountSelectorFormControl}>
          <InputLabel
            className={classes.linkedAccountSelectorLabel}
            id="lined-account-selector-label"
          >
            {LINKED_ACCOUNTS}
          </InputLabel>
          <Select
            {...field}
            className={classes.linkedAccountSelectorSelect}
            id="lined-account-selector"
            labelId="lined-account-selector-label"
            IconComponent={ChevronDown}
          >
            <MenuItem value="all">
              <LinkedAccountSelectorOption
                imgSrc={`${process.env.PUBLIC_URL}/svg/all-account-icon.svg`}
                alt=""
                name={ALL_ACCOUNTS}
                amount={allLinkedAccountsTotalBalance}
                balanceProps={{
                  className: classes.hideBalance,
                  amountVariant: 'p1SemiBold',
                }}
              />
            </MenuItem>
            {formattedLinkedAccountsGroups.map((eachItem) => {
              const { isAccType = false } = eachItem;

              if (isAccType) {
                const { name, total } = eachItem;
                const accType = isCheckingsAccount(name)
                  ? CHECKING_ACCOUNT
                  : SAVINGS_ACCOUNT;
                return (
                  <ListSubheader disableGutters key={name}>
                    <LinkedAccountSelectorCategory
                      name={accType}
                      amount={total}
                    />
                  </ListSubheader>
                );
              }

              const {
                instId = 'chaseplus',
                logoFormat = 'png',
                bankNm,
                accNickName,
                accNm,
                accNbr,
                avlbBalAmt,
              } = eachItem;

              const bankName = getAccountName({ bankNm, accNickName, accNm });

              const maskLastFourDigitAccNbr = maskAccountNumber(accNbr);
              const nameAndNumber = `${bankName} ${maskLastFourDigitAccNbr}`;

              return (
                <MenuItem key={nameAndNumber} value={accNbr}>
                  <LinkedAccountSelectorOption
                    imgSrc={`${serviceUrl.externalBankImagesPath}${instId}.${logoFormat}`}
                    alt=""
                    name={nameAndNumber}
                    amount={avlbBalAmt}
                  />
                </MenuItem>
              );
            })}
          </Select>
        </FormControl>
      )}
    />
  );
};

export default memo(LinkedAccountSelector);

LinkedAccountSelector.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
};
