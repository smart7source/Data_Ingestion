import { render, screen, act, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

describe('Testing PayIt EachBank component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });
  it('should render payit part', async () => {
    userEvent.click(screen.getByTestId('chello-pay-it-btn'));
    await screen.findByTestId('amount-radio');
  });
});
