import PayItEachBank from './PayItEachBank';

export default PayItEachBank;
