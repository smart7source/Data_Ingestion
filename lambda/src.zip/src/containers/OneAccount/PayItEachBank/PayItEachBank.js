import { Grid, Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { useFieldArray, useWatch } from 'react-hook-form';
import { useSelector } from 'react-redux';
import { useEffect } from 'react';
import NumberFormat from 'react-number-format';

import { NumberInput } from 'components';
import strings from 'localization/translation';
import { maskAccountNumber, convertToAmt, getAccountName } from 'utils';
import serviceUrl from 'api/UrlHelper';

const {
  availableBalance: AVAILABLE_BALANCE,
  enterAmountFromEachBankAccount: ENTER_AMOUNT,
  debitAmtGreater: DEBIT_AMNT_GREATER_ERROR,
} = strings;

const PayItEachBank = ({ control }) => {
  const { fields, replace } = useFieldArray({
    control,
    name: 'bankAccounts',
  });

  let bankAccounts = useWatch({
    control,
    name: 'bankAccounts',
  });

  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  bankAccounts = bankAccounts.map((x) => {
    const y = x;
    if (+convertToAmt({ value: x?.debitAmount }) > x.avlbBalAmt) {
      y.error = true;
      y.errorText = DEBIT_AMNT_GREATER_ERROR;
      return y;
    }
    y.error = false;
    y.errorText = '';
    return y;
  });

  useEffect(() => {
    if (linkedAccounts) {
      replace(linkedAccounts);
    }
  }, [linkedAccounts, replace]);

  return (
    <Grid container>
      <Box mb={2}>
        <Typography variant="h3" component="span">
          {ENTER_AMOUNT}
        </Typography>
      </Box>
      {fields.map((item, index) => {
        const {
          instId = 'chaseplus',
          logoFormat = 'png',
          bankNm,
          accNickName,
          accNm,
          accNbr,
          avlbBalAmt,
          id,
        } = item;

        const bankName = getAccountName({ bankNm, accNickName, accNm });

        const maskLastFourDigitAccNbr = maskAccountNumber(accNbr);
        const nameAndNumber = `${bankName} ${maskLastFourDigitAccNbr}`;

        return (
          <Grid container my={1} key={id}>
            <Grid item sm={12} xs={12} md={6}>
              <Box display="flex" gap="10px" alignitems="center">
                <img
                  width="25px"
                  height="25px"
                  style={{ alignSelf: 'center' }}
                  src={`${serviceUrl.externalBankImagesPath}${instId}.${logoFormat}`}
                  alt=""
                />
                <Box>
                  <Typography variant="p1SemiBold" color="#464646">
                    {nameAndNumber}
                  </Typography>
                  <Typography component="p" variant="p2" color="#6B7280">
                    {`${AVAILABLE_BALANCE} `}

                    <NumberFormat
                      value={avlbBalAmt}
                      displayType="text"
                      thousandSeparator
                      prefix="$ "
                      decimalScale="2"
                      fixedDecimalScale
                    />
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item sm={12} xs={12} md={6}>
              <NumberInput
                placeHolder="$ 0.00"
                id={`bankAccounts-${index}-debitAmount`}
                dataTestId={`bankAccounts-${index}-debitAmount`}
                margin="none"
                prefix="$ "
                fixedDecimalScale
                name={`bankAccounts.${index}.debitAmount`}
                control={control}
                error={bankAccounts?.[index]?.error}
                errorText={bankAccounts?.[index]?.errorText}
              />
            </Grid>
          </Grid>
        );
      })}
    </Grid>
  );
};

export default PayItEachBank;
PayItEachBank.propTypes = {
  control: PropTypes.instanceOf(Object),
};

PayItEachBank.defaultProps = {
  control: {},
};
