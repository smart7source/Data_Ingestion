import { Box, Tab, Tabs, Paper, Typography } from '@mui/material';
import { useState } from 'react';

import TabPanel from 'containers/Dashboard/components/TabPanel';
import classes from 'style/DashboardStyle.module.scss';
import globalClasses from 'style/globalStyle.module.scss';
import strings from 'localization/translation';

import AllAccounts from '../AllAccounts';
import ChelloAccounts from '../ChelloAccounts';
import LinkedAccounts from '../LinkedAccounts';

const {
  accounts: ACCOUNTS,
  accountsOverview: ACCOUNTS_OVERVIEW,
  all: ALL,
  linked: LINKED,
  chelloAccounts: CHELLO_ACCOUNTS,
} = strings;

function a11yProps(index) {
  return {
    id: `tab-${index}`,
    'aria-controls': `tabpanel-${index}`,
  };
}

const Accounts = () => {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
      <Box component="main" className={classes.mainContainer}>
        <Paper className={classes.pageHeader} elevation={1}>
          <Typography
            variant="h1"
            component="h1"
            data-testid="one-account-heading"
          >
            {ACCOUNTS}
          </Typography>
          <Tabs
            aria-label={ACCOUNTS_OVERVIEW}
            indicatorColor="primary"
            value={value}
            onChange={handleChange}
            textColor="inherit"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab
              label={ALL}
              {...a11yProps(0)}
              className={globalClasses.h3Headline}
              data-testid="one-account-all-tab"
            />
            <Tab
              label={CHELLO_ACCOUNTS}
              {...a11yProps(1)}
              className={globalClasses.h3Headline}
              data-testid="one-account-chello-tab"
            />
            <Tab
              label={LINKED}
              {...a11yProps(2)}
              className={globalClasses.h3Headline}
              data-testid="one-account-linked-tab"
            />
          </Tabs>
        </Paper>
        <TabPanel value={value} index={0}>
          <AllAccounts handleTabChange={handleChange} />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <ChelloAccounts handleTabChange={handleChange} />
        </TabPanel>
        <TabPanel value={value} index={2}>
          <LinkedAccounts />
        </TabPanel>
      </Box>
    </>
  );
};

export default Accounts;
