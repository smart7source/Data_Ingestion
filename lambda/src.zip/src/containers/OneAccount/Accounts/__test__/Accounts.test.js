import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { usePlaidLink } from 'react-plaid-link';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from '../index';

jest.mock('react-plaid-link', () => ({
  ...jest.requireActual('react-plaid-link'),
  usePlaidLink: jest.fn(),
}));

describe('Testing Accounts component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
    usePlaidLink.mockImplementation(() => ({ ready: false, open: jest.fn() }));
    renderWithProviderAndRouter(<Accounts />, { render });
  });

  it('should render one account page', () => {
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should render the default All account tab', () => {
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
    expect(screen.getByText('Linked Accounts')).toBeInTheDocument();
  });

  it('should display chello account details when chello tab is clicked', async () => {
    userEvent.click(screen.getByTestId('one-account-chello-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
    expect(screen.getByText('Chello Insights')).toBeInTheDocument();
  });

  it('should display linked account details when linked tab is clicked', async () => {
    userEvent.click(screen.getByTestId('one-account-linked-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    expect(
      screen.getByTestId('linked-tab-linked-account-heading'),
    ).toBeInTheDocument();
  });
});
