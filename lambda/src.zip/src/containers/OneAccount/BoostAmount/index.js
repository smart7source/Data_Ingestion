import BoostAmount from './BoostAmount';

export default BoostAmount;
