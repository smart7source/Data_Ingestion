import { useEffect } from 'react';
import {
  Grid,
  Box,
  RadioGroup,
  Radio,
  FormControlLabel,
  Typography,
} from '@mui/material';
import PropTypes from 'prop-types';
import { Controller, useWatch, useFormState } from 'react-hook-form';
import NumberFormat from 'react-number-format';

import { NumberInput } from 'components';
import strings from 'localization/translation';
import globalClasses from 'style/globalStyle.module.scss';

import Classes from '../OneAccount.module.scss';

const { boostAmountText: BOOST_AMOUNT, boostBalanceText: BOOST_BALANCE } =
  strings;

const BoostAmount = (props) => {
  const { control, resetField, availableToSpendBalanceAmount } = props;

  const active = useWatch({
    control,
    name: 'boostAmountRadio',
  });

  const { errors } = useFormState({
    control,
  });

  useEffect(() => {
    resetField('boostInputAmount');
  }, [active, resetField]);

  return (
    <Grid container mt={2.5}>
      <Box>
        <Controller
          render={({ field }) => (
            <RadioGroup
              {...field}
              aria-label="position"
              data-testid="amount-radio"
              row
            >
              <Grid container alignItems="center" mb={1}>
                <Grid item xs={12} sm={7} lg={7}>
                  <FormControlLabel
                    classes={{
                      label: [
                        globalClasses.h3Headline,
                        Classes.boostLabel,
                      ].join(' '),
                    }}
                    value="boostEnteredAmount"
                    control={
                      <Radio
                        color="primary"
                        inputProps={{
                          'data-testid': 'boost-entered-amount-radio',
                        }}
                      />
                    }
                    label={BOOST_AMOUNT}
                  />
                </Grid>
                <Grid item xs={12} sm={5} lg={5}>
                  <NumberInput
                    id="boostInputAmount"
                    name="boostInputAmount"
                    placeHolder="$ 0.00"
                    dataTestId="boost-amount-field"
                    margin="none"
                    prefix="$ "
                    control={control}
                    disabled={active !== 'boostEnteredAmount'}
                    error={!!errors.boostInputAmount}
                    errorText={errors.boostInputAmount?.message}
                    fixedDecimalScale
                  />
                </Grid>
              </Grid>
              <Grid container alignItems="center" mb={1}>
                <Grid item xs={12} sm={7} lg={7}>
                  <FormControlLabel
                    classes={{
                      label: [
                        globalClasses.h3Headline,
                        Classes.boostLabel,
                      ].join(' '),
                    }}
                    value="boostAvlBal"
                    control={
                      <Radio
                        color="primary"
                        inputProps={{
                          'data-testid': 'boost-avl-bal',
                        }}
                      />
                    }
                    label={BOOST_BALANCE}
                  />
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={5}
                  lg={5}
                  container
                  direction="row"
                  className={Classes.ChelloAccountInfo}
                >
                  <Box display="flex" alignItems="center" gap={1.25}>
                    <Typography
                      component="h3"
                      variant="h3"
                      color={active !== 'boostAvlBal' ? '#ccc' : '#000000'}
                    >
                      <NumberFormat
                        value={availableToSpendBalanceAmount}
                        displayType="text"
                        thousandSeparator
                        prefix="$ "
                        decimalScale="2"
                        fixedDecimalScale
                      />
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </RadioGroup>
          )}
          name="boostAmountRadio"
          id="boostAmountRadio"
          control={control}
        />
      </Box>
    </Grid>
  );
};

export default BoostAmount;
BoostAmount.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  resetField: PropTypes.func.isRequired,
  availableToSpendBalanceAmount: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
};

BoostAmount.defaultProps = {
  availableToSpendBalanceAmount: '',
};
