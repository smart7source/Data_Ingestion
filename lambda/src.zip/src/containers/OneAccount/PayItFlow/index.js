import PayItFlow from './PayItFlow';

export default PayItFlow;
