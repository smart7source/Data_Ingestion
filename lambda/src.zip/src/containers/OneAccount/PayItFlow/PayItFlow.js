import { Divider } from '@mui/material';
import PropTypes from 'prop-types';

import { defaultFnPropTypes } from 'utils';

import Classes from '../OneAccount.module.scss';
import PayItEachBank from '../PayItEachBank';
import PayItTotal from '../PayItTotal';
import PayItDate from '../PayItDate';
import PayItRecurringAmount from '../PayItRecurringAmount';
import PayItRecurringBank from '../PayItRecurringBank';

const PayItFlow = ({
  control,
  setValue,
  minPayment,
  payFullBal,
  payItAmount,
  resetField,
}) => {
  if (payItAmount === 'recurring') {
    return (
      <>
        <PayItRecurringAmount
          control={control}
          payFullBal={payFullBal}
          resetField={resetField}
        />
        <Divider className={Classes.divider} />
        <PayItRecurringBank control={control} />
      </>
    );
  }
  return (
    <>
      <PayItEachBank control={control} />
      <Divider className={Classes.divider} />
      <PayItTotal
        control={control}
        setValue={setValue}
        minPayment={minPayment}
        payFullBal={payFullBal}
      />
      <Divider className={Classes.divider} />
      <PayItDate control={control} />
    </>
  );
};

export default PayItFlow;

PayItFlow.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  setValue: PropTypes.instanceOf(Object),
  minPayment: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  payItAmount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  payFullBal: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  resetField: PropTypes.instanceOf(Function),
};
PayItFlow.defaultProps = {
  setValue: {},
  minPayment: '',
  payItAmount: '',
  payFullBal: '',
  resetField: defaultFnPropTypes,
};
