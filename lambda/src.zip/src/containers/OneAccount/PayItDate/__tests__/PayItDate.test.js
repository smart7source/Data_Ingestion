import { ThemeProvider } from '@mui/material';
import { render } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import strings from 'localization/translation';
import { useForm } from 'react-hook-form';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import theme from 'style/theme';
import PayItDate from '../index';

const history = createMemoryHistory();

const initialState = {};
const store = configureStore();

function TestElement() {
  const { control, errors } = useForm({
    mode: 'all',
    defaultValues: {
      amount: '',
      payItNote: '',
      payItAmount: 'enterAmount',
      payItRecurringAmount: 'payTotal',
      frequency: '1M',
    },
  });

  const currentProps = {
    control,
    errors,
  };

  return (
    <ThemeProvider theme={theme}>
      <Provider store={store(initialState)}>
        <Router history={history}>
          <PayItDate {...currentProps} />
        </Router>
      </Provider>
    </ThemeProvider>
  );
}

describe('Should render payit date component', () => {
  it('should render date picker for payment', () => {
    const { getByText } = render(<TestElement />);
    expect(getByText(strings.paymentDate)).toBeInTheDocument();
  });

  it('should render note field', () => {
    const { getByText } = render(<TestElement />);
    expect(getByText('Optional')).toBeInTheDocument();
  });
});
