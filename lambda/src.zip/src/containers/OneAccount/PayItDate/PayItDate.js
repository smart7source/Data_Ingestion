import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { useWatch, useFormState } from 'react-hook-form';

import { DatePicker, CustomInput } from 'components';
import strings from 'localization/translation';
import { setMaxDate, disableWeekends } from 'utils';

import Classes from '../OneAccount.module.scss';
import ShowInfo from '../ShowInfo';

const {
  boostNote: NOTE,
  optional: OPTIONAL,
  paymentDate: PAYMENT_DATE,
} = strings;

const PayItDate = (props) => {
  const { control } = props;

  const payItNote = useWatch({
    control,
    name: 'payItNote',
  });

  const { errors } = useFormState({
    control,
  });

  const infoOption = <ShowInfo content="Awaiting exact content.." />;

  return (
    <Box display="flex" gap="16px" className={Classes.payItDate}>
      <Box flexGrow="1" className={Classes.dateWithIconWrapper}>
        <DatePicker
          label={
            <Typography component="span" variant="h3">
              {PAYMENT_DATE}
            </Typography>
          }
          dataTestid="payit-paymentDate"
          optionalLabel={infoOption}
          placeHolder={strings.selectDateFormat}
          id="paymentDate"
          name="paymentDate"
          control={control}
          minDateValue={new Date()}
          maxDateValue={setMaxDate(new Date(), 364)}
          shouldDisableDate={disableWeekends}
          error={!!errors.paymentDate}
          errorText={errors.paymentDate?.message}
        />
      </Box>
      <Box flexGrow="1">
        <CustomInput
          label={
            <Typography component="span" variant="h3">
              {NOTE}
            </Typography>
          }
          optionalLabel={OPTIONAL}
          id="payItNote"
          name="payItNote"
          control={control}
          dataTestid="payit-note"
          inputProps={{ maxLength: 150 }}
        />
        <Typography variant="p2" component="p" color="grey.600" align="right">
          {`${payItNote.length}/150`}
        </Typography>
      </Box>
    </Box>
  );
};

export default PayItDate;
PayItDate.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
};
