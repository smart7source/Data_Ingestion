import { Grid, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { useWatch } from 'react-hook-form';

import strings from 'localization/translation';
import { convertToAmt, getFrequencyDuration, getFrequencyDays } from 'utils';

import Classes from '../OneAccount.module.scss';

const {
  reccuringPaymentOf: RECURRING_PAYMENT_OF,
  every: EVERY,
  until: UNTIL,
} = strings;

const PayItRecurringAmountCalculation = (props) => {
  const { control, payFullBal } = props;
  const [
    payItRecurringAmount,
    recurringAmount,
    endDate,
    frequency,
    numberoftransaction,
    recurringType,
  ] = useWatch({
    control,
    name: [
      'payItRecurringAmount',
      'recurringAmount',
      'endDate',
      'frequency',
      'numberoftransaction',
      'recurringType',
    ],
  });

  // const frequencyPeriod = getFrequencyDuration(frequency);
  // const frequencyDays = getFrequencyDays(frequency);

  // const calcDays = (endDateEntered) => {
  //   const date1 = new Date().setHours(0, 0, 0, 0);
  //   const date2 = new Date(endDateEntered).setHours(0, 0, 0, 0);
  //   const diffTime = Math.abs(date2 - date1);
  //   const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  //   return diffDays;
  // };

  // const payment = () => {
  //   let payAmt;
  //   let calcAmt;
  //   if (payItRecurringAmount === 'setAmount') {
  //     payAmt = recurringAmount;
  //     calcAmt = payAmt;
  //   } else if (payItRecurringAmount === 'payTotal') {
  //     payAmt = payFullBal || 12000;
  //     if (recurringType === 'numberoftransaction') {
  //       if (payAmt && numberoftransaction) {
  //         calcAmt = payAmt / numberoftransaction;
  //       }
  //     } else if (recurringType === 'end-date' && endDate) {
  //       const noOfDays = calcDays(endDate);

  //       calcAmt = payAmt / (parseInt(noOfDays / frequencyDays, 10) + 1);
  //     }
  //   }
  //   calcAmt = convertToAmt({
  //     value: calcAmt,
  //     prefix: '$ ',
  //     addSeparator: true,
  //   });
  //   return calcAmt;
  // };

  // const calcEndDate = () => {
  //   let endateVal;
  //   if (recurringType === 'numberoftransaction') {
  //     endateVal = new Date();
  //     endateVal.setDate(
  //       endateVal.getDate() + frequencyDays * (numberoftransaction - 1),
  //     );
  //   }
  //   if (recurringType === 'end-date') {
  //     endateVal = endDate;
  //   }
  //   if (endateVal) {
  //     return `${
  //       endateVal.getMonth() + 1
  //     }/${endateVal.getDate()}/${endateVal.getFullYear()}`;
  //   }

  //   return null;
  // };
  return (
    <Grid container>
      <Grid item xs={12}>
        <Typography variant="body2" component="p" color="grey.800">
          {RECURRING_PAYMENT_OF}
          <span
            className={Classes.boldSpan}
            data-testid="pay-it-recurring-ammount"
          >
            {recurringAmount}
          </span>
          {` ${EVERY} `}
          <span className={Classes.boldSpan}>week</span>
          {` ${UNTIL} `}
          <span className={Classes.boldSpan}>12/05/2023</span>
        </Typography>
      </Grid>
    </Grid>
  );
};

export default PayItRecurringAmountCalculation;

PayItRecurringAmountCalculation.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  payFullBal: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
PayItRecurringAmountCalculation.defaultProps = {
  payFullBal: '',
};
