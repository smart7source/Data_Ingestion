import PayItRecurringAmountCalculation from './PayItRecurringAmountCalculation';

export default PayItRecurringAmountCalculation;
