import { render, screen } from '@testing-library/react';
import { useForm } from 'react-hook-form';

import { renderWithProviderAndRouter } from 'testHelpers';

import PayItRecurringAmountCalculation from '../index';

const nextMonthDate = (curr) => {
  curr.setDate(curr.getDate() + 30);
  return curr;
};

describe('Testing payit recurring calculation', () => {
  it('Should display entered amount distribution, if set amount is selected', () => {
    const endDate = nextMonthDate(new Date());
    function TestElement() {
      const payFull = '$ 1,400.00';
      const { control } = useForm({
        mode: 'all',
        defaultValues: {
          payItRecurringAmount: 'setAmount',
          recurringAmount: '$ 700.00',
          frequency: '1M',
          endDate: nextMonthDate(new Date()),
        },
      });

      return (
        <PayItRecurringAmountCalculation
          control={control}
          payFullBal={payFull}
        />
      );
    }
    renderWithProviderAndRouter(<TestElement />, {
      render,
    });
    expect(screen.getByText('$ 700.00')).toBeInTheDocument();
  });
});
