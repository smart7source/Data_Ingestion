import {
  render,
  screen,
  waitFor,
  fireEvent,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import {
  renderWithProviderAndRouter,
  mockMatchMediaToDesktop,
} from 'testHelpers';
import { findNextWorkingDay } from 'utils';
import AccountBoost from '../index';

const initialState = {
  OneAccount: {
    chelloAccountDetails: {
      accounts: [
        {
          avlbToSpdtBalAmt: 5200,
          utlzBalAmt: 1300,
          pymtDueAmt: 120.04,
          pastPymtDueImitAmt: 120.04,
          otsgFeesAmt: 2.18,
          intRate: 6.55,
          accNm: 'Dynamic Line',
          posnNbr: '4hOVLwpsEIlbKV----1F-77-',
          accRtgNbr: '987651234',
          accNbr: '1234567890',
          apprvBalAmt: 15000,
        },
      ],
    },
    linkedAccountDetails: [
      {
        posnId: '4hO_YImR1UiZFF----DF-77-',
        accId: '4hO_YImR1UiZFF----DF-77-',
        accNbr: '123443215678',
        accRtgNbr: '123456789',
        bankNm: 'Chase',
        avlbBalAmt: 10000,
        accNm: 'Checking',
      },
      {
        posnId: '4hOVLwpsEIlbKV----1F-77-',
        accId: '4hOVLwpsEIlbKV----1F-77-',
        accNbr: '987667895432',
        accRtgNbr: '123456789',
        bankNm: 'Wells Fargo',
        avlbBalAmt: 500,
        accNm: 'Savings',
      },
    ],
  },
};

function TestElement() {
  return <AccountBoost />;
}

describe('Testing Account Boost component', () => {
  let boostDate;
  let boostAmount;

  beforeAll(() => {
    mockMatchMediaToDesktop();
    renderWithProviderAndRouter(<TestElement />, {
      render,
      wrapperProps: {
        initialState,
      },
    });
  });
  it('should render the Account boost component', async () => {
    expect(screen.getByText('Want a boost?')).toBeInTheDocument();
  });

  it('should show error when invalid date is entered', async () => {
    boostDate = screen.getByLabelText('Boost date');
    userEvent.type(boostDate, '01/01/2000');
    expect(
      await screen.findByText("Date cannot be lesser than today's date"),
    ).toBeInTheDocument();
  });

  it('should accept a valid date value', async () => {
    userEvent.clear(boostDate);
    const today = new Date();
    const nextWorkingDay = findNextWorkingDay(today).toLocaleDateString('en', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });

    userEvent.type(boostDate, nextWorkingDay);
    await waitFor(() =>
      expect(
        screen.queryByText("Date cannot be lesser than today's date"),
      ).not.toBeInTheDocument(),
    );
    expect(
      screen.queryByText('Transactions are not allowed in weekends'),
    ).not.toBeInTheDocument();
  });

  it('should show error when amount entered', async () => {
    boostAmount = screen.getByTestId('boost-amount-field');
    userEvent.type(boostAmount, '12.12');
    userEvent.clear(boostAmount);

    expect(
      await screen.findByText('Amount cannot be empty'),
    ).toBeInTheDocument();
  });

  it('should accept a valid amount', async () => {
    fireEvent.change(boostAmount, {
      target: {
        value: '1000',
      },
    });
    await waitFor(() =>
      expect(
        screen.queryByText('Amount cannot be empty'),
      ).not.toBeInTheDocument(),
    );
  });
  it('should select boost available balance', async () => {
    userEvent.click(screen.getByTestId('boost-avl-bal'));
    expect(await screen.findByTestId('boost-avl-bal')).toBeChecked();
  });

  it('should not see error when note is not available', async () => {
    userEvent.clear(boostNote);
    await waitFor(() =>
      expect(
        screen.queryByText('Maximum of 150 charcters are only allowed'),
      ).not.toBeInTheDocument(),
    );
  });

  it('should enable the boost now button when valid details are provided', async () => {
    const selectDropdown = screen.getByLabelText('Select bank account');

    userEvent.click(selectDropdown);
    expect(await screen.findByText('Checking *5678')).toBeInTheDocument();

    userEvent.click(screen.getByText('Checking *5678'));
    await screen.findByText('Checking *5678');
  });
  it('should open review dialog on clicking continue', async () => {
    const boostNowBtn = screen.getByTestId('boost-now-btn');
    expect(boostNowBtn).not.toBeDisabled();
    userEvent.click(boostNowBtn);
    expect(
      await screen.findByText('Your cash is ready for take-off.'),
    ).toBeInTheDocument();
  });
  it('should submit transfer request after review', async () => {
    userEvent.click(screen.getByTestId('oneaccount-review-submit'));
    await waitFor(() => {
      expect(
        screen.queryByText('Your cash is ready for take-off.'),
      ).not.toBeInTheDocument();
    });
  });
  it('should show payment confirmation dialog once transfer is done', async () => {
    expect(
      await screen.findByText(/Someone needs to take/i),
    ).toBeInTheDocument();
    userEvent.click(screen.getByText('Ok'));
    await waitFor(() => {
      expect(
        screen.queryByText(/Someone needs to take/i),
      ).not.toBeInTheDocument();
    });
  });
});
