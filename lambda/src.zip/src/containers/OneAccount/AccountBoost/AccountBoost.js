import { Box, Divider, Grid, Typography } from '@mui/material';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import {
  DatePicker,
  LinkedAccountSimpleSelector,
  CustomIcon,
} from 'components';
import {
  openBoostNow,
  oneAccountMakeATransfer,
  fetchAllAccDetails,
  fetchOneAccTransactions,
} from 'store/actions/OneAccountActions';
import { useHandleApiFailure } from 'hooks';
import {
  convertToAmt,
  formatDateToString,
  getDynamicLineOfCreditsAccountDetails,
  setMaxDate,
  disableWeekends,
  maskAccountNumber,
  maskAccountNumberAndPosnNumber,
  handleTransferAPIComplete,
  getSpendBalancePercentage,
  getAccountName,
} from 'utils';
import { ReactComponent as flag } from 'assets/svg/flag.svg';

import ChelloAccountBalanceInfo from '../ChelloAccountBalanceInfo';
import BoostAmount from '../BoostAmount';
import { boostNowSchema } from '../oneAccountSchema';
import Classes from '../OneAccount.module.scss';
import ReviewTransferDialog from '../ReviewTransferDialog';
import BoostNownDialogBox from '../oneAccountTransactionModel';
import PayitHeader from '../PayItHeader';
import BoostNoteandButtons from '../BoostNoteandButtons';

const {
  wantABoost: WANT_A_BOOST,
  boostDate: BOOST_DATE,
  boostOfferValidity: BOOST_OFFER_VALIDITY,
  oneTime: ONE_TIME,
} = strings;

const AccountBoost = (props) => {
  const { tab } = props;
  const [open, setOpen] = useState(false);
  const [counterParty, setCounterParty] = useState({});
  const [modal, setModal] = useState(false);
  const [transferCompletionDetails, setTransferCompleteStatus] = useState(null);
  const dispatch = useDispatch();
  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount.chelloAccountDetails,
  );

  const {
    avlbToSpdtBalAmt: availableToSpendBalanceAmount = 0,
    utlzBalAmt: utilizedAmount = 0,
    accNbr: accountNumber = '',
    posnNbr: posnNumber = '',
    posnId: positionId = '',
    apprvBalAmt: totalLimit = 0,
    accNickName,
    accNm,
  } = getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const availableToSpendBalancePercentage = getSpendBalancePercentage(
    availableToSpendBalanceAmount,
    totalLimit,
  );

  const accNbrAndPosnNbr = maskAccountNumberAndPosnNumber(
    accountNumber,
    posnNumber,
  );
  const maskLastFourDigitAccNbr = maskAccountNumber(accountNumber);

  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  const handleBackClick = () => {
    dispatch(openBoostNow(false));
  };

  const {
    control,
    handleSubmit,
    watch,
    resetField,
    formState: { errors, isValid },
  } = useForm({
    mode: 'onChange',
    resolver: yupResolver(boostNowSchema(availableToSpendBalanceAmount)),
    defaultValues: {
      boostNote: '',
      boostAmountRadio: 'boostEnteredAmount',
      boostInputAmount: '',
      selectedLinkedAccount: '',
    },
  });

  const amount =
    watch('boostAmountRadio') === 'boostAvlBal'
      ? convertToAmt({
          value: availableToSpendBalanceAmount,
          prefix: '$ ',
          addSeparator: true,
        })
      : watch('boostInputAmount');

  const transactionDate = watch('transferDate') || new Date();
  const transactionDateFormatted = transactionDate.toLocaleDateString('en', {
    month: 'short',
    year: 'numeric',
    day: '2-digit',
  });

  const boostAmtNote = watch('boostNote') || '-';

  const handleAPIComplete = (statusParam) => (params) => {
    setModal(true);
    handleTransferAPIComplete({
      setTransferCompleteStatus,
      ...statusParam,
      ...params,
    });
  };

  const handleOpen = (data) => {
    setOpen(true);
    const { selectedLinkedAccount } = data;
    const transferTo = [...linkedAccounts].find(
      (x) => x.accNbr === selectedLinkedAccount,
    );

    setCounterParty(transferTo);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const submitHandler = (data) => {
    const { boostAmountRadio, boostNote, transferDate, boostInputAmount } =
      data;

    const boostAmt =
      boostAmountRadio === 'boostAvlBal'
        ? availableToSpendBalanceAmount
        : boostInputAmount;

    const apiPayload = {
      transferDate: formatDateToString(transferDate, 'YYYY-MM-DD'),
      note: boostNote,
      transferDetail: [
        {
          sourceParty: {
            accountId: positionId,
          },
          counterParty: {
            accountId: counterParty?.posnId,
          },
          transferAmt: +convertToAmt({ value: boostAmt }),
        },
      ],
    };
    setOpen(false);
    dispatch(
      oneAccountMakeATransfer({
        apiPayload,
        successCallback: handleAPIComplete({ status: 'success' }),
        failureCallback: handleAPIComplete({ status: 'error' }),
      }),
    );
  };
  const handleAPIFailure = useHandleApiFailure();

  const handleClosePayItModal = () => {
    dispatch(fetchAllAccDetails({ failureCallback: handleAPIFailure }));
    if (tab === 'chello') {
      dispatch(
        fetchOneAccTransactions({
          accountNumber,
          positionId,
          failureCallback: handleAPIFailure,
        }),
      );
    }
    setModal(false);
    handleBackClick();
  };

  useEffect(
    () => () => {
      dispatch(openBoostNow(false));
    },
    [dispatch],
  );

  const counterPtyAccMask = maskAccountNumber(counterParty?.accNbr);
  const btnProps = {};
  if (!isValid) {
    btnProps.disabled = true;
  } else {
    btnProps.color = 'primary';
  }
  const fromBankName = getAccountName({
    bankNm: '',
    accNickName,
    accNm,
  });
  const toBankName = getAccountName(counterParty);

  return (
    <Grid container direction="column" className={Classes.ChelloAccountInfo}>
      <ReviewTransferDialog
        open={open}
        handleClose={handleClose}
        handleSubmit={handleSubmit(submitHandler)}
        transferFrom={[
          { bankName: fromBankName, accNo: maskLastFourDigitAccNbr },
        ]}
        transferToName={toBankName}
        transferToNo={counterPtyAccMask}
        amount={amount}
        date={transactionDateFormatted}
        frequency={ONE_TIME}
        note={boostAmtNote}
      />
      <PayitHeader
        title={WANT_A_BOOST}
        handleClose={handleBackClick}
        accNbrAndPosnNbr={accNbrAndPosnNbr}
      />
      <Box mt={2.5}>
        <ChelloAccountBalanceInfo
          utilizedAmount={utilizedAmount}
          availableToSpendBalanceAmount={availableToSpendBalanceAmount}
          totalLimit={totalLimit}
          availableToSpendBalancePercentage={availableToSpendBalancePercentage}
        />
      </Box>
      <Grid container>
        <BoostAmount
          control={control}
          resetField={resetField}
          availableToSpendBalanceAmount={availableToSpendBalanceAmount}
        />
      </Grid>
      <Divider className={Classes.divider} />
      <Grid item xs={12} sm={12} container columnSpacing={2} mt={1}>
        <Grid item xs={12} sm={6} lg={6}>
          <LinkedAccountSimpleSelector
            bankAccounts={linkedAccounts}
            control={control}
            name="selectedLinkedAccount"
          />
        </Grid>
        <Grid item xs={12} sm={6} lg={6} gap={0} columnSpacing={0}>
          <DatePicker
            label={BOOST_DATE}
            placeHolder={strings.selectDateFormat}
            id="transferDate"
            name="transferDate"
            control={control}
            dataTestid="transfer-date"
            minDateValue={new Date()}
            maxDateValue={setMaxDate(new Date(), 364)}
            shouldDisableDate={disableWeekends}
            error={!!errors.transferDate}
            errorText={errors.transferDate && errors.transferDate.message}
          />
          <Box className={Classes.boostNowIcon}>
            <CustomIcon
              component={flag}
              color="primary"
              className={Classes.iconSize}
              inheritViewBox
            />
            <Typography color="primary" className={Classes.boostNowOffer}>
              {BOOST_OFFER_VALIDITY}
            </Typography>
          </Box>
        </Grid>
      </Grid>
      <BoostNoteandButtons
        control={control}
        handleBackClick={handleBackClick}
        handleSubmit={handleSubmit}
        handleOpen={handleOpen}
        btnProps={btnProps}
      />

      <BoostNownDialogBox
        handleClosePayItModal={handleClosePayItModal}
        modal={modal}
        headTitle={transferCompletionDetails?.title}
        content={transferCompletionDetails?.content}
        status={transferCompletionDetails?.status}
        statusImage={transferCompletionDetails?.statusImage}
        confirmationId={transferCompletionDetails?.confirmationId}
        confirmationDate={transferCompletionDetails?.confirmationDate}
        amount={amount}
      />
    </Grid>
  );
};

export default AccountBoost;

AccountBoost.propTypes = {
  tab: PropTypes.string,
};

AccountBoost.defaultProps = {
  tab: 'all',
};
