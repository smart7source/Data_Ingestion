import AccountBoost from './AccountBoost';

export default AccountBoost;
