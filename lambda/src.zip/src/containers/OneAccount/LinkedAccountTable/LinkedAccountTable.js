import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  TableFooter,
  useMediaQuery,
} from '@mui/material';
import NumberFormat from 'react-number-format';
import { useSelector } from 'react-redux';
import { memo } from 'react';

import strings from 'localization/translation';

import NoLinkedAccounts from '../NoLinkedAccounts';
import Classes from '../OneAccount.module.scss';
import LinkedEachAccountTypes from '../LinkedEachAccountTypes';

const {
  externalAccountDetails: EXTERNAL_ACCOUNT_DETAILS,
  balance: BALANCE,
  allAccounts: ALL_ACCOUNTS,
  totalColon: TOTAL_COLON,
  noLinkedAccounts: NO_LINKED_ACCOUNTS,
} = strings;

const LinkedAccountTable = () => {
  const belowSm = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const linkedAccountsGrouped = useSelector(
    (state) => state.OneAccount.linkedAccountsGrouped,
  );

  const allLinkedAccountsTotalBalance = useSelector(
    (state) => state.OneAccount.allLinkedAccountsTotalBalance,
  );

  return (
    <Box className={Classes.chelloTransactionsTableWrapper}>
      <Table
        className={Classes.chelloTransactionsTable}
        aria-label="Linked accounts"
      >
        {!belowSm && (
          <TableHead>
            <TableRow>
              <TableCell className={Classes.accountTableHeadDetailCell}>
                <Typography variant="p2" component="p" color="grey.900">
                  {EXTERNAL_ACCOUNT_DETAILS}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="p2" component="p" color="darkGray.500">
                  {BALANCE}
                </Typography>
              </TableCell>
            </TableRow>
          </TableHead>
        )}
        <TableBody className={Classes.accountTableBodyPadding}>
          {!Object.keys(linkedAccountsGrouped).length ? (
            <NoLinkedAccounts message={NO_LINKED_ACCOUNTS} addAccountBtn />
          ) : (
            Object.keys(linkedAccountsGrouped).map((eachAccType, index) => (
              <LinkedEachAccountTypes
                accountType={eachAccType}
                key={`${eachAccType}-${index}`}
                index={index}
              />
            ))
          )}
        </TableBody>
        {!!Object.keys(linkedAccountsGrouped).length && (
          <TableFooter>
            <TableRow>
              <TableCell colSpan={2} scope="colgroup">
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <Box display="flex" gap="10px" alignItems="center">
                    <img
                      width="25px"
                      height="25px"
                      style={{ alignSelf: 'center' }}
                      src={`${process.env.PUBLIC_URL}/svg/all-account-icon.svg`}
                      alt=""
                    />
                    <Box>
                      <Typography
                        component="p"
                        variant="p1SemiBold"
                        color="darkGray.800"
                      >
                        {ALL_ACCOUNTS}
                      </Typography>
                    </Box>
                  </Box>
                  <Box display="flex" justifyContent="flex-end" gap="10px">
                    <Typography component="h3" variant="h3" color="grey.800">
                      {TOTAL_COLON}
                    </Typography>
                    <Typography component="h3" variant="h3" color="grey.800">
                      <NumberFormat
                        value={allLinkedAccountsTotalBalance}
                        displayType="text"
                        thousandSeparator
                        prefix="$ "
                        decimalScale="2"
                        fixedDecimalScale
                      />
                    </Typography>
                  </Box>
                </Box>
              </TableCell>
            </TableRow>
          </TableFooter>
        )}
      </Table>
    </Box>
  );
};

export default memo(LinkedAccountTable);
