import { render, screen } from '@testing-library/react/pure';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

describe('Test LinkedAccounts Table Component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should display sum of all linked account balances as total amount ', async () => {
    expect(await screen.findByText('$ 10,500.00')).toBeInTheDocument();
  });
});
