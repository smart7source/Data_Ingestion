import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';

import Classes from '../OneAccount.module.scss';

const ChelloInsightsSections = (props) => {
  const { title, description, descVariant, amount } = props;
  return (
    <Box className={Classes.chelloInsightsSections}>
      <Typography variant="p1SemiBold" color="grey.800">
        {title}
      </Typography>
      {amount ? (
        <Typography variant={descVariant} color="grey.800">
          <NumberFormat
            value={amount}
            displayType="text"
            thousandSeparator
            prefix="$ "
            decimalScale="2"
            fixedDecimalScale
          />
        </Typography>
      ) : (
        <Typography variant={descVariant} color="grey.800">
          {description}
        </Typography>
      )}
    </Box>
  );
};

export default ChelloInsightsSections;

ChelloInsightsSections.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  descVariant: PropTypes.string,
  amount: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
};

ChelloInsightsSections.defaultProps = {
  title: '',
  description: '',
  descVariant: 'body2',
  amount: '',
};
