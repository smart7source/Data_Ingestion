import ChelloInsightsSections from './ChelloInsightsSections';

export default ChelloInsightsSections;
