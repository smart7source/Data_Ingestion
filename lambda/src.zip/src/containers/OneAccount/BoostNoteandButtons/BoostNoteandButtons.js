import { Button, Grid, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { useWatch } from 'react-hook-form';

import strings from 'localization/translation';
import { CustomInput } from 'components';
import { defaultFnPropTypes } from 'utils';

import Classes from '../OneAccount.module.scss';

const {
  boostNow: BOOST_NOW,
  cancel: CANCEL,
  boostNote: NOTE,
  optional: OPTIONAL,
} = strings;

const BoostNoteandButtons = (props) => {
  const { control, handleBackClick, handleSubmit, handleOpen, btnProps } =
    props;

  const boostNote = useWatch({
    control,
    name: 'boostNote',
  });

  return (
    <>
      <Grid item mt={2.5} className={Classes.boostNoteWrapper}>
        <CustomInput
          label={NOTE}
          optionalLabel={OPTIONAL}
          id="boostNote"
          name="boostNote"
          control={control}
          dataTestid="boost-note"
          inputProps={{ maxLength: 150 }}
        />
        <Typography align="right" variant="p2" component="p" color="grey.600">
          {`${boostNote.length}/150`}
        </Typography>
      </Grid>
      <Grid item xs={12} sm={3} lg={6} mt={2} className={Classes.boostButton}>
        <Button variant="contained" onClick={handleBackClick}>
          <Typography variant="buttonMedium" component="span" color="grey.800">
            {CANCEL}
          </Typography>
        </Button>
        <Button
          variant="contained"
          data-testid="boost-now-btn"
          onClick={handleSubmit(handleOpen)}
          {...btnProps}
        >
          {BOOST_NOW}
        </Button>
      </Grid>
    </>
  );
};

export default BoostNoteandButtons;
BoostNoteandButtons.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  handleBackClick: PropTypes.func,
  handleSubmit: PropTypes.func,
  handleOpen: PropTypes.func,
  btnProps: PropTypes.instanceOf(Object),
};

BoostNoteandButtons.defaultProps = {
  handleBackClick: defaultFnPropTypes,
  handleSubmit: defaultFnPropTypes,
  handleOpen: defaultFnPropTypes,
  btnProps: PropTypes.instanceOf(Object),
};
