import { Button, Typography, useMediaQuery } from '@mui/material';
import { useContext } from 'react';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';

import { CustomIcon } from 'components';
import { ReactComponent as Plus } from 'assets/svg/plus.svg';
import strings from 'localization/translation';
import { fetchAllAccDetails } from 'store/actions/OneAccountActions';
import LinkPlaid from 'containers/Funding/LinkExternalBank/components/LinkPlaid';
import { defaultFnPropTypes } from 'utils';
import { NotificationContext } from 'contexts';
import globalClasses from 'style/globalStyle.module.scss';
import { useHandleApiFailure } from 'hooks';

import Classes from '../OneAccount.module.scss';

const {
  addAccount: ADD_ACCOUNT,
  addAccountSuccess: ADD_SUCCESS,
  addAccountFailure: ADD_FAILURE,
} = strings;

const AddButton = (props) => {
  const belowSm = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const { dataTestid, onClick } = props;

  return (
    <Button
      className={globalClasses.ctaWithIcon}
      color="primary"
      data-testid={dataTestid}
      onClick={onClick}
    >
      <CustomIcon
        component={Plus}
        color="primary"
        className={Classes.closeIconSize}
        inheritViewBox
      />
      <Typography
        component="span"
        variant={belowSm ? 'buttonSmall' : 'buttonMedium'}
      >
        {ADD_ACCOUNT}
      </Typography>
    </Button>
  );
};

AddButton.propTypes = {
  dataTestid: PropTypes.string,
  onClick: PropTypes.func,
};
AddButton.defaultProps = {
  dataTestid: '',
  onClick: defaultFnPropTypes,
};

const AddAccount = (props) => {
  const dispatch = useDispatch();

  const { dataTestid } = props;
  const contextValue = useContext(NotificationContext);
  const { setNotification } = contextValue;

  const handleAPIFailure = useHandleApiFailure();

  const onLinkedAcc = () => {
    setNotification([{ severity: 'success', message: ADD_SUCCESS }]);
    dispatch(fetchAllAccDetails({ failureCallback: handleAPIFailure }));
  };

  const onError = (params) => {
    const { msg = ADD_FAILURE } = params;
    setNotification([{ severity: 'error', message: msg }]);
  };

  return (
    <LinkPlaid onLinkedAcc={onLinkedAcc} onError={onError}>
      <AddButton dataTestid={dataTestid} />
    </LinkPlaid>
  );
};

export default AddAccount;

AddAccount.propTypes = {
  dataTestid: PropTypes.string,
};
AddAccount.defaultProps = {
  dataTestid: '',
};
