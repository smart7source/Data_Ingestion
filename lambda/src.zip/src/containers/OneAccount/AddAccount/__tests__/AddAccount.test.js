import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { usePlaidLink } from 'react-plaid-link';
import { rest } from 'msw';

import { renderWithProviderAndRouter } from 'testHelpers';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';

import AddAccount from '../index';

const initialState = {
  oneAccount: {
    linkToken: 'link-sandbox-0a752f64-c8ab-4492-8123-edc28c87f269',
  },
};

jest.mock('react-plaid-link', () => ({
  ...jest.requireActual('react-plaid-link'),
  usePlaidLink: jest.fn(),
}));

const plaidMock = (config) => ({
  ready: true,
  open: () => {
    config.onSuccess('xxx', {
      account: {},
    });
  },
});

describe('Testing AddAccount Component', () => {
  const mockOpen = jest.fn();

  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();

    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));

    server.use(
      rest.post(serviceUrl.setToken, (req, res, ctx) => res(ctx.status(200))),
    );
  });

  afterEach(() => {
    usePlaidLink.mockClear();
  });

  it('should render AddAccount Component', async () => {
    usePlaidLink.mockImplementation(() => ({ ready: true, open: mockOpen }));

    renderWithProviderAndRouter(<AddAccount dataTestid="add-account-btn" />, {
      render,
      wrapperProps: { initialState },
    });
    expect(screen.getByText('Add account')).toBeInTheDocument();
  });

  it('should open plaid link on clicking add button', async () => {
    usePlaidLink.mockImplementation(() => ({ ready: true, open: mockOpen }));

    userEvent.click(await screen.findByText('Add account'));
    await waitFor(() => {
      expect(mockOpen).toHaveBeenCalled();
    });
  });

  it('should show success notification on adding account successfully', async () => {
    usePlaidLink.mockImplementation(plaidMock);

    userEvent.click(await screen.findByText('Add account'));
  });

  it('should show failure notification when adding account fails', async () => {
    usePlaidLink.mockImplementation(plaidMock);

    server.use(
      rest.post(serviceUrl.setToken, (req, res, ctx) => res(ctx.status(400))),
    );

    userEvent.click(await screen.findByText('Add account'));
  });
});
