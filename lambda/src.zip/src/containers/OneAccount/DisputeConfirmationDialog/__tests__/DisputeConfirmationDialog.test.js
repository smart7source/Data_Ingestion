import {
  render,
  screen,
  act,
  waitFor,
  fireEvent,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Amplify } from 'aws-amplify';

import awsConfig from 'aws-exports';
import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

Amplify.configure(awsConfig);
const submitDispute = async () => {
  let disputeReason = screen.getByTestId('disputeReason');

  fireEvent.change(disputeReason, {
    target: { value: '1' },
  });

  const submitButton = await screen.findByTestId('oneaccount-dispute-submit');
  expect(submitButton).toBeEnabled();
  userEvent.click(submitButton);
};

describe('Dispute Confirmation dialog', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });

  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });

  it('should render chello tab', async () => {
    userEvent.click(screen.getByTestId('one-account-chello-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });
  it('should open dispute dialog', async () => {
    const kebabMenu = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-btn',
    );

    userEvent.click(kebabMenu);
    const menuItem = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-item-1',
    );

    userEvent.click(menuItem);
    await screen.findByText('Dispute a transaction');
  });
  it('should submit dispute', async () => {
    await submitDispute();
    const dialogTitle = await screen.findByText('We’re looking into this');
    expect(dialogTitle).toBeInTheDocument();
  });
  it('should close dialog on close', async () => {
    const okButton = await screen.findByTestId('dispute-confirm-ok');
    userEvent.click(okButton);
    await waitFor(() => {
      expect(
        screen.queryByText("We're looking into this"),
      ).not.toBeInTheDocument();
    });
  });
});
