import {
  Box,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  IconButton,
} from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import { memo } from 'react';

import strings from 'localization/translation';
import { useFetchSelectedTransaction, useRefData } from 'hooks';
import { showDisputeConfirmationDialog } from 'store/actions/OneAccountActions';
import { CustomIcon } from 'components';
import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle.svg';
import { ReactComponent as Close } from 'assets/svg/close.svg';
import {
  getDynamicLineOfCreditsAccountDetails,
  getAccountName,
  maskAccountNumber,
  decidePrefix,
} from 'utils';

import Classes from '../OneAccount.module.scss';
import TransactionInfo from '../TransactionInfo';

const {
  disputeConfirmationTitle: TITLE,
  disputeSubTitle: SUB_TITLE,
  selectedTransaction: SELECTED_TRANSACTION,
  ok: OK,
} = strings;
const DisputeConfirmationDialog = () => {
  const dispatch = useDispatch();
  const open = useSelector(
    (state) => state.OneAccount.showDisputeConfirmationDialog,
  );
  const serviceRequestNo = useSelector(
    (state) => state.OneAccount.serviceRequestNo,
  );
  const handleClose = () => {
    dispatch(showDisputeConfirmationDialog(false));
  };
  const {
    amount = '',
    date = '',
    description = '',
    type = '',
  } = useFetchSelectedTransaction();

  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount.chelloAccountDetails,
  );

  const { accNbr, accNickName, accNm } =
    getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const account = getAccountName({
    bankNm: '',
    accNickName,
    accNm,
  });

  const maskLastFourDigitAccNbr = maskAccountNumber(accNbr);
  const nameAndNumber = `${account} ${maskLastFourDigitAccNbr}`;

  const refData = useSelector((state) => state.global.refData);
  const {
    CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES: chelloTransactionPaymentType,
  } = refData;

  useRefData(['CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES']);

  const prefix = decidePrefix(type, chelloTransactionPaymentType);

  return (
    <Dialog
      open={open}
      className={Classes.disputeConfirmationDialog}
      aria-labelledby="disputeConfirmationModal"
    >
      <IconButton
        aria-label="close"
        size="small"
        className={Classes.closeIcon}
        onClick={handleClose}
      >
        <CustomIcon
          component={Close}
          color="grey.800"
          inheritViewBox
          className={Classes.closeIconSize}
        />
      </IconButton>
      <DialogTitle className={Classes.noPadding} id="disputeConfirmationModal">
        <Typography component="span" variant="h1" gutterBottom>
          {TITLE}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box className={Classes.subTitle}>
          <CustomIcon
            component={CheckmarkCircle}
            inheritViewBox
            color="#30bc76"
            className={Classes.iconSize}
          />
          <Typography
            variant="p1"
            color="grey.1100"
            className={Classes.subTitleContent}
          >
            {SUB_TITLE}
          </Typography>
        </Box>
        <Box classname={Classes.imageContainer}>
          <img
            width="600"
            height="194"
            src={`${process.env.PUBLIC_URL}/images/chello-dispute-claim-success.png`}
            alt="Chello Lamp"
            style={{ width: '100%', height: 'auto' }}
          />
        </Box>
        <Box>
          <Typography variant="h3" gutterBottom>
            {SELECTED_TRANSACTION}
          </Typography>
          <TransactionInfo
            account={nameAndNumber}
            type={type}
            amount={amount}
            date={date}
            description={description}
            serviceTicket={serviceRequestNo}
            prefix={prefix}
          />
        </Box>
      </DialogContent>
      <DialogActions className={Classes.buttonWrapper}>
        <Button
          variant="contained"
          color="primary"
          onClick={handleClose}
          data-testid="dispute-confirm-ok"
        >
          {OK}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default memo(DisputeConfirmationDialog);
