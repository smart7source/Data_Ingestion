import DisputeChargeDialog from './DisputeChargeDialog';

export default DisputeChargeDialog;
