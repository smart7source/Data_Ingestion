import {
  Box,
  Typography,
  Dialog,
  DialogTitle,
  DialogActions,
  Button,
  IconButton,
  DialogContent,
} from '@mui/material';
import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useSelector, useDispatch } from 'react-redux';
import { yupResolver } from '@hookform/resolvers/yup';

import strings from 'localization/translation';
import {
  postDisputeAction,
  showDisputeConfirmationDialog,
  showDisputeDialog,
} from 'store/actions/OneAccountActions';
import { CustomTextArea, CustomIcon } from 'components';
import {
  getDynamicLineOfCreditsAccountDetails,
  getAccountName,
  maskAccountNumber,
  decidePrefix,
  readFileDataAsBase64,
} from 'utils';
import {
  useFetchSelectedTransaction,
  useHandleApiFailure,
  useRefData,
} from 'hooks';
import { disputeValidationSchema } from 'helpers/ValidationSchema';
import globalClasses from 'style/globalStyle.module.scss';
import { ReactComponent as Close } from 'assets/svg/close.svg';

import UploadedDocumentsList from '../UploadedDocumentsList/index';
import Classes from '../OneAccount.module.scss';
import TransactionInfo from '../TransactionInfo';
import DisputeChargeFileUploader from '../DisputeChargeFileUploader';
import DisputeReason from '../DisputeReason';

const {
  disputeTitle: DISPUTE_TITLE,
  cancel: CANCEL,
  submitClaim: SUBMIT_CLAIM,
  selectedTransaction: SELECTED_TRANSACTION,
  supportingDocuments: SUPPORTING_DOCUMENTS,
  disputeDescription: DISPUTE_DESCRIPTION,
  optional: OPTIONAL,
  uploadFileExceedMsg: UPLOAD_FILE_EXCEED_ERR_MSG,
  uploadFileTypeErrMsg: UPLOAD_FILE_TYPE_ERR_MSG,
  maxFileUploadError: MAX_FILE_ERR_MSG,
} = strings;

const DisputeChargeDialog = () => {
  const [files, setFiles] = useState([]);
  const [error, setError] = useState();
  const [uploadPercentage, setUploadPercentage] = useState(0);

  const dispatch = useDispatch();

  const open = useSelector((state) => state.OneAccount.showDisputeDialog);
  const chelloAccountDetails = useSelector(
    (state) => state.OneAccount.chelloAccountDetails,
  );

  const {
    amount = '',
    date = '',
    description = '',
    type = '',
    transactionid: transactionId = '',
    network = '',
    networkCode = '',
    date: txnDate = '',
  } = useFetchSelectedTransaction();

  const {
    accNbr,
    posnId: positionId = '',
    accNickName,
    accNm,
    accId = '',
  } = getDynamicLineOfCreditsAccountDetails(chelloAccountDetails);

  const account = getAccountName({
    bankNm: '',
    accNickName,
    accNm,
  });

  const maskLastFourDigitAccNbr = maskAccountNumber(accNbr);
  const nameAndNumber = `${account} ${maskLastFourDigitAccNbr}`;

  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
    reset,
  } = useForm({
    mode: 'onChange',
    resolver: yupResolver(disputeValidationSchema),
  });

  const handleClose = () => {
    dispatch(showDisputeDialog(false));
  };

  // TODO If upload progress is required after discussion

  const handleChange = (fileList) => {
    setError('');
    if (files.length + fileList.length <= 3) {
      setFiles((prevState) => [...prevState, ...fileList]);
    } else {
      setError(MAX_FILE_ERR_MSG || null);
    }
  };

  useEffect(() => {
    const upload = () => {
      setUploadPercentage(100);
    };
    files
      .filter((item) => !item.isUpdated)
      .forEach((file, i) => {
        const fileObj = file;
        fileObj.isUpdated = true;
        setTimeout(upload, 1000);
      });
  }, [files]);

  const handleTypeError = () => {
    setError(UPLOAD_FILE_TYPE_ERR_MSG);
  };

  const handleSizeError = () => {
    setError(UPLOAD_FILE_EXCEED_ERR_MSG);
  };

  const getDisputeSuccess = (params) => {
    if (params) {
      dispatch(showDisputeConfirmationDialog(true));
    }
  };

  const handleAPIFailure = useHandleApiFailure();

  const formattedDocuments = async (fileList) => {
    const documents = [];
    for await (const file of files) {
      const response = await readFileDataAsBase64(file);

      documents.push({
        fileContentType: file.type,
        fileContent: response,
        fileName: file.name,
      });
    }

    return documents;
  };

  const submitHandler = async (data) => {
    const dataobj = data;

    dataobj.uploadedfile = files;
    const documents = await formattedDocuments(files);

    dispatch(showDisputeDialog(false));
    dispatch(
      postDisputeAction({
        apiPayload: {
          disputeType: networkCode,
          disputeAmt: +amount,
          disputeReason: dataobj?.disputeReason || '',
          trnId: transactionId,
          disputeDesc: dataobj?.disputeDescription || '',
          posId: positionId,
          startDate: txnDate,
          endDate: txnDate,
          accId,
          documents,
        },
        successCallback: getDisputeSuccess,
        failureCallback: handleAPIFailure,
      }),
    );
    resetData();
  };

  const resetData = () => {
    setError('');
    setFiles([]);
    handleClose();
    reset({ disputeReason: '', disputeDescription: '' });
  };

  const handleRemove = (name) => {
    setError('');
    const filesListCopy = [...files];
    const filterdArry = filesListCopy.filter((file) => name !== file.name);
    setFiles(filterdArry);
  };

  const refData = useSelector((state) => state.global.refData);
  const {
    CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES: chelloTransactionPaymentType,
  } = refData;

  useRefData(['CHELLO_ACCOUNT_TRANSACTION_PAYMENT_TYPES']);

  const prefix = decidePrefix(type, chelloTransactionPaymentType);

  return (
    <Dialog
      open={open}
      className={Classes.disputeChargeDialog}
      aria-labelledby="disputeChargeModal"
    >
      <IconButton
        aria-label="close"
        size="small"
        className={Classes.closeIcon}
        data-testid="dispute-close-icon"
        onClick={resetData}
      >
        <CustomIcon
          component={Close}
          className={Classes.closeIconSize}
          color="grey.800"
          inheritViewBox
        />
      </IconButton>
      <DialogTitle className={Classes.noPadding} id="disputeChargeModal">
        <Typography component="span" variant="h1" gutterBottom>
          {DISPUTE_TITLE}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box mt={2.5}>
          <Typography variant="h3" gutterBottom>
            {SELECTED_TRANSACTION}
          </Typography>
          <Box mt={2.5}>
            <TransactionInfo
              account={nameAndNumber}
              type={type}
              amount={amount}
              date={date}
              description={description}
              prefix={prefix}
            />
          </Box>
        </Box>
        <DisputeReason control={control} network={network} errors={errors} />
        <Box>
          <CustomTextArea
            label={DISPUTE_DESCRIPTION}
            optionalLabel={OPTIONAL}
            id="disputeDescription"
            name="disputeDescription"
            dataTestid="dispute-desctiption-text-box"
            control={control}
            classes={globalClasses.textArea}
            minRows={5}
            maxRows={6}
            maxLength={150}
          />
        </Box>

        <Box display="flex" flexDirection="column" gap={1.25}>
          <Typography variant="h3" component="h3" color="grey.800">
            {SUPPORTING_DOCUMENTS}
          </Typography>
          <Box className={Classes.uploadFileContainer}>
            <Box className={Classes.uploadFileArea}>
              <Box className={Classes.fileUploadBox}>
                <DisputeChargeFileUploader
                  handleChange={handleChange}
                  handleTypeError={handleTypeError}
                  handleSizeError={handleSizeError}
                />
              </Box>
              {error && (
                <Box color="red" my={1}>
                  {error}
                </Box>
              )}
            </Box>
            {files?.length > 0 && (
              <Box className={Classes.uploadFileList}>
                <UploadedDocumentsList
                  files={files}
                  uploadPercentage={uploadPercentage}
                  handleRemove={handleRemove}
                />
              </Box>
            )}
          </Box>
        </Box>
      </DialogContent>
      <DialogActions className={Classes.buttonWrapper}>
        <Button
          variant="contained"
          onClick={resetData}
          data-testid="one-account-dispute-cancel"
        >
          <Typography variant="buttonMedium" color="grey.800">
            {CANCEL}
          </Typography>
        </Button>
        <Button
          variant="contained"
          color="primary"
          disabled={!isValid}
          onClick={handleSubmit(submitHandler)}
          data-testid="oneaccount-dispute-submit"
        >
          {SUBMIT_CLAIM}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
export default DisputeChargeDialog;
