import {
  render,
  screen,
  waitFor,
  fireEvent,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Amplify } from 'aws-amplify';

import awsConfig from 'aws-exports';
import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

Amplify.configure(awsConfig);
const testDialogClose = () => {
  expect(screen.queryByText('Dispute a transaction')).not.toBeInTheDocument();
};

const renderDisputeDialog = async () => {
  const kebabMenu = await screen.findByTestId(
    'kebab-menu-chello-transaction-0-btn',
  );

  userEvent.click(kebabMenu);
  const menuItem = await screen.findByTestId(
    'kebab-menu-chello-transaction-0-item-1',
  );

  userEvent.click(menuItem);
  await screen.findByText('Dispute a transaction');
  expect(screen.getByText('Dispute a transaction')).toBeInTheDocument();
};

describe('Dispute Charge dialog', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });

  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });

  it('should render chello tab', async () => {
    userEvent.click(screen.getByTestId('one-account-chello-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });

  it('should render dispute dialog', renderDisputeDialog);

  it('should show submit button in disabled mode if no reason is selected', () => {
    expect(screen.getByTestId('oneaccount-dispute-submit')).toBeDisabled();
  });

  it('should be able to change dispute reason drop-down and provide additional details', async () => {
    let disputeReason = screen.getByTestId('disputeReason');

    fireEvent.change(disputeReason, {
      target: { value: '1' },
    });
    const textbox = await screen.findByTestId('dispute-desctiption-text-box');
    userEvent.type(textbox, 'overcharged');
    expect(textbox).toHaveValue('overcharged');

    const submitButton = await screen.findByTestId('oneaccount-dispute-submit');
    expect(submitButton).toBeEnabled();
  });

  it('should upload file and submit', async () => {
    let disputeReason = screen.getByTestId('disputeReason');
    fireEvent.change(disputeReason, {
      target: { value: '1' },
    });
    var fileel = document.getElementsByName('file')[0];

    fireEvent.drop(fileel, {
      dataTransfer: {
        files: [
          new File(['(⌐□_□)'], 'chucknorris.jpg', {
            type: 'image/jpg',
            name: 'chucknorris',
          }),
        ],
        clearData: jest.fn(),
      },
    });

    const submitButton = await screen.findByTestId('oneaccount-dispute-submit');
    userEvent.click(submitButton);
    await waitFor(() => {
      expect(
        screen.queryByText('Dispute a transaction'),
      ).not.toBeInTheDocument();
    });
  });
});

describe('test disputecharge close', () => {
  it('should render dispute dialog', renderDisputeDialog);

  it('should close dialog on click close icon', async () => {
    userEvent.click(screen.getByTestId('dispute-close-icon'));
    await waitFor(testDialogClose);
  });

  it('should render dispute dialog', renderDisputeDialog);

  it('should close dialog on cancel', async () => {
    userEvent.click(screen.getByTestId('one-account-dispute-cancel'));
    await waitFor(testDialogClose);
  });
});
