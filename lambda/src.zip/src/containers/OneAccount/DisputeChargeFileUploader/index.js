import DisputeChargeFileUploader from './DisputeChargeFileUploader';

export default DisputeChargeFileUploader;
