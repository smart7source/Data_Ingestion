import { Box, Typography, Button } from '@mui/material';
import { FileUploader } from 'react-drag-drop-files';
import PropTypes from 'prop-types';

import { fileTypes, defaultFnPropTypes } from 'utils';
import strings from 'localization/translation';
import { CustomIcon } from 'components';
import { ReactComponent as CloudUpload } from 'assets/svg/cloud-upload.svg';

import Classes from '../OneAccount.module.scss';

const {
  dragAndDrop: DRAG_AND_DROP,
  disputeOr: OR,
  disputeBrowseFiles: BROWSE_FILES,
} = strings;
const DisputeChargeFileUploader = (props) => {
  const { handleChange, handleTypeError, handleSizeError } = props;
  return (
    <FileUploader
      handleChange={handleChange}
      id="file"
      name="file"
      types={fileTypes}
      onTypeError={handleTypeError}
      onSizeError={handleSizeError}
      maxSize="5"
      data-testid="upload-dispute-document"
      multiple
    >
      <Box
        justifyContent="center"
        display="flex"
        flexDirection="column"
        gap="10px"
      >
        <Box justifyContent="center" textAlign="center">
          <CustomIcon
            component={CloudUpload}
            inheritViewBox
            color="grey.600"
            className={Classes.cloudIconSize}
          />
        </Box>
        <Box textAlign="center">
          <Typography variant="p1Paragraph" component="p" color="grey.600">
            {DRAG_AND_DROP}
          </Typography>
          <Typography variant="p1Paragraph" component="p" color="grey.600">
            {OR}
          </Typography>
        </Box>
        <Box justifyContent="center" textAlign="center">
          <Button
            variant="contained"
            color="primary"
            disableElevation
            fullWidth
          >
            {BROWSE_FILES}
          </Button>
        </Box>
      </Box>
    </FileUploader>
  );
};

export default DisputeChargeFileUploader;

DisputeChargeFileUploader.propTypes = {
  handleChange: PropTypes.instanceOf(Function),
  handleTypeError: PropTypes.instanceOf(Function),
  handleSizeError: PropTypes.instanceOf(Function),
};
DisputeChargeFileUploader.defaultProps = {
  handleChange: defaultFnPropTypes,
  handleTypeError: defaultFnPropTypes,
  handleSizeError: defaultFnPropTypes,
};
