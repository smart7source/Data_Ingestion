import {
  render,
  screen,
  act,
  waitFor,
  fireEvent,
} from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Auth } from 'aws-amplify';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';
import strings from 'localization/translation';

describe('Testing PayIt Total string', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });
  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });
  it('should have initial string', async () => {
    userEvent.click(screen.getByTestId('chello-pay-it-btn'));
    await screen.findByText(strings.total);
    const total = screen.getByText(strings.total);
    expect(total).toBeInTheDocument();
  });

  it('initial value should be $0', () => {
    const totalAmount = screen.getByTestId('pay-it-total-amount');
    expect(totalAmount).toHaveTextContent('$ 0.00');
  });

  it('should change value after adding amount to any of bank input', async () => {
    await act(async () => {
      const enterAmount = screen.getByTestId('bankAccounts-0-debitAmount');
      fireEvent.change(enterAmount, { target: { value: '1920' } });

      await waitFor(() =>
        expect(screen.getByText('$ 1,920.00')).toBeInTheDocument(),
      );
    });
  });
});
