import PayItTotal from './PayItTotal';

export default PayItTotal;
