import { Grid, Typography } from '@mui/material';
import { useState, useEffect, useMemo } from 'react';
import PropTypes from 'prop-types';
import { useWatch } from 'react-hook-form';

import strings from 'localization/translation';
import { convertToAmt } from 'utils';

import ViewTotal from '../ViewTotal';

const { total: TOTAL } = strings;

const PayItTotal = (props) => {
  const { control, setValue, minPayment, payFullBal } = props;
  const [toBePaidAmount, setToBePaidAmount] = useState(0);

  const [payItAmount, amount, bankAccounts] = useWatch({
    control,
    name: ['payItAmount', 'amount', 'bankAccounts'],
  });

  useEffect(() => {
    switch (payItAmount) {
      case 'enterAmount': {
        const tot = +convertToAmt({ value: amount });
        return setToBePaidAmount(tot);
      }
      case 'minimumPayment':
        return setToBePaidAmount(minPayment);
      case 'payFull':
        return setToBePaidAmount(payFullBal);
      default:
        return null;
    }
  }, [amount, minPayment, payFullBal, payItAmount]);

  let totalDebitAmount = 0;
  bankAccounts.forEach((bank) => {
    totalDebitAmount += +convertToAmt({ value: bank.debitAmount });
  });

  const totalCurrency = useMemo(() => {
    if (totalDebitAmount > 0) {
      const convertedTotal = convertToAmt({
        value: totalDebitAmount,
        prefix: '$ ',
        addSeparator: true,
      });
      setValue('payItTotal', convertedTotal, { shouldValidate: true });
      return convertedTotal;
    }
    return '$ 0.00';
  }, [setValue, totalDebitAmount]);

  return (
    <Grid container>
      <Grid item xs={6}>
        <Typography variant="h3" component="span" color="grey.800">
          {TOTAL}
        </Typography>
      </Grid>
      <Grid container item xs={6} justifyContent="space-between">
        <Grid item>
          <Typography
            variant="h3"
            component="span"
            color={
              totalDebitAmount === 0 || toBePaidAmount === totalDebitAmount
                ? 'grey.800'
                : 'error'
            }
            data-testid="pay-it-total-amount"
          >
            {totalCurrency}
          </Typography>
        </Grid>
        <ViewTotal total={totalDebitAmount} toBePaidAmount={toBePaidAmount} />
      </Grid>
    </Grid>
  );
};

export default PayItTotal;
PayItTotal.propTypes = {
  setValue: PropTypes.func.isRequired,
  control: PropTypes.instanceOf(Object).isRequired,
  minPayment: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  payFullBal: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
PayItTotal.defaultProps = {
  minPayment: '',
  payFullBal: '',
};
