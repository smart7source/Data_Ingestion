import { Box, Paper, Typography, Button } from '@mui/material';
import { memo, useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useForm } from 'react-hook-form';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

import strings from 'localization/translation';
import { useRefData } from 'hooks';
import Export from 'containers/MoveMoney/Export/Export';
import { exportLinkedAcctTransactions } from 'store/actions/OneAccountActions';
import globalClasses from 'style/globalStyle.module.scss';
import { formatDateToString, download, getContentType } from 'utils';
import { openExport } from 'store/actions/MoveMoneyActions';
import { NotificationContext } from 'contexts';

import Classes from '../OneAccount.module.scss';
import ChelloAccountTransactionFilter from '../ChelloAccountTransactionFilter';
import LinkedAccountTransactions from '../LinkedAccountTransactions';
import LinkedAccountSelector from '../LinkedAccountSelector';
import NickNameDialog from '../NickNameDialog';
import AddAccount from '../AddAccount';
import getFilteredAccounts from '../ChelloAccountTransactionFilter/getFilteredAccounts';

const {
  linkedAccounts: LINKED_ACCOUNTS,
  export: EXPORT,
  transactions: TRANSACTIONS,
  systemError: SYSTEM_ERROR,
} = strings;

const LinkedAccountDetails = () => {
  const contextValue = useContext(NotificationContext);
  const { setNotification } = contextValue;
  const dispatch = useDispatch();
  const { fromDate, toDate, searchType, searchText } = useSelector(
    (state) => state.OneAccount.transactionFilter,
  );

  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  const {
    control,
    watch,
    getValues,
    setValue,
    formState: { errors },
  } = useForm({
    mode: 'all',
    defaultValues: {
      formatDownload: 'CSV',
      selectedLinkedAccount: 'all',
    },
  });

  const selectedLinkedAccount = watch('selectedLinkedAccount');

  const downloadLinkedTransactions = (responseList) => {
    const contentType = getValues('formatDownload');
    if (responseList.length === 0) {
      setNotification([{ severity: 'error', message: SYSTEM_ERROR }]);
    } else if (responseList.length === 1) {
      const {
        value: { content = '' },
      } = responseList[0];
      download(
        `linked-account-transaction.${contentType.toLowerCase()}`,
        content,
        getContentType(contentType),
      );
    } else if (responseList.length > 1) {
      const zip = new JSZip();
      responseList.forEach((x) => {
        const {
          value: { content = '', posId = '' },
        } = x;

        zip.file(`${posId}.${contentType.toLowerCase()}`, content, {
          base64: true,
        });
      });

      zip.generateAsync({ type: 'blob' }).then((content) => {
        saveAs(content, 'linked-account-transactions.zip');
      });
    }
  };

  const handleExport = () => {
    const linkedPosIdDetails = [];
    const filterAccounts = getFilteredAccounts({
      account: 'external',
      selectedLinkedAccount,
      linkedAccounts,
      accountNumber: '',
      positionId: '',
    });

    const type = watch('formatDownload');
    filterAccounts.forEach((x) => {
      const { positionId } = x;
      linkedPosIdDetails.push({ posId: positionId });
    });

    dispatch(
      exportLinkedAcctTransactions({
        linkedPosIdDetails,
        fromDate: formatDateToString(fromDate, 'YYYY-MM-DD'),
        toDate: formatDateToString(toDate, 'YYYY-MM-DD'),
        searchType,
        searchText,
        type,
        successCallback: downloadLinkedTransactions,
        failureCallback: handleExportFailure,
      }),
    );

    dispatch(openExport(false));
  };

  const handleExportFailure = (errResponse) => {
    setNotification([{ severity: 'error', message: errResponse }]);
  };

  const handleClickOpen = () => {
    dispatch(openExport(true));
  };
  const refData = useSelector((state) => state.global.refData);
  const {
    LINKED_ACCOUNT_TRANSACTION_CATEGORY_TYPES:
      chelloTransactionFilterByCategory,
    LINKED_ACCOUNT_TRANSACTION_PAYMENT_TYPES: linkedAccTranasactionPaymentType,
  } = refData;
  useRefData([
    'LINKED_ACCOUNT_TRANSACTION_CATEGORY_TYPES',
    'LINKED_ACCOUNT_TRANSACTION_PAYMENT_TYPES',
  ]);

  return (
    <Paper className={Classes.chelloAccountDetails}>
      <Export
        handleSubmit={handleExport}
        getValues={getValues}
        setValue={setValue}
        control={control}
        errors={errors}
      />
      <Box className={Classes.chelloAccountDetailsWrapper}>
        <Box className={Classes.linkedAccountTitle}>
          <Typography
            data-testid="linked-tab-linked-account-heading"
            variant="h2"
            component="span"
            color="grey.900"
          >
            {LINKED_ACCOUNTS}
          </Typography>
          <Box display="flex" gap="15px" flexWrap="wrap">
            <Button
              className={globalClasses.ctaWithIcon}
              color="primary"
              onClick={handleClickOpen}
              data-testid="linked-export-button"
            >
              <Box component="span" className={Classes.exportButtonIcon} />
              {EXPORT}
            </Button>
            <AddAccount dataTestid="linked-add-account" />
          </Box>
        </Box>
        <LinkedAccountSelector control={control} />
        <ChelloAccountTransactionFilter
          chelloTransactionFilterByOptions={chelloTransactionFilterByCategory}
          account="external"
          selectedLinkedAccount={selectedLinkedAccount}
        />
        <Typography
          component="p"
          variant="h3"
          color="grey.900"
          className={Classes.linkedAccountTransaction}
        >
          {`${TRANSACTIONS} `}
          <Typography component="span" variant="p1">
            (0)
          </Typography>
        </Typography>
        <LinkedAccountTransactions
          control={control}
          paymentTypes={linkedAccTranasactionPaymentType}
        />
        <NickNameDialog />
      </Box>
    </Paper>
  );
};

export default memo(LinkedAccountDetails);
