import { render, screen, waitFor, cleanup } from '@testing-library/react/pure';
import { useState } from 'react';
import userEvent from '@testing-library/user-event';
import { usePlaidLink } from 'react-plaid-link';
import { rest } from 'msw';

import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';
import {
  renderWithProviderAndRouter,
  allAccountsMock,
  oneAccountTransactionsMock,
} from 'testHelpers';
import NotificationContext from 'contexts/NotificationContext';
import LinkedAccountDetails from '..';

jest.mock('react-plaid-link', () => ({
  ...jest.requireActual('react-plaid-link'),
  usePlaidLink: jest.fn(),
}));

jest.mock('file-saver', () => ({
  ...jest.requireActual('file-saver'),
  saveAs: jest.fn(),
}));

jest.mock('utils', () => ({
  ...jest.requireActual('utils'),
  download: jest.fn(),
}));

const TestElement = () => {
  const [notification, setNotification] = useState([]);
  return (
    <NotificationContext.Provider value={{ notification, setNotification }}>
      {!!notification.length && (
        <div data-testid="notification-msg">{notification[0].message}</div>
      )}
      <LinkedAccountDetails />
    </NotificationContext.Provider>
  );
};

describe('Test Linked Account Details Component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
    usePlaidLink.mockImplementation(() => ({ ready: false, open: jest.fn() }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<TestElement />, {
      wrapperProps: {
        initialState: {
          OneAccount: {
            chelloAccountDetails: allAccountsMock.body.chelloaccounts,
            selectedLinkedTransaction: {},
            linkedAccountDetails: [
              {
                posnId: '4hO_YImR1UiZFF----DF-77-',
                accId: '4hO_YImR1UiZFF----DF-77-',
                accNbr: '123443215678',
                accRtgNbr: '123456789',
                bankNm: 'Chase',
                avlbBalAmt: 10000,
                accType: 'checkings',
                accNickName: 'chello',
              },
              {
                posnId: '4hOVLwpsEIlbKV----1F-77-',
                accId: '4hOVLwpsEIlbKV----1F-77-',
                accNbr: '987667895432',
                accRtgNbr: '123456789',
                bankNm: 'Wells Fargo',
                avlbBalAmt: 500,
                accNm: 'Savings',
                accType: 'savings',
                accNickName: 'chello',
              },
            ],
            linkedAccountTransactions: {
              987667895432: oneAccountTransactionsMock.body.transactions,
              123443215678: oneAccountTransactionsMock.body.transactions,
            },
            linkedAccountsGrouped: allAccountsMock.body.linkedaccounts,
            showNickNameDialog: false,
            transactionFilter: {
              fromDate: '',
              toDate: '',
              searchType: '',
              searchTerm: '',
              nextPageKey: 'first',
            },
          },
          global: {
            refData: {},
            loader: [],
            isAuthenticated: false,
            floatingChatbot: {
              enableFloatingChatbot: false,
              maximize: true,
            },
          },
        },
      },
      render,
    });
    expect(
      screen.getByTestId('linked-tab-linked-account-heading'),
    ).toBeInTheDocument();
  });
  it('should able to see menu options on accounts', async () => {
    const kebabMenu = screen.getByTestId('kebab-menu-linked-account-0-btn');
    const unlink = screen.findByText('Unlink');
    await waitFor(() => {
      expect(kebabMenu).toBeInTheDocument();
    });
    userEvent.click(kebabMenu);
    await unlink;
  });
  it('should unlink account', async () => {
    userEvent.click(screen.getByText('Unlink'));
    expect(await screen.findByTestId('notification-msg')).toBeInTheDocument();
  });
  it('should show transactions of opened linked account', async () => {
    userEvent.click(screen.getByTestId('linked-account-accordion-0'));
    await screen.findByTestId('kebab-menu-external-0-transaction-0-btn');
    userEvent.click(
      screen.getByTestId('kebab-menu-external-0-transaction-0-btn'),
    );
    await screen.findByText('Details');
    userEvent.click(screen.getByText('Details'));
  });
  it('should open nickname dialog', async () => {
    const kebabMenu = screen.getByTestId('kebab-menu-linked-account-0-btn');
    const Nickname = screen.findByText('Rename');
    await waitFor(() => {
      expect(kebabMenu).toBeInTheDocument();
    });
    userEvent.click(kebabMenu);
    await Nickname;
    userEvent.click(screen.getByText('Rename'));
  });
  it('should change nickname', async () => {
    await waitFor(() => {
      expect(screen.getByText('Nickname for:')).toBeInTheDocument();
    });
    userEvent.clear(screen.getByTestId('linked-nick-name'));
    userEvent.type(screen.getByTestId('linked-nick-name'), 'mockname');
    await waitFor(() => {
      expect(screen.getByText('Save')).toBeEnabled();
    });
    userEvent.click(screen.getByText('Save'));
    await waitFor(() => {
      expect(screen.queryByTestId('spinner')).not.toBeInTheDocument();
    });
    await waitFor(() => {
      expect(screen.getByText('mockname')).toBeInTheDocument();
    });
  });

  it('should render add account buttons', () => {
    expect(screen.getByTestId('linked-add-account')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('linked-add-account'));
  });

  it('should be able to select accounts from dropdown', async () => {
    userEvent.click(screen.getByText('All accounts'));
    const options = await screen.findByText('mockname *5678');
    userEvent.click(options);
    expect(await screen.findByText('mockname')).toBeInTheDocument();
  });
  it('should render export button', async () => {
    expect(screen.getByTestId('linked-export-button')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('linked-export-button'));
    expect(await screen.findByTestId('export-title')).toBeInTheDocument();
    userEvent.click(screen.getByText('Download'));
    await waitFor(() => {
      expect(screen.queryByTestId('export-title')).not.toBeInTheDocument();
    });
  });

  it('should export one file without zip', async () => {
    server.use(
      rest.post(serviceUrl.getExportLinkedTransaction, (req, res, ctx) =>
        res(
          ctx.json({
            body: {
              errorResponseList: [],
              successResponseList: [
                {
                  id: '',
                  responseCode: 0,
                  responseMessage: '',
                  value: {
                    posId: '4iC2hgxk_WF3AV----XF-77-',
                    content:
                      'RGF0ZSxEZXNjcmlwdGlvbixjYXRlZ29yeSxBbW91bnQsQmFsYW5jZQ0KMjEtTWFyLTIyLE5ldGZsaXgsLSwkMjQuOTIsJA0KMjAtTWFyIFByaW50aW5nIENoYXJnZSAwMTIzNDVjaGVjay9hY2MuMDEyMzQ1Njc4OSBQcGQsLSwkNi4wMCwkDQo=',
                  },
                },
              ],
            },
          }),
        ),
      ),
    );
    expect(screen.getByTestId('linked-export-button')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('linked-export-button'));
    expect(await screen.findByTestId('export-title')).toBeInTheDocument();
    userEvent.click(screen.getByText('Download'));
    await waitFor(() => {
      expect(screen.queryByTestId('export-title')).not.toBeInTheDocument();
    });
  });
  it('should throw error message if responselist is empty', async () => {
    server.use(
      rest.post(serviceUrl.getExportLinkedTransaction, (req, res, ctx) =>
        res(
          ctx.json({
            body: {
              errorResponseList: [],
              successResponseList: [],
            },
          }),
        ),
      ),
    );
    expect(screen.getByTestId('linked-export-button')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('linked-export-button'));
    expect(await screen.findByTestId('export-title')).toBeInTheDocument();
    userEvent.click(screen.getByText('Download'));
    await waitFor(() => {
      expect(screen.queryByTestId('export-title')).not.toBeInTheDocument();
    });
  });
  it('should throw error message if responselist is empty', async () => {
    server.use(
      rest.post(serviceUrl.getExportLinkedTransaction, (req, res, ctx) =>
        res.networkError('Server down'),
      ),
    );
    expect(screen.getByTestId('linked-export-button')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('linked-export-button'));
    expect(await screen.findByTestId('export-title')).toBeInTheDocument();
    userEvent.click(screen.getByText('Download'));
    await waitFor(() => {
      expect(screen.queryByTestId('export-title')).not.toBeInTheDocument();
    });
  });
});
