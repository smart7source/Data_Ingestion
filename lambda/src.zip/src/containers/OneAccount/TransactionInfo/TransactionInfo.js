import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import NumberFormat from 'react-number-format';

import strings from 'localization/translation';
import { useFetchUser } from 'hooks';
import { isValidDate } from 'utils';

import Classes from '../OneAccount.module.scss';

const {
  user: USER,
  account: ACCOUNT,
  type: TYPE,
  amount: AMOUNT,
  date: DATE,
  description: DESC,
  serviceTicketId: SERVICE_TICKET,
} = strings;

const TransactionInfo = (props) => {
  const { account, type, amount, date, description, serviceTicket, prefix } =
    props;
  const { user: userData = '' } = useFetchUser();
  const { username: userName = '' } = userData || '';

  const formattedDate = isValidDate(date)
    ? new Date(date).toLocaleDateString('en', {
        month: 'short',
        year: 'numeric',
        day: '2-digit',
      })
    : date;

  return (
    <Box className={Classes.transactionInfoWrapper}>
      <Box className={Classes.transactionInfoGrid}>
        <Typography variant="h3">{USER}</Typography>
        {userData && userName && (
          <Typography variant="p1">{userName}</Typography>
        )}
        <Typography variant="h3">{ACCOUNT}</Typography>
        <Typography variant="p1">{account}</Typography>
        <Typography variant="h3">{TYPE}</Typography>
        <Typography variant="p1">{type}</Typography>
        <Typography variant="h3">{AMOUNT}</Typography>
        <Typography variant="p1">
          <NumberFormat
            value={amount}
            displayType="text"
            thousandSeparator
            prefix={prefix}
            decimalScale="2"
            fixedDecimalScale
          />
        </Typography>
        <Typography variant="h3">{DATE}</Typography>
        <Typography variant="p1">{formattedDate}</Typography>
        <Typography variant="h3">{DESC}</Typography>
        <Typography variant="p1">{description}</Typography>
        {serviceTicket && (
          <Typography variant="h3">{SERVICE_TICKET}</Typography>
        )}
        <Typography variant="p1">{serviceTicket}</Typography>
      </Box>
    </Box>
  );
};
export default TransactionInfo;
TransactionInfo.propTypes = {
  account: PropTypes.string,
  type: PropTypes.string,
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  date: PropTypes.string,
  description: PropTypes.string,
  serviceTicket: PropTypes.string,
  prefix: PropTypes.string,
};
TransactionInfo.defaultProps = {
  account: '',
  type: '',
  amount: '',
  date: '',
  description: '',
  serviceTicket: '',
  prefix: '$ ',
};
