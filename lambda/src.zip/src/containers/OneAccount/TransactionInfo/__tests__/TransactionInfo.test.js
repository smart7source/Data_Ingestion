import { render, screen, act, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { Amplify } from 'aws-amplify';

import awsConfig from 'aws-exports';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';
Amplify.configure(awsConfig);

describe('Transaction details dialog', () => {
  let menuItem;
  let kebabMenu;

  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });

  it('should render one account chello tab, on clicking the chello tab', async () => {
    userEvent.click(screen.getByTestId('one-account-chello-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });

  it('should show kebab menu for each transactions', async () => {
    kebabMenu = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-btn',
    );
    expect(kebabMenu).toBeInTheDocument;
  });

  it('should show menu options on clicking the kebab menu', async () => {
    userEvent.click(kebabMenu);
    menuItem = await screen.findByTestId(
      'kebab-menu-chello-transaction-0-item-0',
    );
    expect(menuItem).toBeInTheDocument;
  });

  it('should render the details dialog, on clicking the details option ', async () => {
    userEvent.click(menuItem);
    await screen.findByText('Have a closer look');
  });

  it('should show transaction details correctly. in the details dialog', () => {
    expect(screen.getByText('Account')).toBeInTheDocument();
  });
});
