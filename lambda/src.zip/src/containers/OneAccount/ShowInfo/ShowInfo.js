import { Box, Alert } from '@mui/material';
import { useState } from 'react';
import PropTypes from 'prop-types';
import Tooltip from '@mui/material/Tooltip';

import { CustomIcon } from 'components';
import { ReactComponent as Info } from 'assets/svg/info.svg';

import Classes from '../OneAccount.module.scss';

const ShowInfo = ({ content }) => {
  const [open, setOpen] = useState(false);

  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = () => {
    setOpen(true);
  };
  const TooltipContent = (
    <Alert
      icon={false}
      className={Classes.chelloInfoAlert}
      onClose={handleClose}
    >
      {content}
    </Alert>
  );

  return (
    <Tooltip
      open={open}
      onClose={handleClose}
      onOpen={handleOpen}
      title={TooltipContent}
      placement="right-start"
      classes={{ tooltip: Classes.infoHover }}
    >
      <Box className={Classes.infoWrapper} component="span">
        <CustomIcon
          component={Info}
          className={Classes.infoIcon}
          inheritViewBox
          data-testid="info-icon"
        />
      </Box>
    </Tooltip>
  );
};
export default ShowInfo;

ShowInfo.propTypes = {
  content: PropTypes.string,
};

ShowInfo.defaultProps = {
  content: '',
};
