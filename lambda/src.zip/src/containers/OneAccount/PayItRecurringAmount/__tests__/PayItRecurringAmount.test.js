import { render, screen, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import strings from 'localization/translation';
import ChelloAccountPayIt from 'containers/OneAccount/ChelloAccountPayIt';

describe('Testing PayIt Recurring Amount component', () => {
  let amountField;
  const initialState = {
    global: {
      refData: {
        TRANSFER_FREQUENCY: [
          { value: '1D', name: 'Daily' },
          { value: '7D', name: 'Weekly' },
          { value: '14D', name: 'Every two weeks' },
          { value: '1M', name: 'Monthly' },
          { value: '3M', name: 'Every three months' },
        ],
      },
      isAuthenticated: false,
      floatingChatbot: {
        enableFloatingChatbot: false,
        maximize: true,
      },
    },
    OneAccount: {
      chelloAccountDetails: {
        accounts: [
          {
            avlbToSpdtBalAmt: 5200,
            utlzBalAmt: 1300,
            pymtDueAmt: 120.04,
            pastPymtDueImitAmt: 120.04,
            otsgFeesAmt: 2.18,
            intRate: 6.55,
            accNm: 'Dynamic Line',
            posnNbr: '4hOVLwpsEIlbKV----1F-77-',
            accRtgNbr: '987651234',
            accNbr: '1234567890',
            apprvBalAmt: 15000,
          },
        ],
      },
      linkedAccountDetails: [
        {
          posnId: '4hO_YImR1UiZFF----DF-77-',
          accId: '4hO_YImR1UiZFF----DF-77-',
          accNbr: '123443215678',
          accRtgNbr: '123456789',
          bankNm: 'Chase',
          avlbBalAmt: 10000,
          accNm: 'Checking',
        },
        {
          posnId: '4hOVLwpsEIlbKV----1F-77-',
          accId: '4hOVLwpsEIlbKV----1F-77-',
          accNbr: '987667895432',
          accRtgNbr: '123456789',
          bankNm: 'Wells Fargo',
          avlbBalAmt: 500,
          accNm: 'Savings',
        },
      ],
    },
  };

  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });

  it('should render one account page', async () => {
    renderWithProviderAndRouter(<ChelloAccountPayIt />, {
      render,
      wrapperProps: {
        initialState,
      },
    });
    expect(screen.getByText('Pay loan')).toBeInTheDocument();
  });

  it('should render pay it recurring section', async () => {
    const recurring = screen.getByTestId('pay-it-recurring');
    userEvent.click(recurring);
    await waitFor(() => {
      expect(
        screen.getByText(strings.setAmountPerTransaction),
      ).toBeInTheDocument();
    });
  });

  it('should render input amount after click on radio btn', async () => {
    // TODO pass this test case
    const recurring = screen.getByTestId('pay-it-recurring');
    userEvent.click(recurring);
    const enterAmount = await screen.findByTestId(
      'pay-it-recurring-set-amount',
    );
    userEvent.click(enterAmount);
    amountField = await screen.findByTestId('amount-field');
    expect(amountField).toBeInTheDocument();
  });
});
