/* eslint-disable max-lines */
import { useEffect } from 'react';
import {
  Grid,
  Box,
  RadioGroup,
  Radio,
  FormControlLabel,
  FormControl,
  FormLabel,
  Typography,
} from '@mui/material';
import PropTypes from 'prop-types';
import { Controller, useWatch, useFormState } from 'react-hook-form';
import { useSelector } from 'react-redux';

import { NumberInput, DatePicker, CustomSelectBox } from 'components';
import strings from 'localization/translation';
import { setMaxDate, disableWeekends, defaultFnPropTypes } from 'utils';
import { useRefData } from 'hooks';
import globalClasses from 'style/globalStyle.module.scss';

const {
  setAmountPerTransaction: SET_AMOUNT,
  distributeTotalAmountIncludingInterestOverThePayment: PAY_TOTAL,
  endDate: END_DATE,
  frequency: FREQUENCY,
  enterAmt: ENTER_AMOUNT,
  duration: DURATION,
} = strings;

const PayItRecurringAmount = (props) => {
  const { control, resetField } = props;
  const active = useWatch({
    control,
    name: 'payItRecurringAmount',
  });

  const refData = useSelector((state) => state.global.refData);
  const { TRANSFER_FREQUENCY: recurringFrequencyList } = refData;
  useRefData(['TRANSFER_FREQUENCY']);

  const [payItRecurringAmount, paymentDuration] = useWatch({
    control,
    name: ['payItRecurringAmount', 'recurringType'],
  });

  const weeklyFrequency =
    recurringFrequencyList?.filter((x) => x.name === 'Weekly') || [];

  const { errors } = useFormState({
    control,
  });
  useEffect(() => {
    resetField('recurringAmount');
  }, [active, resetField]);
  useEffect(() => {
    if (paymentDuration === 'numberoftransaction') {
      resetField('endDate');
    }
    if (paymentDuration === 'end-date') {
      resetField('numberoftransaction');
    }
  }, [paymentDuration, resetField]);

  return (
    <Grid container>
      <Box>
        <Controller
          render={({ field }) => (
            <FormControl>
              <FormLabel>
                <Typography color="grey.800" variant="h3" component="span">
                  {ENTER_AMOUNT}
                </Typography>
              </FormLabel>
              <RadioGroup {...field} aria-label="position" name="position">
                <Grid container alignItems="center" mb={1}>
                  <Grid item xs={12}>
                    <FormControlLabel
                      value="setAmount"
                      classes={{
                        label: globalClasses.h3Headline,
                      }}
                      control={
                        <Radio
                          color="primary"
                          inputProps={{
                            'data-testid': 'pay-it-recurring-set-amount',
                          }}
                        />
                      }
                      label={SET_AMOUNT}
                    />
                  </Grid>
                  {payItRecurringAmount === 'setAmount' ? (
                    <Grid item xs={12}>
                      <NumberInput
                        id="recurringAmount"
                        name="recurringAmount"
                        placeHolder="$ 0.00"
                        dataTestId="amount-field"
                        margin="normal"
                        prefix="$ "
                        control={control}
                        error={!!errors.recurringAmount}
                        errorText={errors.recurringAmount?.message}
                        fixedDecimalScale
                      />
                    </Grid>
                  ) : null}
                </Grid>
                <Grid container alignItems="center" mb={1}>
                  <Grid item xs={12}>
                    <FormControlLabel
                      value="payTotal"
                      classes={{
                        label: globalClasses.p2Paragraph,
                      }}
                      control={<Radio color="primary" />}
                      label={
                        <Typography
                          color="grey.800"
                          variant="p1"
                          component="span"
                        >
                          {PAY_TOTAL}
                        </Typography>
                      }
                    />
                  </Grid>
                </Grid>
              </RadioGroup>
            </FormControl>
          )}
          name="payItRecurringAmount"
          id="payItRecurringAmount"
          control={control}
        />
      </Box>
      <Grid container>
        <Grid item xs={6} pr={1}>
          <CustomSelectBox
            dataTestid="frequencyBtn"
            label={
              <Typography color="grey.800" variant="h3" component="span">
                {FREQUENCY}
              </Typography>
            }
            hideSelect
            id="frequency"
            name="frequency"
            control={control}
            options={
              payItRecurringAmount === 'setAmount'
                ? recurringFrequencyList
                : weeklyFrequency
            }
            error={!!errors.frequency}
            errorText={errors.frequency?.message}
          />
        </Grid>
        <Grid item xs={6} pl={1}>
          <Typography color="grey.800" variant="h3" component="span">
            {DURATION}
          </Typography>
          <Box>
            <Controller
              render={({ field }) => (
                <FormControl>
                  <RadioGroup
                    {...field}
                    defaultValue="null"
                    aria-label="position2"
                    name="position2"
                    data-testid="amount-radio"
                    row
                  >
                    <Grid container alignItems="center" mb={1}>
                      <Grid item xs={12}>
                        <FormControlLabel
                          value="numberoftransaction"
                          classes={{
                            label: globalClasses.p1Paragraph,
                          }}
                          control={
                            <Radio
                              color="primary"
                              inputProps={{
                                'data-testid': 'numberoftransaction',
                              }}
                            />
                          }
                          label="Number of Transaction"
                        />
                      </Grid>

                      {paymentDuration === 'numberoftransaction' ? (
                        <Grid item xs={12}>
                          <NumberInput
                            id="numberoftransaction"
                            name="numberoftransaction"
                            dataTestId="transaction-field"
                            margin="normal"
                            control={control}
                            error={!!errors.numberoftransaction}
                            errorText={errors.numberoftransaction?.message}
                          />
                        </Grid>
                      ) : null}
                    </Grid>
                    <Grid container alignItems="center" mb={1}>
                      <Grid item xs={12} sm={7} lg={7}>
                        <FormControlLabel
                          value="end-date"
                          classes={{
                            label: globalClasses.p1Paragraph,
                          }}
                          control={
                            <Radio
                              color="primary"
                              inputProps={{
                                'data-testid': 'end-date-radio',
                              }}
                            />
                          }
                          label={END_DATE}
                        />
                      </Grid>
                      {paymentDuration === 'end-date' ? (
                        <DatePicker
                          placeHolder={strings.selectDateFormat}
                          id="endDate"
                          name="endDate"
                          dataTestid="end-date-val"
                          control={control}
                          minDateValue={new Date()}
                          maxDateValue={setMaxDate(new Date(), 364)}
                          shouldDisableDate={disableWeekends}
                          error={!!errors.endDate}
                          errorText={errors.endDate?.message}
                        />
                      ) : null}
                    </Grid>
                  </RadioGroup>
                </FormControl>
              )}
              name="recurringType"
              id="recurringType"
              control={control}
            />
          </Box>
        </Grid>
      </Grid>
      {/* TODO : To be included once finxact amount calculation and respective API is ready  
      {frequency &&
        recurringType &&
        (numberoftransaction || endDate) &&
        !errors?.endDate &&
        !errors.numberoftransaction && (
          <Grid container>
            <Grid item xs={12}>
              <Box display="flex" alignItems="center" gap={1.25}>
                <PayItRecurringAmountCalculation
                  control={control}
                  payFullBal={payFullBal}
                />
                <ShowInfo content={RECURRING_INFO_CONTENT} />
              </Box>
            </Grid>
          </Grid>
        )} */}
    </Grid>
  );
};

export default PayItRecurringAmount;
PayItRecurringAmount.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  payFullBal: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  resetField: PropTypes.instanceOf(Function),
};
PayItRecurringAmount.defaultProps = {
  payFullBal: '',
  resetField: defaultFnPropTypes,
};
