import PayItRecurringAmount from './PayItRecurringAmount';

export default PayItRecurringAmount;
