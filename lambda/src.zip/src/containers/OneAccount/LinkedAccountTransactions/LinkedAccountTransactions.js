import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import { useWatch } from 'react-hook-form';
import { useMemo, memo, useContext } from 'react';
import PropTypes from 'prop-types';

import strings from 'localization/translation';
import { linkedAccountOptions, getNewMenuOptions } from 'utils';
import { useDisableUnlink, useHandleApiFailure } from 'hooks';
import {
  setSelectedAccount,
  showNickNameDialog,
  unlinkAccount,
  fetchAllAccDetails,
} from 'store/actions/OneAccountActions';
import { NotificationContext } from 'contexts';

import LinkedAccountEachTransaction from '../LinkedAccountEachTransaction';
import NoLinkedAccounts from '../NoLinkedAccounts';
import Classes from '../OneAccount.module.scss';

const {
  date: DATE,
  description: DESCRIPTION,
  categoryText: CATEGORY,
  amount: AMOUNT,
  noLinkedAccounts: NO_LINKED_ACCOUNTS,
} = strings;

const LinkedAccountTransactions = (props) => {
  const contextValue = useContext(NotificationContext);
  const { setNotification } = contextValue;
  const { control, paymentTypes } = props;
  const dispatch = useDispatch();

  const selectedLinkedAccount = useWatch({
    control,
    name: 'selectedLinkedAccount',
  });

  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  const filteredLinkedAccounts = useMemo(
    () =>
      linkedAccounts.filter(
        (item) =>
          item.accNbr === selectedLinkedAccount ||
          selectedLinkedAccount === 'all',
      ),
    [linkedAccounts, selectedLinkedAccount],
  );
  const handleAPIFailure = useHandleApiFailure();

  const onMainMenuOptionClick = (account) => (option) => {
    const { posnId = '' } = account;
    dispatch(setSelectedAccount(account));
    if (option.name === 'Nickname' || option.name === 'Rename') {
      dispatch(showNickNameDialog(true));
    }
    if (option.name === 'Unlink') {
      if (linkedAccounts.length > 1) {
        dispatch(
          unlinkAccount({
            id: posnId,
            successCallback: handleApiSuccess,
            failureCallback: handleAPIFailure,
          }),
        );
      }
    }
  };

  const handleApiSuccess = (response) => {
    dispatch(fetchAllAccDetails({ failureCallback: handleAPIFailure }));
    setNotification([
      {
        severity: 'success',
        message: 'Account unlinked successfully',
      },
    ]);
  };

  const menuOptionsUpdated = useDisableUnlink(linkedAccountOptions);

  const accountsLength = filteredLinkedAccounts.length;
  const defaultOpen = accountsLength <= 1;

  return (
    <>
      <Box className={Classes.chelloTransactionsTableWrapper}>
        <Table
          className={Classes.chelloTransactionsTable}
          aria-label="Linked account transactions"
        >
          <TableHead>
            <TableRow>
              <TableCell>
                <Typography color="grey.800" component="span">
                  {DATE}
                </Typography>
              </TableCell>
              <TableCell
                className={Classes.transactionsTableHeadDescriptionCell}
              >
                <Typography color="grey.800" component="span">
                  {DESCRIPTION}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography color="grey.800" component="span">
                  {CATEGORY}
                </Typography>
              </TableCell>
              <TableCell className={Classes.transactionsTableHeadAmountCell}>
                <Typography color="grey.800" component="span">
                  {AMOUNT}
                </Typography>
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody className={Classes.transactionsPadding}>
            {!accountsLength ? (
              <NoLinkedAccounts
                colSpan={4}
                message={NO_LINKED_ACCOUNTS}
                addAccountBtn
              />
            ) : (
              filteredLinkedAccounts.map((eachAcc, index) => {
                const { accNm, accNickName } = eachAcc;
                const newOptions = getNewMenuOptions(
                  menuOptionsUpdated,
                  accNm,
                  accNickName,
                );
                return (
                  <LinkedAccountEachTransaction
                    mainKebabOptions={newOptions}
                    onMainMenuOptionClick={onMainMenuOptionClick(eachAcc)}
                    index={index}
                    key={`${eachAcc.accNbr}-${index}`}
                    defaultOpen={defaultOpen}
                    accountDetails={eachAcc}
                    selectedLinkedAccount={selectedLinkedAccount}
                    paymentTypes={paymentTypes}
                  />
                );
              })
            )}
          </TableBody>
        </Table>
      </Box>
    </>
  );
};

export default memo(LinkedAccountTransactions);

LinkedAccountTransactions.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
  paymentTypes: PropTypes.instanceOf(Array),
};
LinkedAccountTransactions.defaultProps = {
  paymentTypes: [],
};
