import { Grid, Typography } from '@mui/material';
import PropTypes from 'prop-types';
import { useWatch } from 'react-hook-form';
import { useSelector } from 'react-redux';

import { CustomInput, LinkedAccountSimpleSelector } from 'components';
import strings from 'localization/translation';

import Classes from '../OneAccount.module.scss';

const { boostNote: NOTE, optional: OPTIONAL } = strings;

const PayItRecurringBank = (props) => {
  const { control } = props;

  const payItNote = useWatch({
    control,
    name: 'payItNote',
  });

  const linkedAccounts = useSelector(
    (state) => state.OneAccount.linkedAccountDetails,
  );

  return (
    <Grid container>
      <Grid item xs={12}>
        <LinkedAccountSimpleSelector
          bankAccounts={linkedAccounts}
          control={control}
          name="selectedLinkedAccount"
        />
      </Grid>
      <Grid item xs={12} mt={2.5} className={Classes.boostNoteWrapper}>
        <CustomInput
          label={
            <Typography component="span" variant="h3">
              {NOTE}
            </Typography>
          }
          optionalLabel={
            <Typography variant="p2" component="p" color="grey.600">
              {OPTIONAL}
            </Typography>
          }
          id="payItNote"
          name="payItNote"
          control={control}
          dataTestid="payit-note"
          inputProps={{ maxLength: 150 }}
        />
        <Typography variant="p2" component="p" color="grey.600" align="right">
          {`${payItNote.length}/150`}
        </Typography>
      </Grid>
    </Grid>
  );
};

export default PayItRecurringBank;
PayItRecurringBank.propTypes = {
  control: PropTypes.instanceOf(Object).isRequired,
};
