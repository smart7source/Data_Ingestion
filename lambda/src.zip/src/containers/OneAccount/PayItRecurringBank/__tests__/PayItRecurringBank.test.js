import { render, screen, act, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';

import { renderWithProviderAndRouter, allAccountsMock } from 'testHelpers';
import { payitSchema } from 'containers/OneAccount/oneAccountSchema';

import PayItRecurringBank from '../index';

function TestElement() {
  const { control } = useForm({
    mode: 'all',
    resolver: yupResolver(payitSchema(50, 1000)),
    defaultValues: {
      amount: '',
      payItNote: '',
      payItAmount: 'enterAmount',
      payItRecurringAmount: 'payTotal',
      frequency: '1M',
      payItTotal: '$ 0.00',
      bankAccounts: [],
      selectedLinkedAccount: '',
    },
  });

  return <PayItRecurringBank control={control} />;
}

describe('Testing payit recurring bank component', () => {
  it('Should render the payit recurring bank component', () => {
    renderWithProviderAndRouter(<TestElement />, {
      wrapperProps: {
        initialState: {
          OneAccount: {
            linkedAccountDetails: [
              {
                posnId: '4hO_YImR1UiZFF----DF-77-',
                accId: '4hO_YImR1UiZFF----DF-77-',
                accNbr: '123443215678',
                accRtgNbr: '123456789',
                bankNm: 'Chase',
                avlbBalAmt: 10000,
                accType: 'checkings',
                accNickName: 'chello',
              },
              {
                posnId: '4hOVLwpsEIlbKV----1F-77-',
                accId: '4hOVLwpsEIlbKV----1F-77-',
                accNbr: '987667895432',
                accRtgNbr: '123456789',
                bankNm: 'Wells Fargo',
                avlbBalAmt: 500,
                accNm: 'Savings',
                accType: 'savings',
                accNickName: 'chello',
              },
            ],
            linkedAccountsGrouped: allAccountsMock.body.linkedaccounts,
          },
        },
      },
      render,
    });
  });

  it('should render linked bank accounts in  select dropdown', async () => {
    const selectDropdown = screen.getByLabelText('Select bank account');
    expect(selectDropdown).toBeInTheDocument();

    userEvent.click(selectDropdown);
    expect(await screen.findByText('chello *5678')).toBeInTheDocument();

    userEvent.click(screen.getByText('chello *5678'));
    await screen.findByText('chello *5678');
  });
});
