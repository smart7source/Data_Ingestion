import PayItRecurringBank from './PayItRecurringBank';

export default PayItRecurringBank;
