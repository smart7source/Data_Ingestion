import { Box, IconButton, Alert } from '@mui/material';
import PropTypes from 'prop-types';
import Tooltip from '@mui/material/Tooltip';

import strings from 'localization/translation';
import { ReactComponent as CheckmarkCircle } from 'assets/svg/checkmark-circle.svg';
import { ReactComponent as AlertCircle } from 'assets/svg/alert-circle.svg';
import { CustomIcon } from 'components';

import Classes from '../OneAccount.module.scss';

const { matchTotal: MATCH_TOTAL } = strings;

const TooltipContent = (
  <Alert icon={false} className={Classes.chelloInfoAlert}>
    {MATCH_TOTAL}
  </Alert>
);

const ViewTotal = (props) => {
  const { total, toBePaidAmount } = props;
  if (total > 0) {
    if (toBePaidAmount === total) {
      return (
        <CustomIcon
          component={CheckmarkCircle}
          color="success"
          inheritViewBox
          className={Classes.iconSize}
        />
      );
    }
    return (
      <>
        <Box className={Classes.infoWrapper}>
          <Tooltip
            title={TooltipContent}
            classes={{ tooltip: Classes.infoHover }}
          >
            <IconButton className={Classes.noPadding}>
              <CustomIcon
                component={AlertCircle}
                color="error"
                inheritViewBox
                className={Classes.iconSize}
              />
            </IconButton>
          </Tooltip>
        </Box>
      </>
    );
  }
  return null;
};
export default ViewTotal;
ViewTotal.propTypes = {
  total: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  toBePaidAmount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
ViewTotal.defaultProps = {
  total: '',
  toBePaidAmount: '',
};
