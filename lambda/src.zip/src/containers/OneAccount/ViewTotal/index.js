import ViewTotal from './ViewTotal';

export default ViewTotal;
