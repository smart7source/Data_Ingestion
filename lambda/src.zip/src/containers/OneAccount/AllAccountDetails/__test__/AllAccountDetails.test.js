import { render, screen, act, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';
import { usePlaidLink } from 'react-plaid-link';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

jest.mock('react-plaid-link', () => ({
  ...jest.requireActual('react-plaid-link'),
  usePlaidLink: jest.fn(),
}));

describe('Testing AllAccountDetails component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
    usePlaidLink.mockImplementation(() => ({ ready: false, open: jest.fn() }));
  });
  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });

    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should render all tab', async () => {
    userEvent.click(screen.getByTestId('one-account-all-tab'));
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
  });

  it('should display details of chello account and overview of linked account by default', async () => {
    await screen.findByText('$ 5,200.00');
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
    expect(screen.getByText('Linked accounts')).toBeInTheDocument();
  });

  it('should replace  with pay loan section when pay it button in chello account section is clicked', () => {
    userEvent.click(screen.getByTestId('chello-pay-it-btn'));
    expect(screen.getByText('Pay loan')).toBeInTheDocument();
  });

  it('should able to add external account by clicking add account button', async () => {
    const mockOpen = jest.fn();
    usePlaidLink.mockImplementation(() => ({ ready: true, open: mockOpen }));
    userEvent.click(screen.getByTestId('back_icon'));
    expect(await screen.findByText('Boost line of credit')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('chello-add-account-btn'));
    await waitFor(() => {
      expect(mockOpen).toHaveBeenCalled();
    });
  });
});
