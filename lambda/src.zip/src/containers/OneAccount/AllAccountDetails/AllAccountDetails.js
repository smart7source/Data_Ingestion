import { Box, Paper, Typography } from '@mui/material';
import { useSelector } from 'react-redux';

import strings from 'localization/translation';

import Classes from '../OneAccount.module.scss';
import ChelloAccountPayIt from '../ChelloAccountPayIt';
import ChelloAccountInfo from '../ChelloAccountInfo';
import LinkedAccountTable from '../LinkedAccountTable';
import NickNameDialog from '../NickNameDialog';
import AddAccount from '../AddAccount';
import AccountBoost from '../AccountBoost';

const { linkedAccounts: LINKED_ACCOUNTS } = strings;

const AllAccountDetails = () => {
  const showPayIt = useSelector((state) => state.OneAccount.openPayIt);
  const showBoostNow = useSelector((state) => state.OneAccount.openBoostNow);

  return (
    <Box className={Classes.chelloAccountDetails}>
      <Box className={Classes.allAccountsWrapper}>
        {!showPayIt && !showBoostNow ? (
          <>
            <Paper className={Classes.paperBorder}>
              <Box className={Classes.chelloAccountDetailsWrapper}>
                <ChelloAccountInfo />
              </Box>
            </Paper>
            <Paper className={Classes.paperBorder}>
              <Box className={Classes.chelloAccountDetailsWrapper}>
                <Box className={Classes.linkedAccountTitle}>
                  <Typography
                    data-testid="all-tab-linked-account-heading"
                    variant="h2"
                  >
                    {LINKED_ACCOUNTS}
                  </Typography>

                  <AddAccount dataTestid="chello-add-account-btn" />
                </Box>
                <Box className={Classes.chelloTransactionsTableWrapper}>
                  <LinkedAccountTable />
                  <NickNameDialog />
                </Box>
              </Box>
            </Paper>
          </>
        ) : (
          <Paper className={Classes.paperBorder}>
            <Box className={Classes.chelloAccountDetailsWrapper}>
              {showPayIt && <ChelloAccountPayIt />}
              {showBoostNow && <AccountBoost />}
            </Box>
          </Paper>
        )}
      </Box>
    </Box>
  );
};
export default AllAccountDetails;
