import AllAccountDetails from './AllAccountDetails';

export default AllAccountDetails;
