import { Box, Typography } from '@mui/material';
import PropTypes from 'prop-types';

import strings from 'localization/translation';

import Classes from '../OneAccount.module.scss';

const {
  amount: AMOUNT,
  date: DATE,
  frequency: FREQUENCY,
  duration: DURATION,
  boostNote: NOTE,
  endsOn: ENDS_ON,
} = strings;

const ReviewTransferInfo = (props) => {
  const { amount, date, frequency, duration, note } = props;

  return (
    <Box className={Classes.transactionInfoWrapper}>
      <Box className={Classes.transactionInfoGrid}>
        <Typography variant="h3">{AMOUNT}</Typography>
        <Typography variant="p1">{amount}</Typography>
        <Typography variant="h3">{DATE}</Typography>
        <Typography variant="p1">{date}</Typography>
        <Typography variant="h3">{FREQUENCY}</Typography>
        <Typography variant="p1">{frequency}</Typography>
        {duration !== '' && (
          <>
            <Typography variant="h3">{DURATION}</Typography>

            <Typography variant="p1">
              {ENDS_ON} {duration}
            </Typography>
          </>
        )}
        <Typography variant="h3">{NOTE}</Typography>
        <Typography variant="p1">{note}</Typography>
      </Box>
    </Box>
  );
};
export default ReviewTransferInfo;
ReviewTransferInfo.propTypes = {
  amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  date: PropTypes.string,
  frequency: PropTypes.string,
  duration: PropTypes.string,
  note: PropTypes.string,
};
ReviewTransferInfo.defaultProps = {
  amount: '',
  date: '',
  frequency: '',
  duration: '',
  note: '',
};
