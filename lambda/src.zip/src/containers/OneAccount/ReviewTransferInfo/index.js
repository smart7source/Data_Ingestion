import ReviewTransferInfo from './ReviewTransferInfo';

export default ReviewTransferInfo;
