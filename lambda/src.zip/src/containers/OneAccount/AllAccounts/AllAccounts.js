import { Box } from '@mui/material';
import { useState, useEffect, memo } from 'react';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';

import { fetchAllAccDetails } from 'store/actions/OneAccountActions';
import { Notification } from 'components';
import { NotificationContext } from 'contexts';
import { useHandleApiFailure } from 'hooks';

import ChelloInsights from '../ChelloInsights';
import AllAccountDetails from '../AllAccountDetails';
import Classes from '../OneAccount.module.scss';

const AllAccounts = ({ handleTabChange }) => {
  const dispatch = useDispatch();

  const [notification, setNotification] = useState([]);

  const handleAPIFailure = useHandleApiFailure(setNotification);

  useEffect(() => {
    dispatch(fetchAllAccDetails({ failureCallback: handleAPIFailure }));
  }, [dispatch, handleAPIFailure]);

  return (
    <NotificationContext.Provider value={{ notification, setNotification }}>
      {!!notification.length && (
        <Box mb={2.5}>
          <Notification errors={notification} needFocus />
        </Box>
      )}
      <Box className={Classes.chellAccounts}>
        <AllAccountDetails handleTabChange={handleTabChange} />
        <ChelloInsights />
      </Box>
    </NotificationContext.Provider>
  );
};

export default memo(AllAccounts);
AllAccounts.propTypes = {
  handleTabChange: PropTypes.func.isRequired,
};
