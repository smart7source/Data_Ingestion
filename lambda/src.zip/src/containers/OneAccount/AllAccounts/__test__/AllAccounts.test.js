import { render, screen, waitFor, cleanup } from '@testing-library/react/pure';
import { rest } from 'msw';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';
import server from 'apiMocks/server';
import serviceUrl from 'api/UrlHelper';

describe('Testing AllAccounts tab component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });
  afterAll(cleanup);

  it('should render the one account page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });

    expect(screen.getByTestId('one-account-heading')).toBeInTheDocument();
  });

  it('should display details of chello account, overview of linked account and chello insights', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
    expect(
      screen.getByTestId('all-tab-linked-account-heading'),
    ).toBeInTheDocument();
    expect(screen.getByText('Chello Insights')).toBeInTheDocument();
  });

  it('should show notification when add account api fails', async () => {
    server.use(
      rest.post(serviceUrl.getPlaidToken, (req, res, ctx) =>
        res(ctx.status(500)),
      ),
    );
    userEvent.click(screen.getByTestId('chello-add-account-btn'));

    expect(await screen.findByTestId('notification-alert')).toBeInTheDocument();
  });
});
