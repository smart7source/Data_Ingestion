import ChelloAccountOtherInfo from './ChelloAccountOtherInfo';

export default ChelloAccountOtherInfo;
