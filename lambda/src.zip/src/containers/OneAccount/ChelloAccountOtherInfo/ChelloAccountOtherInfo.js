import NumberFormat from 'react-number-format';
import { Button, Typography, useMediaQuery, Box, Divider } from '@mui/material';
import { useState } from 'react';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';

import { openPayIt, openBoostNow } from 'store/actions/OneAccountActions';
import strings from 'localization/translation';
import { CustomIcon } from 'components';
import { ReactComponent as ChevronUp } from 'assets/svg/chevron-up.svg';
import { ReactComponent as ChevronDown } from 'assets/svg/chevron-down.svg';

import Classes from '../OneAccount.module.scss';
import ShowAccountDetails from '../ShowAccountDetails';

const {
  paymentDue: PAYMENT_DUE,
  pastPaymentDue: PAST_PAYMENT_DUE,
  outstandingBalance: OUTSTANDING_BALANCE,
  interestRate: INTEREST_RATE,
  payIt: PAY_IT,
  boostNow: BOOST_NOW,
  accountDetails: ACCOUNT_DETAILS,
} = strings;

const ChelloAccountOtherInfo = (props) => {
  const { paymentDue, pastPaymentDue, outstandingBalance, interestRate } =
    props;
  const dispatch = useDispatch();
  const belowSm = useMediaQuery((theme) => theme.breakpoints.down('sm'));

  const [showDetails, setShowDetails] = useState(false);

  const handleOpenPayIt = () => {
    dispatch(openBoostNow(false));
    dispatch(openPayIt(true));
  };

  const showAccDetails = () => {
    setShowDetails(!showDetails);
  };

  const onBoostClick = () => {
    dispatch(openPayIt(false));
    dispatch(openBoostNow(true));
  };

  return (
    <>
      <Box
        display="flex"
        flexDirection="column"
        gap={2.5}
        mt={2.5}
        flexWrap="wrap"
      >
        <Box
          display="flex"
          alignItems="flex-end"
          justify-content="space-between"
          gap={!belowSm && 2.5}
          flexWrap="wrap"
        >
          <Box
            display="flex"
            flexDirection="column"
            gap={0.625}
            flexGrow="1"
            flexWrap="wrap"
          >
            <Box className={Classes.detailsWrapper}>
              <Typography variant="p1SemiBold" component="p" color="grey.800">
                {PAYMENT_DUE}
              </Typography>
              <Typography variant="p1" component="p">
                <NumberFormat
                  value={paymentDue || 0}
                  displayType="text"
                  thousandSeparator
                  prefix="$ "
                  decimalScale="2"
                  fixedDecimalScale
                />
              </Typography>
            </Box>
            <Box className={Classes.detailsWrapper}>
              <Typography variant="p1SemiBold" component="p" color="grey.800">
                {PAST_PAYMENT_DUE}
              </Typography>
              <Typography variant="p1" component="p">
                <NumberFormat
                  value={pastPaymentDue || 0}
                  displayType="text"
                  thousandSeparator
                  prefix="$ "
                  decimalScale="2"
                  fixedDecimalScale
                />
              </Typography>
            </Box>
          </Box>
          {!belowSm && <Divider orientation="vertical" flexItem />}
          <Box
            display="flex"
            flexDirection="column"
            flexGrow="1"
            flexWrap="wrap"
            gap={0.625}
            mt={belowSm && 0.625}
          >
            <Box className={Classes.detailsWrapper}>
              <Typography variant="p1SemiBold" component="p" color="grey.800">
                {OUTSTANDING_BALANCE}
              </Typography>
              <Typography variant="p1" component="p">
                <NumberFormat
                  value={outstandingBalance || 0}
                  displayType="text"
                  thousandSeparator
                  prefix="$ "
                  decimalScale="2"
                  fixedDecimalScale
                />
              </Typography>
            </Box>
            <Box className={Classes.detailsWrapper}>
              <Typography variant="p1SemiBold" component="p" color="grey.800">
                {INTEREST_RATE}
              </Typography>
              <Typography variant="p1" component="p">
                <NumberFormat
                  value={interestRate || 0}
                  displayType="text"
                  thousandSeparator
                  suffix="%"
                  decimalScale="2"
                  fixedDecimalScale
                />
              </Typography>
            </Box>
          </Box>
        </Box>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="flex-end"
          flexWrap="wrap-reverse"
          gap={1.25}
        >
          <Box display={belowSm && 'flex'} flex={belowSm && '1 0 100%'}>
            <Button
              variant="contained"
              disableElevation
              className={Classes.paybutton}
              onClick={showAccDetails}
              data-testid="chello-account-details-btn"
            >
              <Typography
                variant="buttonSmall"
                component="span"
                color="grey.800"
              >
                {ACCOUNT_DETAILS}
              </Typography>
              {showDetails ? (
                <CustomIcon
                  component={ChevronUp}
                  inheritViewBox
                  color="grey.800"
                  className={Classes.chevronIconSize}
                />
              ) : (
                <CustomIcon
                  component={ChevronDown}
                  inheritViewBox
                  color="grey.800"
                  className={Classes.chevronIconSize}
                />
              )}
            </Button>
          </Box>
          <Box
            display="flex"
            flex={belowSm && '1 0 100%'}
            gap={1.25}
            flexWrap="wrap"
          >
            <Button
              variant="contained"
              disableElevation
              className={Classes.paybutton}
              onClick={handleOpenPayIt}
              data-testid="chello-pay-it-btn"
            >
              <Typography
                component="span"
                variant="buttonSmall"
                color="grey.800"
              >
                {PAY_IT}
              </Typography>
            </Button>

            <Button
              variant="contained"
              color="primary"
              disableElevation
              className={Classes.paybutton}
              onClick={onBoostClick}
              data-testid="chello-boost-now-btn"
            >
              <Typography
                component="span"
                variant="buttonSmall"
                color="grey.100"
              >
                {BOOST_NOW}
              </Typography>
            </Button>
          </Box>
        </Box>
      </Box>

      {showDetails && (
        <>
          <Divider className={Classes.divider} />
          <ShowAccountDetails />
          <Divider className={Classes.divider} />
        </>
      )}
    </>
  );
};

export default ChelloAccountOtherInfo;

ChelloAccountOtherInfo.propTypes = {
  paymentDue: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  pastPaymentDue: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  outstandingBalance: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  interestRate: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
};

ChelloAccountOtherInfo.defaultProps = {
  paymentDue: '',
  pastPaymentDue: '',
  outstandingBalance: '',
  interestRate: '',
};
