import { render, screen, act, waitFor } from '@testing-library/react/pure';
import userEvent from '@testing-library/user-event';

import { renderWithProviderAndRouter } from 'testHelpers';
import Accounts from 'containers/OneAccount/Accounts';

describe('Testing ChelloAccount Other Info component', () => {
  beforeEach(() => {
    const observe = jest.fn();
    const disconnect = jest.fn();
    window.IntersectionObserver = jest.fn(() => ({
      observe,
      disconnect,
    }));
  });
  it('should render accounts overview page', async () => {
    renderWithProviderAndRouter(<Accounts />, { render });
    expect(screen.getByText('Boost line of credit')).toBeInTheDocument();
  });
  it('should render the default All account tab', async () => {
    await waitFor(
      () => expect(screen.queryByTestId('spinner')).not.toBeInTheDocument,
    );
    await screen.findByText('$ 5,200.00');
  });
  it('should expand account details when clicked', async () => {
    userEvent.click(screen.getByTestId('chello-account-details-btn'));
    expect(await screen.findByText('Routing number')).toBeInTheDocument();
  });
  it('should open pay it view when clicked', async () => {
    userEvent.click(screen.getByTestId('chello-pay-it-btn'));
    expect(await screen.findByText('Pay loan')).toBeInTheDocument();
  });
});
