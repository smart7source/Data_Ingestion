import LinkedEachAccount from './LinkedEachAccount';

export default LinkedEachAccount;
