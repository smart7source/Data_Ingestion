import { Box, TableCell, TableRow, Typography } from '@mui/material';
import NumberFormat from 'react-number-format';
import PropTypes from 'prop-types';

import { KebabMenu } from 'components';
import { defaultFnPropTypes, maskAccountNumber } from 'utils';
import serviceUrl from 'api/UrlHelper';

import Classes from '../OneAccount.module.scss';

const LinkedEachAccount = (props) => {
  const { logo, accName, accNo, balance, options, index, onMenuOptionClick } =
    props;
  const id = `external-account-${index}`;
  const ariaLabel = `external account ${index}`;

  const logoUrl = `${serviceUrl.externalBankImagesPath}${logo}`;

  const maskLastFourDigitAccNbr = maskAccountNumber(accNo);

  return (
    <TableRow>
      <TableCell className={Classes.accountTableDetailCell}>
        <Box display="flex" gap="10px">
          <img className={Classes.accountLogo} src={logoUrl} alt="" />

          <Box>
            <Typography component="p" variant="p1SemiBold" color="#464646">
              {accName}
            </Typography>
            <Typography
              component="p"
              variant="p2"
              color="#6B7280"
              className={Classes.maskDigit}
            >
              {maskLastFourDigitAccNbr}
            </Typography>
          </Box>
        </Box>
      </TableCell>
      <TableCell className={Classes.transactionsTableAmountCell}>
        <Box className={Classes.transactionsTableMoreOptionsWrapper}>
          <Typography component="span" variant="p2" color="#374151">
            <NumberFormat
              value={balance}
              displayType="text"
              thousandSeparator
              prefix="$ "
              decimalScale="2"
              fixedDecimalScale
            />
          </Typography>
          <KebabMenu
            options={options}
            ariaLabel={ariaLabel}
            id={id}
            onMenuOptionClick={onMenuOptionClick}
          />
        </Box>
      </TableCell>
    </TableRow>
  );
};

LinkedEachAccount.propTypes = {
  logo: PropTypes.string,
  accName: PropTypes.string,
  accNo: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  balance: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  options: PropTypes.instanceOf(Object),
  index: PropTypes.number,
  onMenuOptionClick: PropTypes.func,
};

LinkedEachAccount.defaultProps = {
  logo: '',
  accName: '',
  accNo: '',
  balance: 0,
  options: [],
  index: 0,
  onMenuOptionClick: defaultFnPropTypes,
};

export default LinkedEachAccount;
