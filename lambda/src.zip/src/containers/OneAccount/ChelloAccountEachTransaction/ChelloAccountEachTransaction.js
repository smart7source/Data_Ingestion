import { Box, TableCell, TableRow, Typography } from '@mui/material';
import NumberFormat from 'react-number-format';
import PropTypes from 'prop-types';

import { KebabMenu } from 'components';
import { defaultFnPropTypes, decidePrefix } from 'utils';

import Classes from '../OneAccount.module.scss';

const ChelloAccountEachTransaction = (props) => {
  const {
    date,
    descriptionOne,
    descriptionTwo,
    amount,
    balance,
    typeOrCategory,
    index,
    lastElRef,
    kebabOptions,
    onMenuOptionClick,
    account,
    paymentTypes,
  } = props;

  const id = `${account}-transaction-${index}`;
  const ariaLabel = `${account} account transaction ${index + 1}`;

  const elRef = lastElRef ? { ref: lastElRef } : {};

  return (
    <TableRow {...elRef}>
      <TableCell>
        <Typography
          variant="body2"
          color="grey.800"
          className={Classes.rightAlign}
        >
          {date}
        </Typography>
      </TableCell>
      <TableCell className={Classes.transactionsTableDescriptionCell}>
        <Typography color="grey.800" component="div" variant="p1SemiBold">
          {descriptionOne}
        </Typography>
        <Typography color="grey.800" component="div" variant="p3">
          {descriptionTwo}
        </Typography>
      </TableCell>
      <TableCell>
        <Typography>{typeOrCategory}</Typography>
      </TableCell>
      <TableCell className={Classes.transactionsTableAmountCell}>
        <Box
          component=""
          className={Classes.transactionsTableMoreOptionsWrapper}
        >
          <Box component="span" className={Classes.transactionsTableAmount}>
            <Typography color="grey.800" component="span" variant="p1SemiBold">
              <NumberFormat
                value={amount}
                displayType="text"
                thousandSeparator
                prefix={decidePrefix(typeOrCategory, paymentTypes)}
                decimalScale="2"
                fixedDecimalScale
              />
            </Typography>
            <Typography color="grey.800" component="span" variant="p3">
              <NumberFormat
                value={balance}
                displayType="text"
                thousandSeparator
                prefix="$ "
                decimalScale="2"
                fixedDecimalScale
              />
            </Typography>
          </Box>
          <KebabMenu
            options={kebabOptions}
            ariaLabel={ariaLabel}
            id={id}
            onMenuOptionClick={onMenuOptionClick}
          />
        </Box>
      </TableCell>
    </TableRow>
  );
};

export default ChelloAccountEachTransaction;

ChelloAccountEachTransaction.propTypes = {
  date: PropTypes.string,
  descriptionOne: PropTypes.string,
  descriptionTwo: PropTypes.string,
  amount: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  balance: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  typeOrCategory: PropTypes.string,
  index: PropTypes.number,
  lastElRef: PropTypes.instanceOf(Object),
  onMenuOptionClick: PropTypes.func,
  kebabOptions: PropTypes.instanceOf(Object),
  account: PropTypes.string,
  paymentTypes: PropTypes.instanceOf(Array),
};

ChelloAccountEachTransaction.defaultProps = {
  date: '',
  descriptionOne: '',
  descriptionTwo: '',
  amount: 0,
  balance: 0,
  typeOrCategory: '',
  index: 0,
  lastElRef: null,
  onMenuOptionClick: defaultFnPropTypes,
  kebabOptions: [],
  account: 'chello',
  paymentTypes: [],
};
