import ChelloAccountEachTransaction from './ChelloAccountEachTransaction';

export default ChelloAccountEachTransaction;
